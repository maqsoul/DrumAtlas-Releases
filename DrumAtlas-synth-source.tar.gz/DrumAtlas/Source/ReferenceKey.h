#pragma once
#include <juce_core/juce_core.h>
#include <array>
#include <algorithm>
#include <cmath>
namespace atlas {
struct ReferenceKey {int tonic=-1,alternative=-1;bool minor=false,alternativeMinor=false;double confidence=0,fit=0;int frames=0;};
struct ReferenceChord {double start=0,end=0,fit=0,margin=0;int root=-1;bool minor=false;};
inline juce::String keyName(int tonic,bool minor){static const char*names[]{"C","C#","D","D#","E","F","F#","G","G#","A","A#","B"};return tonic<0||tonic>11?"Unknown":juce::String(names[tonic])+(minor?" minor":" major");}
// Simple diatonic templates with tonic/dominant emphasis; scores are heuristic, not probabilities.
inline ReferenceKey estimateReferenceKey(const std::array<double,12>&chroma,int frames){
 ReferenceKey result;result.frames=frames;if(frames<8)return result;
 double sum=0;for(auto v:chroma){if(!std::isfinite(v)||v<0)return result;sum+=v;}if(sum<=1e-9)return result;
 double contrast=0;for(auto v:chroma)contrast+=std::pow(v/sum-1./12,2);if(contrast<.003)return result;
 int distinct=0;for(auto v:chroma)if(v/sum>.035)++distinct;if(distinct<4)return result;
 const double profiles[2][12]={{5,0,2,0,3,2,0,4,0,2,0,2},{5,0,2,3,0,2,0,4,2,0,2,0}};
 struct Candidate{int tonic;bool minor;double fit;};std::array<Candidate,24>candidates;int index=0;
 for(int mode=0;mode<2;++mode)for(int tonic=0;tonic<12;++tonic){double dot=0,a=0,b=0;for(int i=0;i<12;++i){double x=chroma[size_t(i)]/sum-1./12,y=profiles[mode][(i-tonic+12)%12]/20.-1./12;dot+=x*y;a+=x*x;b+=y*y;}candidates[size_t(index++)]={tonic,mode==1,a*b>1e-12?dot/std::sqrt(a*b):0};}
 std::stable_sort(candidates.begin(),candidates.end(),[](auto&a,auto&b){return a.fit>b.fit;});auto best=candidates[0],next=candidates[1];if(best.fit<.45)return result;
 result.tonic=best.tonic;result.minor=best.minor;result.fit=best.fit;result.alternative=next.tonic;result.alternativeMinor=next.minor;result.confidence=juce::jlimit(0.,1.,(best.fit-next.fit)*3);return result;
}
}
