#pragma once
#include <juce_core/juce_core.h>

namespace atlas::hosting {
inline void invalidateProbeContext(juce::var&plugins,const juce::String&reason){
 if(!plugins.isArray())return;
 for(auto&row:*plugins.getArray())if(row.isObject()&&row.hasProperty("probe_status")){
  auto*object=row.getDynamicObject();object->setProperty("probe_status","retest_required");object->setProperty("probe_retest_reason",reason);
  for(auto field:{"parameter_count","latency_samples","tail_seconds"})object->removeProperty(field);
  object->setProperty("editor_capability","unknown_until_probe");
 }
}
inline void markChangedProbeEvidence(const juce::var&previous,const juce::String&path,const juce::String&fingerprint,juce::var&plugins){
 if(int(previous["schema"])!=2||previous["status"].toString()!="scanned"||path.isEmpty()||fingerprint.isEmpty()||previous["path"].toString()!=path||previous["fingerprint"].toString()==fingerprint||previous["fingerprint"].toString().isEmpty()||!previous["plugins"].isArray()||!plugins.isArray())return;
 for(auto&row:*plugins.getArray()){if(!row.isObject()||row.hasProperty("probe_status")||row["uid"].toString().isEmpty()||row["class_id"].toString().isEmpty())continue;
  for(const auto&old:*previous["plugins"].getArray())if(old["uid"]==row["uid"]&&old["class_id"]==row["class_id"]&&old.hasProperty("probe_status")){row.getDynamicObject()->setProperty("probe_status","retest_required");break;}
 }
}
// A failed load is evidence about the selected class, not every sibling.
inline bool markFailedProbe(juce::var& plugins, const juce::String& uid,
                            const juce::String& error) {
    if (!plugins.isArray() || uid.isEmpty()) return false;
    juce::var* selected = nullptr;
    int matches = 0;
    for (auto& row : *plugins.getArray())
        if (row.isObject() && row["uid"].toString() == uid) { selected = &row; ++matches; }
    if (matches != 1) return false;
    auto* object = selected->getDynamicObject();
    for (auto field : {"parameter_count", "latency_samples", "tail_seconds"}) object->removeProperty(field);
    object->setProperty("editor_capability", "unknown_until_probe");
    object->setProperty("probe_status", "failed");
    object->setProperty("probe_error", error.substring(0, 2048));
    return true;
}
// A module may expose multiple classes. Re-scanning metadata or probing one
// class must not discard evidence for its unchanged siblings.
inline void retainUnchangedProbeEvidence(const juce::var& previous,
                                         const juce::String& path,
                                         const juce::String& fingerprint,
                                         juce::var& plugins) {
    if (int(previous["schema"]) != 2 || previous["status"].toString() != "scanned"
        || path.isEmpty() || fingerprint.isEmpty()
        || previous["path"].toString() != path
        || previous["fingerprint"].toString() != fingerprint
        || !previous["plugins"].isArray() || !plugins.isArray()) return;
    for (auto& current : *plugins.getArray()) {
        if (!current.isObject() || current.hasProperty("probe_status")
            || current["uid"].toString().isEmpty()
            || current["class_id"].toString().isEmpty()) continue;
        const juce::var* match = nullptr;
        int matches = 0;
        for (const auto& old : *previous["plugins"].getArray()) {
            if (old["uid"] != current["uid"] || old["class_id"] != current["class_id"]
                || old["version"] != current["version"]
                || old["architecture"] != current["architecture"]) continue;
            match = &old;
            ++matches;
        }
        if (matches != 1) continue;
        auto status = (*match)["probe_status"].toString();
        if (status != "audio_verified" && status != "silent" && status != "failed" && status != "retest_required") continue;
        for (auto field : {"probe_status", "editor_capability", "parameter_count",
                           "latency_samples", "tail_seconds", "probe_error", "probe_retest_reason",
                           "probe_worker_fingerprint", "probe_environment", "probe_checked_at"})
            if (match->hasProperty(field))
                current.getDynamicObject()->setProperty(field, (*match)[field].clone());
    }
}
}
