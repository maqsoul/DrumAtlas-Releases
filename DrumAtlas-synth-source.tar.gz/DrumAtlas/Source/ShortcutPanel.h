#pragma once
#include "EmberTheme.h"
#include <map>

namespace atlas {
struct ShortcutAction {juce::String id,label,defaultKey;};
class ShortcutBindings {
public:
 std::vector<ShortcutAction> actions;
 std::map<juce::String,juce::String> keys;
 void defaults(){keys.clear();for(auto&a:actions)keys[a.id]=a.defaultKey;}
 void load(const juce::File&file){
  defaults();const auto json=juce::JSON::parse(file);
  for(auto&a:actions)if(json.hasProperty(a.id)){
   auto value=json.getProperty(a.id,{}).toString();auto key=juce::KeyPress::createFromDescription(value);
   keys[a.id]=key.isValid()?key.getTextDescription():juce::String();
  }
  // Preserve explicit assignments when old defaults would conflict with them.
  for(auto&a:actions)if(json.hasProperty(a.id)&&keys[a.id].isNotEmpty())
   for(auto&b:actions)if(a.id!=b.id&&!json.hasProperty(b.id)&&same(keys[a.id],keys[b.id]))keys[b.id]={};
 }
 static bool same(const juce::String&a,const juce::String&b){return a.isNotEmpty()&&b.isNotEmpty()&&juce::KeyPress::createFromDescription(a)==juce::KeyPress::createFromDescription(b);}
 juce::String conflict(const juce::String&id,const juce::KeyPress&key)const{
  for(auto&a:actions){auto it=keys.find(a.id);if(a.id!=id&&it!=keys.end()&&same(it->second,key.getTextDescription()))return a.label;}return {};
 }
 juce::String actionFor(const juce::KeyPress&key)const{
  for(auto&a:actions){auto it=keys.find(a.id);if(it!=keys.end()&&same(it->second,key.getTextDescription()))return a.id;}return {};
 }
 juce::Result save(const juce::File&file)const{
  auto made=file.getParentDirectory().createDirectory();if(made.failed())return made;
  juce::DynamicObject::Ptr obj=new juce::DynamicObject();for(auto&[id,key]:keys)obj->setProperty(id,key);
  juce::TemporaryFile temp(file);
  if(!temp.getFile().replaceWithText(juce::JSON::toString(juce::var(obj.get())))||!temp.overwriteTargetFileWithTemporary())return juce::Result::fail("Cannot save keyboard shortcuts");
  return juce::Result::ok();
 }
};

class ShortcutPanel:public juce::Component,private juce::ListBoxModel {
public:
 ShortcutBindings draft;std::function<juce::Result(const ShortcutBindings&)>onSave;std::function<void()>onClose;
 juce::TextButton assign,clear,reset,save,cancel;juce::ListBox list;
 explicit ShortcutPanel(const ShortcutBindings&bindings,const juce::String&language):draft(bindings),ru(language=="ru"),list("Shortcuts",this){
  setComponentID("shortcut-panel");setWantsKeyboardFocus(true);
  for(auto*c:std::initializer_list<juce::Component*>{&title,&hint,&message,&list,&assign,&clear,&reset,&save,&cancel})addAndMakeVisible(c);
  title.setText(s("Горячие клавиши","Keyboard shortcuts"),juce::dontSendNotification);title.setFont(ember::headingFont(22));title.setColour(juce::Label::textColourId,ember::text);
  hint.setText(s("Выберите функцию → Назначить → нажмите сочетание. Работает при фокусе внутри DrumAtlas; ввод текста не затрагивается.","Select a function > Assign > press a shortcut. Active while DrumAtlas has focus; typing in text fields is unaffected."),juce::dontSendNotification);hint.setFont(ember::font(13));hint.setColour(juce::Label::textColourId,ember::muted);
  message.setFont(ember::font(13));message.setColour(juce::Label::textColourId,ember::orange);
  assign.setButtonText(s("Назначить","Assign"));clear.setButtonText(s("Очистить","Clear"));reset.setButtonText(s("Сбросить все","Reset all"));save.setButtonText(s("Сохранить","Save"));cancel.setButtonText(s("Отмена","Cancel"));
  assign.setComponentID("shortcut-assign");clear.setComponentID("shortcut-clear");reset.setComponentID("shortcut-reset");save.setComponentID("shortcut-save");cancel.setComponentID("shortcut-cancel");
  list.setColour(juce::ListBox::backgroundColourId,ember::panel);list.setRowHeight(46);list.updateContent();list.selectRow(0);
  for(auto*b:{&assign,&clear,&reset,&save,&cancel})b->setWantsKeyboardFocus(false);
  assign.onClick=[this]{capture=true;message.setText(s("Нажмите сочетание… Esc — отменить назначение.","Press a shortcut… Esc cancels capture."),juce::dontSendNotification);grabKeyboardFocus();};
  clear.onClick=[this]{capture=false;if(auto*a=selected())draft.keys[a->id]={};message.setText({},juce::dontSendNotification);list.repaint();};
  reset.onClick=[this]{capture=false;draft.defaults();message.setText(s("Стандартные назначения восстановлены. Нажмите «Сохранить».","Defaults restored. Press Save to apply."),juce::dontSendNotification);list.repaint();};
  save.onClick=[this]{capture=false;auto result=onSave?onSave(draft):juce::Result::fail("No shortcut storage");if(result.failed())message.setText(result.getErrorMessage(),juce::dontSendNotification);else if(onClose)onClose();};
  cancel.onClick=[this]{if(onClose)onClose();};
 }
 ~ShortcutPanel()override{list.setModel(nullptr);}
 bool keyPressed(const juce::KeyPress&key)override{
  if(key.getKeyCode()==juce::KeyPress::escapeKey){if(capture){capture=false;message.setText({},juce::dontSendNotification);}else if(onClose)onClose();return true;}
  if(!capture)return false;
  if(!key.isValid())return true;
  if(key.getKeyCode()==juce::KeyPress::tabKey||(key.getModifiers().isAltDown()&&key.getKeyCode()==juce::KeyPress::F4Key)){
   message.setText(s("Это сочетание зарезервировано для управления окнами.","This shortcut is reserved for window navigation."),juce::dontSendNotification);return true;
  }
  if(auto*a=selected()){
   auto conflict=draft.conflict(a->id,key);if(conflict.isNotEmpty()){message.setText(s("Уже назначено: ","Already assigned: ")+conflict,juce::dontSendNotification);return true;}
   draft.keys[a->id]=key.getTextDescription();capture=false;message.setText(s("Назначено: ","Assigned: ")+key.getTextDescription()+s(". Нажмите «Сохранить».",". Press Save to apply."),juce::dontSendNotification);list.repaint();
  }return true;
 }
 void paint(juce::Graphics&g)override{g.fillAll(ember::background);ember::card(g,getLocalBounds().toFloat().reduced(.5f),16);}
 void resized()override{
  int w=getWidth(),h=getHeight();title.setBounds(16,12,w-32,32);hint.setBounds(16,48,w-32,56);
  const bool compact=h<440;hint.setVisible(!compact);const int listTop=compact?50:110;
  list.setBounds(16,listTop,w-32,std::max(32,h-listTop-160));message.setBounds(16,h-154,w-32,54);
  int third=(w-48)/3;assign.setBounds(16,h-92,third,34);clear.setBounds(24+third,h-92,third,34);reset.setBounds(32+third*2,h-92,third,34);
  int half=(w-40)/2;cancel.setBounds(16,h-46,half,32);save.setBounds(24+half,h-46,half,32);
 }
private:
 bool ru=false,capture=false;juce::Label title,hint,message;
 juce::String s(const char*rus,const char*eng)const{return juce::String::fromUTF8(ru?rus:eng);}
 const ShortcutAction*selected()const{int row=list.getSelectedRow();return juce::isPositiveAndBelow(row,int(draft.actions.size()))?&draft.actions[size_t(row)]:nullptr;}
 int getNumRows()override{return int(draft.actions.size());}
 void selectedRowsChanged(int)override{capture=false;message.setText({},juce::dontSendNotification);}
 void paintListBoxItem(int row,juce::Graphics&g,int w,int h,bool selected)override{
  if(!juce::isPositiveAndBelow(row,int(draft.actions.size())))return;
  if(selected){g.setColour(ember::orange.withAlpha(.15f));g.fillRect(0,0,w,h);}
  const auto&a=draft.actions[size_t(row)];g.setFont(ember::font(14));g.setColour(ember::text);
  const int keyWidth=std::min(200,w/2);g.drawFittedText(a.label,12,3,w-keyWidth-24,h-6,juce::Justification::centredLeft,2);
  g.setColour(ember::orange);const auto key=draft.keys[a.id];g.drawFittedText(key.isEmpty()?s("Не назначено","Unassigned"):key,w-keyWidth,3,keyWidth-12,h-6,juce::Justification::centredRight,1);
 }
};
}
