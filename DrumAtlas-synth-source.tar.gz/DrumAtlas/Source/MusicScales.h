#pragma once
#include <juce_core/juce_core.h>
#include <array>

namespace atlas::music {
struct DiatonicScale {const char* id;std::array<int,7> degrees;};
inline constexpr std::array<DiatonicScale,7> diatonicScales{{
    {"minor",{0,2,3,5,7,8,10}},
    {"major",{0,2,4,5,7,9,11}},
    {"dorian",{0,2,3,5,7,9,10}},
    {"phrygian",{0,1,3,5,7,8,10}},
    {"lydian",{0,2,4,6,7,9,11}},
    {"mixolydian",{0,2,4,5,7,9,10}},
    {"locrian",{0,1,3,5,6,8,10}}
}};
inline const std::array<int,7>* scaleDegrees(const juce::String& id) {
    for(const auto& scale:diatonicScales)if(id==scale.id)return &scale.degrees;
    return nullptr;
}
}
