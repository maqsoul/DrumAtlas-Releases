#include "AudioEdit.h"
#include "../ThirdParty/signalsmith/signalsmith-stretch.h"
namespace atlas {
juce::File renderAudioEdit(const EditRequest&job,const juce::File&directory,const std::function<bool()>&cancel){
 if(!std::isfinite(job.semitones)||std::abs(job.semitones)>24)throw std::runtime_error("Pitch range is -24 to +24 semitones");
 const bool tempo=job.targetBpm>0;const double ratio=tempo?job.sourceBpm/job.targetBpm:1;
 if(!std::isfinite(ratio)||ratio<.25||ratio>4|| (tempo&&(job.sourceBpm<20||job.targetBpm<20)))throw std::runtime_error("Enter the original BPM; tempo ratio must be 0.25 to 4");
 juce::AudioFormatManager fm;registerFormats(fm);std::unique_ptr<juce::AudioFormatReader>reader(fm.createReaderFor(ioFile(job.source)));
 if(!reader||reader->lengthInSamples<=0||reader->numChannels<1||reader->numChannels>2)throw std::runtime_error("Select a readable mono or stereo audio file");
 if(ioFile(directory).createDirectory().failed())throw std::runtime_error("Cannot create rendered audio folder");
 const auto name=job.source.getFileNameWithoutExtension()+"_pitch"+juce::String(job.semitones,1)+(tempo?"_"+juce::String(job.targetBpm,1)+"bpm":"");
 const auto output=directory.getChildFile(juce::File::createLegalFileName(name).substring(0,120)+"_"+juce::Uuid().toString()+".wav");
 juce::TemporaryFile temporary(ioFile(output));
 std::unique_ptr<juce::OutputStream>stream=temporary.getFile().createOutputStream();juce::WavAudioFormat wav;
 auto writer=wav.createWriterFor(stream,juce::AudioFormatWriterOptions{}.withSampleRate(reader->sampleRate).withNumChannels(reader->numChannels).withBitsPerSample(32).withSampleFormat(juce::AudioFormatWriterOptions::SampleFormat::floatingPoint));
 if(!writer)throw std::runtime_error("Cannot write rendered audio");
 const int channels=int(reader->numChannels);const juce::int64 frames=reader->lengthInSamples,target=juce::int64(std::llround(frames*ratio));
 auto check=[&]{if(cancel&&cancel())throw std::runtime_error("Render cancelled");};
 auto read=[&](juce::AudioBuffer<float>&b,juce::int64 start,int count){b.clear();const int valid=int(std::max<juce::int64>(0,std::min<juce::int64>(count,frames-start)));if(valid&&!reader->read(&b,0,valid,start,true,true))throw std::runtime_error("Cannot read source audio");};
 if(job.semitones==0&&ratio==1){juce::AudioBuffer<float>block(channels,8192);for(juce::int64 pos=0;pos<frames;pos+=8192){check();int n=int(std::min<juce::int64>(8192,frames-pos));read(block,pos,n);if(!writer->writeFromAudioSampleBuffer(block,0,n))throw std::runtime_error("Audio write failed");}}
 else{
  signalsmith::stretch::SignalsmithStretch<float>stretch;stretch.presetDefault(channels,reader->sampleRate);stretch.setTransposeSemitones(job.semitones);
  const int lead=stretch.inputLatency(),delay=stretch.outputLatency();juce::AudioBuffer<float>seed(channels,lead);read(seed,0,lead);stretch.seek(seed.getArrayOfReadPointers(),lead,1/ratio);
  juce::AudioBuffer<float>in(channels,1024),out(channels,std::max(8192,delay));juce::int64 produced=0,written=0;
  auto consume=[&](int n){int begin=int(std::max<juce::int64>(0,delay-produced));int end=int(std::min<juce::int64>(n,delay+target-produced));if(end>begin){if(!writer->writeFromAudioSampleBuffer(out,begin,end-begin))throw std::runtime_error("Audio write failed");written+=end-begin;}produced+=n;};
  for(juce::int64 pos=0;pos<frames;){check();int n=int(std::min<juce::int64>(1024,frames-pos));int m=int(std::llround((pos+n)*ratio)-std::llround(pos*ratio));read(in,pos+lead,n);stretch.process(in.getArrayOfReadPointers(),n,out.getArrayOfWritePointers(),m);consume(m);pos+=n;}
  stretch.flush(out.getArrayOfWritePointers(),delay);consume(delay);if(written!=target)throw std::runtime_error("Unexpected rendered audio length");
 }
 check();writer.reset();if(!temporary.overwriteTargetFileWithTemporary())throw std::runtime_error("Cannot finish rendered audio");return output;
}
AudioEditService::AudioEditService():juce::Thread("DrumAtlas render"){startThread();}
AudioEditService::~AudioEditService(){signalThreadShouldExit();notify();stopThread(-1);}
void AudioEditService::render(EditRequest request){std::lock_guard<std::mutex>g(mutex);auto path=request.source.getFullPathName();completed.erase(std::remove_if(completed.begin(),completed.end(),[&](const EditState&r){return r.source==path;}),completed.end());queue.erase(std::remove_if(queue.begin(),queue.end(),[&](const Pending&p){return p.request.source==request.source;}),queue.end());int version=++serial;latest[path]=version;queue.push_back({std::move(request),version,juce::Time::getMillisecondCounterHiRes()+400});state.busy=true;state.error.clear();state.output.clear();++state.revision;notify();}
void AudioEditService::cancel(const juce::String&path){std::lock_guard<std::mutex>g(mutex);latest.erase(path);queue.erase(std::remove_if(queue.begin(),queue.end(),[&](const Pending&p){return p.request.source.getFullPathName()==path;}),queue.end());completed.erase(std::remove_if(completed.begin(),completed.end(),[&](const EditState&r){return r.source==path;}),completed.end());state.busy=!latest.empty();}
void AudioEditService::cancelAll(){std::lock_guard<std::mutex>g(mutex);latest.clear();queue.clear();completed.clear();state={};++serial;notify();}
bool AudioEditService::isPending(const juce::String&path){std::lock_guard<std::mutex>g(mutex);return latest.count(path)>0||std::any_of(completed.begin(),completed.end(),[&](const EditState&r){return r.source==path;});}
std::vector<EditState> AudioEditService::takeResults(){std::lock_guard<std::mutex>g(mutex);std::vector<EditState>result;result.swap(completed);return result;}
EditState AudioEditService::snapshot(){std::lock_guard<std::mutex>g(mutex);return state;}
void AudioEditService::run(){while(!threadShouldExit()){
 Pending next;{std::lock_guard<std::mutex>g(mutex);if(!queue.empty()&&queue.front().ready<=juce::Time::getMillisecondCounterHiRes()){next=std::move(queue.front());queue.pop_front();active=next.request.source.getFullPathName();}}
 if(!next.revision){wait(40);continue;}auto path=next.request.source.getFullPathName();EditState result;result.source=path;result.revision=next.revision;
 auto cancelled=[&]{std::lock_guard<std::mutex>g(mutex);auto i=latest.find(path);return threadShouldExit()||i==latest.end()||i->second!=next.revision;};
 try{auto override=juce::SystemStats::getEnvironmentVariable("DRUMATLAS_CACHE_DIR",{});auto folder=(override.isNotEmpty()?juce::File(override):juce::File::getSpecialLocation(juce::File::userApplicationDataDirectory).getChildFile("DrumAtlas")).getChildFile("Rendered Audio");result.output=renderAudioEdit(next.request,folder,cancelled).getFullPathName();}
 catch(const std::exception&e){result.error=juce::String::fromUTF8(e.what());}
 {std::lock_guard<std::mutex>g(mutex);auto i=latest.find(path);if(i!=latest.end()&&i->second==next.revision){latest.erase(i);completed.push_back(result);state=result;}else if(result.output.isNotEmpty())juce::File(result.output).deleteFile();active.clear();state.busy=!latest.empty();++state.revision;}
}}
}
