#pragma once
#include "AudioEdit.h"
#include "Locale.h"
#include "EmberTheme.h"
namespace atlas {
class AudioKnobLook:public ember::Look {
public:
 juce::Slider::SliderLayout getSliderLayout(juce::Slider&s)override{juce::Slider::SliderLayout l;auto b=s.getLocalBounds();const bool roomy=ember::styleOf(s)==0;const int dial=std::min(roomy?46:52,std::max(20,b.getHeight()-(roomy?22:21)));l.sliderBounds=b.withHeight(dial);l.textBoxBounds={0,dial+2,b.getWidth(),roomy?20:19};return l;}
 void drawRotarySlider(juce::Graphics&g,int x,int y,int w,int h,float value,float start,float end,juce::Slider&s)override{
  auto box=juce::Rectangle<float>(float(x),float(y),float(w),float(h)).reduced(3);auto c=box.getCentre();float r=std::min(ember::styleOf(s)==0?21.f:21.f,std::min(box.getWidth(),box.getHeight())*.5f);
  g.setGradientFill(juce::ColourGradient(juce::Colour(0xff493024),c.x-r,c.y-r,ember::background,c.x+r,c.y+r,false));g.fillEllipse(c.x-r,c.y-r,r*2,r*2);juce::Path arc;arc.addCentredArc(c.x,c.y,r-2,r-2,0,start,end,true);g.setColour(juce::Colour(0xff493024));g.strokePath(arc,juce::PathStrokeType(3));
  float angle=start+value*(end-start);juce::Path active;active.addCentredArc(c.x,c.y,r-2,r-2,0,start,angle,true);g.setColour(juce::Colour(0xffffa34b).withAlpha(s.isEnabled()?1.f:.35f));g.strokePath(active,juce::PathStrokeType(3));g.drawLine(c.x+std::sin(angle)*r*.3f,c.y-std::cos(angle)*r*.3f,c.x+std::sin(angle)*r*.72f,c.y-std::cos(angle)*r*.72f,2);
 }
 juce::Font getLabelFont(juce::Label&l)override{return ember::styleOf(l)==0?ember::font(13):juce::LookAndFeel_V4::getLabelFont(l);}
 void drawButtonText(juce::Graphics&g,juce::TextButton&b,bool,bool)override{g.setColour(juce::Colour(0xffc0aa99).withAlpha(b.isEnabled()?1.f:.4f));g.setFont(ember::font((ember::styleOf(b)==0?13.f:10.f)*float(b.getProperties().getWithDefault("layoutFontScale",1.)),language));g.drawText(b.getButtonText(),b.getLocalBounds(),juce::Justification::centred);}
};
class AudioKnobs:public juce::Component {
public:
 juce::Slider pitch,tempo;juce::Label pitchLabel,tempoLabel,original;juce::TextButton sync{"Sync DAW"};
 std::function<void(AudioKnobSettings)> changed;std::function<double()>hostTempo;
 AudioKnobs(){setLookAndFeel(&look);
  for(auto*s:{&pitch,&tempo}){addAndMakeVisible(s);s->setSliderStyle(juce::Slider::RotaryHorizontalVerticalDrag);s->setTextBoxStyle(juce::Slider::TextBoxBelow,false,66,16);s->setColour(juce::Slider::textBoxOutlineColourId,juce::Colours::transparentBlack);s->setColour(juce::Slider::rotarySliderFillColourId,juce::Colour(0xffffa34b));s->setColour(juce::Slider::rotarySliderOutlineColourId,juce::Colour(0xff493024));s->setScrollWheelEnabled(false);}
  pitch.setRange(-24,24,.1);pitch.setDoubleClickReturnValue(true,0);tempo.setRange(20,400,.1);tempo.setDoubleClickReturnValue(true,100);
  pitch.textFromValueFunction=[](double v){return (v>0?"+":"")+juce::String(v,1)+" st";};
  tempo.textFromValueFunction=[this](double v){return bpm>=20?juce::String(v,1):juce::String::fromUTF8("—");};
  tempo.valueFromTextFunction=[this](const juce::String&s){auto value=s.getDoubleValue();if(value<20||value>400)return tempo.getValue();if(bpm<20){bpm=value;tempo.setDoubleClickReturnValue(true,bpm);if(changed)changed({pitch.getValue(),100,bpm});}return value;};
  for(auto*l:{&pitchLabel,&tempoLabel}){addAndMakeVisible(l);l->setFont(ember::font(11.f));l->setColour(juce::Label::textColourId,juce::Colour(0xffc0aa99));l->setJustificationType(juce::Justification::centred);}
  pitchLabel.setText("Pitch",juce::dontSendNotification);tempoLabel.setText("Tempo",juce::dontSendNotification);
  original.setEditable(false,true,false);original.onTextChange=[this]{if(loading)return;auto value=original.getText().retainCharacters("0123456789.").getDoubleValue();bpm=value>=20&&value<=400?value:0;refreshOriginal();tempo.updateText();if(changed)changed(values());};
  addAndMakeVisible(sync);sync.onClick=[this]{double target=hostTempo?hostTempo():0;if(bpm>=20&&target>=20)tempo.setValue(juce::jlimit(20.,400.,target));};
  pitch.onValueChange=[this]{if(!loading&&changed)changed(values());};tempo.onValueChange=[this]{if(loading)return;if(bpm<20){bpm=tempo.getValue();tempo.updateText();}if(changed)changed(values());};
  pitch.setValue(0,juce::dontSendNotification);tempo.setValue(100,juce::dontSendNotification);pitch.updateText();tempo.updateText();
  setComponentID("audio-knobs");pitch.setComponentID("pitch-knob");tempo.setComponentID("tempo-knob");original.setComponentID("original-bpm");
 }
 ~AudioKnobs()override{sync.setLookAndFeel(nullptr);setLookAndFeel(nullptr);}
 void localise(const juce::String&language){lang=language;look.setLanguage(lang);pitch.setTooltip(tr("knobPitchHint",lang));tempo.setTooltip(tr("knobTempoHint",lang));original.setTooltip(tr("knobBpmHint",lang));sync.setTooltip(tr("syncDaw",lang));refreshOriginal();}
 void set(AudioKnobSettings s){loading=true;bpm=s.originalBpm;pitch.setValue(s.pitch,juce::dontSendNotification);tempo.setRange(std::max(20.,bpm*.25),bpm>=20?std::min(400.,bpm*4):400.,.1);tempo.setDoubleClickReturnValue(true,bpm>=20?bpm:100.);tempo.setValue(bpm>=20?bpm*s.tempo/100.:100.,juce::dontSendNotification);tempo.updateText();refreshOriginal();loading=false;}
 AudioKnobSettings values()const{return {pitch.getValue(),bpm>=20?tempo.getValue()*100/bpm:100,bpm};}
 void refreshHost(){sync.setEnabled(bpm>=20&&hostTempo&&hostTempo()>=20);}
 void resized()override{if(ember::styleOf(*this)==0&&getHeight()>=80){const int half=getWidth()/2;pitchLabel.setBounds(0,0,half,18);tempoLabel.setBounds(half,0,half,18);pitch.setBounds(0,18,half,64);tempo.setBounds(half,18,half,64);original.setVisible(false);return;}int half=getWidth()/2;pitchLabel.setBounds(0,0,half,14);tempoLabel.setBounds(half,0,getWidth()-half,14);pitch.setBounds(0,12,half,getHeight()-34);tempo.setBounds(half,12,getWidth()-half,getHeight()-34);original.setVisible(false);if(sync.getParentComponent()==this)sync.setBounds(half+std::max(0,(getWidth()-half-78)/2),getHeight()-24,std::min(78,getWidth()-half),22);}
private:
 void refreshOriginal(){bool previous=loading;loading=true;original.setText("BPM: "+(bpm>=20?juce::String(bpm,1):juce::String::fromUTF8("—")),juce::dontSendNotification);loading=previous;}
 AudioKnobLook look;double bpm=0;bool loading=false;juce::String lang="en";
};
}
