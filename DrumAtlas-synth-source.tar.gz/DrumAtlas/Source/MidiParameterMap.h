#pragma once
#include <juce_core/juce_core.h>
#include <vector>
#include <set>
namespace atlas::hosting {
struct CCParameterBinding {int channel=1,controller=1;juce::String parameter,name;};
// A public parameter slot may mean something different after changing a patch.
// Window placement is deliberately irrelevant to this edit precondition.
inline bool sameCCMappingSound(const juce::var& current, const juce::var& opened) {
 if(!current.isObject()||!opened.isObject())return false;
 for(auto key:{"uid","class_id","plugin_version","path","state","sha256"})
  if(current[key]!=opened[key])return false;
 return true;
}
inline juce::Result readCCParameterMap(const juce::var&value,std::vector<CCParameterBinding>&out){
 std::vector<CCParameterBinding>result;if(value.isVoid()){out.clear();return juce::Result::ok();}
 auto*items=value.getArray();if(!items||items->size()>16)return juce::Result::fail("Expected at most 16 MIDI CC parameter bindings.");std::set<int>seen;
 for(const auto&item:*items){if(!item.isObject()||!item["channel"].isInt()||!item["cc"].isInt()||!item["parameter_id"].isString()||!item["name"].isString())return juce::Result::fail("Invalid MIDI CC binding fields.");
  CCParameterBinding binding{int(item["channel"]),int(item["cc"]),item["parameter_id"].toString(),item["name"].toString()};
  if(binding.channel<1||binding.channel>16||binding.controller<0||binding.controller>119||binding.parameter.isEmpty()||binding.parameter.length()>10||!binding.parameter.containsOnly("0123456789")||binding.parameter.getLargeIntValue()>0xffffffffLL||binding.name.length()>256||!seen.insert(binding.channel*128+binding.controller).second)return juce::Result::fail("Invalid or duplicate MIDI CC binding. Channel-mode controllers 120-127 cannot be mapped.");result.push_back(binding);
 }
 out=std::move(result);return juce::Result::ok();
}
inline juce::var encodeCCParameterMap(const std::vector<CCParameterBinding>&bindings){juce::Array<juce::var>items;for(const auto&binding:bindings){auto*item=new juce::DynamicObject;item->setProperty("channel",binding.channel);item->setProperty("cc",binding.controller);item->setProperty("parameter_id",binding.parameter);item->setProperty("name",binding.name);items.add(item);}return items;}
}
