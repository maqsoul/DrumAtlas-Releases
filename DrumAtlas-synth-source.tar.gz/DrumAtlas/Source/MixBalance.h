#pragma once
#include <juce_audio_formats/juce_audio_formats.h>
#include <cmath>
#include <vector>

namespace atlas::music::balance {
struct Measurement {double peak=0,activeRms=0;};
inline juce::Result measure(juce::AudioFormatReader& reader,Measurement& out,const std::function<bool()>& cancel){
    juce::AudioBuffer<float> audio(2,4096);std::vector<double> windows;double maximum=0;
    for(juce::int64 at=0;at<reader.lengthInSamples;at+=4096){
        if(cancel&&cancel())return juce::Result::fail("Render cancelled");
        int count=int(std::min<juce::int64>(4096,reader.lengthInSamples-at));
        if(!reader.read(&audio,0,count,at,true,true))return juce::Result::fail("Cannot measure rendered track");
        double square=0;for(int ch=0;ch<2;++ch)for(int i=0;i<count;++i){double v=audio.getSample(ch,i);if(!std::isfinite(v))return juce::Result::fail("Invalid track audio");out.peak=std::max(out.peak,std::abs(v));square+=v*v;}
        double rms=std::sqrt(square/(2*count));maximum=std::max(maximum,rms);windows.push_back(rms);
    }
    // Relative activity gate excludes arranged rests and silent intros, so
    // adding eight silent bars cannot make an instrument louder.
    windows.erase(std::remove_if(windows.begin(),windows.end(),[&](double x){return x<std::max(1.e-6,maximum*.1);}),windows.end());
    if(!windows.empty()){auto rank=windows.begin()+windows.size()*3/4;std::nth_element(windows.begin(),rank,windows.end());out.activeRms=*rank;}
    return juce::Result::ok();
}
inline float gain(const juce::String& role,const Measurement& m){
    if(m.activeRms<1.e-5||m.peak<1.e-5)return 1; // Never turn near-silence into loud noise.
    double db=role=="Kick"?-19:role=="Snare"?-23:role=="Clap"?-28:role=="Bass"?-24:role=="Chords"?-29:role=="Melody"?-26:role=="Countermelody"?-30:role=="FX"?-34:-31;
    double ceiling=role=="Kick"?.65:role=="Snare"?.55:.35;
    return float(std::min({4.,std::pow(10.,db/20)/m.activeRms,ceiling/m.peak}));
}
}
