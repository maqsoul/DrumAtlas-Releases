#pragma once
#include <juce_dsp/juce_dsp.h>
#include <array>
#include <vector>

namespace atlas::composer {
// Four frequency bands give percussive attacks and harmonic changes independent votes.
// Keep one short envelope per 10 ms instead of retaining the decoded song.
class ReferencePulse {
    static constexpr int size=1024, hop=220, rate=22050, windowSize=1600;
    using Bands=std::array<double,4>;
    juce::dsp::FFT spectrum{10};
    std::array<float,size> window{};
    std::array<int,size/2> band{};
    std::array<float,size/2> previous{};
    std::vector<Bands> flux;
    std::vector<float> carry;
    bool initial=true;
public:
    ReferencePulse(){
        for(int i=0;i<size;++i)window[i]=float(.5-.5*std::cos(juce::MathConstants<double>::twoPi*i/(size-1)));
        for(int i=0;i<size/2;++i){double hz=double(i)*rate/size;band[i]=hz<30?-1:hz<180?0:hz<1500?1:hz<6000?2:3;}
    }
    void append(const std::vector<float>&audio){
        carry.insert(carry.end(),audio.begin(),audio.end());size_t at=0;
        std::array<float,size*2> frame{};
        for(;at+size<=carry.size();at+=hop){
            for(int i=0;i<size;++i)frame[i]=carry[at+i]*window[i];
            spectrum.performFrequencyOnlyForwardTransform(frame.data(),true);Bands values{};
            for(int k=1;k<size/2;++k){float level=std::log1p(10.f*frame[k]);if(band[k]>=0)values[band[k]]+=std::max(0.f,level-previous[k]);previous[k]=level;}
            flux.push_back(initial?Bands{}:values);initial=false;
        }
        carry.erase(carry.begin(),carry.begin()+at);
    }
    double estimate(const std::function<bool()>&cancel) const {
        if(flux.size()<800)return 0;
        Bands mean{},variance{};for(const auto&row:flux)for(int k=0;k<4;++k)mean[k]+=row[k]/flux.size();
        for(const auto&row:flux)for(int k=0;k<4;++k)variance[k]+=std::pow(row[k]-mean[k],2)/flux.size();
        juce::dsp::FFT correlationFFT(12);std::array<double,1501>votes{};
        for(size_t start=0;start+700<flux.size();start+=800){
            if(cancel&&cancel())return 0;
            int count=int(std::min<size_t>(windowSize,flux.size()-start));std::array<double,601>corr{};
            for(int k=0;k<4;++k){if(variance[k]<1.e-10)continue;double local=0;
                for(int i=0;i<count;++i)local+=flux[start+i][k]/count;
                std::array<float,8192>work{};for(int i=0;i<count;++i)work[i]=float((flux[start+i][k]-local)/std::sqrt(variance[k]));
                correlationFFT.performRealOnlyForwardTransform(work.data(),true);
                for(int i=0;i<=2048;++i){float re=work[2*i],im=work[2*i+1];work[2*i]=re*re+im*im;work[2*i+1]=0;}
                correlationFFT.performRealOnlyInverseTransform(work.data());for(int i=0;i<=600;++i)corr[i]+=work[i]/(count-i);
            }
            if(corr[0]<.04)continue;
            auto value=[&](double lag){int i=int(lag);return corr[i]+(lag-i)*(corr[i+1]-corr[i]);};
            for(int i=0;i<=1500;++i){double bpm=50+i*.1,lag=60.*rate/(hop*bpm);
                double support=(value(lag)+.65*value(2*lag)+.35*value(4*lag))/corr[0];
                votes[i]+=std::max(0.,support)*std::exp(-.5*std::pow(std::log2(bpm/112.)/.8,2));}
        }
        auto best=std::max_element(votes.begin(),votes.end());return *best>0?50+.1*std::distance(votes.begin(),best):0;
    }
};
}
