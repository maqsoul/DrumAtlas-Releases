#pragma once
#include "LocalModelRuntime.h"

namespace atlas::composer::openai {
inline juce::String key() { return juce::SystemStats::getEnvironmentVariable("OPENAI_API_KEY", {}).trim(); }
inline void normaliseSchema(juce::var schema) {
    auto* obj=schema.getDynamicObject();if(!obj)return;
    if(schema.hasProperty("const")){
        auto value=schema["const"];obj->setProperty("type",value.isString()?"string":"integer");
        obj->setProperty("enum",juce::Array<juce::var>{value});obj->removeProperty("const");
    }
    obj->removeProperty("maxLength");
    if(auto* properties=schema["properties"].getDynamicObject())for(auto& entry:properties->getProperties())normaliseSchema(entry.value);
    normaliseSchema(schema["items"]);
    if(auto* variants=schema["anyOf"].getArray())for(auto v:*variants)normaliseSchema(v);
}

inline juce::var requestBody(const juce::var& plan) {
    auto* body = new juce::DynamicObject;
    body->setProperty("model", "gpt-5.4");
    body->setProperty("store", false);
    body->setProperty("max_completion_tokens", 8000);
    body->setProperty("messages", plan["messages"].clone());
    auto format=plan["response_format"].clone();normaliseSchema(format["json_schema"]["schema"]);
    body->setProperty("response_format",format);
    return juce::var(body);
}

inline juce::Result limitError(const juce::String& body,const juce::String& retryAfter) {
    const auto error=juce::JSON::parse(body)["error"];
    const auto code=error["code"].toString(), type=error["type"].toString();
    if(code=="credit_balance_exhausted")
        return juce::Result::fail("OpenAI API credits exhausted. Check Billing or select Local AI model.");
    if(code=="project_spend_limit_exceeded")
        return juce::Result::fail("OpenAI project spending limit reached. Check project limits or select Local AI model.");
    if(code=="organization_spend_limit_exceeded"||code=="organization_usage_limit_exceeded")
        return juce::Result::fail("OpenAI organization limit reached. Check organization limits or select Local AI model.");
    if(code=="insufficient_quota"||code=="usage_limit_exceeded"||type=="insufficient_quota")
        return juce::Result::fail("OpenAI API quota exhausted. Check Billing and Limits, or select Local AI model.");
    if(code=="rate_limit_exceeded"||code=="slow_down"||type=="rate_limit_error"||type=="rate_limit_exceeded"){
        auto seconds=retryAfter.trim();
        if(seconds.isNotEmpty()&&seconds.length()<=8&&seconds.containsOnly("0123456789")&&seconds.getIntValue()>0)
            return juce::Result::fail("OpenAI temporary rate limit. Retry in "+seconds+" s or later.");
        return juce::Result::fail("OpenAI temporary rate limit. Wait before trying again.");
    }
    return juce::Result::fail("OpenAI returned HTTP 429 without a recognised limit code. Check API Billing and Limits, or select Local AI model.");
}

inline juce::Result readResponse(int status,const juce::String& body,juce::String& content,const juce::String& retryAfter={}) {
    content.clear();
    if(status==401||status==403)return juce::Result::fail("OpenAI rejected the API key or model access. Check your OpenAI project.");
    if(status==429)return limitError(body,retryAfter);
    if(status!=200)return juce::Result::fail("OpenAI request failed (HTTP "+juce::String(status)+").");
    auto response=juce::JSON::parse(body);
    if(!response["choices"].isArray()||response["choices"].size()!=1)return juce::Result::fail("OpenAI returned no plan.");
    auto choice=response["choices"][0];
    if(choice["finish_reason"].toString()!="stop"||choice["message"]["refusal"].toString().isNotEmpty())
        return juce::Result::fail("OpenAI did not return a complete composition plan.");
    auto value=choice["message"]["content"];
    if(!value.isString()||!juce::JSON::parse(value.toString()).isObject())
        return juce::Result::fail("OpenAI returned an invalid plan.");
    content=value.toString();return juce::Result::ok();
}

inline juce::Result predict(const juce::var& plan,juce::String& content,const std::shared_ptr<LocalModelRequest>& job) {
    auto token=key();
    if(token.isEmpty()||token.containsAnyOf("\r\n"))return juce::Result::fail("Set OPENAI_API_KEY in Windows and restart the DAW, or select a local GGUF model.");
    auto body=juce::JSON::toString(requestBody(plan),true);
    auto url=juce::URL("https://api.openai.com/v1/chat/completions").withPOSTData(body);
    auto stream=std::make_shared<juce::WebInputStream>(url,false);
    stream->withCustomRequestCommand("POST").withNumRedirectsToFollow(0).withConnectionTimeout(120000)
          .withExtraHeaders("Content-Type: application/json\r\nAuthorization: Bearer "+token+"\r\n");
    job->attach(stream);
    if(job->isCancelled())return juce::Result::fail("Cancelled");
    bool connected=stream->connect(nullptr);
    if(job->isCancelled())return juce::Result::fail("Cancelled");
    int status=stream->getStatusCode();
    if(status<=0)return juce::Result::fail("Cannot connect to OpenAI.");
    if(status!=200&&status!=429)return readResponse(status,{},content);
    if(!connected)return status==429?limitError({},{}):juce::Result::fail("Cannot connect to OpenAI.");
    juce::MemoryOutputStream reply;char buffer[4096];
    while(!job->isCancelled()&&!stream->isExhausted()){
        auto n=stream->read(buffer,sizeof(buffer));if(n<=0)break;
        if(status==429&&reply.getDataSize()+size_t(n)>65536)return limitError({},{});
        if(reply.getDataSize()+size_t(n)>1024*1024)return juce::Result::fail("OpenAI response too large.");
        reply.write(buffer,size_t(n));
    }
    if(job->isCancelled()||stream->isError())return juce::Result::fail("OpenAI request interrupted.");
    return readResponse(status,reply.toUTF8(),content,stream->getResponseHeaders()["Retry-After"]);
}
}
