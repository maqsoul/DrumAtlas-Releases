#pragma once
#include "Engine.h"
#include "MusicCore.h"
#include "ReferenceMusic.h"
#include "LocalModelRuntime.h"
#include "LiveBridge.h"
#include "ComposerAudio.h"
#include <optional>
#include <map>

namespace atlas::composer {
struct Analysis {
    double duration=0,bpm=0,tempoConfidence=0,keyConfidence=0;
    int tonic=-1; bool minor=true;
    juce::int64 frames=0,analysedFrames=0;
    std::vector<double> energy;
    std::vector<Hit> timbres;
    juce::var musicalGuide,tempoCandidates;
    referenceMusic::Evidence musicalEvidence;
    juce::StringArray genres;
    juce::var json() const;
    static juce::Result restore(const juce::var&,Analysis&);
};
juce::Result analyseWholeFile(const juce::File&,Analysis&,const std::function<bool()>&cancel={},const std::function<void(double)>&progress={});
struct MidiChange {
    enum Kind { Insert, Replace, Remove } kind=Replace;
    juce::String track;
    music::Note note;
};
juce::Result applyMidiChanges(const music::Project&,const std::vector<MidiChange>&,music::Project&);
struct Request {
    bool editExisting=false, audioBeat=false;
    juce::String midiBase;
    std::vector<MidiChange> midiChanges;
    juce::String audioBase;
    AudioRegionEdit audioEdit;
    juce::String prompt,genre="Trap",model;
    juce::File reference,loop;
    juce::Array<juce::var> instruments,effects;
    std::shared_ptr<const std::vector<Sample>> samples;
};
struct Song {
    bool nativeMix=false, audioBeat=false;
    music::Project project;
    Analysis reference;
    juce::File folder,mix,loopAudio;
    juce::StringArray messages;
    juce::String prompt;
};
// LLM output is data only: no executable actions, paths or arbitrary plugin IDs.
juce::Result planProject(const Request&,const Analysis&,const juce::var&plan,music::Project&,juce::StringArray&notices);
juce::Result selectSamples(music::Project&,const std::vector<Sample>&,bool withLoop,juce::StringArray&notices,const std::vector<Hit>&reference={},bool allowPercussionLoop=false,const juce::File& alignedLoops={},const std::function<bool()>& cancel={});
juce::Result applyEdits(const music::Project&,const juce::var&,music::Project&,bool hasLoop=false,const std::map<juce::String,music::Track>&assets={});
juce::File dataDirectory();
struct State {
    juce::var draft,midiDraft;
    bool busy=false,canUndo=false,canRedo=false; int revision=0;
    juce::String status="Ready",error;
    std::shared_ptr<const Song> song;
    juce::Array<juce::var> instruments,effects;
};
class Service : private juce::Thread {
public:
    // Injectable planner for replaying a captured response through the complete
    // production composition path, without network calls or paid API requests.
    using Planner=std::function<juce::Result(const juce::var&,juce::String&)>;
    explicit Service(Planner={}); ~Service() override;
    bool generate(Request); bool scan(const juce::Array<juce::File>& roots);
    void cancel(); State snapshot();
    void setDraft(juce::var);
    void setMidiDraft(juce::var);
    bool liveCommand(const juce::String&);
    bool undo(); bool redo();
    bool changeMidi(const juce::String& projectId,std::vector<MidiChange>);
    bool changeAudio(const juce::String& projectId,const AudioRegionEdit&);
    juce::String serialise(); juce::Result restore(const juce::String&);
private:
    void run() override; void compose(const Request&); void composeAudio(const Request&); void scanNow(const juce::Array<juce::File>&);
    void edit(const Request&);
    void editMidi(const Request&);
    void editAudio(const Request&);
    void captureLive(const std::shared_ptr<const Song>&);
    void renderSong(const std::shared_ptr<Song>&,const Request&,const Analysis&,const juce::var&,bool edited=false);
    void commitSong(const std::shared_ptr<Song>&);
    bool moveHistory(bool backwards);
    bool cancelled() const {return threadShouldExit()||stop.load();}
    void report(const juce::String&);
    std::mutex mutex; State state; std::optional<Request> pending; juce::Array<juce::File> scanRoots;
    Planner planner;
    juce::String pendingLive;
    bool pendingScan=false; std::atomic<bool>stop{false};
    std::shared_ptr<LocalModelRuntime> runtime=LocalModelRuntime::shared();
    std::shared_ptr<LocalModelRequest> modelRequest;
    std::vector<std::shared_ptr<const Song>> past,future;
};
}
