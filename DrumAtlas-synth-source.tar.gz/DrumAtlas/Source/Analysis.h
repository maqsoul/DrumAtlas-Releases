#pragma once
#include <juce_audio_formats/juce_audio_formats.h>
#include <juce_dsp/juce_dsp.h>
#include <array>
#include <vector>
#include "Formats.h"

namespace atlas {
struct Separated { std::vector<float> percussive,harmonic; };
Separated separate(const std::vector<float>&);
std::vector<float> drumFocus(const std::vector<float>&,const juce::String&);
constexpr double analysisRate = 22050.0;
struct Features {
    std::array<float, 12> bands{};
    float centroid = 0, flatness = 0, zcr = 0, tail = 0, duration = 0, peak = 0;
    std::vector<uint8_t> embedding;
};
struct Label {
    juce::String category = "Other", kind = "One-shot", method = "Audio estimate";
};
struct Decoded {
    std::vector<float> mono;
    double duration = 0;
    juce::String error;
};
Decoded decode(juce::AudioFormatManager&, const juce::File&, double start = 0, double limit = 5);
Features describe(const std::vector<float>&);
std::vector<int> onsets(const std::vector<float>&);
Label classify(const juce::String& filename, const Features&, double duration, const std::vector<int>& hits);
Label nameLabel(const juce::String&);
Label pathLabel(const juce::File&,const juce::StringArray& roots);
juce::StringArray excludedCategories(const juce::String&);
float referenceDistance(const Features&,const Features&,const juce::String& category);
float distance(const Features&, const Features&);
juce::var toJson(const Features&);
Features fromJson(const juce::var&);
juce::StringArray categories();
bool isDrum(const juce::String&);
}
