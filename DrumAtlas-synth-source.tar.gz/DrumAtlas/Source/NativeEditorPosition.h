#pragma once
#include <juce_core/juce_core.h>
#include <algorithm>
namespace atlas::hosting {
inline bool validNativeEditorPosition(const juce::var&value){
    if(value.isVoid())return true;
    if(!value.isObject()||value.getDynamicObject()->getProperties().size()!=2)return false;
    for(auto key:{"x","y"}){auto coordinate=value[key];if(!(coordinate.isInt()||coordinate.isInt64())||juce::int64(coordinate)<-131072||juce::int64(coordinate)>131072)return false;}
    return true;
}
inline juce::var nativeEditorPosition(int x,int y){auto*object=new juce::DynamicObject;object->setProperty("x",std::clamp(x,-131072,131072));object->setProperty("y",std::clamp(y,-131072,131072));return juce::var(object);}
struct NativeEditorPoint{int x=0,y=0;};
inline NativeEditorPoint visibleNativeEditorPosition(NativeEditorPoint wanted,int width,int height,int left,int top,int screenWidth,int screenHeight){
    if(screenWidth<=0||screenHeight<=0)return wanted;
    // Keep the full editor in view when it fits. For fixed oversized editors,
    // keep the title bar/top-left reachable; never resize vendor content blindly.
    return {std::clamp(wanted.x,left,left+std::max(0,screenWidth-width)),std::clamp(wanted.y,top,top+std::max(0,screenHeight-height))};
}
}
