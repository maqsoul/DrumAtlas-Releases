#pragma once
#include "Composer.h"
#include "ComposerLocale.h"
#include "ComposerNoteEditor.h"
#include "ComposerAudioEditor.h"
#include "EmberTheme.h"
#include "InstrumentScanner.h"
#include <juce_audio_utils/juce_audio_utils.h>

namespace atlas::composer {
class Shortcuts {
public:
    Shortcuts(){keys={{"compose","ctrl + return"},{"play","space"},{"stop","shift + space"},{"import","ctrl + I"},{"scan","ctrl + shift + R"},{"chat","ctrl + alt + A"},{"undo","ctrl + alt + Z"},{"redo","ctrl + alt + Y"}};auto v=juce::JSON::parse(dataDirectory().getChildFile("shortcuts.json"));if(auto*o=v.getDynamicObject())for(auto&entry:o->getProperties())if(keys.count(entry.name.toString())){auto copy=keys;copy[entry.name.toString()]=entry.value.toString();if(valid(copy))keys=copy;}}
    static bool valid(const std::map<juce::String,juce::String>&map){std::vector<juce::KeyPress>seen;for(auto&entry:map){if(entry.second.isEmpty())continue;auto k=juce::KeyPress::createFromDescription(entry.second);if(!k.isValid()||std::find(seen.begin(),seen.end(),k)!=seen.end())return false;seen.push_back(k);}return true;}
    juce::String action(const juce::KeyPress&k)const{for(auto&entry:keys)if(entry.second.isNotEmpty()&&juce::KeyPress::createFromDescription(entry.second)==k)return entry.first;return {};}
    juce::Result save(const std::map<juce::String,juce::String>&next){if(!valid(next))return juce::Result::fail("Use valid, unique shortcuts; leave a field empty to disable it.");auto*o=new juce::DynamicObject;for(auto&e:next)o->setProperty(e.first,e.second);auto file=dataDirectory().getChildFile("shortcuts.json");auto result=file.getParentDirectory().createDirectory();if(result.failed()||!file.replaceWithText(juce::JSON::toString(juce::var(o))))return juce::Result::fail("Cannot save shortcuts");keys=next;return juce::Result::ok();}
    std::map<juce::String,juce::String>keys;
};
class ShortcutPage : public juce::Component {
public:
    explicit ShortcutPage(Shortcuts&store):shortcuts(store){
        for(auto&entry:store.keys){auto*label=labels.add(new juce::Label);label->setText(entry.first,juce::dontSendNotification);addAndMakeVisible(label);auto*edit=edits.add(new juce::TextEditor);edit->setText(entry.second);edit->setFont(ember::font(14));addAndMakeVisible(edit);}
        addAndMakeVisible(save);addAndMakeVisible(info);info.setText("Example: ctrl + shift + G. Shortcuts work while DrumAtlas has keyboard focus; typing in the chat keeps text shortcuts inactive.",juce::dontSendNotification);
        save.onClick=[this]{auto next=shortcuts.keys;int i=0;for(auto&e:next)e.second=edits[i++]->getText().trim();auto result=shortcuts.save(next);info.setText(result.wasOk()?"Shortcuts saved":result.getErrorMessage(),juce::dontSendNotification);};
    }
    void localise(const juce::String&language){
        const std::map<juce::String,juce::String>names={{"compose","Create beat"},{"play","Play"},{"stop","Stop"},{"import","Import reference"},{"scan","Scan VST2 / VST3"},{"chat","AI Chat"},{"undo","Undo"},{"redo","Redo"}};
        int i=0;for(auto&entry:shortcuts.keys){auto found=names.find(entry.first);labels[i++]->setText(ct(found==names.end()?entry.first:found->second,language),juce::dontSendNotification);}save.setButtonText(ct("Save",language));info.setText(ct("shortcutHint",language),juce::dontSendNotification);
    }
    void resized()override{auto area=getLocalBounds().reduced(24);info.setBounds(area.removeFromTop(64));for(int i=0;i<edits.size();++i){auto row=area.removeFromTop(42);labels[i]->setBounds(row.removeFromLeft(140));edits[i]->setBounds(row.removeFromLeft(260).reduced(0,4));}save.setBounds(area.removeFromTop(36).withWidth(180));}
private:Shortcuts&shortcuts;juce::OwnedArray<juce::Label>labels;juce::OwnedArray<juce::TextEditor>edits;juce::TextButton save{"Save shortcuts"};juce::Label info;
};
class ExportDrag : public juce::TextButton {
public:
    std::function<juce::File()>file;
    void mouseDown(const juce::MouseEvent&e)override{sent=false;juce::TextButton::mouseDown(e);}
    void mouseDrag(const juce::MouseEvent&e)override{if(!sent&&e.getDistanceFromDragStart()>5&&file){auto f=file();if(f.existsAsFile()){sent=true;juce::DragAndDropContainer::performExternalDragDropOfFiles({f.getFullPathName()},false,this);}}}
private:bool sent=false;
};
class Sequencer : public juce::Component, public juce::SettableTooltipClient {
public:
    void setSong(std::shared_ptr<const Song>s){song=std::move(s);setSize(std::max(760,song?180+song->project.settings.bars*32:760),song?70+int(song->project.tracks.size()+((song->audioBeat||song->loopAudio!=juce::File())?1:0))*62:220);repaint();}
    void paint(juce::Graphics&g)override{
        g.fillAll(ember::background);g.setFont(ember::font(13));if(song&&song->audioBeat){g.setColour(ember::text);g.drawText(ct("Audio beat",composerLanguage(*this))+"   /   Stereo WAV",18,48,480,44,juce::Justification::centredLeft);return;}if(!song){g.setColour(ember::muted);g.drawText(ct("emptySequence",composerLanguage(*this)),getLocalBounds(),juce::Justification::centred);return;}
        const auto&p=song->project;const double bar=double(music::barTicks(p.settings));g.setColour(ember::edge);
        for(int i=0;i<=p.settings.bars;++i){g.drawVerticalLine(180+i*32,30.f,float(getHeight()));if(i%4==0){g.setColour(ember::muted);g.drawText(juce::String(i+1),180+i*32,30,50,20,juce::Justification::left);g.setColour(ember::edge);}}
        if(auto*sections=p.sections.getArray())for(auto&s:*sections){auto rect=juce::Rectangle<int>(180+int(s["start"])*32,0,int(s["bars"])*32-2,27);g.setColour(ember::hot(ember::styleOf(*this)).withAlpha(.24f));g.fillRoundedRectangle(rect.toFloat(),4);g.setColour(ember::text);g.drawFittedText(s["name"].toString(),rect.reduced(5,0),juce::Justification::centredLeft,1);}
        for(size_t ti=0;ti<p.tracks.size();++ti){int y=56+int(ti)*62;const auto&t=p.tracks[ti];g.setColour(ember::text);g.drawText(ct(t.role,composerLanguage(*this)),8,y+3,164,22,juce::Justification::left);g.setColour(ember::muted);g.setFont(ember::font(10));g.drawText(t.liveDevice.isNotEmpty()?t.liveDevice+" / Live":t.instrument.isVoid()?juce::File(t.soundPath).getFileName():t.instrument["name"].toString(),8,y+26,164,20,juce::Justification::left);g.setFont(ember::font(13));g.setColour(ember::edge);g.drawHorizontalLine(y+57,0,float(getWidth()));
            for(auto&n:t.notes){float x=float(180+n.tick/bar*32),w=float(std::max(2.,n.duration/bar*32));float py=float(y+44-(n.pitch%24)*1.5);g.setColour(ember::hot(ember::styleOf(*this)).withAlpha(.4f+.6f*n.velocity/127.f));g.fillRoundedRectangle(x,py,w,3.5f,1.4f);}
        }
        if(song->loopAudio!=juce::File()){int y=56+int(p.tracks.size())*62;g.setColour(ember::text);g.drawText("Loop / audio",8,y+10,164,24,juce::Justification::left);g.setColour(ember::gold.withAlpha(.2f));g.fillRoundedRectangle(180.f,float(y+6),float(p.settings.bars*32),38.f,5);g.setColour(ember::gold);g.drawText(song->loopAudio.getFileName(),190,y+10,p.settings.bars*32-20,24,juce::Justification::left);}
    }
    void mouseDown(const juce::MouseEvent&e)override{dragged=false;selectedRow=song&&e.y>=56?(e.y-56)/62:-1;}
    void mouseUp(const juce::MouseEvent&e)override{if(!dragged&&e.mods.isLeftButtonDown()&&audition){auto id=rowId();if(id.isNotEmpty())audition(id);}}
    void mouseDrag(const juce::MouseEvent&e)override{if(dragged||e.getDistanceFromDragStart()<6||!trackFile)return;auto id=rowId();if(id.isEmpty())return;auto file=trackFile(id,e.mods.isAltDown());if(file.existsAsFile()){dragged=true;juce::DragAndDropContainer::performExternalDragDropOfFiles({file.getFullPathName()},false,this);}}
    void mouseDoubleClick(const juce::MouseEvent&e)override{selectedRow=song&&e.y>=56?(e.y-56)/62:-1;auto id=rowId();if(id.isNotEmpty()&&editTrack)editTrack(id);}
    std::function<void(const juce::String&)>audition,editTrack;
    std::function<juce::File(const juce::String&,bool)>trackFile;
private:
    juce::String rowId()const{if(!song)return {};if(song->audioBeat)return selectedRow==0?"__mix":juce::String();if(juce::isPositiveAndBelow(selectedRow,int(song->project.tracks.size())))return song->project.tracks[size_t(selectedRow)].id;if(selectedRow==int(song->project.tracks.size())&&song->loopAudio!=juce::File())return "__loop";return {};}
    std::shared_ptr<const Song>song;int selectedRow=-1;bool dragged=false;
};
class Panel : public juce::Component,private juce::Timer {
public:
    Panel(Service&composerService,Shortcuts&bindings,const juce::String&language="en"):service(composerService),shortcuts(bindings),shortcutPage(bindings),tabs(juce::TabbedButtonBar::TabsAtTop){
        setWantsKeyboardFocus(true);addAndMakeVisible(tabs);tabs.setColour(juce::TabbedComponent::outlineColourId,ember::edge);auto&bar=tabs.getTabbedButtonBar();bar.setColour(juce::TabbedButtonBar::tabOutlineColourId,ember::edge);bar.setColour(juce::TabbedButtonBar::frontOutlineColourId,ember::orange);bar.setColour(juce::TabbedButtonBar::tabTextColourId,ember::muted);bar.setColour(juce::TabbedButtonBar::frontTextColourId,ember::text);tabs.addTab("AI Chat",ember::panel,&page,false);tabs.addTab("Keyboard shortcuts",ember::panel,&shortcutPage,false);addAndMakeVisible(close);
        for(auto*c:std::initializer_list<juce::Component*>{&import,&useLoop,&clearSource,&source,&model,&scan,&allowed,&sendLive,&prompt,&send,&cancel,&editMode,&undo,&redo,&log,&viewport,&play,&stop,&midi,&audio,&folder,&status})page.addAndMakeVisible(c);
        close.onClick=[this]{if(noteEditor.dirty()){status.setText("Apply or revert MIDI edits before leaving",juce::dontSendNotification);return;}if(onClose)onClose();};import.onClick=[this]{chooseReference();};clearSource.onClick=[this]{reference={};loop={};refreshSource();};useLoop.onClick=[this]{auto selected=selectedLoop?selectedLoop():juce::File();if(selected.existsAsFile()){loop=selected;reference={};refreshSource();}else status.setText("Select a loop in the sample library first",juce::dontSendNotification);};
        modelPath=dataDirectory().getChildFile("chat-model.txt").loadFileAsString().trim();
        cloud=dataDirectory().getChildFile("ai-provider.txt").loadFileAsString().trim()!="local";
        model.onClick=[this]{if(editMode.getSelectedId()==3)chooseAudioEngine();else chooseProvider();};
        scan.onClick=[this]{chooseScan();};allowed.onClick=[this]{chooseInstruments();};sendLive.onClick=[this]{juce::PopupMenu menu;menu.addItem(1,ct("Send arrangement to Live",lang));auto s=service.snapshot();menu.addItem(2,ct("Render complete mix in Live",lang),s.song&&live::native(s.song->project));auto safe=juce::Component::SafePointer<Panel>(this);menu.showMenuAsync(juce::PopupMenu::Options().withTargetComponent(&sendLive),[safe](int id){if(safe&&id>0)if(!safe->service.liveCommand(id==2?"render":"import"))safe->status.setText("Create a composition first",juce::dontSendNotification);});};
        prompt.setMultiLine(true);prompt.setReturnKeyStartsNewLine(true);prompt.setFont(ember::font(15));prompt.setTextToShowWhenEmpty("Describe your beat, genre and preferred instruments...",ember::muted);
        log.setMultiLine(true);log.setReadOnly(true);log.setFont(ember::font(13));log.setText("Import a complete reference, choose a library loop, or describe a genre. Select which VST instruments the AI may use. Audio analysis and the language model run locally.\nEnable DrumAtlasBridge in Live 12.3+ to select native instruments. They play on new tracks in Ableton.");
        welcomeText=log.getText();
        page.addChildComponent(audioEditor);audioEditor.onClose=[this]{audioEditor.setVisible(false);viewport.setVisible(true);};audioEditor.onPlay=[this]{auto s=service.snapshot();if(s.song&&onPlay)onPlay(s.song->loopAudio);};audioEditor.onApply=[this](const juce::String&id,const AudioRegionEdit&edit){if(onStop)onStop();if(service.changeAudio(id,edit))audioEditor.setBusy(true);};page.addChildComponent(noteEditor);noteEditor.onClose=[this]{noteEditor.setVisible(false);viewport.setVisible(true);revision=-1;};noteEditor.onDirty=[this]{service.setMidiDraft(noteEditor.grid.draft());revision=-1;};
        noteEditor.onApply=[this](const juce::String&id,std::vector<MidiChange>changes){if(onStop)onStop();if(service.changeMidi(id,std::move(changes)))noteEditor.setBusy(true);};
        sequencer.editTrack=[this](const juce::String&id){auto s=service.snapshot();if(s.busy||!s.song||s.song->audioBeat)return;if(id=="__loop"){audioEditor.open(s.song);audioEditor.setVisible(true);noteEditor.setVisible(false);viewport.setVisible(false);return;}audioEditor.setVisible(false);noteEditor.setVisible(true);viewport.setVisible(false);noteEditor.open(s.song,id);noteEditor.setBusy(false);revision=-1;};
        editMode.addItem("New beat",1);editMode.addItem("Audio beat",3);editMode.addItem("Edit current beat",2);editMode.setSelectedId(1);editMode.setTooltip("Edit keeps untouched parts and selected sounds. Write a specific track and section, then Apply edit.");editMode.onChange=[this]{refreshProvider();saveDraft();revision=-1;send.setButtonText(ct(editMode.getSelectedId()==2?"Apply edit":"Create beat",lang));};
        undo.onClick=[this]{if(onStop)onStop();if(noteEditor.isVisible())noteEditor.grid.undo();else service.undo();};redo.onClick=[this]{if(onStop)onStop();if(noteEditor.isVisible())noteEditor.grid.redo();else service.redo();};
        sequencer.setSong({});viewport.setViewedComponent(&sequencer,false);viewport.setScrollBarsShown(true,true);send.onClick=[this]{generate();};cancel.onClick=[this]{service.cancel();};play.onClick=[this]{auto s=service.snapshot();if(s.song){if(live::native(s.song->project))service.liveCommand("play");else if(onPlay)onPlay(s.song->mix);}};stop.onClick=[this]{if(onStop)onStop();auto s=service.snapshot();if(s.song&&live::native(s.song->project))service.liveCommand("stop");};
        midi.setButtonText("Drag MIDI to DAW");audio.setButtonText("Drag audio to DAW");midi.file=[this]{auto s=service.snapshot();return s.song?s.song->folder.getChildFile("song.mid"):juce::File();};audio.file=[this]{auto s=service.snapshot();return s.song&&(!live::native(s.song->project)||s.song->nativeMix)?s.song->mix:juce::File();};folder.onClick=[this]{auto s=service.snapshot();if(s.song)s.song->folder.revealToUser();};
        sequencer.setTooltip("Double-click a track to edit MIDI notes or source-loop audio. Click to hear it. Drag to your DAW for audio; hold Alt for MIDI.");
        sequencer.trackFile=[this](const juce::String&id,bool asMidi){auto state=service.snapshot();if(!state.song)return juce::File();if(id=="__loop")return asMidi?juce::File():state.song->loopAudio;if(asMidi)return state.song->folder.getChildFile("track-"+id+".mid");auto dir=state.song->folder.getChildFile("tracks");auto manifest=juce::JSON::parse(dir.getChildFile("manifest.json"));if(auto*outputs=manifest["outputs"].getArray())for(auto&o:*outputs)if(o["file"].toString()!="Mix.wav"&&o["track_ids"].size()==1&&o["track_ids"][0].toString()==id)return dir.getChildFile(o["file"].toString());return juce::File();};
        sequencer.audition=[this](const juce::String&id){auto file=sequencer.trackFile(id,false);if(file.existsAsFile()&&onPlay)onPlay(file);else status.setText("Native instrument: use Play in Live or the Live track solo control",juce::dontSendNotification);};
        auto draft=service.snapshot().draft;if(bool(draft["audio_beat"]))editMode.setSelectedId(3,juce::dontSendNotification);prompt.setText(draft["prompt"].toString(),false);
        if(juce::File::isAbsolutePath(draft["reference"].toString()))reference=juce::File(draft["reference"].toString());if(juce::File::isAbsolutePath(draft["loop"].toString()))loop=juce::File(draft["loop"].toString());
        if(auto*values=draft["instruments"].getArray())for(auto&v:*values)selected.add(v.toString());allowed.setButtonText(ct("Allowed plugins",lang)+": "+juce::String(selected.size()));
        auto roots=juce::JSON::parse(dataDirectory().getChildFile("composer-vst-folders.json"));if(auto*values=roots.getArray())for(auto&v:*values)if(juce::File::isAbsolutePath(v.toString()))extraRoots.add(v.toString());
        prompt.onTextChange=[this]{saveDraft();};
        localise(language);refreshSource();startTimerHz(5);timerCallback();auto saved=service.snapshot();if(saved.song&&saved.midiDraft.isObject()&&saved.midiDraft["project"].toString()==saved.song->project.id){noteEditor.open(saved.song,saved.midiDraft["track"].toString());if(noteEditor.grid.restoreDraft(saved.midiDraft)){noteEditor.setVisible(true);viewport.setVisible(false);revision=-1;}}
    }
    void localise(const juce::String&language){
        lang=language;getProperties().set("atlasLanguage",lang);prompt.setTextToShowWhenEmpty(ct("chatPrompt",lang),ember::muted);if(welcomeText.isNotEmpty()&&log.getText().startsWith(welcomeText))log.setText(welcomeMessage()+log.getText().substring(welcomeText.length()));welcomeText=welcomeMessage();localiseComposerControls(*this,lang);tabs.setTabName(1,ct("Keyboard shortcuts",lang));
        int mode=editMode.getSelectedId();editMode.clear(juce::dontSendNotification);editMode.addItem("MIDI + VST",1);editMode.addItem(ct("Audio beat",lang),3);editMode.addItem(ct("Edit current beat",lang),2);editMode.setSelectedId(mode,juce::dontSendNotification);
        send.setButtonText(ct(mode==2?"Apply edit":"Create beat",lang));allowed.setButtonText(ct("Allowed plugins",lang)+": "+juce::String(selected.size()));
        updateProviderLabel();noteEditor.localise(lang);audioEditor.localise(lang);shortcutPage.localise(lang);refreshSource();revision=-1;
    }
    ~Panel()override{stopTimer();viewport.setViewedComponent(nullptr,false);tabs.clearTabs();}
    void paint(juce::Graphics&g)override{g.fillAll(ember::background);}
    void resized()override{
        close.setBounds(getWidth()-96,4,88,28);tabs.setBounds(getLocalBounds());close.toFront(false);tabs.setTabBarDepth(36);
        auto area=page.getLocalBounds().reduced(12);auto top=area.removeFromTop(32);import.setBounds(top.removeFromLeft(152));top.removeFromLeft(8);useLoop.setBounds(top.removeFromLeft(150));top.removeFromLeft(8);clearSource.setBounds(top.removeFromLeft(82));
        area.removeFromTop(6);source.setBounds(area.removeFromTop(24));auto row=area.removeFromTop(32);model.setBounds(row.removeFromLeft(140));row.removeFromLeft(8);scan.setBounds(row.removeFromLeft(150));row.removeFromLeft(8);sendLive.setBounds(row.removeFromRight(132));row.removeFromRight(8);allowed.setBounds(row);
        area.removeFromTop(8);auto bottom=area.removeFromBottom(34);status.setBounds(area.removeFromBottom(28));
        const int buttonWidth=std::max(1,(bottom.getWidth()-24)/5);for(auto*c:std::initializer_list<juce::Component*>{&play,&stop,&midi,&audio,&folder}){c->setBounds(bottom.removeFromLeft(buttonWidth));bottom.removeFromLeft(6);}
        auto editBounds=area;const int side=juce::jlimit(250,370,area.getWidth()/3);auto chat=area.removeFromLeft(side);area.removeFromLeft(12);viewport.setBounds(area);noteEditor.setBounds(getWidth()<1100?editBounds:area);audioEditor.setBounds(getWidth()<1100?editBounds:area);auto action=chat.removeFromBottom(34);send.setBounds(action.removeFromLeft(action.getWidth()-88));action.removeFromLeft(8);cancel.setBounds(action);chat.removeFromBottom(6);auto historyRow=chat.removeFromBottom(30);redo.setBounds(historyRow.removeFromRight(54));historyRow.removeFromRight(4);undo.setBounds(historyRow.removeFromRight(54));historyRow.removeFromRight(4);editMode.setBounds(historyRow);chat.removeFromBottom(8);prompt.setBounds(chat.removeFromBottom(std::min(130,chat.getHeight()/3)));chat.removeFromBottom(8);log.setBounds(chat);
    }
    bool action(const juce::String&name){if(name=="undo"){undo.triggerClick();return true;}if(name=="redo"){redo.triggerClick();return true;}if(name=="scan"){scanNow();return true;}if(name=="compose"){generate();return true;}if(name=="play"){play.triggerClick();return true;}if(name=="stop"){stop.triggerClick();return true;}if(name=="import"){chooseReference();return true;}return false;}
    bool keyPressed(const juce::KeyPress&key)override{auto focused=juce::Component::getCurrentlyFocusedComponent();if(dynamic_cast<juce::TextEditor*>(focused)&&!key.getModifiers().isCtrlDown())return false;return action(shortcuts.action(key));}
    std::function<void()>onClose,onStop;std::function<void(const juce::File&)>onPlay;std::function<juce::File()>selectedLoop;std::function<std::shared_ptr<const std::vector<Sample>>()>catalog;
private:
    bool cloud=true;
    juce::String welcomeMessage()const{
        if(editMode.getSelectedId()==3)return ct("audioBeatHint",lang);
        if(!cloud)return ct("chatWelcome",lang);
        return lang=="ru"?juce::String::fromUTF8("Напиши жанр или прикрепи референс. OpenAI API получает запрос, названия выбранных инструментов и музыкальные признаки. Аудио остаётся на компьютере. Запросы оплачиваются в аккаунте API."):
            "Describe a genre or import a reference. OpenAI receives the prompt, allowed instrument names and musical analysis. Audio stays on this computer. API usage is billed to your API account.";
    }
    void updateProviderLabel(){if(editMode.getSelectedId()==3){model.setButtonText("ACE-Step");return;}model.setButtonText(cloud?"ChatGPT (API)":ct("Local AI model",lang));}
    void selectProvider(bool online){
        cloud=online;dataDirectory().getChildFile("ai-provider.txt").replaceWithText(cloud?"openai":"local");
        refreshProvider();
    }
    void refreshProvider(){
        auto next=welcomeMessage();if(welcomeText.isNotEmpty()&&log.getText().startsWith(welcomeText))log.setText(next+log.getText().substring(welcomeText.length()));welcomeText=next;updateProviderLabel();
    }
    void chooseAudioEngine(){
        chooser=std::make_unique<juce::FileChooser>("ACE-Step folder (bin + models)");
        auto safe=juce::Component::SafePointer<Panel>(this);
        chooser->launchAsync(juce::FileBrowserComponent::openMode|juce::FileBrowserComponent::canSelectDirectories,[safe](const juce::FileChooser& c){
            auto root=c.getResult();
            if(!safe || root==juce::File())return;
            if(!root.getChildFile("bin/ace-synth.exe").existsAsFile() || !root.getChildFile("models").isDirectory())
                safe->status.setText("Select the folder containing bin/ace-synth.exe and models",juce::dontSendNotification);
            else if(dataDirectory().getChildFile("audio-engine.txt").replaceWithText(root.getFullPathName()))
                safe->status.setText("ACE-Step ready",juce::dontSendNotification);
        });
    }
    void chooseProvider(){
        juce::PopupMenu menu;menu.addItem(1,"ChatGPT (OpenAI API)",true,cloud);menu.addItem(2,ct("Local AI model",lang),true,!cloud);
        menu.addItem(3,lang=="ru"?juce::String::fromUTF8("Выбрать файл GGUF…"):"Select GGUF file...");menu.addSeparator();menu.addItem(4,"platform.openai.com/api-keys");
        auto safe=juce::Component::SafePointer<Panel>(this);
        menu.showMenuAsync(juce::PopupMenu::Options().withTargetComponent(&model),[safe](int id){
            if(!safe)return;
            if(id==1||id==2)safe->selectProvider(id==1);
            if(id==3)safe->chooseLocalModel();
            if(id==4)juce::URL("https://platform.openai.com/api-keys").launchInDefaultBrowser();
        });
    }
    void chooseLocalModel(){chooser=std::make_unique<juce::FileChooser>("Choose a local GGUF model",juce::File(),"*.gguf");auto safe=juce::Component::SafePointer<Panel>(this);chooser->launchAsync(juce::FileBrowserComponent::openMode|juce::FileBrowserComponent::canSelectFiles,[safe](const juce::FileChooser&c){if(safe&&c.getResult().existsAsFile()){safe->selectProvider(false);safe->modelPath=c.getResult().getFullPathName();dataDirectory().getChildFile("chat-model.txt").replaceWithText(safe->modelPath);safe->status.setText("Local model selected",juce::dontSendNotification);}});}
    void saveDraft(){auto*o=new juce::DynamicObject;o->setProperty("audio_beat",editMode.getSelectedId()==3);o->setProperty("prompt",prompt.getText());o->setProperty("reference",reference.getFullPathName());o->setProperty("loop",loop.getFullPathName());o->setProperty("instruments",selected);service.setDraft(juce::var(o));}
    void scanNow(){auto roots=hosting::defaultRoots();for(auto&path:extraRoots)roots.addIfNotAlreadyThere(juce::File(path));service.scan(roots);}
    void chooseScan(){
        juce::PopupMenu menu;menu.addItem(1,"Scan all configured folders");menu.addItem(2,"Add VST folder and scan");menu.addSeparator();menu.addItem(3,"Add preset folder (.vstpreset / .fxp / .fxb)");menu.addItem(4,"Reset additional preset folders");
        auto safe=juce::Component::SafePointer<Panel>(this);menu.showMenuAsync(juce::PopupMenu::Options().withTargetComponent(&scan),[safe](int id){
            if(!safe)return;if(id==1)safe->scanNow();
            if(id==4){dataDirectory().getChildFile("composer-preset-folders.json").replaceWithText("[]");safe->status.setText("Additional preset folders reset",juce::dontSendNotification);}
            if(id==2||id==3){safe->chooser=std::make_unique<juce::FileChooser>(id==2?"Choose a VST2 / VST3 folder":"Choose a standard preset folder");safe->chooser->launchAsync(juce::FileBrowserComponent::openMode|juce::FileBrowserComponent::canSelectDirectories,[safe,id](const juce::FileChooser&c){
                if(!safe||!c.getResult().isDirectory())return;
                if(id==2){safe->extraRoots.addIfNotAlreadyThere(c.getResult().getFullPathName());dataDirectory().getChildFile("composer-vst-folders.json").replaceWithText(juce::JSON::toString(juce::var(safe->extraRoots)));safe->scanNow();}
                else{auto file=dataDirectory().getChildFile("composer-preset-folders.json");auto values=juce::JSON::parse(file);juce::StringArray paths;if(auto*items=values.getArray())for(auto&v:*items)paths.addIfNotAlreadyThere(v.toString());paths.addIfNotAlreadyThere(c.getResult().getFullPathName());if(paths.size()>16){safe->status.setText("Maximum 16 preset folders",juce::dontSendNotification);return;}bool saved=file.replaceWithText(juce::JSON::toString(juce::var(paths)));safe->status.setText(saved?"Preset folder added for automatic sound audition":"Could not save preset folders",juce::dontSendNotification);}
            });}
        });
    }
    void refreshSource(){source.setText(reference!=juce::File()?ct("Full reference",lang)+": "+reference.getFileName():loop!=juce::File()?ct("Library loop",lang)+": "+loop.getFileName():ct("Source: genre / text",lang),juce::dontSendNotification);saveDraft();}
    void chooseReference(){chooser=std::make_unique<juce::FileChooser>("Import full reference",juce::File(),"*.wav;*.mp3;*.flac;*.aiff;*.m4a;*.ogg");auto safe=juce::Component::SafePointer<Panel>(this);chooser->launchAsync(juce::FileBrowserComponent::openMode|juce::FileBrowserComponent::canSelectFiles,[safe](const juce::FileChooser&c){if(safe&&c.getResult().existsAsFile()){safe->reference=c.getResult();safe->loop={};safe->refreshSource();}});}
    void chooseInstruments(){auto s=service.snapshot();s.instruments.addArray(live::instruments(dataDirectory()));s.instruments.addArray(s.effects);juce::PopupMenu menu;for(int i=0;i<s.instruments.size();++i){auto&v=s.instruments.getReference(i);menu.addItem(i+1,v["name"].toString()+" ("+v["format"].toString()+(bool(v["instrument"])?")":" effect)"),true,selected.contains(v["uid"].toString()));}if(s.instruments.isEmpty())menu.addItem(-1,"Scan instruments first",false);auto safe=juce::Component::SafePointer<Panel>(this);menu.showMenuAsync(juce::PopupMenu::Options().withTargetComponent(&allowed),[safe,s](int id){if(safe&&juce::isPositiveAndBelow(id-1,s.instruments.size())){auto uid=s.instruments[id-1]["uid"].toString();if(safe->selected.contains(uid))safe->selected.removeString(uid);else safe->selected.add(uid);safe->allowed.setButtonText(ct("Allowed plugins",safe->lang)+": "+juce::String(safe->selected.size()));safe->saveDraft();}});}
    void generate(){const bool audioOnly=editMode.getSelectedId()==3;if(!audioOnly&&cloud&&juce::SystemStats::getEnvironmentVariable("OPENAI_API_KEY",{}).trim().isEmpty()){status.setText(lang=="ru"?juce::String::fromUTF8("Добавь OPENAI_API_KEY в Windows и перезапусти DAW или выбери локальный ИИ."): "Set OPENAI_API_KEY in Windows and restart the DAW, or choose Local AI.",juce::dontSendNotification);return;}if(noteEditor.dirty()){status.setText("Apply or revert MIDI edits first",juce::dontSendNotification);return;}Request r;r.audioBeat=audioOnly;r.editExisting=editMode.getSelectedId()==2;if(r.editExisting&&(!service.snapshot().song||service.snapshot().song->audioBeat)){status.setText("Create a beat before editing",juce::dontSendNotification);return;}r.prompt=prompt.getText();r.genre.clear();r.model=cloud?"openai":modelPath;r.reference=reference;r.loop=loop;if(!audioOnly){r.samples=catalog?catalog():nullptr;auto s=service.snapshot();s.instruments.addArray(live::instruments(dataDirectory()));for(auto&uid:selected)if(!r.editExisting&&uid.startsWith("live:")&&std::none_of(s.instruments.begin(),s.instruments.end(),[&](const auto&v){return v["uid"].toString()==uid;})){status.setText(live::connection(dataDirectory()).error,juce::dontSendNotification);return;}for(auto&v:s.instruments)if(selected.contains(v["uid"].toString()))r.instruments.add(v.clone());for(auto&v:s.effects)if(selected.contains(v["uid"].toString()))r.effects.add(v.clone());}if(service.generate(std::move(r))){log.moveCaretToEnd();log.insertTextAtCaret("\n\nYou: "+prompt.getText()+"\n");}}
    void timerCallback(){auto s=service.snapshot();if(s.revision==revision)return;revision=s.revision;status.setText(s.status=="Ready"?tr("ready",lang):s.status,juce::dontSendNotification);noteEditor.setBusy(s.busy);audioEditor.setBusy(s.busy);send.setEnabled(!s.busy&&!noteEditor.dirty());editMode.setEnabled(!s.busy&&!noteEditor.dirty());undo.setEnabled(!s.busy&&(noteEditor.isVisible()?noteEditor.grid.canUndo():s.canUndo));redo.setEnabled(!s.busy&&(noteEditor.isVisible()?noteEditor.grid.canRedo():s.canRedo));sendLive.setEnabled(!s.busy&&!noteEditor.dirty()&&s.song&&!s.song->audioBeat);scan.setEnabled(!s.busy&&editMode.getSelectedId()!=3);allowed.setEnabled(!s.busy&&editMode.getSelectedId()!=3);cancel.setEnabled(s.busy);import.setEnabled(!s.busy);useLoop.setEnabled(!s.busy);
        if(s.song!=shown){shown=s.song;if(audioEditor.isVisible())audioEditor.open(shown);if(noteEditor.isVisible()){auto id=noteEditor.grid.trackId;noteEditor.open(shown,id);if(!noteEditor.grid.track()){noteEditor.setVisible(false);viewport.setVisible(true);}}bool native=shown&&live::native(shown->project);audio.setEnabled(!native||shown->nativeMix);audio.setTooltip(native&&!shown->nativeMix?"Use Ableton Live > Render complete mix, then drag the resulting WAV":"Drag the complete rendered mix");play.setButtonText(ct("Play",lang)+(native?" / Live":""));sequencer.setSong(shown);if(shown){log.moveCaretToEnd();log.insertTextAtCaret("\nAI: "+(shown->audioBeat?juce::String():juce::String(shown->project.settings.bpm,1)+" BPM / "+juce::String(shown->project.settings.bars)+" bars\n")+shown->messages.joinIntoString("\n"));}}
        midi.setEnabled(!s.busy&&!noteEditor.dirty()&&s.song&&!s.song->audioBeat);audio.setEnabled(!s.busy&&!noteEditor.dirty()&&!(s.song&&live::native(s.song->project)&&!s.song->nativeMix));play.setEnabled(!s.busy&&!noteEditor.dirty());
        if(s.error!=lastError){lastError=s.error;if(lastError.isNotEmpty()){log.moveCaretToEnd();log.insertTextAtCaret("\n"+lastError);}}
    }
    Service&service;Shortcuts&shortcuts;juce::Component page;ShortcutPage shortcutPage;juce::TabbedComponent tabs;
    juce::TextButton close{"Library"},import{"Import reference"},useLoop{"Use selected loop"},clearSource{"Clear"},model{"Local AI model"},scan{"Scan VST2 / VST3"},allowed{"Allowed plugins: 0"},sendLive{"Ableton Live..."},send{"Create beat"},cancel{"Cancel"},play{"Play"},stop{"Stop"},folder{"Exported files"},undo{"Undo"},redo{"Redo"};
    ExportDrag midi,audio;juce::Label source,status;juce::ComboBox editMode;juce::TextEditor prompt,log;juce::Viewport viewport;Sequencer sequencer;NoteEditor noteEditor;AudioRegionEditor audioEditor;
    juce::File reference,loop;juce::String lang="en",modelPath,lastError,welcomeText;juce::StringArray selected,extraRoots;std::unique_ptr<juce::FileChooser>chooser;int revision=-1;std::shared_ptr<const Song>shown;
};
}
