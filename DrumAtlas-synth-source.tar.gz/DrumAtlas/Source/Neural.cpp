#define NOMINMAX
#include "Neural.h"
#include "ContentHash.h"
#include "DrumSpectralCleanup.h"
#define ORT_API_MANUAL_INIT
#include <onnxruntime_cxx_api.h>
#include "Platform.h"
#include <mutex>
#include <cmath>
#include <complex>
#include <juce_cryptography/juce_cryptography.h>
#if JUCE_WINDOWS
#include <windows.h>
#include <dxgi1_2.h>
#endif

namespace atlas {
static void* atlasRuntimeModule=nullptr;
static juce::File modelFolder(){return bundledModels();}
static void initialiseAtlasRuntime(){
            static std::once_flag flag; static juce::String runtimeError;
            std::call_once(flag, [] {
                #if JUCE_WINDOWS
                auto path=modelFolder().getChildFile("onnxruntime.dll");
#else
                auto path=modelFolder().getChildFile("libonnxruntime.dylib");
#endif
                auto dll=loadNativeLibrary(path);
                if(!dll){runtimeError="AI runtime: "+nativeLibraryError();return;}
                auto getApi=reinterpret_cast<const OrtApiBase*(ORT_API_CALL*)()>(nativeSymbol(dll,"OrtGetApiBase"));
                const auto* api = getApi ? getApi()->GetApi(ORT_API_VERSION) : nullptr;
                if (!api) { runtimeError = "Unsupported ONNX Runtime"; return; }
                Ort::InitApi(api); atlasRuntimeModule=dll;
                // Retain this module for process lifetime: sessions from different plugin instances share its API.
            });
            if (runtimeError.isNotEmpty()) throw std::runtime_error(runtimeError.toStdString());
}
struct Neural::Impl {
    juce::String problem;
    std::unique_ptr<Ort::Env> env;
    std::unique_ptr<Ort::Session> session;
    Impl() {
        try {
            initialiseAtlasRuntime();
            env = std::make_unique<Ort::Env>(ORT_LOGGING_LEVEL_ERROR, "DrumAtlas");
            Ort::SessionOptions opts; opts.SetIntraOpNumThreads(1); opts.SetInterOpNumThreads(1);
            opts.SetGraphOptimizationLevel(GraphOptimizationLevel::ORT_ENABLE_ALL);
            session = std::make_unique<Ort::Session>(*env, ATLAS_ORT_PATH(modelFolder().getChildFile("yamnet.onnx")), opts);
        } catch (const std::exception& e) { problem = juce::String::fromUTF8(e.what()); }
    }
};
Neural::Neural() : impl(std::make_unique<Impl>()) {}
Neural::~Neural() = default;
bool Neural::available() const { return impl->session != nullptr; }
juce::String Neural::error() const { return impl->problem; }
NeuralResult Neural::analyse(const std::vector<float>& audio) {
    NeuralResult result; if (!available() || audio.empty()) return result;
    try {
        // YAMNet expects mono PCM at 16 kHz and at least 0.975 seconds. Short one-shots are zero padded.
        size_t first = 0; float peak = 0;
        for (auto v : audio) peak = std::max(peak, std::abs(v));
        if (peak < 1e-7f) return result;
        while (first + 1 < audio.size() && std::abs(audio[first]) < peak * 0.01f) ++first;
        const int samples = std::min(80000, int((audio.size() - first) * 16000.0 / analysisRate));
        std::vector<float> input(size_t(std::max(15600, samples)), 0);
        for (int i = 0; i < samples; ++i) {
            const double pos = first + i * analysisRate / 16000.0;
            const auto a = std::min(audio.size() - 1, size_t(pos)), b = std::min(audio.size() - 1, a + 1);
            input[size_t(i)] = float((audio[a] + (audio[b] - audio[a]) * (pos - a)) * (0.8 / peak));
        }
        int64_t dim = int64_t(input.size()); auto memory = Ort::MemoryInfo::CreateCpu(OrtArenaAllocator, OrtMemTypeDefault);
        auto tensor = Ort::Value::CreateTensor<float>(memory, input.data(), input.size(), &dim, 1);
        const char* inputName = "waveform"; const char* outputNames[] = {"output_0", "output_1"};
        auto output = impl->session->Run(Ort::RunOptions{nullptr}, &inputName, &tensor, 1, outputNames, 2);
        const auto scoreShape = output[0].GetTensorTypeAndShapeInfo().GetShape();
        if (scoreShape.size() != 2 || scoreShape[1] != 521 || scoreShape[0] < 1) return result;
        std::array<float, 521> scores{}; const auto* raw = output[0].GetTensorData<float>();
        for (int64_t row = 0; row < scoreShape[0]; ++row)
            for (int k = 0; k < 521; ++k) scores[size_t(k)] = std::max(scores[size_t(k)], raw[row * 521 + k]);
        const auto add = [&](const char* category, std::initializer_list<int> ids) {
            float confidence = 0; for (int id : ids) confidence = std::max(confidence, scores[size_t(id)]);
            if (confidence >= 0.08f) result.instruments.emplace_back(category, confidence);
        };
        add("Vocal", {0,1,2,3,6,9,24,25,26,27,29,30,31,32,249,250});
        add("Kick", {163}); add("Snare", {160}); add("Rim", {161}); add("Clap", {58});
        add("Closed Hat", {167}); add("Cymbal", {166}); add("Percussion", {156,157,158,159,164,165,168,169,170,171,172,174,175});
        add("Bass", {137,189}); add("Guitar", {135,136,138,139,142,143,144,146});
        add("Keys", {147,148,149,150,151,152,155}); add("Synth", {153,208});
        add("Strings", {179,184,185,186,187,188,194}); add("Brass", {180,181,182,183}); add("Instrument", {190,191,192,193,203,204,205,206});
        std::sort(result.instruments.begin(), result.instruments.end(), [](const auto& a, const auto& b){return a.second > b.second;});
        const std::vector<std::pair<const char*,std::vector<int>>> genreMap {
            {"Hip-Hop",{212}}, {"Electronic",{234,239,240}}, {"House",{235}}, {"Techno",{236}}, {"Drum & Bass",{238}},
            {"Dubstep",{237}}, {"Trance",{242}}, {"Ambient",{241}}, {"Rock",{214,215,216,217,218,219,220}},
            {"Pop",{211}}, {"Jazz",{225,230}}, {"Classical",{232,233}}, {"Folk",{228,259}}, {"Funk",{227}},
            {"R&B / Soul",{221,222}}, {"Reggae",{223,258}}, {"Latin",{243,244,245}}, {"Blues",{246}}, {"Country",{224,226}} };
        std::vector<std::pair<juce::String,float>> genres;
        if (audio.size() >= size_t(analysisRate * 2.0)) for (const auto& entry : genreMap) {
            float value = 0; for (int id : entry.second) value = std::max(value, scores[size_t(id)]);
            if (value >= 0.18f) genres.emplace_back(entry.first, value);
        }
        std::sort(genres.begin(), genres.end(), [](const auto& a, const auto& b){return a.second > b.second;});
        for (size_t i = 0; i < std::min(size_t(3),genres.size()); ++i) result.genres.add(genres[i].first);
        const auto shape = output[1].GetTensorTypeAndShapeInfo().GetShape();
        if (shape.size() == 2 && shape[1] == 1024 && shape[0] > 0) {
            std::array<float,1024> embedding{}; auto* values = output[1].GetTensorData<float>(); float largest = 0;
            for (int64_t row = 0; row < shape[0]; ++row) for (int k = 0; k < 1024; ++k) embedding[size_t(k)] += values[row * 1024 + k];
            for (float value : embedding) largest = std::max(largest, value);
            if (largest > 1e-10f) { result.embedding.resize(1024);
                for (size_t i = 0; i < 1024; ++i) result.embedding[i] = uint8_t(juce::jlimit(0,255,int(std::round(embedding[i] * 255 / largest)))); }
        }
        result.valid = true;
    } catch (const std::exception& e) { impl->problem = juce::String::fromUTF8(e.what()); }
    return result;
}
#include "Acceleration.inc"
#include "VocalGpu.inc"
struct StemSeparator::Impl {
 juce::String problem;std::unique_ptr<Ort::Env>env;std::unique_ptr<Ort::Session>session;std::unique_ptr<VocalGpuSession>gpu;Model model;int cpuThreads=0;
 Impl(Model selected,int threads,bool allowGpu):model(selected){try{
   initialiseAtlasRuntime();
   cpuThreads=threads;
   if(model==CleanVocals&&allowGpu){gpu=std::make_unique<VocalGpuSession>();if(gpu->available())return;gpu.reset();}
   env=std::make_unique<Ort::Env>(ORT_LOGGING_LEVEL_ERROR,"DrumAtlas stems");
   // CPU only: this RoFormer graph can hang the tested DirectML device.
   env->DisableTelemetryEvents();session=preparedCpuSession(*env,modelFolder().getChildFile(model==CleanVocals?"melband_roformer_vocals.onnx":model==FineDrums?"htdemucs_ft_drums.onnx":model==FineBass?"htdemucs_ft_bass.onnx":model==FineVocals?"htdemucs_ft_vocals.onnx":"htdemucs_6s.onnx"),threads);
   if(session->GetInputCount()!=1||session->GetOutputCount()!=1)throw std::runtime_error("Unexpected stem model interface");
 }catch(const std::exception&e){problem=juce::String::fromUTF8(e.what());session.reset();}}
};
StemSeparator::StemSeparator(bool drums):StemSeparator(drums?FineDrums:General){}
StemSeparator::StemSeparator(Model model,int threads,bool allowGpu):impl(std::make_unique<Impl>(model,threads,allowGpu)){}StemSeparator::~StemSeparator()=default;
bool StemSeparator::available()const{return impl->session!=nullptr||(impl->gpu&&impl->gpu->available());}juce::String StemSeparator::error()const{return impl->problem;}
bool StemSeparator::usesGpu()const{return impl->gpu&&impl->gpu->available();}
std::vector<std::vector<float>> StemSeparator::process(const std::vector<float>&audio,const std::function<bool()>&cancelled){
 if(!available()||audio.size()!=size_t(frames*2))throw std::runtime_error("Stem model or input is unavailable");
 if(impl->model==CleanVocals){
  constexpr int modelFrames=352800;
  // Pad each channel independently; padding the flattened stereo vector would
  // move the right channel into the left channel's tail and corrupt alignment.
  std::vector<float>padded(modelFrames*2,0.f);
  for(int c=0;c<2;++c)std::copy_n(audio.data()+c*frames,frames,padded.data()+c*modelFrames);
  if(impl->gpu){std::vector<float>gpuAudio;if(impl->gpu->run(padded,gpuAudio,cancelled)){
   std::vector<std::vector<float>>result(6);result[3].resize(frames*2);for(int c=0;c<2;++c)std::copy_n(gpuAudio.data()+c*modelFrames,frames,result[3].data()+c*frames);return result;
  }impl->gpu.reset();if(cancelled&&cancelled())return std::vector<std::vector<float>>(6);impl->env=std::make_unique<Ort::Env>(ORT_LOGGING_LEVEL_ERROR,"DrumAtlas vocal CPU fallback");impl->env->DisableTelemetryEvents();impl->session=preparedCpuSession(*impl->env,modelFolder().getChildFile("melband_roformer_vocals.onnx"),impl->cpuThreads);}
  auto memory=Ort::MemoryInfo::CreateCpu(OrtArenaAllocator,OrtMemTypeDefault);const int64_t shape[]{1,2,modelFrames};
  auto input=Ort::Value::CreateTensor<float>(memory,padded.data(),padded.size(),shape,3);
  const char*in="mix";const char*out="sources";auto output=impl->session->Run(Ort::RunOptions{nullptr},&in,&input,1,&out,1);
  auto info=output[0].GetTensorTypeAndShapeInfo();
  if(info.GetElementType()!=ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT||info.GetShape()!=std::vector<int64_t>{1,2,2,modelFrames})throw std::runtime_error("Unexpected clean vocal output shape");
  const auto*data=output[0].GetTensorData<float>();std::vector<std::vector<float>>result(6);result[3].resize(frames*2);
  for(int c=0;c<2;++c)std::copy_n(data+c*modelFrames,frames,result[3].data()+c*frames);
  for(auto v:result[3])if(!std::isfinite(v))throw std::runtime_error("Non-finite clean vocal output");
  return result; // Model source 1 is residual accompaniment, never a vocal.
 }
 auto memory=Ort::MemoryInfo::CreateCpu(OrtArenaAllocator,OrtMemTypeDefault);const int64_t shape[]{1,2,frames};
 auto input=Ort::Value::CreateTensor<float>(memory,const_cast<float*>(audio.data()),audio.size(),shape,3);
 const char*in="mix";const char*out="stems";auto outputs=impl->session->Run(Ort::RunOptions{nullptr},&in,&input,1,&out,1);
 auto info=outputs[0].GetTensorTypeAndShapeInfo();if(info.GetShape()!=std::vector<int64_t>{1,impl->model==General?6:4,2,frames})throw std::runtime_error("Unexpected stem output shape");
 const float*data=outputs[0].GetTensorData<float>();std::vector<std::vector<float>>result(6);
 for(size_t i=0;i<6;++i){if(impl->model==FineDrums&&i!=0)continue;if(impl->model==FineBass&&i!=1)continue;if(impl->model==FineVocals&&i!=3)continue;result[i].assign(data+i*frames*2,data+(i+1)*frames*2);for(auto v:result[i])if(!std::isfinite(v))throw std::runtime_error("Non-finite stem output");}return result;
}
#include "DetailModels.inc"
juce::StringArray genreNames() {
    return {"Unknown","Hip-Hop","Trap","Electronic","House","Techno","Drum & Bass","Dubstep","Trance","Ambient","Rock","Pop","Jazz","Classical","Folk","Funk","R&B / Soul","Reggae","Latin","Blues","Country"};
}
juce::StringArray genreTags(const juce::String& path) {
    auto s = " " + path.toLowerCase().replaceCharacters("_-/\\.()", "       ") + " ";
    juce::StringArray out;
    const std::vector<std::pair<const char*, const char*>> tags {{"hip hop","Hip-Hop"},{"hiphop","Hip-Hop"},{"trap","Trap"},{"techno","Techno"},{"house","House"},{"dnb","Drum & Bass"},{"drum and bass","Drum & Bass"},{"dubstep","Dubstep"},{"trance","Trance"},{"ambient","Ambient"},{"rock","Rock"},{"metal","Rock"},{"pop","Pop"},{"jazz","Jazz"},{"classical","Classical"},{"folk","Folk"},{"funk","Funk"},{"soul","R&B / Soul"},{"reggae","Reggae"},{"latin","Latin"},{"blues","Blues"},{"country","Country"},{"edm","Electronic"}};
    for (const auto& pair : tags) if (s.contains(" " + juce::String(pair.first) + " ")) out.addIfNotAlreadyThere(pair.second);
    return out;
}
}

#include "StemNotes.inc"
