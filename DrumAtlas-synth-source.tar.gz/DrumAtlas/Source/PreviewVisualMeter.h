#pragma once
#include <algorithm>
#include <array>
#include <atomic>
#include <cmath>
#include <cstdint>

namespace atlas {
struct PreviewVisualLevels { float level=0, bass=0, treble=0, peak=0; };

// Audio-thread-owned filters. Only published atomics are read by the editor.
// Measures the preview contribution, not the DAW's incoming signal.
class PreviewVisualMeter {
public:
    void begin(double sampleRate, std::uint64_t generation) noexcept {
        if (rate == sampleRate && epoch == generation) return;
        rate=sampleRate; epoch=generation; low={}; highLow={}; energy={}; transient=0;
        const double safeRate=std::max(1000.0,sampleRate);
        lowCoefficient=float(1-std::exp(-6.283185307179586*200/safeRate));
        highCoefficient=float(1-std::exp(-6.283185307179586*2500/safeRate));
        attack=float(1-std::exp(-1/(.005*safeRate)));
        release=float(1-std::exp(-1/(.14*safeRate)));
        peakDecay=float(std::exp(-1/(.10*safeRate)));
    }
    void push(float left,float right) noexcept {
        float total=0,bass=0,treble=0,peak=0;
        const float values[]={left,right};
        for(int ch=0;ch<2;++ch){
            const float x=std::isfinite(values[ch])?std::clamp(values[ch],-16.f,16.f):0.f;
            low[ch]+=lowCoefficient*(x-low[ch]);
            highLow[ch]+=highCoefficient*(x-highLow[ch]);
            total+=x*x; bass+=low[ch]*low[ch];
            const float high=x-highLow[ch]; treble+=high*high;
            peak=std::max(peak,std::abs(x));
        }
        const float targets[]={total*.5f,bass*.5f,treble*.5f};
        for(int i=0;i<3;++i)energy[i]+=(targets[i]>energy[i]?attack:release)*(targets[i]-energy[i]);
        transient=std::max(peak,transient*peakDecay);
    }
    void publish() noexcept {
        for(int i=0;i<3;++i)published[i].store(std::sqrt(std::max(0.f,energy[i])),std::memory_order_relaxed);
        published[3].store(transient,std::memory_order_relaxed);
    }
    PreviewVisualLevels read() const noexcept {
        return {published[0].load(std::memory_order_relaxed),published[1].load(std::memory_order_relaxed),
                published[2].load(std::memory_order_relaxed),published[3].load(std::memory_order_relaxed)};
    }
private:
    static_assert(std::atomic<float>::is_always_lock_free,"Visual meters must not lock the audio thread");
    std::array<std::atomic<float>,4> published{};
    std::array<float,2> low{},highLow{};std::array<float,3> energy{};
    double rate=0;std::uint64_t epoch=0;
    float lowCoefficient=0,highCoefficient=0,attack=0,release=0,peakDecay=0,transient=0;
};
}
