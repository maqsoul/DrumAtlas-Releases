#pragma once
#include "MusicCore.h"

namespace atlas::composer {
inline juce::Result spliceArrangement(music::Project&project,int first,int end,int destination,bool duplicate){
    const auto fail=[](const char*message){return juce::Result::fail(message);};
    if(first<0||end<=first||end>project.settings.bars||destination<0||destination>project.settings.bars)return fail("Invalid section range");
    if(!project.tempos.empty())return fail("Section splicing with a tempo map is not supported");
    for(auto&t:project.tracks)if(t.midiLocked)return fail("Unlock MIDI before changing section positions");
    auto*sections=project.sections.getArray();if(!sections)return fail("The song has no section markers");
    auto boundary=[&](int bar){if(bar==project.settings.bars)return true;for(auto&section:*sections)if(int(section["start"])==bar)return true;return false;};
    if(!boundary(first)||!boundary(end)||(duplicate&&!boundary(destination)))return fail("Choose complete sections and a section boundary");
    const int count=end-first,newBars=project.settings.bars+(duplicate?count:-count);if(newBars<1||newBars>4096)return fail("Song length must remain 1..4096 bars");
    auto next=project;next.settings.bars=newBars;const auto bar=music::barTicks(next.settings),from=first*bar,to=end*bar,at=destination*bar,length=count*bar;
    for(auto&track:next.tracks){auto original=track.notes;track.notes.clear();
        auto add=[&](music::Note note,int64_t begin,int64_t finish,bool copy){if(finish<=begin)return;note.tick=begin;note.microtiming=0;note.duration=finish-begin;note.glideTicks=int(std::min<int64_t>(note.glideTicks,note.duration));if(copy)note.id=juce::Uuid().toString().removeCharacters("-");track.notes.push_back(note);};
        for(auto&note:original){auto begin=note.tick+note.microtiming,finish=begin+note.duration;
            if(duplicate){if(begin>=at)add(note,begin+length,finish+length,false);else if(finish>at)add(note,begin,at,false);else track.notes.push_back(note);
                if(begin<to&&finish>from)add(note,at+std::max(begin,from)-from,at+std::min(finish,to)-from,true);
            }else{if(finish<=from)track.notes.push_back(note);else if(begin>=to)add(note,begin-length,finish-length,false);else if(begin<from)add(note,begin,from,false);else if(finish>to)add(note,from,finish-length,false);}
        }
        auto controls=track.controls;track.controls.clear();for(auto event:controls){auto tick=event.tick;if(duplicate){if(tick>=at)event.tick+=length;track.controls.push_back(event);if(tick>=from&&tick<to){event.tick=at+tick-from;event.id=juce::Uuid().toString().removeCharacters("-");track.controls.push_back(event);}}else if(tick<from)track.controls.push_back(event);else if(tick>=to){event.tick-=length;track.controls.push_back(event);}}
        std::stable_sort(track.notes.begin(),track.notes.end(),[](auto&a,auto&b){return a.tick<b.tick;});std::stable_sort(track.controls.begin(),track.controls.end(),[](auto&a,auto&b){return a.tick<b.tick;});
    }
    juce::Array<juce::var>markers;
    for(auto&section:*sections){int start=int(section["start"]),bars=int(section["bars"]);auto marker=section.clone();if(duplicate){if(start>=destination)marker.getDynamicObject()->setProperty("start",start+count);markers.add(marker);if(start>=first&&start+bars<=end){auto copy=section.clone();copy.getDynamicObject()->setProperty("start",destination+start-first);markers.add(copy);}}else if(start<first)markers.add(marker);else if(start>=end){marker.getDynamicObject()->setProperty("start",start-count);markers.add(marker);}}
    std::stable_sort(markers.begin(),markers.end(),[](auto&a,auto&b){return int(a["start"])<int(b["start"]);});if(markers.size()>64)return fail("Section count exceeds 64");next.sections=markers;
    auto result=music::validate(next);if(result.failed())return result;result=music::verifyLockedContent(project,next);if(result.wasOk())project=std::move(next);return result;
}
}
