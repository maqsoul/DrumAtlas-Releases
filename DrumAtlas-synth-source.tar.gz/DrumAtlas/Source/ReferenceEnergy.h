#pragma once
#include <vector>
#include <cmath>
#include <algorithm>
namespace atlas {
struct EnergyPoint {double start=0,duration=0,rms=0;};
inline void appendReferenceEnergy(std::vector<EnergyPoint>&out,const std::vector<float>&audio,double rate,double context,double start,double end){
 if(!std::isfinite(rate)||rate<=0||!std::isfinite(context)||!std::isfinite(start)||!std::isfinite(end)||start<context||end<=start)return;
 for(double time=start;time<end;time+=1){double finish=std::min(end,time+1);auto first=std::min(audio.size(),size_t(std::max(0.,std::round((time-context)*rate))));auto last=std::min(audio.size(),size_t(std::max(0.,std::round((finish-context)*rate))));if(last<=first)continue;double sum=0;bool valid=true;for(auto i=first;i<last;++i){if(!std::isfinite(audio[i])){valid=false;break;}sum+=double(audio[i])*audio[i];}if(valid)out.push_back({time,finish-time,std::sqrt(sum/double(last-first))});
 }
}
inline std::vector<double> energyTransitions(const std::vector<EnergyPoint>&points){
 std::vector<double>result;for(size_t i=2;i+1<points.size();++i){bool valid=true;for(size_t k=i-2;k<=i+1;++k){auto&p=points[k];if(!std::isfinite(p.start)||!std::isfinite(p.duration)||!std::isfinite(p.rms)||p.duration<=0||p.rms<0)valid=false;if(k>i-2&&std::abs(points[k-1].start+points[k-1].duration-p.start)>.01)valid=false;}if(!valid)continue;double before=(points[i-2].rms+points[i-1].rms)*.5,after=(points[i].rms+points[i+1].rms)*.5;if(std::max(before,after)<1e-4)continue;double change=20*std::log10(std::max(after,1e-6)/std::max(before,1e-6));if(std::abs(change)>=6&&(result.empty()||points[i].start-result.back()>=4))result.push_back(points[i].start);}return result;
}
}
