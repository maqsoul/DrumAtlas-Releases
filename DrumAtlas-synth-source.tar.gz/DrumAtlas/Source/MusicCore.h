#pragma once
#include <juce_audio_basics/juce_audio_basics.h>
#include <cstdint>
#include <vector>
#include "MusicProfiles.h"
#include "MusicScales.h"

namespace atlas::music {
constexpr int ppq = 960;
struct Note {
    juce::String id;
    int pitch=60, velocity=90, channel=1;
    int64_t tick=0, duration=240, microtiming=0;
    double probability=1;
    int glideFrom=0, glideTicks=0, bendRange=12; // Relative semitones to target; 0 ticks disables glide.
    juce::String articulation="normal"; // normal, ghost, accent, roll; dynamics remain explicit.
};
// Event-local decision: identical for full/selected MIDI, built-in and VST rendering.
inline bool playsNote(uint32_t seed,const Note&n){
 uint32_t hash=2166136261u^seed;for(unsigned char c:n.id.toStdString()){hash^=c;hash*=16777619u;}
 hash^=hash>>16;hash*=0x7feb352du;hash^=hash>>15;hash*=0x846ca68bu;hash^=hash>>16;
 return double(hash)/4294967296.<n.probability;
}
struct ControlEvent { juce::String id,kind="cc"; int64_t tick=0; int channel=1,number=1,value=0; };
struct Track {
    juce::String id, role, soundPath, liveDevice; // Live-native instrument; rendered only by the companion.
    // Optional schema-2 instrument descriptor and saved opaque VST3 state.
    juce::var instrument, effects;
    bool midiLocked=false, soundLocked=false;
    std::vector<Note> notes;
    juce::String customName; // Nonempty only for user-created drum lanes.
    std::vector<ControlEvent> controls;
    int sampleRoot=60; // Source one-shot MIDI root; drums ignore pitched transposition.
    int drumNote=-1; // -1: legacy/default GM mapping; otherwise user lane note.
};
inline bool modernProfileVersion(const juce::String&v){return v=="profiles-3"||v=="profiles-4";}
inline bool expressiveProfileVersion(const juce::String&v){return v=="profiles-2"||modernProfileVersion(v);}
inline bool profileVersion(const juce::String&v){return v=="profiles-1"||expressiveProfileVersion(v);}
inline juce::StringArray generationRoles(){return {"Kick","Snare","Clap","Closed Hat","Open Hat","Percussion","Bass","Chords","Melody","Countermelody","FX"};}
struct Settings {
    juce::StringArray activeRoles{"Kick","Snare","Clap","Closed Hat","Open Hat","Percussion","Bass","Chords","Melody"};
    double genreInfluence=1;
    double bpm=140, swing=0, humanize=0.1, density=0.5;
    double energy=.5,darkness=.5,complexity=.5,groove=.5,melodicDensity=.5;
    // Optional profiles-4 refinements. -1 preserves the original generator;
    // .5 is neutral. These are explicit controls, not measured audio features.
    double hatsDensity=-1,drumAccents=-1;
    int bars=4, numerator=4, denominator=4, tonic=9;
    uint32_t seed=45192;
    double variationAmount=1;
    bool keepGroove=false;
    juce::String genre="Trap", mood="Dark", scale="minor";
};
struct TempoPoint {int64_t tick=0;double bpm=120;};
struct Project {
    juce::String id, generatorVersion="rules-1";
    Settings settings;
    std::vector<Track> tracks;
    juce::var styleSnapshot, harmony, sections, assets;
    std::vector<TempoPoint> tempos;
    juce::var comparisonA, comparisonB, comparisonC; // Flat snapshots; never contain other slots.
    bool hatChoke=false;
};
inline std::vector<int64_t> hatClosures(const Project&p){std::vector<int64_t> ticks;if(p.hatChoke)for(auto&t:p.tracks)if(t.role=="Closed Hat")for(auto&n:t.notes)if(playsNote(p.settings.seed,n))ticks.push_back(n.tick+n.microtiming);std::sort(ticks.begin(),ticks.end());ticks.erase(std::unique(ticks.begin(),ticks.end()),ticks.end());return ticks;}
inline int64_t hatCut(const Track&t,const Note&n,const std::vector<int64_t>&closed){if(t.role!="Open Hat")return -1;auto it=std::lower_bound(closed.begin(),closed.end(),n.tick+n.microtiming);return it==closed.end()?-1:*it;}
inline juce::String trackName(const Track&t){return t.customName.isEmpty()?t.role:t.customName;}
inline bool validLiveDevice(const juce::String&name){return juce::StringArray{"Analog","Collision","Drift","Electric","Meld","Operator","Tension","Wavetable"}.contains(name)||(name.startsWith("Live track: ")&&name.length()>12&&name.length()<=92&&!name.containsAnyOf("\r\n"));}
// SHA-256 of protected event/state content; no paths or state blobs in the report.
juce::var lockedContentHashes(const Project&);
juce::Result verifyLockedContent(const Project& before,const Project& after);
juce::Result setTempoPoint(Project&,int64_t tick,double bpm);
juce::Result removeTempoPoint(Project&,int64_t tick);
juce::Result setControlEvent(Project&,const juce::String&track,const ControlEvent&);
juce::Result removeControlEvent(Project&,const juce::String&track,const juce::String&id);
juce::Result makeBassMonophonic(Project&);
juce::Result captureComparison(Project&,int slot);
juce::Result restoreComparison(Project&,int slot);
// Copy one complete part (MIDI and sounds), preserving the source slots and other current parts.
juce::Result combineComparison(Project&,int slot,const juce::String& part);
juce::Result clearComparison(Project&,int slot);
// Atomic multi-part combination; slot -1 keeps the current part.
juce::Result combineComparisons(Project&,int drums,int bass,int chords,int melody);
juce::Result addDrumLane(Project&,const juce::String& name,const juce::String& role,int pitch);
juce::Result renameDrumLane(Project&,const juce::String& id,const juce::String& name);
juce::Result removeDrumLane(Project&,const juce::String& id);
int gmDrumNote(const juce::String& role);
juce::Result setDrumNote(Project&,const juce::String& track,int pitch);
juce::Result validate(const Project&);
juce::Result validate(const Settings&);
Project generate(const Settings&);
juce::Result generateStyled(const Settings&,const ProfileRegistry&,const std::vector<StyleWeight>& genres,const std::vector<StyleWeight>& moods,Project&,const juce::String& version="profiles-4");
// Atomic edit: locks and tracks outside the scope retain their exact state.
juce::Result regenerate(Project&, const juce::String& trackId, int firstBar, int endBar, uint32_t seed);
juce::var encode(const Project&);
juce::Result decode(const juce::var&, Project&);
juce::Result save(const Project&, const juce::File&);
juce::Result load(const juce::File&, Project&);
// Empty trackId exports the entire song. A selected track retains its song timing.
juce::Result exportMidi(const Project&, const juce::File&, const juce::String& trackId = {});
int64_t barTicks(const Settings&);
bool validGrid(int steps);
int64_t gridTick(const Settings&,int bar,int step,int steps);
juce::Result setArticulation(Project&,const juce::String&track,const juce::StringArray&ids,const juce::String&articulation);
juce::Result editNote(Project&,const juce::String& track,const Note& replacement);
// Move a group with a common, boundary-clamped offset; preserve intervals and microtiming.
juce::Result moveNotes(Project&,const juce::String& track,const juce::StringArray& ids,int64_t ticks,int semitones);
enum class NoteField { Velocity, Duration, Microtiming, Probability };
// Absolute value for every selected note; one atomic transaction.
juce::Result setNoteValues(Project&,const juce::String& track,const juce::StringArray& ids,NoteField,double value);
juce::Result quantizeNotes(Project&,const juce::String& track,const juce::StringArray& ids,int steps);
// Split each selected drum note inside its existing duration; velocity endpoints are percentages.
juce::Result fillDrums(Project&,const juce::String& track,int bar,int beats,int steps,uint32_t seed,double density=-1,double energy=-1);
juce::Result rollNotes(Project&,const juce::String& track,const juce::StringArray& ids,int hits,int startPercent,int endPercent,juce::StringArray* created=nullptr);
juce::Result removeNote(Project&,const juce::String& track,const juce::String& note);
juce::Result copyBars(Project&,const juce::String& track,int first,int end,int destination);
class History {
public:
    explicit History(Project initial,size_t historyBudget=64u*1024u*1024u): current(std::move(initial)),budget(historyBudget) {}
    const Project& project()const{return current;}
    juce::Result apply(Project);
    bool undo(); bool redo();
    juce::var commandJournal()const{return journal.clone();}
    void recordCommand(const juce::var& entry);
    juce::var serialize()const;
    juce::Result restore(const juce::var&);
    juce::Result saveSession(const juce::File&)const;
    juce::Result loadSession(const juce::File&);
private:
    struct Snapshot { Project project;size_t bytes=0; };
    void trimHistory();
    static Snapshot snapshot(const Project& p);
    juce::var journal{juce::Array<juce::var>{}};
    Project current;
    size_t budget;bool memoryTrimmed=false;
    std::vector<Snapshot> past,future;
};
}
