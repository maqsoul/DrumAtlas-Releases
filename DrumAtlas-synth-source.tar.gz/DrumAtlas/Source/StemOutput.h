#pragma once
#include <juce_audio_formats/juce_audio_formats.h>
#include <stdexcept>

namespace atlas {
// Model estimates can exceed 0 dBFS even for an unclipped mixture. Preserve them
// both between separator stages and in exported files; never saturate to PCM24.
inline std::unique_ptr<juce::AudioFormatWriter> createStemWriter(const juce::File& file,double rate,int channels){
 std::unique_ptr<juce::OutputStream> stream=file.createOutputStream();
 if(!stream)throw std::runtime_error("Cannot write stem cache");
 juce::WavAudioFormat wav;
 auto options=juce::AudioFormatWriterOptions{}.withSampleRate(rate).withNumChannels(channels)
     .withBitsPerSample(32).withSampleFormat(juce::AudioFormatWriterOptions::SampleFormat::floatingPoint);
 auto writer=wav.createWriterFor(stream,options);
 if(!writer)throw std::runtime_error("Cannot create floating-point stem WAV");
 return writer;
}
}
