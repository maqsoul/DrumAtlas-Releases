#pragma once
#include <juce_core/juce_core.h>
#include <array>
#include <cmath>
namespace atlas::hosting::ipc {
constexpr int version=1;
constexpr int maxMessageBytes=32*1024*1024;
constexpr juce::uint32 magic=0x44414831;
// Sample libraries can legitimately take several minutes to restore. Other
// control requests retain their short bound; cancellation still closes the pipe.
inline int maximumTimeout(const juce::String&operation){return operation=="CREATE"||operation=="SET_STATE"||operation=="PREPARE"?600000:120000;}
inline bool identifier(const juce::String&value){return value.length()>=16&&value.length()<=64&&value.containsOnly("0123456789abcdefABCDEF-");}
inline bool integer(const juce::var&value){return value.isInt()||value.isInt64();}
struct Request {juce::String id,instance,operation;juce::int64 deadline=0;juce::var payload;};
struct Failure {juce::String code,message;explicit operator bool()const{return code.isNotEmpty();}};
inline Failure decodeRequest(const juce::var&value,const juce::String&instance,const juce::String&token,juce::int64 now,Request&request){
    if(!value.isObject()||value.getDynamicObject()->getProperties().size()!=7)return {"E_PROTOCOL","Invalid control envelope"};
    for(const auto&property:value.getDynamicObject()->getProperties())if(!juce::StringArray{"protocol","request_id","instance_id","token","deadline_ms","operation","payload"}.contains(property.name.toString()))return {"E_PROTOCOL","Unknown control envelope field"};
    if(!value["protocol"].isInt()||int(value["protocol"])!=version)return {"E_PROTOCOL","Unsupported control protocol"};
    if(!value["token"].isString()||value["token"].toString()!=token)return {"E_AUTH","Invalid connection token"};
    if(!value["request_id"].isString()||!identifier(value["request_id"].toString())||!value["instance_id"].isString()||value["instance_id"].toString()!=instance)return {"E_INSTANCE","Request or instance identity mismatch"};
    if(!integer(value["deadline_ms"])||juce::int64(value["deadline_ms"])<=now||juce::int64(value["deadline_ms"])>now+maximumTimeout(value["operation"].toString()))return {"E_DEADLINE","Expired or excessive request deadline"};
    if(!value["operation"].isString()||!juce::StringArray{"HELLO","CAPS","CREATE","PREPARE","PROCESS","MIDI","GUI_OPEN","GUI_CLOSE","GET_STATE","SET_STATE","SUSPEND","RESUME","CLOSE"}.contains(value["operation"].toString())||!value["payload"].isObject())return {"E_OPERATION","Unknown operation or invalid payload"};
    Request next;next.id=value["request_id"].toString();next.instance=instance;next.operation=value["operation"].toString();next.deadline=juce::int64(value["deadline_ms"]);next.payload=value["payload"];request=std::move(next);return {};
}
inline juce::var encodeRequest(const juce::String&instance,const juce::String&token,const juce::String&operation,juce::var payload,int timeout=10000){
    auto*o=new juce::DynamicObject;o->setProperty("protocol",version);o->setProperty("request_id",juce::Uuid().toString());o->setProperty("instance_id",instance);o->setProperty("token",token);o->setProperty("deadline_ms",juce::Time::currentTimeMillis()+juce::jlimit(1,maximumTimeout(operation),timeout));o->setProperty("operation",operation);o->setProperty("payload",payload.isObject()?payload:juce::var(new juce::DynamicObject));return o;
}
inline juce::var reply(const juce::var&request,const juce::String&instance,const Failure&failure={},juce::var payload={}){
    auto*o=new juce::DynamicObject;o->setProperty("protocol",version);o->setProperty("request_id",request["request_id"]);o->setProperty("instance_id",instance);o->setProperty("operation",request["operation"]);o->setProperty("time_ms",juce::Time::currentTimeMillis());o->setProperty("ok",!bool(failure));o->setProperty("error_code",failure?failure.code:"OK");o->setProperty("error",failure.message);o->setProperty("payload",payload.isObject()?payload:juce::var(new juce::DynamicObject));return o;
}
inline Failure validateReply(const juce::var&request,const juce::var&response){
    if(!response.isObject()||!response["protocol"].isInt()||int(response["protocol"])!=version||response["request_id"].toString()!=request["request_id"].toString()||response["instance_id"].toString()!=request["instance_id"].toString()||response["operation"].toString()!=request["operation"].toString()||!response["ok"].isBool()||!response["error_code"].isString()||!response["error"].isString()||!integer(response["time_ms"])||!response["payload"].isObject())return {"E_PROTOCOL","Invalid worker response identity or fields"};
    if(bool(response["ok"]))return response["error_code"].toString()=="OK"&&response["error"].toString().isEmpty()?Failure{}:Failure{"E_PROTOCOL","Conflicting response status"};
    if(response["error_code"].toString().isEmpty()||response["error_code"].toString()=="OK")return {"E_PROTOCOL","Missing worker error code"};
    return {response["error_code"].toString(),response["error"].toString()};
}
// Control transport only. Never invoke these blocking functions from an audio callback.
inline Failure writeFrame(juce::NamedPipe&pipe,const juce::var&value,int timeout){
    const auto deadline=juce::Time::currentTimeMillis()+std::max(0,timeout);auto remaining=[&]{return timeout<0?-1:std::max(0,int(deadline-juce::Time::currentTimeMillis()));};auto text=juce::JSON::toString(value,true);auto bytes=text.getNumBytesAsUTF8();if(bytes==0||bytes>maxMessageBytes)return {"E_SIZE","Control message exceeds limit"};
    std::array<juce::uint32,2>header{juce::ByteOrder::swapIfBigEndian(magic),juce::ByteOrder::swapIfBigEndian(juce::uint32(bytes))};
    if(pipe.write(header.data(),int(sizeof(header)),remaining())!=int(sizeof(header))||pipe.write(text.toRawUTF8(),int(bytes),remaining())!=int(bytes))return {"E_PIPE","Control write failed or timed out"};return {};
}
inline Failure readFrame(juce::NamedPipe&pipe,juce::var&value,int timeout){
    const auto deadline=juce::Time::currentTimeMillis()+std::max(0,timeout);auto remaining=[&]{return timeout<0?-1:std::max(0,int(deadline-juce::Time::currentTimeMillis()));};auto readAll=[&](void*data,int size){int offset=0;while(offset<size){int left=remaining();if(timeout>=0&&left<=0)return false;int n=pipe.read(static_cast<char*>(data)+offset,size-offset,left);if(n<=0||n>size-offset)return false;offset+=n;}return true;};std::array<juce::uint32,2>header{};if(!readAll(header.data(),int(sizeof(header))))return {"E_PIPE","Control read failed or timed out"};
    auto size=juce::ByteOrder::swapIfBigEndian(header[1]);if(juce::ByteOrder::swapIfBigEndian(header[0])!=magic||size==0||size>juce::uint32(maxMessageBytes))return {"E_SIZE","Invalid control frame size or magic"};
    juce::MemoryBlock body(size);if(!readAll(body.getData(),int(size)))return {"E_PIPE","Incomplete control frame"};
    if(juce::JSON::parse(juce::String::fromUTF8(static_cast<const char*>(body.getData()),int(size)),value).failed()||!value.isObject())return {"E_PROTOCOL","Invalid control JSON"};return {};
}
enum class Phase {empty,created,prepared,suspended,closed};
inline Failure allowed(Phase phase,const juce::String&operation){
    if(phase==Phase::closed)return {"E_STATE","Instance is closed"};
    if(operation=="HELLO"||operation=="CAPS"||operation=="CLOSE")return {};
    if(operation=="CREATE")return phase==Phase::empty?Failure{}:Failure{"E_STATE","Instance already exists"};
    if(phase==Phase::empty)return {"E_STATE","Create the instance first"};
    if(operation=="PREPARE")return phase==Phase::created||phase==Phase::suspended?Failure{}:Failure{"E_STATE","Suspend before changing the audio format"};
    if(operation=="PROCESS"||operation=="MIDI"||operation=="SUSPEND")return phase==Phase::prepared?Failure{}:Failure{"E_STATE","Instance is not running"};
    if(operation=="RESUME")return phase==Phase::suspended?Failure{}:Failure{"E_STATE","Instance is not suspended"};
    if(operation=="SET_STATE")return phase==Phase::created||phase==Phase::suspended?Failure{}:Failure{"E_STATE","Suspend before replacing state"};
    return {};
}
}
