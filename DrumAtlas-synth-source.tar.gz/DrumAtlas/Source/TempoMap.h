#pragma once
#include "MusicCore.h"
#include <algorithm>
namespace atlas::music {
class TempoMap {
public:
 struct Segment { double tick,seconds,bpm; };
 explicit TempoMap(const Project&p){segments.push_back({0,0,p.settings.bpm});for(const auto&t:p.tempos){auto last=segments.back();segments.push_back({double(t.tick),last.seconds+(t.tick-last.tick)*60./(ppq*last.bpm),t.bpm});}}
 double seconds(double tick)const{auto it=std::upper_bound(segments.begin(),segments.end(),tick,[](double n,const Segment&s){return n<s.tick;});if(it!=segments.begin())--it;return it->seconds+(tick-it->tick)*60./(ppq*it->bpm);}
 double ticks(double seconds)const{auto it=std::upper_bound(segments.begin(),segments.end(),seconds,[](double n,const Segment&s){return n<s.seconds;});if(it!=segments.begin())--it;return it->tick+(seconds-it->seconds)*ppq*it->bpm/60.;}
 double bpmAt(double tick)const{auto it=std::upper_bound(segments.begin(),segments.end(),tick,[](double n,const Segment&s){return n<s.tick;});if(it!=segments.begin())--it;return it->bpm;}
 std::vector<Segment> segments;
};
}
