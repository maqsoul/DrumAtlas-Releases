#pragma once
#include <juce_core/juce_core.h>
#if JUCE_WINDOWS
#ifndef NOMINMAX
#define NOMINMAX
#endif
#pragma push_macro("near")
#pragma push_macro("far")
#pragma push_macro("small")
#include <windows.h>
#pragma pop_macro("small")
#pragma pop_macro("far")
#pragma pop_macro("near")
#endif
namespace atlas {
// Snapshot admission, not a reservation or prediction of third-party allocations.
struct MemoryAdmission {
    static constexpr juce::int64 reserve = 512LL * 1024 * 1024;
    static constexpr juce::int64 minimum = 256LL * 1024 * 1024;
    static juce::Result capacity(juce::int64 physical, juce::int64 commit, juce::int64 needed) {
        if(physical < 0 || commit < 0 || needed <= 0)
            return juce::Result::fail("Available memory could not be determined. Retry before starting this background job.");
        if(physical < reserve || commit < reserve || needed > physical-reserve || needed > commit-reserve)
            return juce::Result::fail("Not enough available RAM or system commit capacity. Save your work and close unused instruments or unload the local AI model, then retry.");
        return juce::Result::ok();
    }
    static juce::Result check(juce::int64 needed = minimum) {
       #if JUCE_WINDOWS
        MEMORYSTATUSEX status{};status.dwLength=sizeof(status);
        if(!GlobalMemoryStatusEx(&status))return capacity(-1,-1,needed);
        return capacity(juce::int64(status.ullAvailPhys),juce::int64(status.ullAvailPageFile),needed);
       #else
        juce::ignoreUnused(needed);return juce::Result::ok();
       #endif
    }
};
}
