#pragma once
#include "Neural.h"
#include <mutex>
#include <deque>
#include <atomic>
#include <map>
namespace atlas {
struct Sample {
    juce::String path, name, category, kind, method, error;
    juce::StringArray genres;
    juce::int64 modified = 0, bytes = 0;
    double duration = 0;int classificationVersion=0;
    Features features;
};
struct Hit { double time = 0; juce::String category; Features features; float confidence = 0; };
struct Match { juce::String path, category; float distance = 1, confidence = 0; double time = 0; };
struct ReferenceStem {juce::String name,path;};
juce::Result exportStemCopies(const std::vector<ReferenceStem>&,const juce::File& folder,const juce::String& name,juce::File& output);
struct Snapshot {
    std::shared_ptr<const std::vector<Sample>> samples = std::make_shared<const std::vector<Sample>>();
    std::vector<Hit> hits; std::vector<Match> matches;
    std::vector<ReferenceStem> stems;
    juce::StringArray roots, recent, collections;
    std::map<juce::String, juce::StringArray> favourites;
    juce::String recallWarning;
    juce::String status = "ready", detail, reference, language = "en", theme = "ion";
    bool busy = false, neural = false;
    int revision = 0, catalogRevision = 0, matchRevision=0, processed = 0, total = 0, cached = 0, issues = 0;
    double elapsed = 0;
};
bool matchesFilters(const Sample&, const juce::String&, const juce::String&, const juce::String&, const juce::String&);
class Engine : private juce::Thread {
public:
    Engine(); ~Engine() override;
    Snapshot snapshot(); int revision() const { return version.load(); }
    void addRoot(const juce::File&); void addRoots(const juce::Array<juce::File>&); void setRoots(const juce::StringArray&);
    void selectReference(const juce::File&);
    std::unique_ptr<juce::XmlElement> saveReferenceState();
    void restoreReferenceState(const juce::XmlElement*);
    void rescan(); void analyseReference(const juce::File&, double start = 0, double length = -1, const juce::String& category = {}, bool aiStems = false, bool detailedStems = false, int stemQuality = 0, bool synthLayers = false);
    void cancel(); void relabel(const juce::String&, const juce::String&, const juce::String&);
    void used(const juce::String&); void favourite(const juce::String&, const juce::String& collection, bool add);
    void createCollection(const juce::String&); void preferences(const juce::String&, const juce::String&);
    juce::StringArray roots();
private:
    struct Job { int type = 0, generation = 0; juce::File file; double start = 0, length = -1; juce::String category; bool aiStems=false,detailedStems=false,synthLayers=false; int stemQuality=0; std::shared_ptr<Snapshot> recall; };
    void run() override; void enqueue(Job); void scan(const Job&); void reference(const Job&);
    std::vector<ReferenceStem> splitReference(const Job&,double end);
    std::vector<ReferenceStem> splitSynthLayers(const Job&,double end);
    enum class DetailStage { all, kit, percussion };
    std::vector<ReferenceStem> splitDetailed(const Job&,double,const std::vector<ReferenceStem>&,DetailStage=DetailStage::all,DetailSeparator* prepared=nullptr,bool reportProgress=true,const std::atomic<bool>* stop=nullptr);
    void loadCache(); bool saveCache(); bool savePreferences(); void status(const juce::String&, bool, const juce::String& detail = {});
    bool cancelled(const Job& j) const { return threadShouldExit() || j.generation != generation.load(); }
    void changed() { state.revision = ++version; }
    void markDirty() { dirty = true; notify(); }
    std::mutex stateMutex, queueMutex;
    Snapshot state; std::shared_ptr<Snapshot> pendingRecall; std::deque<Job> jobs;
    std::atomic<int> version{0}, generation{0}; std::atomic<bool> dirty{false}, catalogDirty{false};
    bool rootsSet=false, preferencesSet=false;
    juce::AudioFormatManager formats; juce::File cache, oldCache, settings;
    // Worker-thread-only, completed output cache. Audio files stay available for DAW drag.
    juce::String stemCacheKey; std::vector<ReferenceStem> stemCacheFiles;
    std::vector<juce::String> stemCacheHashes;
    juce::String synthCacheKey; std::vector<ReferenceStem> synthCacheFiles;
    std::vector<juce::String> synthCacheHashes;
};
}
