#pragma once
#include "Analysis.h"
#include <atomic>
#include <mutex>
#include <deque>
#include <map>
namespace atlas {
struct AudioKnobSettings{double pitch=0,tempo=100,originalBpm=0;};
struct EditRequest{juce::File source;double semitones=0,sourceBpm=0,targetBpm=0;};
struct EditState{bool busy=false;int revision=0;juce::String source,output,error;};
juce::File renderAudioEdit(const EditRequest&,const juce::File& directory,const std::function<bool()>&cancel={});
class AudioEditService:private juce::Thread{
public:
 AudioEditService();~AudioEditService()override;void render(EditRequest);EditState snapshot();
 void cancel(const juce::String&);void cancelAll();bool isPending(const juce::String&);std::vector<EditState>takeResults();
private:
 struct Pending{EditRequest request;int revision=0;double ready=0;};
 void run()override;std::mutex mutex;std::deque<Pending>queue;std::vector<EditState>completed;std::map<juce::String,int>latest;juce::String active;EditState state;int serial=0;
};
}
