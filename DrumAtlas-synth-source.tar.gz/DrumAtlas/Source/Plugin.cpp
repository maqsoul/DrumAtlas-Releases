#include "Engine.h"
#include "StemSounds.h"
#include "StemMidiClock.h"
#include "AudioEdit.h"
#include "TempoDetector.h"
#include "PreviewVisualMeter.h"
#include "LicensePanel.h"
#include "Updates.h"
#include "Locale.h"
#include "AudioKnobs.h"
#include "HelpPanel.h"
#include "ShortcutPanel.h"
#include "LayoutDesigner.h"
#include <juce_audio_utils/juce_audio_utils.h>

namespace atlas {
class Preview : private juce::Thread {
public:
    Preview():juce::Thread("DrumAtlas preview"),ring(2,capacity){registerFormats(formats);startThread();}
    ~Preview()override{signalThreadShouldExit();notify();stopThread(-1);}
    void load(const juce::File&f,double start=0,double length=-1){
        std::lock_guard<std::mutex>g(requestMutex);++requestId;file=f;offset=std::max(0.,start);duration=length;pending=true;paused=false;playing=false;
        const juce::SpinLock::ScopedLockType audio(lock);++visualGeneration;visualPublishedAt.store(juce::Time::getMillisecondCounter()-1000,std::memory_order_relaxed);readIndex=writeIndex=filled=0;fraction=0;eof=false;ready=false;playhead=offset;notify();
    }
    void stop(){std::lock_guard<std::mutex>g(requestMutex);++requestId;pending=false;playing=false;paused=false;ready=false;const juce::SpinLock::ScopedLockType a(lock);playhead=0;}
    void pause(){std::lock_guard<std::mutex>g(requestMutex);if(playing||pending||ready){paused=true;playing=false;}}
    bool resume(const juce::File&f){std::lock_guard<std::mutex>g(requestMutex);if(file!=f||!paused)return false;paused=false;playing=ready;return true;}
    bool isPlaying()const{return playing.load();}bool isPaused()const{return paused.load();}
    juce::File currentFile(){std::lock_guard<std::mutex>g(requestMutex);return file;}
    juce::String message(){std::lock_guard<std::mutex>g(requestMutex);return info;}
    std::atomic<double>playhead{0};std::atomic<float>gain{.25f};
    PreviewVisualLevels visualLevels()const noexcept{return playing&&juce::Time::getMillisecondCounter()-visualPublishedAt.load(std::memory_order_relaxed)<150?visualMeter.read():PreviewVisualLevels{};}
    void render(juce::AudioBuffer<float>&out,double hostRate){
        if(!playing||hostRate<=0)return;const juce::SpinLock::ScopedTryLockType guard(lock);if(!guard.isLocked()||!playing)return;
        const double step=sourceRate/hostRate;const float level=gain.load();
        visualMeter.begin(hostRate,visualGeneration);
        for(int i=0;i<out.getNumSamples();++i){
            const int advance=int(fraction+step);
            if(filled<std::max(2,advance+1)){if(eof){playing=false;}for(int silent=i;silent<out.getNumSamples();++silent)visualMeter.push(0,0);break;}
            float fade=float(std::min({1.,consumed/(sourceRate*.003),double(totalFrames-consumed)/(sourceRate*.008)}));
            float visual[2]{};
            for(int ch=0;ch<out.getNumChannels();++ch){const auto*src=ring.getReadPointer(std::min(ch,1));float a=src[readIndex],b=src[(readIndex+1)%capacity];const float sample=(a+float(fraction)*(b-a))*level*fade;out.addSample(ch,i,sample);if(ch<2)visual[ch]=sample;}
            visualMeter.push(visual[0],out.getNumChannels()==1?visual[0]:visual[1]);
            fraction+=step;int count=int(fraction);fraction-=count;readIndex=(readIndex+count)%capacity;filled-=count;consumed+=count;
        }
        playhead=playbackStart+(consumed+fraction)/sourceRate;
        visualMeter.publish();
        visualPublishedAt.store(juce::Time::getMillisecondCounter(),std::memory_order_relaxed);
    }
private:
    void run()override{
        std::unique_ptr<juce::AudioFormatReader>reader;int active=-1;juce::int64 next=0,end=0;juce::AudioBuffer<float>chunk(2,8192);
        while(!threadShouldExit()){
            juce::File target;double start=0,length=0;int requested=-1;bool opening=false;
            {std::lock_guard<std::mutex>g(requestMutex);if(pending){target=file;start=offset;length=duration;requested=requestId;pending=false;opening=true;}else if(active!=requestId)reader.reset();}
            if(opening){
                auto fresh=std::unique_ptr<juce::AudioFormatReader>(formats.createReaderFor(ioFile(target)));
                std::lock_guard<std::mutex>g(requestMutex);if(requested!=requestId)continue;
                if(!fresh||fresh->sampleRate<1000||fresh->sampleRate>384000){info="Cannot open preview file";reader.reset();continue;}
                active=requested;next=juce::jlimit<juce::int64>(0,fresh->lengthInSamples,juce::int64(start*fresh->sampleRate));
                end=length<0?fresh->lengthInSamples:std::min(fresh->lengthInSamples,next+juce::int64(length*fresh->sampleRate));
                {const juce::SpinLock::ScopedLockType a(lock);sourceRate=fresh->sampleRate;playbackStart=double(next)/sourceRate;consumed=0;totalFrames=end-next;}
                reader=std::move(fresh);info.clear();
            }
            if(!reader){wait(10);continue;}
            int free=0;{const juce::SpinLock::ScopedLockType a(lock);free=capacity-filled;}
            if(free<8192||next>=end){wait(5);continue;}
            int count=int(std::min<juce::int64>(8192,end-next));chunk.clear();bool ok=reader->read(&chunk,0,count,next,true,true);
            {std::lock_guard<std::mutex>g(requestMutex);if(active!=requestId){reader.reset();continue;}
                const juce::SpinLock::ScopedLockType a(lock);
                if(!ok){info="Cannot decode preview";playing=false;ready=false;reader.reset();continue;}
                int first=std::min(count,capacity-writeIndex);for(int ch=0;ch<2;++ch){ring.copyFrom(ch,writeIndex,chunk,ch,0,first);if(first<count)ring.copyFrom(ch,0,chunk,ch,first,count-first);}
                writeIndex=(writeIndex+count)%capacity;filled+=count;next+=count;eof=next>=end;
                if(!ready){ready=true;playing=!paused.load();}
            }
        }
    }
    static constexpr int capacity=131072;
    PreviewVisualMeter visualMeter;std::uint64_t visualGeneration=0;std::atomic<juce::uint32>visualPublishedAt{0};
    juce::AudioFormatManager formats;juce::AudioBuffer<float>ring;juce::SpinLock lock;std::mutex requestMutex;
    juce::File file;juce::String info;int requestId=0,readIndex=0,writeIndex=0,filled=0;
    double offset=0,duration=-1,sourceRate=44100,playbackStart=0,fraction=0;juce::int64 consumed=0,totalFrames=0;
    bool pending=false,ready=false,eof=false;std::atomic<bool>playing{false},paused{false};
};

class Processor : public juce::AudioProcessor {
public:
    Processor() : AudioProcessor(BusesProperties().withInput("Input", juce::AudioChannelSet::stereo(), true)
                                                  .withOutput("Output", juce::AudioChannelSet::stereo(), true)) {}
    const juce::String getName() const override { return "DrumAtlas"; }
    void prepareToPlay(double sampleRate, int) override { rate = sampleRate; preview.stop(); }
    void releaseResources() override { preview.stop(); }
    bool isBusesLayoutSupported(const BusesLayout& b) const override {
        return b.getMainOutputChannelSet() == juce::AudioChannelSet::stereo()
            && (b.getMainInputChannelSet() == juce::AudioChannelSet::stereo() || b.getMainInputChannelSet().isDisabled());
    }
    void processBlock(juce::AudioBuffer<float>& audio, juce::MidiBuffer&) override {
        juce::ScopedNoDenormals guard;
        double bpm=0;if(auto*head=getPlayHead())if(auto position=head->getPosition())if(auto tempo=position->getBpm())bpm=*tempo;hostBpm=std::isfinite(bpm)&&bpm>0?bpm:0;
        for (int i = getTotalNumInputChannels(); i < audio.getNumChannels(); ++i) audio.clear(i, 0, audio.getNumSamples());
        if(isLicensed)preview.render(audio, rate);
    }
    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }
    double getTailLengthSeconds() const override { return 0; }
    bool acceptsMidi() const override { return false; }
    bool producesMidi() const override { return false; }
    int getNumPrograms() override { return 1; }
    int getCurrentProgram() override { return 0; }
    void setCurrentProgram(int) override {}
    const juce::String getProgramName(int) override { return {}; }
    void changeProgramName(int, const juce::String&) override {}
    void getStateInformation(juce::MemoryBlock& dest) override {
        std::lock_guard<std::recursive_mutex> edits(editMutex);collectAudioEdits();
        juce::XmlElement xml("DrumAtlas"); xml.setAttribute("gain", double(preview.gain.load()));
        xml.setAttribute("width",editorWidth);xml.setAttribute("height",editorHeight);
        xml.setAttribute("stemQuality",stemQuality);xml.setAttribute("zoom",editorZoom);xml.setAttribute("split",editorSplit);
        xml.setAttribute("interfaceStyle",interfaceStyle);xml.setAttribute("emberAnimation",emberAnimation);xml.setAttribute("showReference",showReference);xml.setAttribute("showResults",showResults);xml.setAttribute("showSampleWave",showSampleWave);
        xml.createNewChildElement("userLayouts")->addTextElement(userLayouts.serialise());
        for (const auto& root : engine.roots()) xml.createNewChildElement("root")->setAttribute("path", root);
        {std::lock_guard<std::mutex>g(renderMutex);for(const auto&pair:renderedFiles){if(audioEdit.isPending(pair.first))continue;auto*node=xml.createNewChildElement("render");node->setAttribute("source",pair.first);node->setAttribute("output",pair.second);}}
        {std::lock_guard<std::mutex>g(renderMutex);for(const auto&pair:knobSettings){auto*node=xml.createNewChildElement("audioKnobs");node->setAttribute("source",pair.first);node->setAttribute("pitch",pair.second.pitch);node->setAttribute("tempo",pair.second.tempo);node->setAttribute("bpm",pair.second.originalBpm);}}
        xml.setAttribute("analysisMode",savedAnalysisMode.load());xml.setAttribute("selectedStem",savedStemIndex.load());
        xml.addChildElement(engine.saveReferenceState().release());
        copyXmlToBinary(xml, dest);
    }
    void setStateInformation(const void* data, int size) override {
        if (auto xml = getXmlFromBinary(data, size); xml && xml->hasTagName("DrumAtlas")) {
            std::lock_guard<std::recursive_mutex> edits(editMutex);audioEdit.cancelAll();clearEditError();
            editorWidth=juce::jlimit(400,7680,xml->getIntAttribute("width",1280));editorHeight=juce::jlimit(288,4320,xml->getIntAttribute("height",840));
            stemQuality=juce::jlimit(0,2,xml->getIntAttribute("stemQuality",0));editorZoom=juce::jlimit(.4,2.,xml->getDoubleAttribute("zoom",1.));editorSplit=juce::jlimit(.4,.75,xml->getDoubleAttribute("split",.62));
            interfaceStyle=0;themeFromProject=true;emberAnimation=xml->getBoolAttribute("emberAnimation",true);showReference=xml->getBoolAttribute("showReference",true);showResults=xml->getBoolAttribute("showResults",true);showSampleWave=xml->getBoolAttribute("showSampleWave",true);
            if(auto*layouts=xml->getChildByName("userLayouts"))userLayouts.restore(layouts->getAllSubText());
            preview.gain = float(juce::jlimit(0.0, 1.0, xml->getDoubleAttribute("gain", 0.25)));
            juce::StringArray roots;
            for (auto* child : xml->getChildIterator()) if (child->hasTagName("root")) roots.add(child->getStringAttribute("path"));
            {std::lock_guard<std::mutex>g(renderMutex);renderedFiles.clear();for(auto*child:xml->getChildIterator())if(child->hasTagName("render"))renderedFiles[child->getStringAttribute("source")]=child->getStringAttribute("output");}
            {std::lock_guard<std::mutex>g(renderMutex);knobSettings.clear();for(auto*child:xml->getChildIterator())if(child->hasTagName("audioKnobs")){AudioKnobSettings s;s.pitch=juce::jlimit(-24.,24.,child->getDoubleAttribute("pitch"));s.tempo=juce::jlimit(25.,400.,child->getDoubleAttribute("tempo",100));s.originalBpm=juce::jlimit(0.,400.,child->getDoubleAttribute("bpm"));knobSettings[child->getStringAttribute("source")]=s;}}
            preview.stop();
            savedAnalysisMode=juce::jlimit(1,4,xml->getIntAttribute("analysisMode",3));savedStemIndex=juce::jlimit(1,128,xml->getIntAttribute("selectedStem",1));++sessionRecallRevision;
            engine.setRoots(roots);engine.restoreReferenceState(xml->getChildByName("referenceSession"));
        }
    }
    juce::String renderedPath(const juce::String&source){std::lock_guard<std::mutex>g(renderMutex);auto i=renderedFiles.find(source);return i!=renderedFiles.end()&&ioFile(juce::File(i->second)).existsAsFile()?i->second:source;}
    void setRendered(const juce::String&source,const juce::String&output){std::lock_guard<std::mutex>g(renderMutex);if(output.isEmpty())renderedFiles.erase(source);else renderedFiles[source]=output;}
    void collectAudioEdits(){std::lock_guard<std::recursive_mutex> edits(editMutex);for(auto&r:audioEdit.takeResults()){if(r.output.isNotEmpty())setRendered(r.source,r.output);if(r.error.isNotEmpty()){setRendered(r.source,{});std::lock_guard<std::mutex>g(renderMutex);editError=r.error;}}}
    juce::String audioEditError(){std::lock_guard<std::mutex>g(renderMutex);return editError;}
    void clearEditError(){std::lock_guard<std::mutex>g(renderMutex);editError.clear();}
    AudioKnobSettings knobs(const juce::String&source){std::lock_guard<std::mutex>g(renderMutex);auto i=knobSettings.find(source);return i==knobSettings.end()?AudioKnobSettings{}:i->second;}
    void setKnobs(const juce::String&source,AudioKnobSettings settings){
        std::lock_guard<std::recursive_mutex> edits(editMutex);clearEditError();
        {std::lock_guard<std::mutex>g(renderMutex);knobSettings[source]=settings;}
        if(settings.pitch==0&&settings.tempo==100){audioEdit.cancel(source);setRendered(source,{});return;}
        double bpm=100;
        audioEdit.render({juce::File(source),settings.pitch,bpm,bpm*settings.tempo/100});
    }
    std::recursive_mutex editMutex;std::mutex renderMutex;std::map<juce::String,juce::String>renderedFiles;
    std::map<juce::String,AudioKnobSettings>knobSettings;juce::String editError;
    std::atomic<int>savedAnalysisMode{3},savedStemIndex{1},sessionRecallRevision{0};
    Engine engine;TempoDetector tempoDetector;UserLayouts userLayouts;
    std::atomic<bool>isLicensed{licensed()};Updates updates;AudioEditService audioEdit;std::atomic<double>hostBpm{0};
    int editorWidth=1280,editorHeight=840;
    int interfaceStyle=0;bool themeFromProject=false;int stemQuality=0;double editorZoom=1.,editorSplit=.62;
    bool showReference=true,showResults=true,showSampleWave=true,emberAnimation=true;
    Preview preview;
private:
    double rate = 44100;
};

class FileDragButton : public juce::TextButton {
public:
    FileDragButton() : juce::TextButton("Drag to DAW") {}
    std::function<juce::String()> path;
    void mouseDrag(const juce::MouseEvent& e) override {
        if (!sent && e.getDistanceFromDragStart() > 5 && path) {
            const auto file = path();
            if (atlas::ioFile(juce::File(file)).existsAsFile()) { sent = true; juce::DragAndDropContainer::performExternalDragDropOfFiles({file}, false, this); }
        }
    }
    void mouseDown(const juce::MouseEvent& e) override { sent = false; juce::TextButton::mouseDown(e); }
private:
    bool sent = false;
};

class CatalogList : public juce::ListBox {
public:
    CatalogList(const juce::String& name, juce::ListBoxModel* model) : juce::ListBox(name, model) {}
    juce::String emptyText = "Add a sample folder to start";
    void paintOverChildren(juce::Graphics& g) override {
        if (getModel() && getModel()->getNumRows() == 0) {
            g.setColour(ember::muted); g.setFont(ember::font(14.f));
            g.drawFittedText(emptyText, getLocalBounds().reduced(24), juce::Justification::centred, 3);
        }
    }
};



#include "Editor.inc"
#include "Platform.h"
#if DRUMATLAS_ENABLE_SMOKE_TESTS
#include <iostream>
#include <stdexcept>
int runAtlasSessionRecall(const juce::File& scratch){
    auto check=[](bool ok,const char*message){if(!ok)throw std::runtime_error(message);std::cout<<"PASS: "<<message<<std::endl;};
    scratch.createDirectory();const auto reference=scratch.getChildFile(juce::String::fromUTF8("Референс.wav"));
    auto write=[&](const juce::File&file){auto stream=file.createOutputStream();juce::WavAudioFormat format;std::unique_ptr<juce::AudioFormatWriter>w(format.createWriterFor(stream.release(),44100,2,16,{},0));if(!w)throw std::runtime_error("fixture writer");juce::AudioBuffer<float>b(2,44100);for(int ch=0;ch<2;++ch)for(int i=0;i<44100;++i)b.setSample(ch,i,float(.2*std::sin(i*.04)));w->writeFromAudioSampleBuffer(b,0,44100);};
    write(reference);const auto bass=scratch.getChildFile("Bass.wav"),kick=scratch.getChildFile("Kick.wav");write(bass);write(kick);
    auto wait=[&](atlas::Processor&p){auto until=juce::Time::getMillisecondCounter()+20000;while(p.engine.snapshot().busy&&juce::Time::getMillisecondCounter()<until){(juce::Thread::sleep(20),juce::Timer::callPendingTimersSynchronously());}check(!p.engine.snapshot().busy,"Recall worker completes without inference");};
    juce::MemoryBlock saved;
    {atlas::Processor original;original.engine.setRoots({});wait(original);
     juce::XmlElement session("referenceSession");session.setAttribute("path",reference.getFullPathName());
     for(const auto&f:{kick,bass}){auto*n=session.createNewChildElement("stem");n->setAttribute("path",f.getFullPathName());n->setAttribute("name",f.getFileNameWithoutExtension());}
     auto*m=session.createNewChildElement("match");m->setAttribute("path",kick.getFullPathName());m->setAttribute("category","Kick");m->setAttribute("distance",.12);
     original.savedAnalysisMode=4;original.savedStemIndex=2;original.engine.restoreReferenceState(&session);
     original.getStateInformation(saved);check(saved.getSize()>0,"Host can save immediately while recall is pending");}
    atlas::Processor restored;restored.isLicensed=true;restored.setStateInformation(saved.getData(),int(saved.getSize()));wait(restored);
    auto state=restored.engine.snapshot();check(state.reference==reference.getFullPathName()&&state.stems.size()==2&&state.stems[1].path==bass.getFullPathName(),"Fresh processor restores Unicode reference and both ordered stems");
    check(state.matches.size()==1&&state.matches[0].category=="Kick","Reference matches restored");check(!restored.preview.isPlaying(),"Recall never auto-plays audio");
    check(restored.savedAnalysisMode==4&&restored.savedStemIndex==2,"Mode and selected stem restored");
    auto base=std::unique_ptr<juce::AudioProcessorEditor>(restored.createEditor());
    auto child=[&](const char*id){return base->findChildWithID(id);};
    for(int i=0;i<10;++i)(juce::Thread::sleep(20),juce::Timer::callPendingTimersSynchronously());
    auto*wave=dynamic_cast<atlas::ReferenceWave*>(child("reference-wave"));auto*stem=dynamic_cast<atlas::ReferenceWave*>(child("stem-wave"));
    check(wave&&stem&&wave->file==reference&&stem->file==bass,"Editor displays restored reference and selected Bass waveform");
    restored.prepareToPlay(44100,512);restored.preview.load(bass);for(int i=0;i<100&&!restored.preview.isPlaying();++i)juce::Thread::sleep(10);
    juce::AudioBuffer<float>audio(2,512);audio.clear();juce::MidiBuffer midi;restored.processBlock(audio,midi);check(audio.getMagnitude(0,512)>.001f,"Restored stem decodes and plays");
    auto xml=juce::AudioProcessor::getXmlFromBinary(saved.getData(),int(saved.getSize()));xml->getChildByName("referenceSession")->setAttribute("path",scratch.getChildFile("Missing.wav").getFullPathName());
    juce::MemoryBlock missing;juce::AudioProcessor::copyXmlToBinary(*xml,missing);restored.setStateInformation(missing.getData(),int(missing.getSize()));wait(restored);
    for(int i=0;i<10;++i)(juce::Thread::sleep(20),juce::Timer::callPendingTimersSynchronously());
    check(restored.engine.snapshot().recallWarning.contains("Missing.wav")&&restored.engine.snapshot().stems.size()==2,"Missing reference is reported without discarding existing stems");
    check(wave->file.getFileName()=="Missing.wav"&&!restored.preview.isPlaying(),"Loading a project replaces an already-open editor and stops old playback");
    xml->removeChildElement(xml->getChildByName("referenceSession"),true);juce::MemoryBlock legacy;juce::AudioProcessor::copyXmlToBinary(*xml,legacy);restored.setStateInformation(legacy.getData(),int(legacy.getSize()));wait(restored);
    for(int i=0;i<10;++i)(juce::Thread::sleep(20),juce::Timer::callPendingTimersSynchronously());
    check(restored.engine.snapshot().reference.isEmpty()&&restored.engine.snapshot().stems.empty()&&wave->file==juce::File()&&stem->file==juce::File(),"Legacy project clears previous media without retaining stale waveforms");
    restored.setStateInformation(saved.getData(),int(saved.getSize()));wait(restored);
    check(restored.engine.snapshot().recallWarning.isEmpty(),"Valid project clears missing-media warning");
    base.reset();
    {juce::XmlElement large("referenceSession");large.setAttribute("path",reference.getFullPathName());
     constexpr int count=100000;
     for(int i=count-1;i>=0;--i){auto*n=new juce::XmlElement("match");n->setAttribute("path",scratch.getChildFile("Sample-"+juce::String(i)+".wav").getFullPathName());n->setAttribute("category","Kick");n->setAttribute("time",i);large.prependChildElement(n);}
     restored.engine.restoreReferenceState(&large);wait(restored);
     juce::MemoryBlock largeSaved;const auto started=juce::Time::getMillisecondCounterHiRes();restored.getStateInformation(largeSaved);const auto seconds=(juce::Time::getMillisecondCounterHiRes()-started)/1000.;
     std::cout<<"Large session save: "<<seconds<<" seconds, "<<largeSaved.getSize()<<" bytes"<<std::endl;
     check(seconds<10.,"100000 matches save without quadratic append delay");
     auto largeXml=juce::AudioProcessor::getXmlFromBinary(largeSaved.getData(),int(largeSaved.getSize()));auto*session=largeXml?largeXml->getChildByName("referenceSession"):nullptr;
     int index=0;bool ordered=session!=nullptr;if(session)for(auto*n:session->getChildIterator())if(n->hasTagName("match")){ordered=ordered&&n->getIntAttribute("time")==index;++index;}
     check(ordered&&index==count,"Large session preserves every match in ranked order");}
    std::cout<<"PASS: session recall suite"<<std::endl;return 0;
}
int runAtlasLayout(const juce::File& scratch) {
    const auto check=[](bool ok,const char*message){if(!ok)throw std::runtime_error(message);};
    scratch.createDirectory();atlas::Processor processor;processor.isLicensed=true;processor.userLayouts.restore("[]");
    std::unique_ptr<juce::AudioProcessorEditor>base(processor.createEditor());auto*editor=dynamic_cast<atlas::Editor*>(base.get());
    auto child=[&](const juce::String&id)->juce::Component*{for(auto*c:editor->getChildren())if(c->getComponentID()==id)return c;return nullptr;};
    auto*quality=dynamic_cast<juce::ComboBox*>(child("stem-quality"));check(quality&&quality->getNumItems()==3,"Stem quality selector available");quality->setSelectedId(3,juce::sendNotificationSync);juce::MemoryBlock qualityState;processor.getStateInformation(qualityState);processor.stemQuality=0;processor.setStateInformation(qualityState.getData(),int(qualityState.getSize()));check(processor.stemQuality==2,"Stem quality persists in DAW state");
    auto*zoom=dynamic_cast<juce::ComboBox*>(child("interface-zoom"));auto*list=child("library");check(zoom&&list,"Layout controls missing");
    auto shot=[&](const char*name){juce::FileOutputStream out(scratch.getChildFile(name));out.setPosition(0);out.truncate();juce::PNGImageFormat().writeImageToStream(editor->createComponentSnapshot(editor->getLocalBounds()),out);};
    // Render actual row artwork at the user's compact scale and at 100%.
    {
      juce::Image artwork(juce::Image::RGB,1000,710,true);
      {juce::Graphics g(artwork);g.fillAll(atlas::ember::background);
       auto types=atlas::categories();types.add("Piano");types.add("Drums");
       for(int i=0;i<types.size();++i){float x=10.f+(i%4)*248.f,y=10.f+(i/4)*86.f;atlas::ember::card(g,{x,y,238,76},12);atlas::ember::sampleArt(g,{x+12,y+21,34,34},types[i],0);g.setColour(atlas::ember::text);g.setFont(atlas::ember::font(14));g.drawText(types[i],int(x)+58,int(y)+22,178,30,juce::Justification::centredLeft);}
      }
      juce::FileOutputStream out(scratch.getChildFile("sample-icons.png"));out.setPosition(0);out.truncate();juce::PNGImageFormat().writeImageToStream(artwork,out);
    }
    editor->setSize(1000,720);shot("layout-normal.png");const auto normal=list->getBounds();
    auto*help=dynamic_cast<juce::TextButton*>(child("instructions"));check(help!=nullptr,"Instructions navigation available");help->onClick();auto*panel=dynamic_cast<atlas::HelpPanel*>(child("help-panel"));check(panel!=nullptr,"Instructions open inside editor");
    for(int id=1;id<=6;++id){panel->topics.setSelectedId(id,juce::sendNotificationSync);panel->topics.onChange();check(panel->content.getText().length()>120,"Instruction topic contains actual usage guidance");check(panel->illustratedCount()>=4,"Every help topic has illustrated controls");shot(("instructions-topic-"+juce::String(id)+".png").toRawUTF8());}shot("layout-instructions.png");editor->setSize(400,600);shot("instructions-narrow.png");editor->setSize(1000,720);help->onClick();check(!child("help-panel"),"Instructions close without replacing editor");
    atlas::AudioKnobs knobs;knobs.set({3,125,120});check(std::abs(knobs.tempo.getTextFromValue(knobs.tempo.getValue()).getDoubleValue()-150)<.01,"Known BPM displays target tempo");knobs.hostTempo=[] {return 132.;};knobs.sync.onClick();check(std::abs(knobs.values().tempo-110)<.01,"DAW sync sets tempo ratio");knobs.set({0,100,0});check(knobs.tempo.getTextFromValue(100)==juce::String::fromUTF8("—"),"Unknown BPM is not invented");
    auto fake=scratch.getChildFile("knob-state.wav").getFullPathName();{std::lock_guard<std::mutex>lock(processor.renderMutex);processor.knobSettings[fake]={5,120,90};}juce::MemoryBlock knobState;processor.getStateInformation(knobState);processor.knobSettings.clear();processor.setStateInformation(knobState.getData(),int(knobState.getSize()));check(processor.knobs(fake).pitch==5&&processor.knobs(fake).tempo==120&&processor.knobs(fake).originalBpm==90,"Per-source knob settings persist in host state");
    editor->applyView(4);check(!child("reference-wave")->isVisible()&&!child("reference-results")->isVisible()&&!child("sample-wave")->isVisible(),"Focus hides optional panels");
    check(list->getWidth()>normal.getWidth()&&list->getHeight()>normal.getHeight(),"Focus expands library in both dimensions");shot("layout-focus.png");
    juce::MemoryBlock state;processor.getStateInformation(state);processor.showReference=true;processor.showResults=true;processor.setStateInformation(state.getData(),int(state.getSize()));check(!processor.showReference&&!processor.showResults,"Panel state persists");
    editor->applyView(5);zoom->setSelectedId(40,juce::sendNotificationSync);check(std::abs(list->getTransform().mat00-.4f)<.01f,"40 percent zoom applies to controls");shot("layout-40.png");
    zoom->setSelectedId(200,juce::sendNotificationSync);check(processor.editorZoom==2.,"200 percent option available");shot("layout-large.png");
    editor->setSize(400,288);check(list->getHeight()>0&&child("reference-results")->getHeight()>0,"Minimum window retains usable logical layout");shot("layout-minimum.png");
    for(const auto size: {juce::Point<int>(400,288),juce::Point<int>(1000,720),juce::Point<int>(1280,840),juce::Point<int>(1920,1080)}){
      editor->applyView(5);editor->setSize(size.x,size.y);
      auto*ref=child("reference-wave");auto*stem=child("stem-wave");auto*matches=child("reference-results");
      check(ref->getWidth()>list->getWidth()&&ref->getBottom()<list->getY(),"Wide reference remains above library");
      check(stem->getBottom()<matches->getY()&&matches->getHeight()>=40,"Stems and results do not overlap at all supported sizes");
      editor->applyView(2);check(stem->isVisible()&&!matches->isVisible(),"Hiding results preserves stem controls");
      editor->applyView(1);check(!stem->isVisible()&&list->getWidth()>normal.getWidth(),"Hiding reference and results expands library");
    }
    editor->applyView(5);editor->setSize(1280,840);shot("layout-ember.png");
    editor->applyView(6);juce::MemoryBlock motionState;processor.getStateInformation(motionState);processor.emberAnimation=true;processor.setStateInformation(motionState.getData(),int(motionState.getSize()));check(!processor.emberAnimation,"Reduced motion preference persists in host state");
    check(child("interface-design")==nullptr&&atlas::ember::styleNames().size()==1&&processor.interfaceStyle==0,"Only EMBER is available");
    {
      auto*open=dynamic_cast<juce::TextButton*>(child("keyboard-shortcuts"));check(open!=nullptr,"Shortcut settings replace theme picker");open->onClick();
      auto*keys=dynamic_cast<atlas::ShortcutPanel*>(child("shortcut-panel"));check(keys&&keys->draft.actions.size()>25,"Shortcut panel lists real plugin actions");
      int motionRow=0;for(int i=0;i<int(keys->draft.actions.size());++i)if(keys->draft.actions[size_t(i)].id=="motion")motionRow=i;
      keys->list.selectRow(motionRow);keys->assign.onClick();keys->keyPressed(juce::KeyPress::createFromDescription("ctrl + I"));
      check(keys->draft.keys["motion"].isEmpty(),"Conflicting shortcut cannot silently replace another binding");
      const auto custom=juce::KeyPress::createFromDescription("ctrl + shift + F8");keys->keyPressed(custom);
      check(keys->draft.actionFor(custom)=="motion","Key capture assigns a custom function binding");
      check(keys->onSave(keys->draft).wasOk(),"Shortcut assignments save successfully");
      auto reloaded=editor->shortcutDefinitions();reloaded.load(atlas::stemsounds::root().getChildFile("shortcuts.json"));check(reloaded.actionFor(custom)=="motion","Saved shortcut survives reload");
      shot("keyboard-shortcuts.png");editor->setSize(400,600);shot("keyboard-shortcuts-narrow.png");editor->setSize(1280,840);editor->closeShortcuts();
      bool wasAnimated=processor.emberAnimation;check(editor->dispatchShortcut(custom)&&processor.emberAnimation!=wasAnimated,"Assigned key dispatches the chosen action");editor->dispatchShortcut(custom);
      editor->showShortcuts();keys=dynamic_cast<atlas::ShortcutPanel*>(child("shortcut-panel"));keys->list.selectRow(motionRow);keys->clear.onClick();check(keys->draft.keys["motion"].isEmpty(),"Clear removes selected assignment in draft");editor->closeShortcuts();
      check(editor->dispatchShortcut(custom),"Closing without Save preserves active bindings");editor->dispatchShortcut(custom);
      editor->showShortcuts();keys=dynamic_cast<atlas::ShortcutPanel*>(child("shortcut-panel"));keys->reset.onClick();check(keys->onSave(keys->draft).wasOk(),"Default shortcuts restore and save");editor->closeShortcuts();check(!editor->dispatchShortcut(custom),"Reset removes custom binding");
      processor.interfaceStyle=9;juce::MemoryBlock oldTheme;processor.getStateInformation(oldTheme);processor.setStateInformation(oldTheme.getData(),int(oldTheme.getSize()));check(processor.interfaceStyle==0,"Projects with a removed theme reopen as EMBER");
    }
    {atlas::RowsModel cards;cards.columns=3;cards.lastColumn=0;cards.dragPath=[](int i){return juce::String(i);};juce::Component row;row.setSize(900,124);auto now=juce::Time::getCurrentTime();auto input=juce::Desktop::getInstance().getMainMouseSource();juce::MouseEvent down(input,{750,40},juce::ModifierKeys::leftButtonModifier,1,0,0,0,0,&row,&row,now,{750,40},now,1,false);cards.mouseDown(down);juce::SparseSet<int> selected;selected.addRange({0,1});check(cards.getDragSourceDescription(selected).toString()=="2","Dragging a neighbouring card uses its mouse-down column, not the previously selected card");}
    zoom->setSelectedId(100,juce::sendNotificationSync);
    auto*divider=dynamic_cast<atlas::LibraryDivider*>(child("library-divider"));const int oldWidth=list->getWidth();divider->moved(180);check(list->getWidth()!=oldWidth,"Divider changes library width");
    check(!atlas::loadNativeLibrary(scratch.getChildFile("missing-runtime.dll"))&&atlas::nativeLibraryError().contains("missing-runtime.dll"),"Runtime diagnostic identifies absent file");
    auto kkFace=atlas::ember::bodyFace("kk");auto alphabet=juce::String::fromUTF8("АаӘәБбВвГгҒғДдЕеЁёЖжЗзИиЙйКкҚқЛлМмНнҢңОоӨөПпРрСсТтУуҰұҮүФфХхҺһЦцЧчШшЩщЪъЫыІіЬьЭэЮюЯя");
    for(auto c:alphabet)check(kkFace->getNominalGlyphForCodepoint(c).has_value(),"Embedded Kazakh font contains entire alphabet without system fallback");
    auto phrase=juce::String::fromUTF8("Барлық жанрлар Әә Ғғ Ққ Ңң Өө Ұұ Үү Һһ Іі");juce::GlyphArrangement glyphs;glyphs.addLineOfText(atlas::ember::font(14,"kk"),phrase,0,20);
    for(const auto&glyph:glyphs){check(std::abs(glyph.getBounds().getHeight()-atlas::ember::font(14,"kk").getHeight())<.01f,"Kazakh letters retain uniform font size");}
    auto*languages=dynamic_cast<juce::ComboBox*>(child("language"));languages->setSelectedId(3,juce::sendNotificationSync);
    juce::ComboBox*genres=nullptr;for(auto*c:editor->getChildren())if(c->getProperties()["layoutName"].toString()=="genre")genres=dynamic_cast<juce::ComboBox*>(c);
    check(genres&&genres->getLookAndFeel().getComboBoxFont(*genres).getTypefacePtr()->getName()==kkFace->getName(),"Kazakh genre selector uses uniform embedded font");shot("layout-kazakh.png");
    {juce::FileOutputStream out(scratch.getChildFile("kazakh-genre.png"));out.setPosition(0);out.truncate();juce::PNGImageFormat().writeImageToStream(genres->createComponentSnapshot(genres->getLocalBounds(),true,3.f),out);}
    languages->setSelectedId(1,juce::sendNotificationSync);check(genres->getLookAndFeel().getComboBoxFont(*genres).getTypefacePtr()->getName()==atlas::ember::bodyFace()->getName(),"Switching back restores original font");
    auto*designer=dynamic_cast<atlas::LayoutDesigner*>(child("layout-designer"));check(designer!=nullptr,"Native layout designer exists");
    auto*selection=child("analyse-selection");const auto original=selection->getBounds();
    editor->applyView(7);check(designer->editing(),"Edit interface opens overlay");
    check(designer->setItemBounds("analyse-selection",original.translated(12,8).withWidth(original.getWidth()-20)),"Move/resize existing action");
    check(selection->getBounds()!=original&&!processor.engine.snapshot().busy,"Layout editing never triggers analysis");
    designer->discard();check(selection->getBounds()==original,"Cancel restores original action bounds");
    editor->applyView(7);designer->setItemBounds("analyse-selection",original.translated(15,10));const auto moved=selection->getBounds();
    check(designer->commit(),"Save layout succeeds");atlas::UserLayouts disk;check(disk.get(0).count("analyse-selection")==1,"Layout persists across application launches");
    juce::MemoryBlock layoutState;processor.getStateInformation(layoutState);processor.userLayouts.restore("[]");editor->resized();check(selection->getBounds()==original,"Cleared project restores default");
    processor.setStateInformation(layoutState.getData(),int(layoutState.getSize()));editor->resized();check(selection->getBounds()==moved,"Host state restores custom layout");
    editor->setSize(700,500);auto normalized=processor.userLayouts.get(0).at("analyse-selection");check(std::abs(selection->getX()/1100.-normalized.x)<.003,"Custom coordinates follow the scrollable logical page on a narrow window");
    editor->setSize(1280,940);editor->applyView(7);
    auto*sample=dynamic_cast<atlas::ReferenceWave*>(child("sample-wave"));const auto syncDefault=sample->knobs.sync.getBounds();designer->setItemBounds("sample-sync",syncDefault.translated(20,-10));check(sample->knobs.sync.getBounds()!=syncDefault,"Nested Sync DAW can move independently");
    auto*bar=designer->getChildComponent(0);auto*picker=dynamic_cast<juce::ComboBox*>(bar->findChildWithID("layout-picker"));auto*font=dynamic_cast<juce::Slider*>(bar->findChildWithID("layout-font"));
    for(int i=0;i<picker->getNumItems();++i)if(picker->getItemText(i).startsWith("sample-pitch-label"))picker->setSelectedItemIndex(i,juce::sendNotificationSync);
    auto fontBefore=sample->knobs.pitchLabel.getFont().getHeight();font->setValue(150,juce::sendNotificationSync);check(sample->knobs.pitchLabel.getFont().getHeight()>fontBefore*1.4f,"Label font resizes independently");
    dynamic_cast<juce::TextButton*>(bar->findChildWithID("layout-undo"))->onClick();check(std::abs(sample->knobs.pitchLabel.getFont().getHeight()-fontBefore)<.1f,"Undo restores typed font size");
    auto*pageScroll=dynamic_cast<juce::ScrollBar*>(child("page-scroll-y"));check(pageScroll&&pageScroll->isVisible(),"Approved design scrolls instead of shrinking to window height");
    const auto oldScale=selection->getTransform().mat00;pageScroll->setCurrentRangeStart(900,juce::sendNotificationSync);check(selection->getTransform().mat00==oldScale&&selection->getTransform().mat12<0,"Scrolling moves content without changing font scale");
    editor->addToDesktop(0);editor->setVisible(true);auto syncBox=designer->getLocalArea(&sample->knobs.sync,sample->knobs.sync.getLocalBounds());auto point=syncBox.getCentre().toFloat();auto input=juce::Desktop::getInstance().getMainMouseSource();auto now=juce::Time::getCurrentTime();
    juce::MouseEvent down(input,point,juce::ModifierKeys::leftButtonModifier,1,0,0,0,0,designer,designer,now,point,now,1,false);designer->mouseDown(down);
    const auto beforeDrag=sample->knobs.sync.getBounds();auto nextPoint=point+juce::Point<float>(10,-6);juce::MouseEvent drag(input,nextPoint,juce::ModifierKeys::leftButtonModifier,1,0,0,0,0,designer,designer,now,point,now,1,true);designer->mouseDrag(drag);designer->mouseUp(drag);check(sample->knobs.sync.getBounds()!=beforeDrag,"Mouse dragging nested button uses parent coordinates");
    auto beforeKey=sample->knobs.sync.getX();designer->keyPressed(juce::KeyPress(juce::KeyPress::rightKey,juce::ModifierKeys::shiftModifier,0));check(sample->knobs.sync.getX()==beforeKey+10,"Shift-arrow moves selection by ten logical pixels");
    shot("layout-designer.png");dynamic_cast<juce::TextButton*>(bar->findChildWithID("layout-reset-theme"))->onClick();check(selection->getBounds()==original&&sample->knobs.sync.getBounds()==syncDefault,"Reset theme restores root and nested controls");
    check(designer->commit(),"Reset saves successfully");check(processor.userLayouts.get(0).empty(),"Reset removes current theme overrides");
    editor->removeFromDesktop();
    pageScroll->setCurrentRangeStart(0,juce::sendNotificationSync);processor.editorSplit=.62;
    languages->setSelectedId(2,juce::sendNotificationSync);editor->setSize(1226,1256);shot("approved-full-page.png");
    check(child("stem-midi")->getBottom()<child("reference-results")->getY(),"Stem action row precedes results");
    check(child("stem-midi")->getWidth()==160&&std::abs(child("stem-midi")->getBounds().getCentreX()-child("stem-wave")->getBounds().getCentreX())<=1,"MIDI button is wide and centred on stem panel");
    check(child("sample-wave")->getBottom()<child("view-panels")->getY(),"Full-size previews cannot overlap footer settings");
    editor->setSize(1226,840);check(selection->getTransform().mat00==1.f&&selection->getHeight()==36,"Laptop height preserves compact 36px controls at 100 percent");shot("approved-laptop-top.png");
    check(child("category")->getY()==child("genre")->getY()&&child("type")->getY()==child("genre")->getY(),"Genre is beside instrument and type filters");
    check(child("genre")->getWidth()>=150&&child("genre")->getX()>=child("type")->getRight(),"Genre filter has readable width without overlap");
    auto*headerFire=child("global-fire");check(headerFire&&headerFire->getX()==294&&headerFire->getRight()<editor->getWidth()-516,"Common animation occupies free center of header");
    pageScroll->setCurrentRangeStart(760,juce::sendNotificationSync);shot("approved-laptop-bottom.png");
    check(atlas::UserLayouts::decode("[{\"style\":99,\"id\":\"x\",\"w\":1,\"h\":1}]").empty(),"Unknown styles rejected");
    check(child("ai-chat")==nullptr && child("stem-midi") && child("stem-sound")==nullptr,"Stem MIDI remains available without Find sound");
    std::cout<<"PASS: layout zoom, compact view, panel persistence, draggable divider, runtime diagnostic\n";return 0;
}
int runAtlasVisuals(const juce::File& scratch) {
    auto check=[](bool ok,const char*message){if(!ok)throw std::runtime_error(message);};
    check(scratch.createDirectory().wasOk(),"Visual test scratch");
    const auto file=scratch.getChildFile("visual-tone.wav");
    juce::AudioBuffer<float> signal(2,44100);
    for(int i=0;i<44100;++i){float x=.5f*std::sin(float(i*juce::MathConstants<double>::twoPi*80/44100));signal.setSample(0,i,x);signal.setSample(1,i,-x);}
    juce::WavAudioFormat format;auto stream=file.createOutputStream();check(stream!=nullptr,"Visual test stream");stream->setPosition(0);stream->truncate();
    {std::unique_ptr<juce::AudioFormatWriter> writer(format.createWriterFor(stream.release(),44100,2,16,{},0));check(writer&&writer->writeFromAudioSampleBuffer(signal,0,44100),"Visual test WAV");}
    atlas::Preview preview;juce::AudioBuffer<float> out(2,512);
    auto load=[&]{preview.load(file);for(int n=0;n<200&&!preview.isPlaying();++n)juce::Thread::sleep(5);check(preview.isPlaying(),"Preview starts");check(preview.visualLevels().level==0,"No stale level from previous file");};
    load();for(int n=0;n<6;++n){out.clear();preview.render(out,48000);}
    const auto levels=preview.visualLevels();check(levels.level>.01f&&levels.bass>levels.treble,"Actual resampled preview drives low-frequency motion");
    atlas::GlobalFire fire;fire.setSize(280,44);fire.update(levels,1./30.,file,true);check(fire.firePhase>0&&fire.fireLevels.level>0,"Common header responds to measured preview audio");
    atlas::ReferenceWave wave;wave.approved=true;wave.setSize(960,206);check(wave.plotBounds()==wave.contentBounds().reduced(14,12),"Reference waveform has equal horizontal and vertical inset");
    atlas::ReferenceWave sample,stem;sample.approved=stem.approved=true;sample.setEditable(true);stem.setEditable(false);sample.setSize(640,190);stem.setSize(500,238);
    for(auto*panel:{&sample,&stem}){auto plot=panel->plotBounds();check(plot.getX()==14&&plot.getRight()==panel->getWidth()-14&&plot.getCentre()==panel->contentBounds().getCentre(),"Sample and stem waveforms are centered with equal side margins");}
    auto input=juce::Desktop::getInstance().getMainMouseSource();auto now=juce::Time::getCurrentTime();auto plot=wave.plotBounds();auto point=juce::Point<float>(float(plot.getX()+plot.getWidth()/4),float(plot.getCentreY()));
    juce::MouseEvent down(input,point,juce::ModifierKeys::leftButtonModifier,1,0,0,0,0,&wave,&wave,now,point,now,1,false);wave.mouseDown(down);
    auto end=juce::Point<float>(float(plot.getX()+plot.getWidth()*3/4),point.y);juce::MouseEvent drag(input,end,juce::ModifierKeys::leftButtonModifier,1,0,0,0,0,&wave,&wave,now,point,now,1,true);wave.mouseDrag(drag);wave.mouseUp(drag);check(wave.hasSelection(),"New waveform bounds retain drag selection");
    preview.pause();check(preview.visualLevels().level==0,"Pause has no visual input");
    for(int n=0;n<90;++n)fire.update({},1./30.,file,true);const auto phase=fire.firePhase;fire.update({},1./30.,file,true);check(fire.fireLevels.level==0&&fire.firePhase==phase,"Animation settles and stops in silence");
    fire.update(levels,1./30.,file,true);fire.update({},0,scratch.getChildFile("another-stem.wav"),true);check(fire.fireLevels.level==0&&fire.firePhase==0,"Switching source clears previous header energy");
    fire.update(levels,1./30.,file,false);check(fire.fireLevels.level==0&&fire.firePhase==0,"Motion preference disables common animation");
    check(preview.resume(file),"Resume preview");out.clear();preview.render(out,48000);check(preview.visualLevels().level>0,"Resume restores reactive motion");
    preview.stop();check(preview.visualLevels().level==0,"Stop removes visual input");
    load();preview.gain=0;
    for(int n=0;n<6;++n){for(int ch=0;ch<2;++ch)for(int i=0;i<512;++i)out.setSample(ch,i,.7f);preview.render(out,48000);}
    check(preview.visualLevels().level==0&&out.getSample(0,200)==.7f,"Muted preview ignores unrelated DAW audio and preserves passthrough");
    preview.gain=.25f;out.clear();preview.render(out,48000);check(preview.visualLevels().level>0,"Unmute restores meter");
    juce::Thread::sleep(180);check(preview.visualLevels().level==0,"Stopped host callback cannot leave animation running");
    preview.stop();std::cout<<"PASS: rendered preview, stereo phase, editor response, silence, pause/resume, stop, source reset, gain, DAW isolation, stopped callback\n";return 0;
}

int runAtlasSmoke(const juce::File& scratch) {
    const auto check = [](bool ok, const char* message) { if (!ok) throw std::runtime_error(message); };
    check(juce::SystemStats::getEnvironmentVariable("DRUMATLAS_CACHE_DIR", {}).isNotEmpty(), "Set test cache directory");
    scratch.createDirectory(); auto fixtures = scratch.getChildFile("samples-"+juce::String(juce::Time::currentTimeMillis()));
    if(juce::SystemStats::getEnvironmentVariable("DRUMATLAS_TEST_LONG_PATHS",{})=="1")for(int i=0;i<5;++i)fixtures=fixtures.getChildFile(juce::String::repeatedString("nested library ",5)+juce::String(i));
    check(atlas::ioFile(fixtures).createDirectory().wasOk(),"Create fixture directory including long paths");
    juce::WavAudioFormat format;
    const auto write = [&](const juce::String& name, double hz, int seconds) {
        const auto file = fixtures.getChildFile(name);
        juce::AudioBuffer<float> audio(2, 44100 * seconds);
        for (int i = 0; i < audio.getNumSamples(); ++i) {
            const double t = (i % 22050) / 44100.0;
            const float value = float(0.8 * std::sin(juce::MathConstants<double>::twoPi * hz * t) * std::exp(-t * 18));
            audio.setSample(0, i, value); audio.setSample(1, i, value);
        }
        auto stream = atlas::ioFile(file).createOutputStream(); check(stream != nullptr, "Fixture stream"); stream->setPosition(0); stream->truncate();
        std::unique_ptr<juce::AudioFormatWriter> writer(format.createWriterFor(stream.release(), 44100, 2, 16, {}, 0));
        check(writer != nullptr && writer->writeFromAudioSampleBuffer(audio, 0, audio.getNumSamples()), "Fixture WAV writing");
        return file;
    };
    const auto kick = write("Pack_Kick_01.wav", 65, 1);
    write("Pack_Piano_C4.wav", 262, 1);
    const auto loop = write("Drum_Loop_120BPM.wav", 90, 4);
    atlas::ioFile(fixtures.getChildFile("broken.wav")).replaceWithText("not audio");
    atlas::Processor processor;
    check(processor.isLicensed,"Test fixture must contain a valid signed activation");
    struct TestPlayHead:juce::AudioPlayHead{juce::Optional<PositionInfo>getPosition()const override{PositionInfo position;position.setBpm(137.0);return position;}} testPlayHead;
    processor.setPlayHead(&testPlayHead);
    const auto wait = [&] {
        const auto end = juce::Time::getMillisecondCounter() + 45000;
        while (processor.engine.snapshot().busy && juce::Time::getMillisecondCounter() < end) juce::Thread::sleep(20);
        check(!processor.engine.snapshot().busy, "Analysis job timeout");
    };
    processor.engine.setRoots({fixtures.getFullPathName(), fixtures.getFullPathName()}); wait();
    auto snap = processor.engine.snapshot();
    check(snap.samples->size() == 4, "Recursive scan, duplicate roots, corrupt file handling");
    check(snap.issues==1,"Corrupt files remain visible with an error");
    check(snap.neural,"Scanner loads bundled audio model");
    const auto second=scratch.getChildFile(juce::String::fromUTF8("Екінші кітапхана"));second.createDirectory();
    atlas::ioFile(kick).copyFileTo(second.getChildFile("Another_Kick.wav"));
    processor.engine.addRoots({second,fixtures});wait();
    check(processor.engine.snapshot().samples->size()==5&&processor.engine.roots().size()==2,"Multiple roots add without replacement or duplication");
    processor.engine.createCollection(juce::String::fromUTF8("Любимые кики"));
    processor.engine.favourite(kick.getFullPathName(),juce::String::fromUTF8("Любимые кики"),true);processor.engine.used(kick.getFullPathName());processor.engine.used(loop.getFullPathName());processor.engine.used(kick.getFullPathName());
    snap=processor.engine.snapshot();check(snap.recent.size()==2&&snap.recent[0]==kick.getFullPathName(),"Recent samples ordered and deduplicated");
    check(snap.favourites.at(kick.getFullPathName()).contains(juce::String::fromUTF8("Любимые кики")),"Favourite collection membership");
    processor.engine.relabel(kick.getFullPathName(), "Tom", "One-shot");
    processor.engine.rescan(); wait();
    snap = processor.engine.snapshot();
    bool manual = false;
    for (const auto& s : *snap.samples) if (s.path == kick.getFullPathName()) manual = s.category == "Tom" && s.method == "Manual";
    check(manual, "Manual tags survive rescan");
    processor.engine.analyseReference(loop, 0, 4); wait();
    check(processor.engine.snapshot().hits.size() >= 1, "Reference attack extraction");
    auto longReference=write("Reference_40s.wav",65,40);
    processor.engine.analyseReference(longReference,34,3);wait();
    snap=processor.engine.snapshot();check(!snap.hits.empty(),"Reference analysis beyond old 30 second cap");
    for(auto&hit:snap.hits)check(hit.time>=34&&hit.time<37,"Selection boundaries respected");
    processor.engine.analyseReference(longReference,34,3,"Kick");wait();
    snap=processor.engine.snapshot();check(!snap.hits.empty(),"Targeted Kick analysis detects a low-frequency rhythm");for(auto&hit:snap.hits)check(hit.category=="Kick"&&hit.time>=34&&hit.time<37,"Targeted analysis only returns selected instrument and time");
    processor.engine.analyseReference(longReference);wait();
    check(processor.engine.snapshot().processed==40,"Full-track analysis reaches the end");
    for(auto&m:processor.engine.snapshot().matches){bool same=false;for(auto&s:*processor.engine.snapshot().samples)if(s.path==m.path)same=s.category==m.category;check(same,"Reference matches keep detected category");}
    processor.prepareToPlay(48000, 512);
    juce::AudioBuffer<float> block(2, 512); juce::MidiBuffer midi;
    for (int ch = 0; ch < 2; ++ch) for (int i = 0; i < 512; ++i) block.setSample(ch, i, 0.125f);
    processor.processBlock(block, midi);
    check(std::abs(processor.hostBpm.load()-137.0)<.001,"DAW tempo read from host playhead");
    check(std::abs(block.getSample(0, 100) - 0.125f) < 0.000001f, "Idle audio passthrough");
    processor.preview.load(kick);
    for (int i = 0; i < 100 && !processor.preview.isPlaying(); ++i) juce::Thread::sleep(10);
    block.clear(); processor.processBlock(block, midi);
    check(block.getMagnitude(0, 512) > 0.01f, "Preview decoding and 44.1 to 48 kHz playback");
    processor.preview.pause();const auto pausedAt=processor.preview.playhead.load();block.clear();processor.processBlock(block,midi);
    check(block.getMagnitude(0,512)==0&&processor.preview.playhead.load()==pausedAt,"Pause is silent and preserves position");
    check(!processor.preview.resume(loop)&&processor.preview.resume(kick),"Resume is scoped to the paused file");block.clear();processor.processBlock(block,midi);check(processor.preview.playhead.load()>pausedAt,"Resume continues from paused cursor");
    processor.preview.stop(); block.clear(); processor.processBlock(block, midi);
    check(block.getMagnitude(0, 512) == 0, "Stop silences preview");
    processor.preview.load(kick); processor.preview.stop(); juce::Thread::sleep(100);
    check(!processor.preview.isPlaying(), "Stop cancels pending preview");
    const auto edited=atlas::renderAudioEdit({kick,7,0,0},scratch.getChildFile("rendered"));processor.setRendered(kick.getFullPathName(),edited.getFullPathName());
    juce::MemoryBlock state; processor.preview.gain = 0.42f; processor.getStateInformation(state);
    processor.setRendered(kick.getFullPathName(),{});
    processor.preview.gain = 0.1f; processor.setStateInformation(state.getData(), int(state.getSize())); wait();
    check(std::abs(processor.preview.gain.load() - 0.42f) < 0.001f, "Host state roundtrip");
    check(processor.renderedPath(kick.getFullPathName())==edited.getFullPathName(),"Rendered sample path survives DAW state roundtrip");processor.setRendered(kick.getFullPathName(),{});
    processor.engine.analyseReference(loop,0,2,"Kick",true);wait();
    auto stemCheck=processor.engine.snapshot();check(stemCheck.status=="referenceReady"&&stemCheck.stems.size()==1&&atlas::ioFile(juce::File(stemCheck.stems[0].path)).existsAsFile(),"AI analysis creates the selected drum stem");
    std::unique_ptr<juce::AudioProcessorEditor> editor(processor.createEditor());
    for (int i = 0; i < editor->getNumChildComponents(); ++i)
        if (auto* combo = dynamic_cast<juce::ComboBox*>(editor->getChildComponent(i)); combo && combo->getComponentID() == "language")
            combo->setSelectedId(2, juce::sendNotificationSync);
    for (int i = 0; i < editor->getNumChildComponents(); ++i)
        if (auto* list = dynamic_cast<juce::ListBox*>(editor->getChildComponent(i))) list->selectRow(0);
    atlas::ReferenceWave* selectedWave=nullptr;for(auto*c:editor->getChildren())if(c->getComponentID()=="sample-wave")selectedWave=dynamic_cast<atlas::ReferenceWave*>(c);
    check(selectedWave&&selectedWave->file!=juce::File(),"Selecting a result loads its sample waveform");
    check(selectedWave->dragAudio.path()==selectedWave->file.getFullPathName(),"Waveform drag exports the previewed file");
    atlas::RowsModel dragModel;dragModel.dragPath=[&](int){return edited.getFullPathName();};juce::SparseSet<int>dragRows;dragRows.addRange({0,1});check(dragModel.getDragSourceDescription(dragRows).toString()==edited.getFullPathName(),"Sample row drag carries rendered WAV path");
    const auto auditionedPath=selectedWave->file.getFullPathName();
    {auto now=juce::Time::getCurrentTime();auto source=juce::Desktop::getInstance().getMainMouseSource();auto plot=selectedWave->plotBounds();float x1=plot.getX()+plot.getWidth()*.25f,x2=plot.getX()+plot.getWidth()*.75f;
      juce::MouseEvent down(source,{x1,45},juce::ModifierKeys::leftButtonModifier,1,0,0,0,0,selectedWave,selectedWave,now,{x1,45},now,1,false);
      juce::MouseEvent drag(source,{x2,45},juce::ModifierKeys::leftButtonModifier,1,0,0,0,0,selectedWave,selectedWave,now,{x1,45},now,1,true);
      selectedWave->mouseDown(down);selectedWave->mouseDrag(drag);selectedWave->mouseUp(drag);
      for(int i=0;i<100&&!processor.preview.isPlaying();++i)juce::Thread::sleep(10);
      check(processor.preview.isPlaying()&&std::abs(selectedWave->start()-.25)<.02&&std::abs(selectedWave->length()-.5)<.02,"Dragging the sample waveform auditions the selected interval");
      selectedWave->pause.onClick();check(processor.preview.isPaused(),"Waveform pause button pauses the active track");selectedWave->play.onClick();check(processor.preview.isPlaying(),"Waveform play button resumes");
      selectedWave->stop.onClick();check(!processor.preview.isPlaying()&&processor.preview.playhead.load()==0&&selectedWave->cursor==0&&selectedWave->playbackStart()==0,"Waveform stop rewinds audio and cursor to track beginning");
      selectedWave->mouseDown(down);selectedWave->mouseUp(down);check(!selectedWave->hasSelection()&&selectedWave->start()==0&&std::abs(selectedWave->length()-1)<.02,"A left click seeks without creating a selection");processor.preview.stop();
      juce::MouseEvent right(source,{x2,45},juce::ModifierKeys::rightButtonModifier,1,0,0,0,0,selectedWave,selectedWave,now,{x2,45},now,1,false);auto seekBefore=selectedWave->playbackStart();selectedWave->mouseDown(right);selectedWave->mouseUp(right);check(selectedWave->playbackStart()==seekBefore&&!selectedWave->hasSelection(),"Right click does not select or seek a waveform");
      atlas::RowsModel popupModel;juce::Point<int>popupPoint;popupModel.context=[&](int,juce::Point<int>point){popupPoint=point;};popupModel.listBoxItemClicked(0,right);check(popupPoint==right.getScreenPosition(),"Context menu receives the clicked sample screen location");
      selectedWave->mouseDoubleClick(down);check(selectedWave->start()==0&&std::abs(selectedWave->length()-1)<.02,"Double click restores whole sample");processor.preview.stop();
    }
    selectedWave->knobs.pitch.setValue(12,juce::sendNotificationSync);
    check(processor.audioEdit.isPending(auditionedPath)&&selectedWave->dragAudio.path().isEmpty(),"Knob edit queues automatically and blocks stale drag");
    for(int i=0;i<500&&selectedWave->file.getFullPathName()==auditionedPath;++i){juce::Thread::sleep(10);juce::Timer::callPendingTimersSynchronously();}
    check(selectedWave->file.getFullPathName()!=auditionedPath&&selectedWave->dragAudio.path()==selectedWave->file.getFullPathName(),"Completed knob edit becomes waveform and drag source without Apply");
    selectedWave->knobs.pitch.setValue(0,juce::sendNotificationSync);check(selectedWave->file.getFullPathName()==auditionedPath,"Neutral knobs restore original preview and drag");
    auto image = editor->createComponentSnapshot(editor->getLocalBounds(), true, 1.0f);
    juce::FileOutputStream out(scratch.getChildFile("DrumAtlas-preview.png"));
    out.setPosition(0); out.truncate();
    check(juce::PNGImageFormat().writeImageToStream(image, out), "Editor snapshot");
    for(int language=1;language<=14;++language){
      for(int i=0;i<editor->getNumChildComponents();++i)if(auto*combo=dynamic_cast<juce::ComboBox*>(editor->getChildComponent(i));combo&&combo->getComponentID()=="language")combo->setSelectedId(language,juce::sendNotificationSync);
      editor->setSize(1120,780);auto render=editor->createComponentSnapshot(editor->getLocalBounds(),true,1.f);check(render.isValid(),"All 14 language layouts render");
      if(language==7){juce::FileOutputStream chinese(scratch.getChildFile("DrumAtlas-zh.png"));chinese.setPosition(0);chinese.truncate();juce::PNGImageFormat().writeImageToStream(render,chinese);}
    }
    juce::ComboBox*category=nullptr;juce::ListBox*library=nullptr;
    for(int i=0;i<editor->getNumChildComponents();++i){auto*c=editor->getChildComponent(i);if(c->getComponentID()=="category")category=dynamic_cast<juce::ComboBox*>(c);if(c->getComponentID()=="library")library=dynamic_cast<juce::ListBox*>(c);}
    check(category&&library,"Library filtering controls exist");category->setSelectedId(2,juce::sendNotificationSync);
    check(library->getModel()->getNumRows()==1,"Localized Kick filter only shows the actual Kick category");
    check(category->getItemId(1)==1000,"Drums group follows All instruments");category->setSelectedId(1000,juce::sendNotificationSync);check(library->getModel()->getNumRows()>1&&library->getModel()->getNumRows()<6,"Drums menu selects multiple drum classes and excludes non-drums");
    juce::ComboBox*scope=nullptr;juce::ResizableCornerComponent*corner=nullptr;
    for(int i=0;i<editor->getNumChildComponents();++i){auto*c=editor->getChildComponent(i);if(c->getComponentID()=="scope")scope=dynamic_cast<juce::ComboBox*>(c);if(auto*r=dynamic_cast<juce::ResizableCornerComponent*>(c))corner=r;}
    check(scope&&corner&&corner->getWidth()>=20,"Folder selection and mouse resize corner are available");category->setSelectedId(1,juce::sendNotificationSync);scope->setSelectedId(1001,juce::sendNotificationSync);check(library->getModel()->getNumRows()==1,"Selected root excludes files in other roots");scope->setSelectedId(1,juce::sendNotificationSync);check(library->getModel()->getNumRows()==6,"All roots view restores the full catalog");
    auto now=juce::Time::getCurrentTime();auto source=juce::Desktop::getInstance().getMainMouseSource();
    juce::MouseEvent down(source,{20,20},juce::ModifierKeys::leftButtonModifier,1,0,0,0,0,corner,corner,now,{20,20},now,1,false);static_cast<juce::Component*>(corner)->mouseDown(down);
    int beforeWidth=editor->getWidth();juce::MouseEvent move(source,{110,80},juce::ModifierKeys::leftButtonModifier,1,0,0,0,0,corner,corner,now,{20,20},now,1,true);static_cast<juce::Component*>(corner)->mouseDrag(move);static_cast<juce::Component*>(corner)->mouseUp(move);check(editor->getWidth()>beforeWidth,"Mouse drag actually resizes the editor");
    editor->setSize(1600,1000);check(editor->getWidth()==1600&&editor->getHeight()==1000,"Editor supports arbitrary dimensions");
    editor->setSize(1000,720);processor.getStateInformation(state);processor.editorWidth=1280;processor.editorHeight=840;processor.setStateInformation(state.getData(),int(state.getSize()));wait();check(processor.editorWidth==1000&&processor.editorHeight==720,"Window dimensions saved in host state");
    {auto compact=editor->createComponentSnapshot(editor->getLocalBounds(),true,1.f);juce::FileOutputStream outMin(scratch.getChildFile("DrumAtlas-compact.png"));outMin.setPosition(0);outMin.truncate();juce::PNGImageFormat().writeImageToStream(compact,outMin);}
    for(int i=0;i<editor->getNumChildComponents();++i)
        check(!editor->getChildComponent(i)->getComponentID().startsWith("splice-"),"Online service controls removed");
    check(scope->indexOfItemId(5)<0,"Removed online source is absent from local folder selection");
    processor.engine.preferences("ru","ion");
    editor.reset();
    juce::Thread::sleep(600);
    {atlas::Engine restored;juce::Thread::sleep(400);auto saved=restored.snapshot();check(saved.language=="ru"&&saved.collections.contains(juce::String::fromUTF8("Любимые кики"))&&saved.favourites.count(kick.getFullPathName())&&saved.recent.contains(kick.getFullPathName())&&saved.recent[0]==auditionedPath,"Language, favourites and recent history persist");}
    const auto bench=scratch.getChildFile("benchmark");bench.createDirectory();
    for(int i=0;i<160;++i)atlas::ioFile(loop).copyFileTo(bench.getChildFile("House_Kick_Loop_"+juce::String(i)+".wav"));
    processor.engine.setRoots({bench.getFullPathName()});wait();double cold=processor.engine.snapshot().elapsed;
    processor.engine.rescan();wait();snap=processor.engine.snapshot();check(snap.samples->size()==160&&snap.cached==160,"All unchanged files use cached features");
    std::cout<<"BENCHMARK: 160 stereo WAV files, 4 seconds each; cold="<<cold<<"s, cached="<<snap.elapsed<<"s\n";
    processor.engine.analyseReference(longReference,0,3,"Kick");wait();snap=processor.engine.snapshot();
    check(snap.matches.size()==160,"Ranking retains alternatives beyond the first eight");
    {std::unique_ptr<juce::AudioProcessorEditor> paging(processor.createEditor());juce::TextButton*more=nullptr,*previous=nullptr;juce::ListBox*matches=nullptr;atlas::ReferenceWave*sampleWave=nullptr;
      for(auto*c:paging->getChildren()){auto id=c->getComponentID();if(id=="more-matches")more=dynamic_cast<juce::TextButton*>(c);if(id=="previous-matches")previous=dynamic_cast<juce::TextButton*>(c);if(id=="reference-results")matches=dynamic_cast<juce::ListBox*>(c);if(id=="sample-wave")sampleWave=dynamic_cast<atlas::ReferenceWave*>(c);}
      check(more&&previous&&matches&&sampleWave,"Alternative navigation and sample waveform exist");
      auto pagePaths=[&]{juce::StringArray paths;for(int i=0;i<matches->getModel()->getNumRows();++i){matches->selectRow(i);paths.add(sampleWave->file.getFullPathName());}return paths;};
      check(matches->getModel()->getNumRows()==8&&!previous->isEnabled()&&more->isEnabled(),"First batch has eight candidates");auto first=pagePaths();more->onClick();auto secondPage=pagePaths();for(auto&path:secondPage)check(!first.contains(path),"Next batch contains new candidates");previous->onClick();check(pagePaths()==first,"Previous restores exactly the earlier batch");
      for(int i=0;i<19;++i)more->onClick();check(!more->isEnabled()&&previous->isEnabled(),"Last batch disables further alternatives");
    }
    juce::File exported;auto copyResult=atlas::exportStemCopies({{"Drums",kick.getFullPathName()},{"Keys",loop.getFullPathName()}},scratch,"Export test",exported);
    check(copyResult.wasOk()&&atlas::ioFile(exported.getChildFile("Drums.wav")).getSize()==atlas::ioFile(kick).getSize(),"Stem export copies playable WAV files");
    juce::File exportedAgain;check(atlas::exportStemCopies({{"Drums",kick.getFullPathName()}},scratch,"Export test",exportedAgain).wasOk()&&exportedAgain!=exported,"Repeated export preserves previous files");
    check(!atlas::exportStemCopies({{"Missing",scratch.getChildFile("missing.wav").getFullPathName()}},scratch,"Bad export",exportedAgain).wasOk(),"Export reports missing source");
    const auto longPreview=write("Long_preview_62s.wav",65,62);processor.preview.load(longPreview,59,3);for(int i=0;i<100&&!processor.preview.isPlaying();++i)juce::Thread::sleep(10);
    for(int i=0;i<400&&processor.preview.isPlaying();++i){block.clear();processor.processBlock(block,midi);juce::Thread::sleep(1);}
    check(processor.preview.playhead.load()>61.9&&!processor.preview.isPlaying(),"Waveform audition seeks beyond sixty seconds and stops at selection end");
    processor.preview.load(longPreview);for(int i=0;i<100&&!processor.preview.isPlaying();++i)juce::Thread::sleep(10);
    for(int i=0;i<6500&&processor.preview.isPlaying();++i){block.clear();processor.processBlock(block,midi);juce::Thread::sleep(1);}
    check(processor.preview.playhead.load()>61.9&&!processor.preview.isPlaying(),"Streaming plays a complete long file with bounded buffer memory");
    processor.engine.selectReference(kick);snap=processor.engine.snapshot();check(snap.matches.empty()&&snap.stems.empty()&&snap.hits.empty(),"New reference clears stale matches and stems");
    processor.engine.setRoots({}); wait();
    check(processor.engine.snapshot().samples->empty(), "Remove library folders");
    std::cout << "PASS: WAV scan, deduplication, corrupt-file handling, cached rescan, manual tags, reference attacks, audio passthrough, resampled preview, stop race, host state, editor render, folder removal\n";
    return 0;
}
#endif

