#pragma once
#include <juce_core/juce_core.h>
namespace atlas::hosting {
inline bool validPluginClassIdentity(const juce::String& value) {
    auto hex = value.startsWith("vst2:") ? value.substring(5) : value;
    return hex.length() == (value.startsWith("vst2:") ? 64 : 32)
        && hex.containsOnly("0123456789abcdefABCDEF");
}
}
