#pragma once
#include "Analysis.h"
#include <functional>
namespace atlas::stemnotes {
using Cancel = std::function<bool()>;
struct Note { int pitch, velocity; double start, end; };
struct Part {
    std::vector<Note> notes;
    Features timbre;
    juce::String role, family;
    bool drums = false;
    bool tonalDrums = false; // Measured pitched percussion, not GM kit keys.
    double duration = 0;
};
inline double exportTempo(double hostBpm,double referenceBpm,double tempoPercent){
    const auto valid=[](double v){return std::isfinite(v)&&v>=20&&v<=400;};
    if(valid(hostBpm))return hostBpm; // One clock for all tracks in the DAW.
    double source=referenceBpm*tempoPercent/100.;
    return valid(referenceBpm)&&valid(source)?source:0;
}
juce::Result analyse(const juce::File&, const juce::String& stem, Part&, const Cancel& = {}, bool allowUnpitched = false);
juce::Result writeMidi(const Part&, double bpm, const juce::File&);
}
