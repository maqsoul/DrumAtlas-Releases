#pragma once
#include "Composer.h"
#include "EmberTheme.h"
#include "ComposerLocale.h"
#include <juce_gui_extra/juce_gui_extra.h>
#include <set>
#include <tuple>

namespace atlas::composer {
class NoteGrid : public juce::Component {
public:
    static constexpr int left=58,top=26,rowHeight=14,barWidth=192;
    struct Step { MidiChange change; std::optional<music::Note> before; };
    std::function<void()> changed,selectionChanged;
    std::shared_ptr<const Song> song;
    juce::String trackId,selected;
    std::set<juce::String> selectedIds;
    std::vector<music::Note> notes;
    int divisions=16;

    NoteGrid(){setWantsKeyboardFocus(true);setComponentID("composer-note-grid");}
    const music::Track* track()const{if(song)for(auto&t:song->project.tracks)if(t.id==trackId)return &t;return nullptr;}
    const music::Note* selection()const{for(auto&n:notes)if(n.id==selected)return &n;return nullptr;}
    void load(std::shared_ptr<const Song>s,const juce::String&id){song=std::move(s);trackId=id;auto*t=track();notes=t?t->notes:std::vector<music::Note>{};selected.clear();selectedIds.clear();steps.clear();cursor=0;dragging=false;lasso=false;setSize(song?left+song->project.settings.bars*barWidth+16:760,top+128*rowHeight);repaint();if(selectionChanged)selectionChanged();}
    bool dirty()const{return cursor>0;}
    bool canUndo()const{return cursor>0;}
    bool canRedo()const{return cursor<steps.size();}
    std::vector<MidiChange> pending()const{std::vector<MidiChange> result;for(size_t i=0;i<cursor;++i)for(auto&step:steps[i])result.push_back(step.change);return result;}
    bool undo(){if(!isEnabled()||!cursor)return false;auto&batch=steps[--cursor];for(auto it=batch.rbegin();it!=batch.rend();++it)replaceLocal(it->change.note.id,it->before);finish();return true;}
    bool redo(){if(!isEnabled()||cursor>=steps.size())return false;for(auto&step:steps[cursor++])replaceLocal(step.change.note.id,step.change.kind==MidiChange::Remove?std::optional<music::Note>{}:step.change.note);finish();return true;}
    void revert(){load(song,trackId);if(changed)changed();}
    void velocity(int value){std::vector<MidiChange>batch;for(auto&n:notes)if(isSelected(n.id)){auto copy=n;copy.velocity=juce::jlimit(1,127,value);if(copy.velocity!=n.velocity)batch.push_back({MidiChange::Replace,trackId,copy});}recordBatch(batch);}
    void removeSelected(){std::vector<MidiChange>batch;for(auto&n:notes)if(isSelected(n.id))batch.push_back({MidiChange::Remove,trackId,n});recordBatch(batch);}
    void selectAll(){selectedIds.clear();for(auto&n:notes)selectedIds.insert(n.id);selected=notes.empty()?juce::String():notes.front().id;finish(false);}
    void copySelected(){clipboard.clear();for(auto&n:notes)if(isSelected(n.id))clipboard.push_back(n);}
    void pasteAt(int64_t tick){if(clipboard.empty()||!song)return;auto first=clipboard.front().tick;for(auto&n:clipboard)first=std::min(first,n.tick);std::vector<MidiChange>batch;std::set<juce::String>ids;for(auto n:clipboard){n.id=juce::Uuid().toString().removeCharacters("-");n.tick+=tick-first;if(n.tick+n.microtiming<0||n.tick+n.microtiming+n.duration>endTick())return;ids.insert(n.id);batch.push_back({MidiChange::Insert,trackId,n});}if(recordBatch(batch)){selectedIds=ids;selected=batch.front().note.id;finish(false);}}
    void duplicateSelected(){copySelected();if(clipboard.empty())return;int64_t end=0;for(auto&n:clipboard)end=std::max(end,n.tick+n.duration+n.microtiming);pasteAt(((end+gridTick()-1)/gridTick())*gridTick());}
    juce::var draft()const{if(!dirty()||!song)return {};auto project=song->project;for(auto&t:project.tracks)if(t.id==trackId)t.notes=notes;auto encoded=music::encode(project);juce::var values;for(auto&t:*encoded["tracks"].getArray())if(t["id"].toString()==trackId)values=t["notes"].clone();auto*o=new juce::DynamicObject;o->setProperty("project",song->project.id);o->setProperty("track",trackId);o->setProperty("notes",values);o->setProperty("divisions",divisions);return juce::var(o);}
    bool restoreDraft(const juce::var&value){
        if(!song||value["project"].toString()!=song->project.id||value["track"].toString()!=trackId||!value["notes"].isArray())return false;
        auto encoded=music::encode(song->project);for(auto&t:*encoded["tracks"].getArray())if(t["id"].toString()==trackId)t.getDynamicObject()->setProperty("notes",value["notes"].clone());music::Project restored;if(music::decode(encoded,restored).failed())return false;
        auto fields=[](const music::Note&n){return std::tie(n.pitch,n.velocity,n.channel,n.tick,n.duration,n.microtiming,n.probability,n.glideFrom,n.glideTicks,n.bendRange,n.articulation);};
        std::map<juce::String,music::Note>before,after;for(auto&n:notes)before.emplace(n.id,n);for(auto&t:restored.tracks)if(t.id==trackId)for(auto&n:t.notes)after.emplace(n.id,n);
        std::vector<MidiChange>batch;for(auto&entry:before)if(!after.count(entry.first))batch.push_back({MidiChange::Remove,trackId,entry.second});
        for(auto&entry:after){auto old=before.find(entry.first);if(old==before.end())batch.push_back({MidiChange::Insert,trackId,entry.second});else if(fields(old->second)!=fields(entry.second))batch.push_back({MidiChange::Replace,trackId,entry.second});}
        if(!batch.empty()&&!recordBatch(batch))return false;int d=int(value["divisions"]);if(d==4||d==8||d==16||d==32)divisions=d;return true;
    }
    juce::Rectangle<float> noteRect(const music::Note&n)const{double bar=song?double(music::barTicks(song->project.settings)):3840.;return {float(left+(n.tick+n.microtiming)/bar*barWidth),float(top+(127-n.pitch)*rowHeight+1),float(std::max(4.,n.duration/bar*barWidth)),float(rowHeight-2)};}
    void paint(juce::Graphics&g)override{
        g.fillAll(ember::background);if(!song)return;auto clip=g.getClipBounds();g.setFont(ember::font(11));
        for(int pitch=0;pitch<128;++pitch){int y=top+(127-pitch)*rowHeight;if(y+rowHeight<clip.getY()||y>clip.getBottom())continue;bool black=juce::StringArray{"1","3","6","8","10"}.contains(juce::String(pitch%12));g.setColour(black?juce::Colour(0xff19130f):juce::Colour(0xff241b16));g.fillRect(0,y,getWidth(),rowHeight);g.setColour(ember::edge);g.drawHorizontalLine(y,0,float(getWidth()));g.setColour(ember::text);g.drawText(juce::MidiMessage::getMidiNoteName(pitch,true,true,3),3,y,left-5,rowHeight,juce::Justification::centredLeft);}
        int first=std::max(0,(clip.getX()-left)/barWidth),last=std::min(song->project.settings.bars,(clip.getRight()-left)/barWidth+1);
        for(int bar=first;bar<=last;++bar){for(int step=0;step<divisions;++step){float x=float(left+bar*barWidth+step*barWidth/double(divisions));g.setColour(ember::edge.withAlpha(step==0?1.f:.4f));g.drawVerticalLine(int(x),float(top),float(getHeight()));}g.setColour(ember::text);g.drawText(juce::String(bar+1),left+bar*barWidth+3,0,50,top,juce::Justification::centredLeft);}
        for(auto&note:notes){auto n=note;if(dragging)for(auto&p:previews)if(p.id==n.id){n=p;break;}auto rect=noteRect(n);if(!rect.intersects(clip.toFloat()))continue;g.setColour(ember::hot(ember::styleOf(*this)).withAlpha(.35f+.65f*n.velocity/127.f));g.fillRoundedRectangle(rect,2);if(isSelected(n.id)){g.setColour(ember::text);g.drawRoundedRectangle(rect,2,1.3f);}}
        if(lasso){g.setColour(ember::orange.withAlpha(.15f));g.fillRect(lassoBounds);g.setColour(ember::orange);g.drawRect(lassoBounds,1.f);}
    }
    void mouseDown(const juce::MouseEvent&e)override{
        if(!isEnabled()||!song||!track())return;grabKeyboardFocus();dragging=false;lasso=false;origin=e.position;pasteTick=tickAt(e.x);auto id=hit(e.position);bool extend=e.mods.isShiftDown()||e.mods.isCtrlDown();if(!extend&&!isSelected(id))selectedIds.clear();if(id.isNotEmpty()){if(extend&&selectedIds.count(id)){selectedIds.erase(id);selected=selectedIds.empty()?juce::String():*selectedIds.begin();}else{selectedIds.insert(id);selected=id;}}else{selected.clear();if(!extend)selectedIds.clear();lassoBase=selectedIds;lasso=true;lassoBounds={e.position,e.position};}if(selectionChanged)selectionChanged();repaint();
        if(e.mods.isPopupMenu()){removeSelected();return;}
        originals.clear();for(auto&n:notes)if(isSelected(n.id))originals.push_back(n);if(auto*n=selection()){original=*n;auto rect=noteRect(*n);resize=e.x>=rect.getRight()-std::min(6.f,rect.getWidth()*.25f);}
    }
    void mouseDoubleClick(const juce::MouseEvent&e)override{
        if(!isEnabled()||!song||!track()||!e.mods.isLeftButtonDown()||e.x<left||e.y<top)return;
        if(!hit(e.position).isEmpty())return;lasso=false;music::Note n;n.id=juce::Uuid().toString().removeCharacters("-");n.tick=tickAt(e.x);auto end=endTick();if(n.tick>=end)return;n.pitch=pitchAt(e.y);n.channel=music::gmDrumNote(track()->role)>=0?10:1;n.duration=std::min(gridTick(),end-n.tick);n.velocity=100;selected=n.id;selectedIds={n.id};record({MidiChange::Insert,trackId,n});
    }
    void mouseDrag(const juce::MouseEvent&e)override{
        if(!isEnabled()||!e.mods.isLeftButtonDown()||e.getDistanceFromDragStart()<3)return;
        if(lasso){lassoBounds={origin,e.position};selectedIds=lassoBase;for(auto&n:notes)if(noteRect(n).intersects(lassoBounds))selectedIds.insert(n.id);selected=selectedIds.empty()?juce::String():*selectedIds.begin();finish(false);return;}
        if(originals.empty())return;dragging=true;previews=originals;auto delta=int64_t(std::llround((e.x-origin.x)/barWidth*music::barTicks(song->project.settings)/gridTick()))*gridTick();int pitchDelta=-int(std::lround((e.y-origin.y)/rowHeight));
        int64_t minDelta=-endTick(),maxDelta=endTick();int minPitch=-127,maxPitch=127;
        for(auto&n:originals){if(resize){minDelta=std::max(minDelta,1-n.duration);maxDelta=std::min(maxDelta,endTick()-n.tick-n.microtiming-n.duration);}else{minDelta=std::max(minDelta,-n.tick-n.microtiming);maxDelta=std::min(maxDelta,endTick()-n.tick-n.microtiming-n.duration);minPitch=std::max(minPitch,-n.pitch);maxPitch=std::min(maxPitch,127-n.pitch);}}delta=juce::jlimit(minDelta,maxDelta,delta);pitchDelta=juce::jlimit(minPitch,maxPitch,pitchDelta);
        for(auto&n:previews)if(resize){n.duration+=delta;n.glideTicks=int(std::min<int64_t>(n.glideTicks,n.duration));}else{n.tick+=delta;n.pitch+=pitchDelta;}
        repaint();
    }
    void mouseUp(const juce::MouseEvent&)override{if(lasso){lasso=false;repaint();return;}if(!dragging)return;dragging=false;std::vector<MidiChange>batch;for(auto&n:previews)batch.push_back({MidiChange::Replace,trackId,n});recordBatch(batch);repaint();}
    bool keyPressed(const juce::KeyPress&key)override{
        if(key.getKeyCode()==juce::KeyPress::deleteKey||key.getKeyCode()==juce::KeyPress::backspaceKey){removeSelected();return true;}
        if(key.getModifiers().isCtrlDown()&&key.getKeyCode()=='Z'){if(key.getModifiers().isShiftDown())redo();else undo();return true;}
        if(key.getModifiers().isCtrlDown()){switch(key.getKeyCode()){case 'Y':redo();return true;case 'A':selectAll();return true;case 'C':copySelected();return true;case 'V':pasteAt(pasteTick);return true;case 'D':duplicateSelected();return true;}}return false;
    }
    // Public command entry also permits deterministic UI gesture tests.
    void record(const MidiChange&change){recordBatch({change});}
    bool recordBatch(const std::vector<MidiChange>&changes){if(!isEnabled()||!track()||track()->midiLocked||changes.empty()||pending().size()+changes.size()>4096)return false;auto current=song->project;for(auto&t:current.tracks)if(t.id==trackId)t.notes=notes;music::Project checked;if(applyMidiChanges(current,changes,checked).failed())return false;std::vector<Step>batch;for(auto&change:changes){std::optional<music::Note>before;for(auto&n:notes)if(n.id==change.note.id)before=n;batch.push_back({change,before});replaceLocal(change.note.id,change.kind==MidiChange::Remove?std::optional<music::Note>{}:change.note);}steps.resize(cursor);steps.push_back(std::move(batch));++cursor;finish();return true;}
private:
    std::vector<std::vector<Step>>steps;size_t cursor=0;bool dragging=false,resize=false,lasso=false;music::Note original;std::vector<music::Note>originals,previews,clipboard;juce::Point<float>origin;juce::Rectangle<float>lassoBounds;std::set<juce::String>lassoBase;int64_t pasteTick=0;
    bool isSelected(const juce::String&id)const{return id.isNotEmpty()&&(selectedIds.count(id)||(selectedIds.empty()&&id==selected));}
    int64_t gridTick()const{return std::max<int64_t>(1,music::barTicks(song->project.settings)/divisions);}
    int64_t endTick()const{return music::barTicks(song->project.settings)*song->project.settings.bars;}
    int64_t tickAt(float x)const{return std::max<int64_t>(0,int64_t(std::llround((x-left)/barWidth*music::barTicks(song->project.settings)/gridTick()))*gridTick());}
    int pitchAt(float y)const{return juce::jlimit(0,127,127-int((y-top)/rowHeight));}
    juce::String hit(juce::Point<float>p)const{for(auto it=notes.rbegin();it!=notes.rend();++it)if(noteRect(*it).contains(p))return it->id;return {};}
    void replaceLocal(const juce::String&id,const std::optional<music::Note>&value){auto it=std::find_if(notes.begin(),notes.end(),[&](const auto&n){return n.id==id;});if(it!=notes.end())notes.erase(it);if(value)notes.push_back(*value);std::stable_sort(notes.begin(),notes.end(),[](const auto&a,const auto&b){return a.tick<b.tick;});}
    void finish(bool content=true){repaint();if(selectionChanged)selectionChanged();if(content&&changed)changed();}
};

class NoteViewport : public juce::Viewport {
public: std::function<void()> scrolled;
    void visibleAreaChanged(const juce::Rectangle<int>&)override{if(scrolled)scrolled();}
};
class NoteAxis : public juce::Component {
public:
    NoteAxis(NoteGrid&g,juce::Viewport&v,bool vertical):grid(g),view(v),keys(vertical){}
    void paint(juce::Graphics&g)override{
        g.fillAll(ember::panel);g.setFont(ember::font(11));if(!grid.song)return;
        if(keys){for(int p=0;p<128;++p){int y=NoteGrid::top+(127-p)*NoteGrid::rowHeight-view.getViewPositionY();if(y+NoteGrid::rowHeight<0||y>getHeight())continue;g.setColour(ember::edge);g.drawHorizontalLine(y,0,float(getWidth()));g.setColour(ember::text);g.drawText(juce::MidiMessage::getMidiNoteName(p,true,true,3),3,y,getWidth()-6,NoteGrid::rowHeight,juce::Justification::centredLeft);}}
        else{int first=std::max(0,view.getViewPositionX()/NoteGrid::barWidth);for(int bar=first;bar<=grid.song->project.settings.bars;++bar){int x=NoteGrid::left+bar*NoteGrid::barWidth-view.getViewPositionX();if(x>getWidth())break;if(x<NoteGrid::left)continue;g.setColour(ember::text);g.drawText(juce::String(bar+1),x+3,0,50,getHeight(),juce::Justification::centredLeft);}g.setColour(ember::muted);g.drawText("Bar",3,0,NoteGrid::left-6,getHeight(),juce::Justification::centredLeft);}
    }
private:NoteGrid&grid;juce::Viewport&view;bool keys;
};

class NoteEditor : public juce::Component {
public:
    NoteGrid grid;
    std::function<void()>onClose,onDirty;
    std::function<void(const juce::String&,std::vector<MidiChange>)>onApply;
    NoteEditor():keyboard(grid,view,true),ruler(grid,view,false){
        setComponentID("composer-note-editor");for(auto*c:std::initializer_list<juce::Component*>{&back,&apply,&revert,&undo,&redo,&division,&velocity,&label,&hint,&view,&keyboard,&ruler})addAndMakeVisible(c);
        view.scrolled=[this]{keyboard.repaint();ruler.repaint();};
        view.setViewedComponent(&grid,false);view.setScrollBarsShown(true,true);for(int n:{4,8,16,32})division.addItem("1/"+juce::String(n),n);division.setSelectedId(16);division.onChange=[this]{grid.divisions=division.getSelectedId();grid.repaint();};
        velocity.setRange(1,127,1);velocity.setSliderStyle(juce::Slider::LinearHorizontal);velocity.setTextBoxStyle(juce::Slider::TextBoxRight,false,44,24);velocity.setTooltip("Velocity of the selected note (1-127)");
        velocity.onDragEnd=[this]{grid.velocity(int(velocity.getValue()));};velocity.onValueChange=[this]{if(!updating&&!velocity.isMouseButtonDown())grid.velocity(int(velocity.getValue()));};
        grid.selectionChanged=[this]{refresh();};grid.changed=[this]{refresh();if(onDirty)onDirty();};
        apply.onClick=[this]{if(onApply&&grid.song)onApply(grid.song->project.id,grid.pending());};revert.onClick=[this]{grid.revert();};undo.onClick=[this]{grid.undo();};redo.onClick=[this]{grid.redo();};
        back.onClick=[this]{if(grid.dirty()){hint.setText("Apply MIDI or Revert before closing",juce::dontSendNotification);return;}if(onClose)onClose();};
        hint.setText("Drag empty area: select | Shift-click: add to selection | Ctrl+C/V: copy/paste | Ctrl+D: duplicate | Delete: remove",juce::dontSendNotification);
    }
    void localise(const juce::String&language){localiseComposerControls(*this,language);hint.setText(ct("midiHint",language),juce::dontSendNotification);}
    ~NoteEditor()override{view.setViewedComponent(nullptr,false);}
    void open(std::shared_ptr<const Song>song,const juce::String&id){bool same=grid.song&&grid.trackId==id;auto position=view.getViewPosition();auto selected=grid.selected;grid.load(std::move(song),id);if(same){grid.selected=selected;view.setViewPosition(position);}if(auto*t=grid.track()){label.setText(t->role+" / Velocity",juce::dontSendNotification);if(!same){int pitch=t->notes.empty()?60:t->notes.front().pitch;view.setViewPosition(0,std::max(0,NoteGrid::top+(127-pitch)*NoteGrid::rowHeight-view.getHeight()/2));}}refresh();}
    void setBusy(bool value){busy=value;grid.setEnabled(!busy&&grid.track()&&!grid.track()->midiLocked);refresh();}
    bool dirty()const{return grid.dirty();}
    void resized()override{auto area=getLocalBounds();auto row=area.removeFromTop(30);back.setBounds(row.removeFromLeft(96));row.removeFromLeft(4);apply.setBounds(row.removeFromLeft(106));row.removeFromLeft(4);revert.setBounds(row.removeFromLeft(66));row.removeFromLeft(4);undo.setBounds(row.removeFromLeft(54));row.removeFromLeft(4);redo.setBounds(row.removeFromLeft(54));row.removeFromLeft(4);division.setBounds(row.removeFromLeft(96));auto values=area.removeFromTop(30);label.setBounds(values.removeFromLeft(180));velocity.setBounds(values.removeFromLeft(230));hint.setBounds(area.removeFromBottom(32));ruler.setBounds(area.removeFromTop(22));view.setBounds(area.reduced(0,4));keyboard.setBounds(view.getX(),view.getY(),NoteGrid::left,std::max(0,view.getHeight()-view.getScrollBarThickness()));}
    void paint(juce::Graphics&g)override{g.fillAll(ember::background);}
private:
    juce::TextButton back{"Arrangement"},apply{"Apply MIDI"},revert{"Revert"},undo{"Undo"},redo{"Redo"};juce::ComboBox division;juce::Slider velocity;juce::Label label,hint;NoteViewport view;NoteAxis keyboard,ruler;bool busy=false,updating=false;
    void refresh(){updating=true;auto*n=grid.selection();velocity.setEnabled(!busy&&n);if(n)velocity.setValue(n->velocity,juce::dontSendNotification);updating=false;apply.setEnabled(!busy&&grid.dirty());revert.setEnabled(!busy&&grid.dirty());undo.setEnabled(!busy&&grid.canUndo());redo.setEnabled(!busy&&grid.canRedo());back.setEnabled(!busy);division.setEnabled(!busy);}
};
}
