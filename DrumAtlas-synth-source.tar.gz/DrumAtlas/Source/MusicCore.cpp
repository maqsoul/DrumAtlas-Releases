#include "SoundAdapters.h"
#include "MusicCore.h"
#include "MidiParameterMap.h"
#include "NativeEditorPosition.h"
#include "TempoMap.h"
#include <juce_cryptography/juce_cryptography.h>
#include "MidiGlide.h"
#include "MusicHarmony.h"
#include <algorithm>
#include <cmath>
#include <set>
#include <tuple>
#include <stdexcept>

namespace atlas::music {
namespace {
// Defined integer PRNG, independent of std::uniform_distribution implementations.
struct Random { uint32_t state; uint32_t next(){state=state*1664525u+1013904223u;return state;} int bounded(int n){return int(next()%uint32_t(n));} };
uint32_t roleHash(const juce::String& role){uint32_t h=2166136261u;for(auto c:role.toStdString()){h^=uint8_t(c);h*=16777619u;}return h;}
juce::var object(){return new juce::DynamicObject();}
void put(juce::var&v,const char*k,const juce::var&x){v.getDynamicObject()->setProperty(k,x);}
bool number(const juce::var&v){return v.isInt()||v.isInt64()||v.isDouble();}
bool integer(const juce::var&v){return v.isInt()||v.isInt64();}
juce::Result fail(const char*s){return juce::Result::fail(s);}
juce::Result resolveStyle(const juce::var&snapshot,StyleBlend&style){
    if(!snapshot.isObject()||!snapshot["genres"].isArray()||!snapshot["moods"].isArray())return fail("Missing style snapshot");
    ProfileRegistry registry;auto r=registry.decode(snapshot["registry"]);if(r.failed())return r;
    std::vector<StyleWeight>genres,moods;
    for(auto key:{"genres","moods"}){if(snapshot[key].size()>64)return fail("Too many profile weights");for(auto&w:*snapshot[key].getArray()){if(!w["id"].isString()||!number(w["weight"]))return fail("Invalid profile weight");(juce::String(key)=="genres"?genres:moods).push_back({w["id"].toString(),double(w["weight"])});}}
    return registry.blend(genres,moods,style);
}
std::array<int,4> styledProgression(const Settings&s,const StyleBlend&style){
    const double darkness=(s.darkness+style.mood.darkness)*.5,energy=(s.energy+style.mood.energy)*.5;
    return darkness>=.6?std::array<int,4>{0,5,3,6}:energy>=.6
        ?std::array<int,4>{0,4,5,3}:std::array<int,4>{0,3,1,4};
}
Track makeStyledTrack(const Settings&s,const StyleBlend&style,const juce::String&role,bool expressive=false,const std::array<int,4>*savedPlan=nullptr,bool moodTiming=false,bool anchors=false){
    auto genre=style.genre;
    if(moodTiming&&s.genreInfluence!=1){
        auto mix=[&](double neutral,double value){return neutral+(value-neutral)*s.genreInfluence;};
        for(int i=0;i<16;++i){genre.kick[size_t(i)]=mix(i==0?1.:i==8?.5:0.,genre.kick[size_t(i)]);genre.snare[size_t(i)]=mix(i==4||i==12?1.:0.,genre.snare[size_t(i)]);genre.hat[size_t(i)]=mix(i%2==0?.75:0.,genre.hat[size_t(i)]);}
        genre.swing=mix(0,genre.swing);genre.microtiming=mix(.5,genre.microtiming);genre.density=mix(.5,genre.density);
    }
    Track t;t.id="track-"+role;t.role=role;Random r{s.seed^roleHash(role)};const auto bar=barTicks(s);
    const bool melodic=role=="Bass"||role=="Chords"||role=="Melody"||role=="Countermelody";
    const double energy=(s.energy+style.mood.energy)*.5,complexity=(s.complexity+style.mood.complexity)*.5;
    const double effectiveGroove=moodTiming?juce::jlimit(0.,1.,s.groove*(.5+style.mood.groove)):s.groove;
    const double effectiveHumanize=moodTiming?juce::jlimit(0.,1.,s.humanize*(.5+genre.microtiming)):s.humanize;
    auto add=[&](int b,int step,int pitch,int64_t duration,int velocity,bool anchor=false){
        Note n;n.id=t.id+"-"+juce::String(int(t.notes.size()));n.channel=melodic?1:10;n.pitch=juce::jlimit(0,127,pitch);n.tick=b*bar+bar*step/16;
        if(step%2)n.tick+=int64_t(bar/16*(s.swing+genre.swing)*.225*effectiveGroove);
        n.duration=std::min(duration,(b+1)*bar-n.tick);n.velocity=juce::jlimit(1,127,int(velocity*(.65+.7*energy))+r.bounded(9)-4);
        // Accent strength changes only generated anchor velocities. It does not
        // move anchors, change their protection, or consume additional random draws.
        if(anchor&&anchors&&s.drumAccents>=0)n.velocity=juce::jlimit(1,127,n.velocity+int(std::lround((s.drumAccents-.5)*32.)));
        n.microtiming=int64_t((r.bounded(41)-20)*effectiveHumanize);if(anchor){n.microtiming=0;n.articulation="accent";}n.microtiming=juce::jlimit(-n.tick,bar*s.bars-n.tick-n.duration,n.microtiming);t.notes.push_back(n);
    };
    const auto&scale=*scaleDegrees(s.scale);
    // The saved plan keeps separately regenerated parts harmonically aligned,
    // even after expression settings have changed without regenerating chords.
    const auto progression=!expressive?std::array<int,4>{0,5,3,4}:savedPlan?*savedPlan:styledProgression(s,style);
    for(int b=0;b<s.bars;++b){
        const int degree=progression[b%4],root=36+s.tonic+scale[degree];
        auto chordNote=[&](int d){return 48+s.tonic+scale[d%7]+12*(d/7);};
        if(role=="Chords"){for(int interval:{0,2,4})add(b,0,chordNote(degree+interval),std::max<int64_t>(1,int64_t(bar*(.45+.5*(1-style.mood.articulation)))),64);if(complexity>.6)add(b,0,chordNote(degree+6),bar*3/4,55);}
        else if(role=="Bass"){for(int step=0;step<16;++step)if(genre.kick[size_t(step)]>.5){int next=step+1;while(next<16&&genre.kick[size_t(next)]<=.5)++next;add(b,step,root-12,std::max<int64_t>(1,bar*(next-step)/16*(expressive?(.45+.5*(1-style.mood.articulation)):1.)-10),95);}}
        else if(role=="Countermelody"){
            // Sparse offbeat answer, using the saved harmonic plan and its own role seed.
            for(int step:{6,14})if(step==14||double(r.next())/4294967296.<s.melodicDensity){int d=degree+(step==6?2:4);add(b,step,60+s.tonic+scale[d%7]+12*(d/7),std::max<int64_t>(1,bar/16),60);}
        }
        else if(role=="FX"){
            // Transition trigger; user samples/VSTs can replace the built-in noise hit.
            if(b%4==3||b==s.bars-1)add(b,14,60,std::max<int64_t>(1,bar/8),60);
        }
        else if(role=="Melody"){
            const double density=(s.melodicDensity+style.mood.melodicDensity)*.5;
            for(int step=0;step<16;step+=complexity>.65?2:4)if(double(r.next())/4294967296.<density){int d=(degree+(expressive&&step%4==0?2*r.bounded(3):r.bounded(complexity>.5?7:3)))%7;int octave=(s.darkness+style.mood.darkness)>1.2?48:60;add(b,step,octave+s.tonic+scale[d],expressive?std::max<int64_t>(1,int64_t(bar/8*(.35+1.3*(1-style.mood.articulation)))):bar/8,75);}
        }else{
            for(int step=0;step<16;++step){double chance=0;int pitch=36,velocity=100;
                if(role=="Kick")chance=genre.kick[size_t(step)];
                else if(role=="Snare"||role=="Clap"){chance=genre.snare[size_t(step)];pitch=role=="Snare"?38:39;velocity=role=="Snare"?100:65;}
                else if(role=="Closed Hat"){chance=genre.hat[size_t(step)];pitch=42;velocity=step%4?65:82;}
                else if(role=="Open Hat"){chance=step%8==6?.5:0;pitch=46;velocity=72;}
                else if(role=="Percussion"){chance=step%4==3?.4*complexity:0;pitch=64;velocity=60;}
                if(anchors&&style.genre.id=="Trap"&&s.numerator==4&&s.denominator==4&&role=="Kick"&&step!=0){
                    // Retain the opening anchor; vary the syncopated answers by seed.
                    if(chance>0)chance*=.65+.25*complexity;
                    else if(step==3||step==10||step==15)chance=.25*complexity*s.genreInfluence;
                }
                chance*=juce::jlimit(0.,1.5,(s.density+genre.density));
                // Closed/open hats only: .5 is the original probability, 0 is
                // silent (and cannot trigger rolls), 1 doubles the probability.
                if(anchors&&s.hatsDensity>=0&&(role=="Closed Hat"||role=="Open Hat"))chance=std::min(1.,chance*(2.*s.hatsDensity));
                const bool anchor=anchors&&s.density>0&&((role=="Kick"&&step==0&&genre.kick[0]>=.8)||((role=="Snare"||role=="Clap")&&genre.snare[size_t(step)]>=.95));
                const bool chosen=double(r.next())/4294967296.<chance;
                if(chosen||anchor){
                    add(b,step,pitch,std::min<int64_t>(120,bar/16),velocity,anchor);
                    if(anchors&&role=="Closed Hat"&&step%8==7&&s.complexity>.65&&s.density>0&&r.bounded(4)==0){
                        auto&first=t.notes.back();if(first.duration>=2){auto second=first;const auto length=first.duration;first.duration=length/2;first.articulation="roll";second.tick+=first.duration;second.duration=length-first.duration;second.id=t.id+"-"+juce::String(int(t.notes.size()));second.articulation="roll";second.velocity=std::max(1,second.velocity-12);t.notes.push_back(second);}
                    }
                }
            }
        }
    }return t;
}
Track makeTrack(const Settings&s,const juce::String&role){
    Track t;t.id="track-"+role;t.role=role;
    Random r{s.seed^roleHash(role)};const auto bar=barTicks(s);
    auto add=[&](int b,int64_t offset,int pitch,int64_t duration,int velocity,bool anchor=false){
        Note n;n.id=t.id+"-"+juce::String(b)+"-"+juce::String(int(t.notes.size()));n.pitch=pitch;n.channel=(role=="Bass"||role=="Chords"||role=="Melody")?1:10;
        n.tick=b*bar+offset;n.duration=std::min(duration,bar-offset);n.velocity=juce::jlimit(1,127,velocity+r.bounded(11)-5);
        if(!anchor)n.microtiming=int64_t((r.bounded(41)-20)*s.humanize);
        n.microtiming=std::max(-n.tick,std::min(n.microtiming,bar*s.bars-n.tick-n.duration));t.notes.push_back(n);
    };
    const int roots[]={0,8,5,7};const int intervals[]={0,2,3,5,7,8,10};
    for(int b=0;b<s.bars;++b){
        const int root=36+s.tonic+roots[b%4];
        if(role=="Kick"){add(b,0,36,120,112,true);if(s.density>.25)add(b,bar*3/8,36,120,94);if(s.density>.6||b%2)add(b,bar*13/16,36,120,103);}
        else if(role=="Snare"||role=="Clap"){add(b,bar/2,role=="Snare"?38:39,120,role=="Snare"?105:75,true);}
        else if(role=="Closed Hat"){
            const int steps=s.density>.65?16:8;
            for(int i=0;i<steps;++i){if(i==steps-1)continue;int64_t tick=bar*i/steps;if(i%2)tick+=int64_t((bar/steps)*s.swing*.45);add(b,tick,42,90,i%2?64:84);}
        }else if(role=="Open Hat")add(b,bar*7/8,46,std::min<int64_t>(240,bar/8),75);
        else if(role=="Percussion"){if(s.density>.3)add(b,bar*11/16,64,120,65);}
        else if(role=="Bass"){add(b,0,root-12,bar*3/8,100,true);add(b,bar/2,root-12,bar*3/8,92,true);}
        else if(role=="Chords"){
            // A-minor family: Am(add9), Fmaj7, Dm9, Em7, transposed by tonic.
            const std::vector<std::vector<int>> chords{{0,3,7,14},{0,4,7,11},{0,3,7,10,14},{0,3,7,10}};
            for(int n:chords[size_t(b%4)])add(b,0,root+12+n,bar-120,68,true);
        }else if(role=="Melody"){
            for(int i=0;i<4;++i){if(i==2&&b%2==0)continue;int degree=(i+(b%2?2:0))%7;add(b,bar*i/4,60+s.tonic+intervals[degree],bar/8,80);}
        }
    }
    std::stable_sort(t.notes.begin(),t.notes.end(),[](const Note&a,const Note&b){return a.tick<b.tick;});return t;
}
}
int gmDrumNote(const juce::String&role){const char*roles[]{"Kick","Snare","Clap","Closed Hat","Open Hat","Percussion"};const int notes[]{36,38,39,42,46,64};for(int i=0;i<6;++i)if(role==roles[i])return notes[i];return -1;}
juce::Result addDrumLane(Project&p,const juce::String&name,const juce::String&role,int pitch){
 auto r=validate(p);if(r.failed())return r;if(gmDrumNote(role)<0||pitch<0||pitch>127)return fail("Choose a drum role and MIDI note 0..127");auto next=p;Track t;t.id="lane-"+juce::Uuid().toString();t.role=role;t.customName=name.trim();if(t.customName.isEmpty())return fail("Enter a lane name");t.drumNote=pitch;next.tracks.push_back(t);r=validate(next);if(r.wasOk())p=std::move(next);return r;
}
juce::Result renameDrumLane(Project&p,const juce::String&id,const juce::String&name){auto next=p;auto t=std::find_if(next.tracks.begin(),next.tracks.end(),[&](const Track&t){return t.id==id;});if(t==next.tracks.end()||t->customName.isEmpty()||t->midiLocked||t->soundLocked)return fail("Select an unlocked custom drum lane");auto clean=name.trim();if(clean.isEmpty())return fail("Enter a lane name");t->customName=clean;auto r=validate(next);if(r.wasOk())p=std::move(next);return r;}
juce::Result removeDrumLane(Project&p,const juce::String&id){auto next=p;auto t=std::find_if(next.tracks.begin(),next.tracks.end(),[&](const Track&t){return t.id==id;});if(t==next.tracks.end()||t->customName.isEmpty()||t->midiLocked||t->soundLocked)return fail("Select an unlocked custom drum lane");next.tracks.erase(t);auto r=validate(next);if(r.wasOk())p=std::move(next);return r;}
juce::Result setDrumNote(Project&p,const juce::String&track,int pitch){
 auto r=validate(p);if(r.failed())return r;if(pitch<0||pitch>127)return fail("Drum note must be 0..127");auto next=p;auto t=std::find_if(next.tracks.begin(),next.tracks.end(),[&](const Track&t){return t.id==track;});
 if(t==next.tracks.end()||gmDrumNote(t->role)<0||t->midiLocked)return fail("Missing, non-drum or MIDI-locked track");t->drumNote=pitch;for(auto&n:t->notes){n.pitch=pitch;n.channel=10;}
 r=validate(next);if(r.wasOk())p=std::move(next);return r;
}
int64_t barTicks(const Settings&s){return int64_t(ppq)*4*s.numerator/s.denominator;}
bool validGrid(int steps){return steps==16||steps==32||steps==64||steps==12||steps==24||steps==48;}
int64_t gridTick(const Settings&s,int bar,int step,int steps){if(!validGrid(steps)||bar<0||bar>=s.bars||step<0||step>steps)return -1;return barTicks(s)*bar+barTicks(s)*step/steps;}
juce::Result setArticulation(Project&p,const juce::String&track,const juce::StringArray&ids,const juce::String&articulation){
    if(!juce::StringArray{"normal","ghost","accent","roll"}.contains(articulation)||ids.isEmpty())return fail("Choose notes and a supported articulation");
    auto next=p;auto t=std::find_if(next.tracks.begin(),next.tracks.end(),[&](const Track&t){return t.id==track;});
    if(t==next.tracks.end()||t->midiLocked)return fail("Missing or locked MIDI track");
    for(const auto&id:ids){auto n=std::find_if(t->notes.begin(),t->notes.end(),[&](const Note&n){return n.id==id;});if(n==t->notes.end())return fail("Selected note no longer exists");n->articulation=articulation;if(articulation=="ghost")n->velocity=30;else if(articulation=="accent")n->velocity=std::max(100,n->velocity);}
    auto result=validate(next);if(result.wasOk())p=std::move(next);return result;
}
juce::Result editNote(Project&p,const juce::String&track,const Note&note){
    auto next=p;auto t=std::find_if(next.tracks.begin(),next.tracks.end(),[&](const Track&t){return t.id==track;});
    if(t==next.tracks.end()||t->midiLocked)return fail("Missing or locked MIDI track");
    auto n=std::find_if(t->notes.begin(),t->notes.end(),[&](const Note&n){return n.id==note.id;});if(n==t->notes.end())t->notes.push_back(note);else *n=note;
    std::stable_sort(t->notes.begin(),t->notes.end(),[](const Note&a,const Note&b){return a.tick<b.tick;});auto r=validate(next);if(r.wasOk())p=std::move(next);return r;
}
juce::Result moveNotes(Project&p,const juce::String&track,const juce::StringArray&ids,int64_t ticks,int semitones){
    auto valid=validate(p);if(valid.failed())return valid;
    auto next=p;auto t=std::find_if(next.tracks.begin(),next.tracks.end(),[&](const Track&t){return t.id==track;});
    if(t==next.tracks.end()||t->midiLocked)return fail("Missing or locked MIDI track");
    if(ids.isEmpty())return fail("No notes selected");
    auto end=barTicks(p.settings)*p.settings.bars;int64_t low=-end,high=end;int lowPitch=-127,highPitch=127;
    for(const auto&id:ids){auto n=std::find_if(t->notes.begin(),t->notes.end(),[&](const Note&n){return n.id==id;});
        if(n==t->notes.end())return fail("Selected note no longer exists");
        low=std::max({low,-n->tick,-n->tick-n->microtiming});high=std::min({high,end-n->tick-n->duration,end-n->tick-n->microtiming-n->duration});
        lowPitch=std::max({lowPitch,-n->pitch,-n->pitch-n->glideFrom});highPitch=std::min({highPitch,127-n->pitch,127-n->pitch-n->glideFrom});
    }
    ticks=juce::jlimit(low,high,ticks);semitones=juce::jlimit(lowPitch,highPitch,semitones);
    for(auto&n:t->notes)if(ids.contains(n.id)){n.tick+=ticks;n.pitch+=semitones;}
    std::stable_sort(t->notes.begin(),t->notes.end(),[](const Note&a,const Note&b){return a.tick<b.tick;});
    valid=validate(next);if(valid.wasOk())p=std::move(next);return valid;
}
namespace {
template<class Edit>juce::Result batchNotes(Project&p,const juce::String&track,const juce::StringArray&ids,Edit edit){
 auto r=validate(p);if(r.failed())return r;if(ids.isEmpty())return fail("No notes selected");auto next=p;
 auto t=std::find_if(next.tracks.begin(),next.tracks.end(),[&](const Track&t){return t.id==track;});if(t==next.tracks.end()||t->midiLocked)return fail("Missing or locked MIDI track");
 std::set<juce::String>wanted;for(auto&id:ids)wanted.insert(id);size_t found=0;
 for(auto&n:t->notes)if(wanted.count(n.id)){++found;edit(n);}if(found!=wanted.size())return fail("Selected note no longer exists");
 std::stable_sort(t->notes.begin(),t->notes.end(),[](const Note&a,const Note&b){return a.tick<b.tick;});r=validate(next);if(r.wasOk())p=std::move(next);return r;
}
}
juce::Result setNoteValues(Project&p,const juce::String&track,const juce::StringArray&ids,NoteField field,double value){
 if(!std::isfinite(value))return fail("Invalid note value");
 if(field==NoteField::Probability){if(value<0||value>1)return fail("Probability must be 0..100%");}
 else if(std::floor(value)!=value||value < -10000000||value>10000000)return fail("Invalid integer note value");
 if(field==NoteField::Velocity&&(value<1||value>127))return fail("Velocity must be 1..127");
 if(field==NoteField::Duration&&value<1)return fail("Length must be positive");
 if(field!=NoteField::Velocity&&field!=NoteField::Duration&&field!=NoteField::Microtiming&&field!=NoteField::Probability)return fail("Unknown note field");
 return batchNotes(p,track,ids,[&](Note&n){switch(field){case NoteField::Velocity:n.velocity=int(value);break;case NoteField::Duration:n.duration=int64_t(value);n.glideTicks=int(std::min<int64_t>(n.glideTicks,n.duration));break;case NoteField::Microtiming:n.microtiming=int64_t(value);break;case NoteField::Probability:n.probability=value;break;}});
}
juce::Result quantizeNotes(Project&p,const juce::String&track,const juce::StringArray&ids,int steps){
 if(!validGrid(steps))return fail("Invalid quantize grid");auto r=validate(p);if(r.failed())return r;const auto bar=barTicks(p.settings),end=bar*p.settings.bars;
 return batchNotes(p,track,ids,[&](Note&n){auto gridIndex=int64_t(std::llround(double(n.tick+n.microtiming)*steps/bar));auto latest=((end-n.duration+1)*steps-1)/bar;gridIndex=juce::jlimit<int64_t>(0,latest,gridIndex);n.tick=gridIndex*bar/steps;n.microtiming=0;});
}
juce::Result fillDrums(Project&p,const juce::String&track,int barIndex,int beats,int steps,uint32_t seed,double density,double energy){
 if(density==-1)density=p.settings.density;if(energy==-1)energy=p.settings.energy;if(!std::isfinite(density)||density<0||density>1||!std::isfinite(energy)||energy<0||energy>1)return fail("Fill density / energy must be 0..1");
 auto r=validate(p);if(r.failed())return r;if(barIndex<0||barIndex>=p.settings.bars||beats<1||beats>p.settings.numerator||steps<2||steps>32)return fail("Choose a valid bar, fill length and 2..32 steps");
 auto next=p;auto t=std::find_if(next.tracks.begin(),next.tracks.end(),[&](const Track&t){return t.id==track;});if(t==next.tracks.end()||t->midiLocked||gmDrumNote(t->role)<0)return fail("Choose an unlocked drum lane for Fill");
 auto bar=barTicks(p.settings),start=barIndex*bar,end=start+bar,begin=end-bar*beats/p.settings.numerator;
 auto anchor=[&](const Note&n){return n.articulation=="accent"||(t->role=="Kick"&&n.tick==start)||((t->role=="Snare"||t->role=="Clap")&&n.tick==start+bar/2);};
 t->notes.erase(std::remove_if(t->notes.begin(),t->notes.end(),[&](const Note&n){return n.tick>=begin&&n.tick<end&&!anchor(n);}),t->notes.end());
 Random random{seed^roleHash(t->id)};int pitch=t->drumNote>=0?t->drumNote:gmDrumNote(t->role);
 for(int i=0;i<steps;++i){auto tick=begin+(end-begin)*i/steps,finish=begin+(end-begin)*(i+1)/steps;auto draw=random.next();int variation=random.bounded(13)-6;
  if(i>0&&i<steps-1&&double(draw)/4294967296.>(.25+.75*density))continue;
  // Preserve existing notes outside this edit and anchor notes; do not double their attacks.
  bool conflict=false;for(auto&n:t->notes){auto onset=n.tick+n.microtiming;if(onset<finish&&onset+n.duration>tick){conflict=true;break;}}if(conflict)continue;
  Note n;n.id=p.id+":"+t->id+":fill:"+juce::String(barIndex)+":"+juce::String(beats)+":"+juce::String(steps)+":"+juce::String(juce::int64(seed))+":"+juce::String(i);n.pitch=pitch;n.channel=10;n.tick=tick;n.duration=std::max<int64_t>(1,(finish-tick)*3/4);n.velocity=juce::jlimit(1,127,55+int(energy*35)+int(20.*i/(steps-1))+variation);t->notes.push_back(n);
 }
 std::stable_sort(t->notes.begin(),t->notes.end(),[](const Note&a,const Note&b){return a.tick<b.tick;});r=validate(next);if(r.wasOk())r=verifyLockedContent(p,next);if(r.wasOk())p=std::move(next);return r;
}
juce::Result rollNotes(Project&p,const juce::String&track,const juce::StringArray&ids,int hits,int startPercent,int endPercent,juce::StringArray*created){
 auto r=validate(p);if(r.failed())return r;if(hits<2||hits>32||startPercent<1||startPercent>200||endPercent<1||endPercent>200||ids.isEmpty())return fail("Roll needs 2..32 hits, velocity 1..200%, and selected notes");
 auto next=p;auto t=std::find_if(next.tracks.begin(),next.tracks.end(),[&](const Track&t){return t.id==track;});if(t==next.tracks.end()||t->midiLocked||gmDrumNote(t->role)<0)return fail("Select an unlocked drum lane for rolls");
 std::set<juce::String>wanted;for(auto&id:ids)wanted.insert(id);size_t found=0;for(auto&n:t->notes)if(wanted.count(n.id)){++found;if(n.duration<hits||n.glideTicks>0)return fail("Roll note is too short or has Glide; increase Length or remove Glide");}
 if(found!=wanted.size())return fail("Selected note no longer exists");if(t->notes.size()+wanted.size()*size_t(hits-1)>100000)return fail("Roll exceeds track event limit");
 std::vector<Note> result;result.reserve(t->notes.size()+wanted.size()*size_t(hits-1));juce::StringArray output;auto token=juce::Uuid().toString();
 for(auto&n:t->notes){if(!wanted.count(n.id)){result.push_back(n);continue;}for(int h=0;h<hits;++h){auto child=n;child.articulation="roll";auto offset=n.duration*h/hits;child.tick=n.tick+offset;child.duration=n.duration*(h+1)/hits-offset;child.id=h==0?n.id:n.id+":roll:"+token+":"+juce::String(h);child.velocity=juce::jlimit(1,127,int(std::lround(n.velocity*(startPercent+(endPercent-startPercent)*double(h)/(hits-1))/100.)));result.push_back(child);output.add(child.id);}}
 t->notes=std::move(result);std::stable_sort(t->notes.begin(),t->notes.end(),[](const Note&a,const Note&b){return a.tick<b.tick;});r=validate(next);if(r.wasOk()){p=std::move(next);if(created)*created=output;}return r;
}
juce::Result removeNote(Project&p,const juce::String&track,const juce::String&note){
    auto next=p;auto t=std::find_if(next.tracks.begin(),next.tracks.end(),[&](const Track&t){return t.id==track;});if(t==next.tracks.end()||t->midiLocked)return fail("Missing or locked MIDI track");
    auto n=std::find_if(t->notes.begin(),t->notes.end(),[&](const Note&n){return n.id==note;});if(n==t->notes.end())return fail("Note not found");t->notes.erase(n);auto r=validate(next);if(r.wasOk())p=std::move(next);return r;
}
juce::Result copyBars(Project&p,const juce::String&track,int first,int end,int destination){
    auto r=validate(p);if(r.failed())return r;if(first<0||end<=first||end>p.settings.bars||destination<0||destination>p.settings.bars-(end-first))return fail("Invalid copy range");
    auto next=p;auto t=std::find_if(next.tracks.begin(),next.tracks.end(),[&](const Track&t){return t.id==track;});if(t==next.tracks.end()||t->midiLocked)return fail("Missing or locked MIDI track");
    auto bar=barTicks(p.settings),begin=bar*first,finish=bar*end,dest=bar*destination;std::vector<Note>copied;
    for(auto n:t->notes)if(n.tick>=begin&&n.tick<finish){n.id=juce::Uuid().toString();n.duration=std::min(n.duration,finish-n.tick);n.glideTicks=int(std::min<int64_t>(n.glideTicks,n.duration));n.tick+=dest-begin;n.microtiming=juce::jlimit(-n.tick,bar*p.settings.bars-n.tick-n.duration,n.microtiming);copied.push_back(n);}
    t->notes.erase(std::remove_if(t->notes.begin(),t->notes.end(),[&](const Note&n){return n.tick>=dest&&n.tick<dest+finish-begin;}),t->notes.end());t->notes.insert(t->notes.end(),copied.begin(),copied.end());
    std::stable_sort(t->notes.begin(),t->notes.end(),[](const Note&a,const Note&b){return a.tick<b.tick;});r=validate(next);if(r.wasOk())p=std::move(next);return r;
}
juce::Result validate(const Settings&s){
    if(!std::isfinite(s.bpm)||s.bpm<20||s.bpm>300)return fail("BPM must be 20..300");
    if(s.bars<1||s.bars>4096||s.numerator<1||s.numerator>12||(s.denominator!=4&&s.denominator!=8))return fail("Invalid bars or meter");
    const auto supported=generationRoles();
    juce::StringArray seen;
    if(s.activeRoles.isEmpty())return fail("Choose at least one active generation track");
    for(const auto&role:s.activeRoles){if(!supported.contains(role)||seen.contains(role))return fail("Invalid or duplicate active generation track");seen.add(role);}
    if(s.tonic<0||s.tonic>11)return fail("Invalid key");
    for(double x:{s.swing,s.humanize,s.density,s.energy,s.darkness,s.complexity,s.groove,s.melodicDensity,s.variationAmount,s.genreInfluence})if(!std::isfinite(x)||x<0||x>1)return fail("Control outside 0..1");
    for(double x:{s.hatsDensity,s.drumAccents})if(!std::isfinite(x)||(x!=-1&&(x<0||x>1)))return fail("Optional drum controls must be unset (-1) or within 0..1");
    // Explicit supported scope; unknown styles must not silently generate a claimed profile.
    if(!scaleDegrees(s.scale))return fail("Supported scales: minor, major, dorian, phrygian, lydian, mixolydian, locrian");
    if(s.genre.isEmpty()||s.mood.isEmpty())return fail("Missing style");
    return juce::Result::ok();
}
juce::Result validate(const Project&p){
    size_t snapshotBytes=0;
    for(const auto&slot:{p.comparisonA,p.comparisonB,p.comparisonC})if(!slot.isVoid()){
        if(!slot.isObject()||slot.hasProperty("comparison_a")||slot.hasProperty("comparison_b")||slot.hasProperty("comparison_c"))return fail("Invalid or nested A/B/C snapshot");
        snapshotBytes+=juce::JSON::toString(slot,true).getNumBytesAsUTF8();if(snapshotBytes>16*1024*1024)return fail("A/B/C snapshots exceed 16 MB; clear a slot or save a separate project");
        Project restored;auto r=decode(slot,restored);if(r.failed())return r;
    }
    if(!p.assets.isVoid()){if(!p.assets.isArray()||p.assets.size()>512||juce::JSON::toString(p.assets,true).getNumBytesAsUTF8()>4*1024*1024)return fail("Invalid or oversized file registry");for(const auto&a:*p.assets.getArray()){if(!a.isObject()||!a["path"].isString()||a["path"].toString().isEmpty()||!a["kind"].isString()||!juce::StringArray{"source","output"}.contains(a["kind"].toString())||!a["sha256"].isString()||!integer(a["bytes"])||juce::int64(a["bytes"])<0||!a["status"].isString()||!juce::StringArray{"verified","missing","unreadable"}.contains(a["status"].toString())||!a["track_ids"].isArray()||a["track_ids"].size()>128)return fail("Invalid file registry entry");auto hash=a["sha256"].toString();if((hash.isNotEmpty()&&(hash.length()!=64||hash.containsOnly("0123456789abcdef")==false))||(a["status"].toString()=="verified"&&hash.isEmpty())||!a["project_revision"].isString()||a["project_revision"].toString().length()!=64)return fail("Invalid file checksum");for(const auto&id:*a["track_ids"].getArray())if(!id.isString())return fail("Invalid source track ID");}}
    auto result=validate(p.settings);if(result.failed())return result;
    if(p.id.isEmpty()||(p.generatorVersion!="rules-1"&&!profileVersion(p.generatorVersion))||p.tracks.size()>128)return fail("Unsupported project identity, generator or track count");
    if((p.settings.hatsDensity>=0||p.settings.drumAccents>=0)&&p.generatorVersion!="profiles-4")return fail("Hats density and drum accents require the profiles-4 generator; legacy projects retain their original behavior");
    if(!modernProfileVersion(p.generatorVersion)&&(p.settings.genreInfluence!=1||p.settings.activeRoles.contains("Countermelody")||p.settings.activeRoles.contains("FX")))return fail("Extra tracks and genre influence require profiles-3 or newer");
    if(p.generatorVersion=="rules-1"&&(p.settings.genre!="Trap"||p.settings.mood!="Dark"||p.settings.scale!="minor"))return fail("Invalid legacy generator style");
    if(expressiveProfileVersion(p.generatorVersion)){
        auto plan=p.styleSnapshot["harmonic_degrees"];if(!plan.isArray()||plan.size()!=4)return fail("Missing saved harmonic plan");
        for(const auto&degree:*plan.getArray())if(!integer(degree)||int(degree)<0||int(degree)>6)return fail("Invalid saved harmonic degree");
    }
    if(profileVersion(p.generatorVersion)){StyleBlend style;auto r=resolveStyle(p.styleSnapshot,style);if(r.failed())return r;if(p.settings.genre!=style.genre.id||p.settings.mood!=style.mood.id)return fail("Style snapshot identity mismatch");}
    if(!p.harmony.isVoid()){HarmonyOptions options;auto r=decodeHarmony(p.harmony,options);if(r.failed())return r;}
    if(!p.sections.isVoid()){if(!p.sections.isArray()||p.sections.size()==0||p.sections.size()>64)return fail("Invalid song sections");int position=0;for(const auto&section:*p.sections.getArray()){if(!section.isObject()||!section["name"].isString()||section["name"].toString().trim().isEmpty()||section["name"].toString().length()>64||!section["start"].isInt()||!section["bars"].isInt()||int(section["start"])!=position||int(section["bars"])<1||int(section["bars"])>4096-position)return fail("Invalid section name or range");position+=int(section["bars"]);}if(position!=p.settings.bars)return fail("Song sections must cover the song");}
    std::set<juce::String> ids;const auto end=barTicks(p.settings)*p.settings.bars;
    std::set<juce::String>laneNames;for(auto&t:p.tracks)if(t.customName.isEmpty())laneNames.insert(t.role.toLowerCase());
    if(p.tempos.size()>512)return fail("Tempo map limit is 512 points");int64_t previousTempo=0;for(const auto&t:p.tempos){if(t.tick<=previousTempo||t.tick>=end||!std::isfinite(t.bpm)||t.bpm<20||t.bpm>300)return fail("Tempo points must be unique, ordered and inside the song; edit initial BPM separately");previousTempo=t.tick;}
    size_t instrumentBytes=0;
    for(const auto&t:p.tracks){if(t.id.isEmpty()||!ids.insert(t.id).second||t.notes.size()>100000||t.sampleRoot<0||t.sampleRoot>127)return fail("Invalid track ID or event count");
        if(t.customName.isNotEmpty()&&(t.customName!=t.customName.trim()||t.customName.length()>64||t.customName.containsAnyOf("\r\n\t")||gmDrumNote(t.role)<0||t.drumNote<0||!laneNames.insert(t.customName.toLowerCase()).second))return fail("Custom lane needs a unique name (1..64 characters), drum role and MIDI mapping");
        if(t.drumNote < -1||t.drumNote>127||(t.drumNote>=0&&gmDrumNote(t.role)<0))return fail("Invalid drum note map");
        if(t.liveDevice.isNotEmpty()&&(!validLiveDevice(t.liveDevice)||!t.instrument.isVoid()||t.soundPath.isNotEmpty()||!t.effects.isVoid()))return fail("Invalid Live-native instrument assignment");
        if(!t.instrument.isVoid()){
            if(!hosting::validNativeEditorPosition(t.instrument["editor_position"]))return fail("Invalid native instrument editor position");
            std::vector<hosting::CCParameterBinding> cc;auto ccResult=hosting::readCCParameterMap(t.instrument["cc_parameter_map"],cc);if(ccResult.failed())return ccResult;
            auto bindings=validateSoundBindings(t.instrument["sound_adapter"]);if(bindings.failed())return bindings;
            auto design=t.instrument["sound_design"];if(!design.isVoid()&&(!design.isObject()||!design["adapter_id"].isString()||design["adapter_id"].toString().length()>96||!design["adapter_version"].isInt()||int(design["adapter_version"])!=1||!design["plugin_version"].isString()||!design["edits"].isArray()||design["edits"].size()>64||juce::JSON::toString(design).getNumBytesAsUTF8()>65536))return fail("Invalid sound design provenance");
            if(bool(t.instrument["effect"])||!t.instrument.isObject()||!integer(t.instrument["schema"])||int(t.instrument["schema"])!=1)return fail("Invalid instrument schema");
            if(t.instrument.hasProperty("class_id")&&(!t.instrument["class_id"].isString()||!hosting::validPluginClassIdentity(t.instrument["class_id"].toString())))return fail("Invalid instrument class ID");
            for(auto key:{"path","uid","name","xml","state","sha256"})if(!t.instrument[key].isString())return fail("Invalid instrument field");
            if(!juce::File::isAbsolutePath(t.instrument["path"].toString())||t.instrument["uid"].toString().isEmpty()||t.instrument["xml"].toString().length()>65536||t.instrument["sha256"].toString().length()!=64)return fail("Invalid instrument identity");
            instrumentBytes+=size_t(t.instrument["state"].toString().length());if(instrumentBytes>48*1024*1024)return fail("Instrument states exceed project size budget");
        }
        if(!t.effects.isVoid()){if(!t.effects.isArray()||t.effects.size()>8)return fail("Effect chain limit is 8");for(const auto&fx:*t.effects.getArray()){if(!hosting::validNativeEditorPosition(fx["editor_position"]))return fail("Invalid native effect editor position");if(!fx.isObject()||!integer(fx["schema"])||int(fx["schema"])!=1||!fx["effect"].isBool()||!bool(fx["effect"]))return fail("Invalid effect descriptor");if(fx.hasProperty("class_id")&&(!fx["class_id"].isString()||!hosting::validPluginClassIdentity(fx["class_id"].toString())))return fail("Invalid effect class ID");for(auto key:{"path","uid","name","xml","state","sha256"})if(!fx[key].isString())return fail("Invalid effect field");if(!juce::File::isAbsolutePath(fx["path"].toString())||fx["uid"].toString().isEmpty()||fx["xml"].toString().length()>65536||fx["sha256"].toString().length()!=64||(fx.hasProperty("bypass")&&!fx["bypass"].isBool()))return fail("Invalid effect identity");instrumentBytes+=size_t(fx["state"].toString().length());if(instrumentBytes>48*1024*1024)return fail("Plugin states exceed project size budget");}}
        if(t.controls.size()>100000)return fail("Too many MIDI control events");
        std::set<std::tuple<int64_t,int,juce::String,int>> controlPositions;
        for(const auto&e:t.controls){if(e.id.isEmpty()||!ids.insert(e.id).second||e.tick<0||e.tick>=end||e.channel<1||e.channel>16||e.number<0||e.number>127||e.value<0||(e.kind!="cc"&&e.kind!="bend")||(e.kind=="cc"&&e.value>127)||(e.kind=="bend"&&(e.value>16383||e.number!=0)))return fail("Invalid MIDI control event");if(!controlPositions.insert({e.tick,e.channel,e.kind,e.number}).second)return fail("Conflicting controls at the same tick");
            if(e.kind=="bend")for(const auto&n:t.notes)if(n.channel==e.channel&&n.glideTicks>0)return fail("Manual pitch bend and generated glide share a channel; remove one first");}
        for(const auto&n:t.notes){if(!juce::StringArray{"normal","ghost","accent","roll"}.contains(n.articulation))return fail("Invalid note articulation");if(n.id.isEmpty()||!ids.insert(n.id).second)return fail("Duplicate or empty event ID");
            if(n.tick<0||n.tick>=end||n.duration<=0||n.duration>end-n.tick||n.microtiming < -n.tick||n.microtiming>end-n.tick-n.duration||n.pitch<0||n.pitch>127||n.velocity<1||n.velocity>127||n.channel<1||n.channel>16||!std::isfinite(n.probability)||n.probability<0||n.probability>1)return fail("Invalid MIDI event");
            if(n.glideTicks<0||n.glideTicks>960||n.glideTicks>n.duration||n.bendRange<1||n.bendRange>48||(n.glideFrom < -n.bendRange||n.glideFrom>n.bendRange)||(n.glideTicks==0&&n.glideFrom!=0)||n.pitch+n.glideFrom<0||n.pitch+n.glideFrom>127||(n.glideTicks>0&&n.channel==10))return fail("Invalid pitch bend / glide");}
        for(int channel=1;channel<=16;++channel){bool bent=false;std::vector<const Note*> ordered;for(auto&n:t.notes)if(n.channel==channel){ordered.push_back(&n);bent|=n.glideTicks>0;}
            if(bent){std::sort(ordered.begin(),ordered.end(),[](auto*a,auto*b){return a->tick+a->microtiming<b->tick+b->microtiming;});int64_t finish=-1;for(auto*n:ordered){if(n->tick+n->microtiming<finish)return fail("Pitch bend requires monophonic notes on its channel");finish=n->tick+n->microtiming+n->duration;}}
        }
    }return juce::Result::ok();
}
Project generate(const Settings&s){auto v=validate(s);if(s.hatsDensity>=0||s.drumAccents>=0)throw std::invalid_argument("Optional hats density and drum accents require the profiles-4 generator");if(s.activeRoles.contains("Countermelody")||s.activeRoles.contains("FX")||s.genreInfluence!=1)throw std::invalid_argument("Extra tracks and genre influence require profiles-3 or newer");if(s.genre!="Trap"||s.mood!="Dark"||s.scale!="minor")throw std::invalid_argument("Legacy generator requires Trap / Dark / minor");if(v.failed())throw std::invalid_argument(v.getErrorMessage().toStdString());Project p;p.id=juce::Uuid().toString();p.settings=s;for(const auto&role:generationRoles())if(s.activeRoles.contains(role))p.tracks.push_back(makeTrack(s,role));return p;}
juce::Result generateStyled(const Settings&s,const ProfileRegistry&registry,const std::vector<StyleWeight>&genres,const std::vector<StyleWeight>&moods,Project&target,const juce::String&version){
    if(!profileVersion(version))return fail("Unsupported styled generator version");
    if((s.hatsDensity>=0||s.drumAccents>=0)&&version!="profiles-4")return fail("Optional hats density and drum accents require the profiles-4 generator");
    auto r=validate(s);if(r.failed())return r;if(!modernProfileVersion(version)&&(s.activeRoles.contains("Countermelody")||s.activeRoles.contains("FX")||s.genreInfluence!=1))return fail("Extra tracks and genre influence require profiles-3 or newer");StyleBlend style;r=registry.blend(genres,moods,style);if(r.failed())return r;
    Project p;p.id=juce::Uuid().toString();p.generatorVersion=version;p.settings=s;p.settings.genre=style.genre.id;p.settings.mood=style.mood.id;p.styleSnapshot=object();put(p.styleSnapshot,"registry",registry.encode());
    for(auto key:{"genres","moods"}){juce::Array<juce::var>weights;for(const auto&w:juce::String(key)=="genres"?style.genres:style.moods){auto v=object();put(v,"id",w.id);put(v,"weight",w.weight);weights.add(v);}put(p.styleSnapshot,key,weights);}
    if(expressiveProfileVersion(version)){juce::Array<juce::var>plan;for(auto degree:styledProgression(p.settings,style))plan.add(degree);put(p.styleSnapshot,"harmonic_degrees",plan);}
    for(const auto&role:generationRoles())if(s.activeRoles.contains(role))p.tracks.push_back(makeStyledTrack(p.settings,style,role,expressiveProfileVersion(version),nullptr,modernProfileVersion(version),version=="profiles-4"));
    r=validate(p);if(r.wasOk())target=std::move(p);return r;
}
namespace {
bool overlaps(const Track&t){std::vector<const Note*>notes;for(const auto&n:t.notes)notes.push_back(&n);std::sort(notes.begin(),notes.end(),[](auto*a,auto*b){return a->tick+a->microtiming<b->tick+b->microtiming;});int64_t end=-1;for(auto*n:notes){auto start=n->tick+n->microtiming;if(start<end)return true;end=start+n->duration;}return false;}
}
juce::Result makeBassMonophonic(Project&p){
    auto valid=validate(p);if(valid.failed())return valid;auto next=p;bool found=false;
    for(auto&t:next.tracks)if(t.role=="Bass"){
        found=true;if(t.midiLocked)return fail("Unlock Bass MIDI before making it monophonic");
        std::vector<Note*>notes;for(auto&n:t.notes)notes.push_back(&n);std::sort(notes.begin(),notes.end(),[](auto*a,auto*b){return a->tick+a->microtiming<b->tick+b->microtiming;});
        for(size_t i=1;i<notes.size();++i){auto&previous=*notes[i-1];const auto&current=*notes[i];auto space=current.tick+current.microtiming-previous.tick-previous.microtiming;if(space<=0)return fail("Bass has simultaneous attacks; move or remove one manually before Make bass mono");
            if(previous.duration>space){previous.duration=space;previous.glideTicks=std::min(previous.glideTicks,int(space));}
        }
    }
    if(!found)return fail("No Bass track found");valid=validate(next);if(valid.failed())return valid;p=std::move(next);return juce::Result::ok();
}
juce::Result setTempoPoint(Project&p,int64_t tick,double bpm){auto next=p;auto it=std::find_if(next.tempos.begin(),next.tempos.end(),[&](const auto&t){return t.tick==tick;});if(it==next.tempos.end())next.tempos.push_back({tick,bpm});else it->bpm=bpm;std::sort(next.tempos.begin(),next.tempos.end(),[](const auto&a,const auto&b){return a.tick<b.tick;});auto r=validate(next);if(r.wasOk())p=std::move(next);return r;}
juce::Result removeTempoPoint(Project&p,int64_t tick){auto next=p;auto size=next.tempos.size();next.tempos.erase(std::remove_if(next.tempos.begin(),next.tempos.end(),[&](const auto&t){return t.tick==tick;}),next.tempos.end());if(size==next.tempos.size())return fail("Tempo point not found");auto r=validate(next);if(r.wasOk())p=std::move(next);return r;}
juce::Result setControlEvent(Project&p,const juce::String&track,const ControlEvent&event){
 auto next=p;auto t=std::find_if(next.tracks.begin(),next.tracks.end(),[&](const Track&t){return t.id==track;});if(t==next.tracks.end()||t->midiLocked)return fail("Select an unlocked MIDI track");
 auto found=std::find_if(t->controls.begin(),t->controls.end(),[&](const ControlEvent&e){return e.id==event.id;});if(found==t->controls.end())t->controls.push_back(event);else *found=event;
 std::stable_sort(t->controls.begin(),t->controls.end(),[](const auto&a,const auto&b){return a.tick<b.tick;});auto r=validate(next);if(r.wasOk())p=std::move(next);return r;
}
juce::Result removeControlEvent(Project&p,const juce::String&track,const juce::String&id){
 auto next=p;auto t=std::find_if(next.tracks.begin(),next.tracks.end(),[&](const Track&t){return t.id==track;});if(t==next.tracks.end()||t->midiLocked)return fail("Select an unlocked MIDI track");auto size=t->controls.size();t->controls.erase(std::remove_if(t->controls.begin(),t->controls.end(),[&](const auto&e){return e.id==id;}),t->controls.end());if(size==t->controls.size())return fail("Control event no longer exists");auto r=validate(next);if(r.wasOk())p=std::move(next);return r;
}
juce::var lockedContentHashes(const Project&p){
    juce::Array<juce::var> rows;
    for(const auto&t:p.tracks){
        if(!t.midiLocked&&!t.soundLocked)continue;
        Project single;single.tracks.push_back(t);auto encoded=encode(single)["tracks"][0];auto row=object();put(row,"track_id",t.id);
        auto hash=[](const juce::var&v){auto text=juce::JSON::toString(v,true);return juce::SHA256(text.toRawUTF8(),text.getNumBytesAsUTF8()).toHexString();};
        if(t.midiLocked){auto content=object();put(content,"notes",encoded["notes"].clone());put(content,"controls",encoded["controls"].clone());put(content,"drum_note",t.drumNote);put(content,"role",t.role);put(row,"midi_sha256",hash(content));}
        if(t.soundLocked){auto content=object();put(content,"sample",t.soundPath);if(t.sampleRoot!=60)put(content,"sample_root",t.sampleRoot);put(content,"instrument",t.instrument.clone());put(content,"effects",t.effects.clone());put(row,"sound_sha256",hash(content));}
        rows.add(row);
    }
    return rows;
}
juce::Result verifyLockedContent(const Project&before,const Project&after){
    auto expected=lockedContentHashes(before),actual=lockedContentHashes(after);
    for(const auto&row:*expected.getArray()){
        const juce::var*match=nullptr;for(const auto&candidate:*actual.getArray())if(candidate["track_id"]==row["track_id"]){match=&candidate;break;}
        if(!match)return juce::Result::fail("Generation removed or unlocked a protected track: "+row["track_id"].toString());
        for(auto key:{"midi_sha256","sound_sha256"})if(row.hasProperty(key)&&row[key]!=(*match)[key])return juce::Result::fail("Generation changed protected content: "+row["track_id"].toString()+" / "+key);
    }
    return juce::Result::ok();
}
juce::Result regenerate(Project&p,const juce::String&id,int first,int last,uint32_t seed){
    auto valid=validate(p);if(valid.failed())return valid;
    if(first<0||last<=first||last>p.settings.bars)return fail("Invalid bar range");
    auto next=p;auto it=std::find_if(next.tracks.begin(),next.tracks.end(),[&](const Track&t){return t.id==id;});
    if(it==next.tracks.end())return fail("Track not found");if(it->midiLocked)return fail("Track MIDI is locked");
    if(!generationRoles().contains(it->role))return fail("No generator for this track role");
    if(p.settings.variationAmount==0)return juce::Result::ok();
    const auto scopeStart=first*barTicks(p.settings),scopeEnd=last*barTicks(p.settings);
    auto anchor=[&](const Note&n){auto offset=n.tick%barTicks(p.settings);return n.articulation=="accent"||(it->role=="Kick"&&offset==0)||((it->role=="Snare"||it->role=="Clap")&&offset==barTicks(p.settings)/2);};
    if(p.settings.keepGroove){
        for(auto&n:it->notes)if(n.tick>=scopeStart&&n.tick<scopeEnd&&!anchor(n)){Random r{seed^roleHash(id+":"+n.id)};int delta=int(std::lround((r.bounded(49)-24)*p.settings.variationAmount));n.velocity=juce::jlimit(1,127,n.velocity+delta);}
        valid=validate(next);if(valid.failed())return valid;valid=verifyLockedContent(p,next);if(valid.failed())return valid;p=std::move(next);return juce::Result::ok();
    }
    Settings s=p.settings;s.seed=seed;if(it->customName.isNotEmpty())s.seed^=roleHash(it->id);Track replacement;
    if(profileVersion(p.generatorVersion)){StyleBlend style;auto r=resolveStyle(p.styleSnapshot,style);if(r.failed())return r;std::array<int,4>plan{};if(expressiveProfileVersion(p.generatorVersion))for(int i=0;i<4;++i)plan[size_t(i)]=int(p.styleSnapshot["harmonic_degrees"][i]);replacement=makeStyledTrack(s,style,it->role,expressiveProfileVersion(p.generatorVersion),&plan,modernProfileVersion(p.generatorVersion),p.generatorVersion=="profiles-4");}else replacement=makeTrack(s,it->role);
    if(it->customName.isEmpty()&&!p.harmony.isVoid()&&(it->role=="Chords"||it->role=="Bass"||it->role==p.harmony.getProperty("melody_target","Melody").toString())){
        HarmonyOptions o;auto r=decodeHarmony(p.harmony,o);if(r.failed())return r;o.chords=it->role=="Chords";o.bass=it->role=="Bass";o.melody=it->role==o.melodyTarget;
        auto generated=p;generated.settings.seed=seed;r=applyHarmony(generated,o);if(r.failed())return r;
        for(auto&t:generated.tracks)if(t.id==id)replacement=t;
    }
    const auto begin=first*barTicks(s),end=last*barTicks(s);
    auto replaceCell=[&](const Note&n){if(n.tick<begin||n.tick>=end)return false;if(s.variationAmount>=1)return true;auto bar=barTicks(s);auto cell=(n.tick/bar)*16+(n.tick%bar)*16/bar;Random r{seed^roleHash(id+":"+juce::String(cell))};return double(r.next())/4294967296.<s.variationAmount;};
    auto protectedAnchor=[&](const Note&n){return s.variationAmount<1&&anchor(n);};
    std::vector<int64_t> retainedAnchors;for(const auto&n:it->notes)if(protectedAnchor(n))retainedAnchors.push_back(n.tick);
    it->notes.erase(std::remove_if(it->notes.begin(),it->notes.end(),[&](const Note&n){return replaceCell(n)&&!protectedAnchor(n);}),it->notes.end());
    for(auto n:replacement.notes)if(replaceCell(n)&&std::find(retainedAnchors.begin(),retainedAnchors.end(),n.tick)==retainedAnchors.end()){if(it->drumNote>=0){n.pitch=it->drumNote;n.channel=10;}n.id=p.id+":"+id+":"+juce::String(first)+":"+juce::String(last)+":"+juce::String(juce::int64(seed))+":"+n.id;it->notes.push_back(n);}
    std::stable_sort(it->notes.begin(),it->notes.end(),[](const Note&a,const Note&b){return a.tick<b.tick;});
    if(it->role=="Bass"&&overlaps(*it))return fail("Bass variation would overlap MIDI notes. Try a different seed/amount, or Make bass mono before varying.");
    valid=validate(next);if(valid.failed())return valid;valid=verifyLockedContent(p,next);if(valid.failed())return valid;p=std::move(next);return juce::Result::ok();
}
juce::var encode(const Project&p){
    bool articulated=false;for(const auto&t:p.tracks)for(const auto&n:t.notes)articulated|=n.articulation!="normal";
    auto o=object();bool ccMapped=false;for(const auto&t:p.tracks)ccMapped|=t.instrument["cc_parameter_map"].size()>0;bool rooted=false;for(const auto&t:p.tracks)rooted|=t.sampleRoot!=60;bool instruments=false;for(const auto&t:p.tracks)instruments|=!t.instrument.isVoid();bool glide=false;for(auto&t:p.tracks)for(auto&n:t.notes)glide|=n.glideTicks>0;bool mapped=false;for(auto&t:p.tracks)mapped|=t.drumNote>=0;bool custom=false;for(auto&t:p.tracks)custom|=t.customName.isNotEmpty();bool automation=false,effects=false;for(const auto&t:p.tracks){automation|=!t.controls.empty();effects|=!t.effects.isVoid();}bool native=false;for(auto&t:p.tracks)native|=t.liveDevice.isNotEmpty();put(o,"schema_version",native?21:(p.settings.hatsDensity>=0||p.settings.drumAccents>=0)?20:articulated?19:(p.settings.activeRoles!=Settings{}.activeRoles||p.settings.genreInfluence!=1)?18:ccMapped?17:rooted?16:effects?15:!p.assets.isVoid()?14:!p.tempos.empty()?13:automation?12:!p.comparisonC.isVoid()?11:!p.sections.isVoid()?10:(p.settings.keepGroove||p.settings.variationAmount!=1)?9:(!p.comparisonA.isVoid()||!p.comparisonB.isVoid())?8:p.hatChoke?7:custom?6:mapped?5:glide?4:!p.harmony.isVoid()?3:instruments?2:1);put(o,"ppq",ppq);put(o,"project_id",p.id);put(o,"generator_version",p.generatorVersion);
    auto s=object();if(p.settings.hatsDensity>=0)put(s,"hats_density",p.settings.hatsDensity);if(p.settings.drumAccents>=0)put(s,"drum_accents",p.settings.drumAccents);if(p.settings.genreInfluence!=1)put(s,"genre_influence",p.settings.genreInfluence);if(p.settings.activeRoles!=Settings{}.activeRoles){juce::Array<juce::var> roles;for(const auto&role:p.settings.activeRoles)roles.add(role);put(s,"active_roles",roles);}put(s,"bpm",p.settings.bpm);put(s,"bars",p.settings.bars);put(s,"numerator",p.settings.numerator);put(s,"denominator",p.settings.denominator);put(s,"tonic",p.settings.tonic);put(s,"seed",juce::int64(p.settings.seed));put(s,"genre",p.settings.genre);put(s,"mood",p.settings.mood);put(s,"scale",p.settings.scale);put(s,"swing",p.settings.swing);put(s,"humanize",p.settings.humanize);put(s,"density",p.settings.density);put(s,"energy",p.settings.energy);put(s,"darkness",p.settings.darkness);put(s,"complexity",p.settings.complexity);put(s,"groove",p.settings.groove);put(s,"melodic_density",p.settings.melodicDensity);if(p.settings.keepGroove||p.settings.variationAmount!=1){put(s,"variation_amount",p.settings.variationAmount);put(s,"keep_groove",p.settings.keepGroove);}put(o,"settings",s);
    juce::Array<juce::var> tracks;
    for(const auto&t:p.tracks){auto a=object();put(a,"id",t.id);put(a,"role",t.role);if(t.customName.isNotEmpty())put(a,"custom_name",t.customName);put(a,"sound",t.soundPath);if(t.liveDevice.isNotEmpty())put(a,"live_device",t.liveDevice);if(t.sampleRoot!=60)put(a,"sample_root",t.sampleRoot);if(!t.instrument.isVoid())put(a,"instrument",t.instrument.clone());if(!t.effects.isVoid())put(a,"effects",t.effects.clone());put(a,"midi_locked",t.midiLocked);put(a,"sound_locked",t.soundLocked);if(t.drumNote>=0)put(a,"drum_note",t.drumNote);juce::Array<juce::var>notes;
        for(const auto&n:t.notes){auto b=object();put(b,"id",n.id);if(n.articulation!="normal")put(b,"articulation",n.articulation);put(b,"pitch",n.pitch);put(b,"velocity",n.velocity);put(b,"channel",n.channel);put(b,"tick",juce::int64(n.tick));put(b,"duration",juce::int64(n.duration));put(b,"microtiming",juce::int64(n.microtiming));put(b,"probability",n.probability);if(n.glideTicks>0){put(b,"glide_from",n.glideFrom);put(b,"glide_ticks",n.glideTicks);put(b,"bend_range",n.bendRange);}notes.add(b);}put(a,"notes",notes);if(!t.controls.empty()){juce::Array<juce::var>controls;for(const auto&e:t.controls){auto c=object();put(c,"id",e.id);put(c,"kind",e.kind);put(c,"tick",juce::int64(e.tick));put(c,"channel",e.channel);put(c,"number",e.number);put(c,"value",e.value);controls.add(c);}put(a,"controls",controls);}tracks.add(a);}
    if(!p.tempos.empty()){juce::Array<juce::var>tempo;for(const auto&t:p.tempos){auto point=object();put(point,"tick",juce::int64(t.tick));put(point,"bpm",t.bpm);tempo.add(point);}put(o,"tempo_map",tempo);}
    if(!p.assets.isVoid())put(o,"assets",p.assets.clone());
    put(o,"tracks",tracks);if(!p.sections.isVoid())put(o,"sections",p.sections.clone());if(!p.comparisonA.isVoid())put(o,"comparison_a",p.comparisonA.clone());if(!p.comparisonB.isVoid())put(o,"comparison_b",p.comparisonB.clone());if(!p.comparisonC.isVoid())put(o,"comparison_c",p.comparisonC.clone());if(p.hatChoke)put(o,"hat_choke",true);if(!p.harmony.isVoid())put(o,"harmony",p.harmony.clone());if(!p.styleSnapshot.isVoid())put(o,"style_snapshot",p.styleSnapshot.clone());return o;
}
juce::Result decode(const juce::var&o,Project&target){
    if(!o.isObject()||!integer(o["schema_version"])||(int(o["schema_version"])<1||int(o["schema_version"])>21)||int(o["ppq"])!=ppq||!o["settings"].isObject()||!o["tracks"].isArray())return fail("Unsupported project schema");
    Project p;if(o.hasProperty("assets")){if(int(o["schema_version"])<14)return fail("File registry requires schema 14");p.assets=o["assets"].clone();}if(o.hasProperty("sections")){if(int(o["schema_version"])<10||!o["sections"].isArray())return fail("Song sections require schema 10");p.sections=o["sections"].clone();}for(auto key:{"comparison_a","comparison_b","comparison_c"})if(o.hasProperty(key)){if(int(o["schema_version"])<(juce::String(key)=="comparison_c"?11:8)||!o[key].isObject()||o[key].hasProperty("comparison_a")||o[key].hasProperty("comparison_b")||o[key].hasProperty("comparison_c"))return fail("Snapshots require schema 8 (A/B) or 11 (C), with no nested slots");(juce::String(key)=="comparison_a"?p.comparisonA:juce::String(key)=="comparison_b"?p.comparisonB:p.comparisonC)=o[key].clone();}if(o.hasProperty("hat_choke")){if(int(o["schema_version"])<7||!o["hat_choke"].isBool())return fail("Hat choke requires schema 7 and boolean");p.hatChoke=bool(o["hat_choke"]);}p.id=o["project_id"].toString();p.generatorVersion=o["generator_version"].toString();auto s=o["settings"];
    if(s.hasProperty("genre_influence")){if(int(o["schema_version"])<18||!number(s["genre_influence"]))return fail("Genre influence requires schema 18 and a number");p.settings.genreInfluence=double(s["genre_influence"]);}
    for(auto key:{"hats_density","drum_accents"})if(s.hasProperty(key)){
        auto value=s[key];if(int(o["schema_version"])<20||!number(value)||!std::isfinite(double(value))||double(value)<0||double(value)>1)return fail("Optional drum controls require schema 20 and values 0..1; omit unset controls");
        (juce::String(key)=="hats_density"?p.settings.hatsDensity:p.settings.drumAccents)=double(value);
    }
    if(s.hasProperty("active_roles")){if(int(o["schema_version"])<18||!s["active_roles"].isArray()||s["active_roles"].size()>11)return fail("Active generation tracks require schema 18 and a role array");p.settings.activeRoles.clear();for(const auto&role:*s["active_roles"].getArray()){if(!role.isString())return fail("Invalid generation role");p.settings.activeRoles.add(role.toString());}}
    for(auto key:{"bpm","swing","humanize","density"})if(!number(s[key]))return fail("Missing numeric setting");
    for(auto key:{"bars","numerator","denominator","tonic","seed"})if(!integer(s[key]))return fail("Missing integer setting");
    if(s.hasProperty("variation_amount")||s.hasProperty("keep_groove")){if(int(o["schema_version"])<9||!number(s["variation_amount"])||!s["keep_groove"].isBool())return fail("Variation controls require schema 9");p.settings.variationAmount=double(s["variation_amount"]);p.settings.keepGroove=bool(s["keep_groove"]);}
    auto seed=juce::int64(s["seed"]);if(seed<0||seed>4294967295LL)return fail("Invalid seed");
    p.settings.bpm=double(s["bpm"]);p.settings.bars=int(s["bars"]);p.settings.numerator=int(s["numerator"]);p.settings.denominator=int(s["denominator"]);p.settings.tonic=int(s["tonic"]);p.settings.seed=uint32_t(seed);p.settings.genre=s["genre"].toString();p.settings.mood=s["mood"].toString();p.settings.scale=s["scale"].toString();p.settings.swing=double(s["swing"]);p.settings.humanize=double(s["humanize"]);p.settings.density=double(s["density"]);
    for(auto key:{"energy","darkness","complexity","groove","melodic_density"})if(s.hasProperty(key)&&!number(s[key]))return fail("Invalid expression setting");
    p.settings.energy=double(s.getProperty("energy",.5));p.settings.darkness=double(s.getProperty("darkness",.5));p.settings.complexity=double(s.getProperty("complexity",.5));p.settings.groove=double(s.getProperty("groove",.5));p.settings.melodicDensity=double(s.getProperty("melodic_density",.5));p.styleSnapshot=o["style_snapshot"].clone();
    if(o.hasProperty("harmony")){if(int(o["schema_version"])<3)return fail("Harmony requires schema 3");p.harmony=o["harmony"].clone();}
    if(o["tracks"].size()>128)return fail("Too many tracks");
    if(o.hasProperty("tempo_map")){if(int(o["schema_version"])<13||!o["tempo_map"].isArray()||o["tempo_map"].size()>512)return fail("Tempo map requires schema 13");for(const auto&t:*o["tempo_map"].getArray()){if(!t.isObject()||!integer(t["tick"])||!number(t["bpm"]))return fail("Invalid tempo point");p.tempos.push_back({juce::int64(t["tick"]),double(t["bpm"])});}}
    for(auto&a:*o["tracks"].getArray()){
        if(!a.isObject()||!a["notes"].isArray()||a["notes"].size()>100000||!a["midi_locked"].isBool()||!a["sound_locked"].isBool())return fail("Invalid track");
        Track t;t.id=a["id"].toString();t.role=a["role"].toString();if(a.hasProperty("custom_name")){if(int(o["schema_version"])<6||!a["custom_name"].isString()||a["custom_name"].toString().isEmpty())return fail("Custom lanes require schema 6 and a name");t.customName=a["custom_name"].toString();}t.soundPath=a["sound"].toString();if(a.hasProperty("live_device")){if(int(o["schema_version"])<21||!a["live_device"].isString())return fail("Live instruments require schema 21");t.liveDevice=a["live_device"].toString();}if(a.hasProperty("sample_root")){if(int(o["schema_version"])<16||!a["sample_root"].isInt())return fail("Sample root requires schema 16 and an integer MIDI note");t.sampleRoot=int(a["sample_root"]);}t.midiLocked=bool(a["midi_locked"]);t.soundLocked=bool(a["sound_locked"]);if(a.hasProperty("drum_note")){if(int(o["schema_version"])<5||!a["drum_note"].isInt())return fail("Drum map requires schema 5 and integer note");t.drumNote=int(a["drum_note"]);}
        if(a.hasProperty("instrument")){if(int(o["schema_version"])<2)return fail("Instrument requires schema 2");t.instrument=a["instrument"].clone();if(t.instrument["cc_parameter_map"].size()>0&&int(o["schema_version"])<17)return fail("MIDI CC parameter mappings require schema 17");}
        if(a.hasProperty("effects")){if(int(o["schema_version"])<15)return fail("Effect chains require schema 15");t.effects=a["effects"].clone();}
        if(a.hasProperty("controls")){if(int(o["schema_version"])<12||!a["controls"].isArray()||a["controls"].size()>100000)return fail("MIDI controls require schema 12");for(const auto&c:*a["controls"].getArray()){if(!c.isObject()||!c["id"].isString()||!c["kind"].isString())return fail("Invalid MIDI control fields");for(auto key:{"tick","channel","number","value"})if(!integer(c[key]))return fail("Invalid MIDI control number");for(auto key:{"channel","number","value"})if(juce::int64(c[key])<0||juce::int64(c[key])>16383)return fail("MIDI control value out of range");ControlEvent e;e.id=c["id"].toString();e.kind=c["kind"].toString();e.tick=juce::int64(c["tick"]);e.channel=int(c["channel"]);e.number=int(c["number"]);e.value=int(c["value"]);t.controls.push_back(e);}}
        for(auto&b:*a["notes"].getArray()){
            for(auto key:{"pitch","velocity","channel","tick","duration","microtiming"})if(!integer(b[key]))return fail("Invalid MIDI field type");
            if(!number(b["probability"]))return fail("Invalid probability type");
            Note n;n.id=b["id"].toString();if(b.hasProperty("articulation")){if(int(o["schema_version"])<19||!b["articulation"].isString())return fail("Note articulation requires schema 19");n.articulation=b["articulation"].toString();}n.pitch=int(b["pitch"]);n.velocity=int(b["velocity"]);n.channel=int(b["channel"]);n.tick=juce::int64(b["tick"]);n.duration=juce::int64(b["duration"]);n.microtiming=juce::int64(b["microtiming"]);n.probability=double(b["probability"]);
            if(b.hasProperty("glide_ticks")||b.hasProperty("glide_from")||b.hasProperty("bend_range")){if(int(o["schema_version"])<4)return fail("Glide requires schema 4");for(auto key:{"glide_ticks","glide_from","bend_range"})if(!b[key].isInt())return fail("Invalid glide field type");n.glideTicks=int(b["glide_ticks"]);n.glideFrom=int(b["glide_from"]);n.bendRange=int(b["bend_range"]);}t.notes.push_back(n);
        }p.tracks.push_back(t);
    }auto result=validate(p);if(result.wasOk())target=std::move(p);return result;
}
juce::Result save(const Project&p,const juce::File&f){auto v=validate(p);if(v.failed())return v;juce::TemporaryFile tmp(f);if(!tmp.getFile().replaceWithText(juce::JSON::toString(encode(p)))||!tmp.overwriteTargetFileWithTemporary())return fail("Cannot save project");return juce::Result::ok();}
juce::Result load(const juce::File&f,Project&p){if(!f.existsAsFile()||f.getSize()>64*1024*1024)return fail("Missing or oversized project");juce::var v;auto result=juce::JSON::parse(f.loadFileAsString(),v);return result.failed()?result:decode(v,p);}
juce::Result exportMidi(const Project&p,const juce::File&f,const juce::String&trackId){
    auto v=validate(p);if(v.failed())return v;
    if(trackId.isNotEmpty()&&std::none_of(p.tracks.begin(),p.tracks.end(),[&](const Track&t){return t.id==trackId;}))return fail("MIDI track no longer exists");
    if(trackId.isEmpty()){unsigned used=0,bent=0;for(const auto&t:p.tracks){unsigned channels=0,glides=0;for(const auto&e:t.controls){channels|=1u<<e.channel;if(e.kind=="bend")glides|=1u<<e.channel;}for(const auto&n:t.notes){channels|=1u<<n.channel;if(n.glideTicks>0)glides|=1u<<n.channel;}if((channels&bent)||(glides&used))return fail("Pitch bend channel is shared by another track; export the bass separately");used|=channels;bent|=glides;}}
    auto closures=hatClosures(p);juce::MidiFile midi;midi.setTicksPerQuarterNote(ppq);juce::MidiMessageSequence conductor;
    conductor.addEvent(juce::MidiMessage::tempoMetaEvent(int(std::round(60000000./p.settings.bpm))));conductor.addEvent(juce::MidiMessage::timeSignatureMetaEvent(p.settings.numerator,p.settings.denominator));
    for(const auto&t:p.tempos){auto tempo=juce::MidiMessage::tempoMetaEvent(int(std::round(60000000./t.bpm)));tempo.setTimeStamp(double(t.tick));conductor.addEvent(tempo);}
    if(auto*sections=p.sections.getArray())for(const auto&section:*sections){auto marker=juce::MidiMessage::textMetaEvent(6,section["name"].toString());marker.setTimeStamp(double(int(section["start"])*barTicks(p.settings)));conductor.addEvent(marker);}
    auto end=juce::MidiMessage::endOfTrack();end.setTimeStamp(double(barTicks(p.settings)*p.settings.bars));conductor.addEvent(end);midi.addTrack(conductor);
    for(const auto&t:p.tracks){if(trackId.isNotEmpty()&&t.id!=trackId)continue;juce::MidiMessageSequence seq;for(const auto&e:t.controls){auto m=e.kind=="bend"?juce::MidiMessage::pitchWheel(e.channel,e.value):juce::MidiMessage::controllerEvent(e.channel,e.number,e.value);m.setTimeStamp(double(e.tick));seq.addEvent(m);}seq.addEvent(juce::MidiMessage::textMetaEvent(3,trackName(t)));
        for(const auto&n:t.notes){if(!playsNote(p.settings.seed,n))continue;auto cutoff=hatCut(t,n,closures);if(cutoff==n.tick+n.microtiming)continue;glideMidi(n.channel,n.glideFrom,n.glideTicks,n.bendRange,[&](int tick,juce::MidiMessage m){m.setTimeStamp(double(n.tick+n.microtiming+tick));seq.addEvent(m);});auto on=juce::MidiMessage::noteOn(n.channel,n.pitch,juce::uint8(n.velocity));on.setTimeStamp(double(n.tick+n.microtiming));seq.addEvent(on);auto off=juce::MidiMessage::noteOff(n.channel,n.pitch);off.setTimeStamp(double(cutoff<0?n.tick+n.microtiming+n.duration:std::min(n.tick+n.microtiming+n.duration,cutoff)));seq.addEvent(off);}seq.addEvent(end);seq.updateMatchedPairs();midi.addTrack(seq);}
    juce::TemporaryFile tmp(f);{juce::FileOutputStream out(tmp.getFile());if(out.failedToOpen()||!midi.writeTo(out,1))return fail("Cannot write MIDI");out.flush();if(out.getStatus().failed())return out.getStatus();}return tmp.overwriteTargetFileWithTemporary()?juce::Result::ok():fail("Cannot replace MIDI file");
}
juce::Result captureComparison(Project&p,int slotIndex){
    if(slotIndex<0||slotIndex>2)return fail("Choose snapshot A, B or C");
    auto valid=validate(p);if(valid.failed())return valid;auto flat=p;flat.comparisonA=juce::var();flat.comparisonB=juce::var();flat.comparisonC=juce::var();auto next=p;
    (slotIndex==2?next.comparisonC:slotIndex==1?next.comparisonB:next.comparisonA)=encode(flat);valid=validate(next);if(valid.failed())return valid;p=std::move(next);return juce::Result::ok();
}
juce::Result restoreComparison(Project&p,int slotIndex){
    if(slotIndex<0||slotIndex>2)return fail("Choose snapshot A, B or C");
    auto valid=validate(p);if(valid.failed())return valid;auto slot=slotIndex==2?p.comparisonC:slotIndex==1?p.comparisonB:p.comparisonA;if(slot.isVoid())return fail("This A/B/C slot is empty");
    for(const auto&t:p.tracks)if(t.midiLocked||t.soundLocked)return fail("Unlock MIDI and sound tracks before restoring a whole A/B/C snapshot");
    Project next;valid=decode(slot,next);if(valid.failed())return valid;next.assets=p.assets.clone();next.comparisonA=p.comparisonA.clone();next.comparisonB=p.comparisonB.clone();next.comparisonC=p.comparisonC.clone();valid=validate(next);if(valid.failed())return valid;p=std::move(next);return juce::Result::ok();
}
juce::Result combineComparison(Project&p,int slotIndex,const juce::String&part){
    if(slotIndex<0||slotIndex>2)return fail("Choose snapshot A, B or C");
    auto valid=validate(p);if(valid.failed())return valid;
    if(!juce::StringArray{"Drums","Bass","Chords","Melody"}.contains(part))return fail("Choose Drums, Bass, Chords or Melody");
    auto slot=slotIndex==2?p.comparisonC:slotIndex==1?p.comparisonB:p.comparisonA;if(slot.isVoid())return fail("This A/B/C slot is empty");Project source;valid=decode(slot,source);if(valid.failed())return valid;
    const auto&a=p.settings;const auto&b=source.settings;
    if(a.bars!=b.bars||a.numerator!=b.numerator||a.denominator!=b.denominator||std::abs(a.bpm-b.bpm)>1e-6)return fail("Parts require matching BPM, meter and song length; no automatic stretching or cropping");
    if(p.tempos.size()!=source.tempos.size())return fail("Parts require the same tempo map");for(size_t i=0;i<p.tempos.size();++i)if(p.tempos[i].tick!=source.tempos[i].tick||p.tempos[i].bpm!=source.tempos[i].bpm)return fail("Parts require the same tempo map");
    if(part!="Drums"&&(a.tonic!=b.tonic||a.scale!=b.scale))return fail("Melodic parts require matching key and scale; no automatic transposition");
    auto selected=[&](const Track&t){return part=="Drums"?gmDrumNote(t.role)>=0:t.role==part;};
    for(const auto&t:p.tracks)if(selected(t)&&(t.midiLocked||t.soundLocked))return fail("Unlock MIDI and sound for the destination part before combining");
    std::vector<Track> incoming;for(const auto&t:source.tracks)if(selected(t))incoming.push_back(t);if(incoming.empty())return fail("The snapshot has no tracks for this part");
    auto next=p;next.tracks.clear();bool inserted=false;
    for(const auto&t:p.tracks){if(selected(t)){if(!inserted){next.tracks.insert(next.tracks.end(),incoming.begin(),incoming.end());inserted=true;}}else next.tracks.push_back(t);}
    if(!inserted)next.tracks.insert(next.tracks.end(),incoming.begin(),incoming.end());
    if(part=="Drums")next.hatChoke=source.hatChoke;
    valid=validate(next);if(valid.failed())return valid;p=std::move(next);return juce::Result::ok();
}
juce::Result clearComparison(Project&p,int slotIndex){
    if(slotIndex<0||slotIndex>2)return fail("Choose snapshot A, B or C");
    auto next=p;(slotIndex==2?next.comparisonC:slotIndex==1?next.comparisonB:next.comparisonA)=juce::var();auto valid=validate(next);if(valid.failed())return valid;p=std::move(next);return juce::Result::ok();
}
juce::Result combineComparisons(Project&p,int drums,int bass,int chords,int melody){
    auto next=p;const int slots[]={drums,bass,chords,melody};const char*parts[]={"Drums","Bass","Chords","Melody"};bool any=false;
    for(int i=0;i<4;++i){if(slots[i]<-1||slots[i]>2)return fail("Invalid source snapshot");if(slots[i]<0)continue;any=true;auto r=combineComparison(next,slots[i],parts[i]);if(r.failed())return r;}
    if(!any)return fail("Choose at least one source snapshot");auto valid=validate(next);if(valid.failed())return valid;p=std::move(next);return juce::Result::ok();
}
void History::recordCommand(const juce::var&entry){
    journal.append(entry.clone());while(journal.size()>128||juce::JSON::toString(journal,true).getNumBytesAsUTF8()>1024*1024)journal.getArray()->remove(0);
}
juce::var History::serialize()const{
    auto state=object();put(state,"history_version",1);put(state,"project",encode(current));put(state,"command_journal",journal.clone());juce::Array<juce::var>undoStates,redoStates;size_t bytes=0;bool stopped[2]{false,false};
    for(size_t depth=0;depth<16;++depth)for(int side=0;side<2;++side){const auto&stack=side==0?past:future;if(stopped[side]||depth>=stack.size())continue;
        auto snapshot=encode(stack[stack.size()-1-depth].project);auto size=juce::JSON::toString(snapshot,true).getNumBytesAsUTF8();if(bytes+size>16*1024*1024){stopped[side]=true;continue;}bytes+=size;(side==0?undoStates:redoStates).insert(0,snapshot);
    }
    put(state,"undo",undoStates);put(state,"redo",redoStates);put(state,"history_trimmed",memoryTrimmed||size_t(undoStates.size())<past.size()||size_t(redoStates.size())<future.size());return state;
}
juce::Result History::restore(const juce::var&state){
    if(!state.hasProperty("history_version")){Project legacy;auto r=decode(state,legacy);if(r.failed())return r;current=std::move(legacy);past.clear();future.clear();memoryTrimmed=false;journal=juce::Array<juce::var>{};return juce::Result::ok();}
    if(!state.isObject()||!state["history_version"].isInt()||int(state["history_version"])!=1||!state["undo"].isArray()||!state["redo"].isArray()||!state["history_trimmed"].isBool())return fail("Unsupported or invalid edit history");
    auto loadedJournal=state.hasProperty("command_journal")?state["command_journal"].clone():juce::var(juce::Array<juce::var>{});
    if(!loadedJournal.isArray()||loadedJournal.size()>128||juce::JSON::toString(loadedJournal,true).getNumBytesAsUTF8()>1024*1024)return fail("Invalid command journal size");
    for(auto&entry:*loadedJournal.getArray()){
        if(!entry.isObject()||!entry["version"].isInt()||int(entry["version"])!=1||!entry["command"].isObject())return fail("Invalid command journal entry");
        for(auto key:{"time_iso8601","project_id","generator_version","before_fingerprint","after_fingerprint","summary"})if(!entry[key].isString())return fail("Invalid command journal text");
        for(auto key:{"seed_before","seed_after"})if((!entry[key].isInt64()&&!entry[key].isInt())||juce::int64(entry[key])<0||juce::int64(entry[key])>4294967295LL)return fail("Invalid journal seed");
    }
    Project loaded;auto r=decode(state["project"],loaded);if(r.failed())return r;std::vector<Snapshot> stacks[2];size_t bytes=0;
    for(int side=0;side<2;++side){auto list=state[side==0?"undo":"redo"];if(list.size()>16)return fail("Too many saved history states");for(const auto&snapshot:*list.getArray()){
        bytes+=juce::JSON::toString(snapshot,true).getNumBytesAsUTF8();if(bytes>16*1024*1024)return fail("Saved edit history exceeds 16 MB");Project p;r=decode(snapshot,p);if(r.failed())return r;stacks[side].push_back({std::move(p),size_t(juce::JSON::toString(snapshot,true).getNumBytesAsUTF8())});
    }}
    journal=std::move(loadedJournal);current=std::move(loaded);past=std::move(stacks[0]);future=std::move(stacks[1]);memoryTrimmed=bool(state["history_trimmed"]);trimHistory();return juce::Result::ok();
}
juce::Result History::saveSession(const juce::File&file)const{
    auto valid=validate(current);if(valid.failed())return valid;auto text=juce::JSON::toString(serialize(),true);if(text.getNumBytesAsUTF8()>64*1024*1024)return fail("Project and history exceed 64 MB; reduce saved instrument state or clear A/B/C slots");
    juce::TemporaryFile temporary(file);if(!temporary.getFile().replaceWithText(text)||!temporary.overwriteTargetFileWithTemporary())return fail("Cannot save project with history");return juce::Result::ok();
}
juce::Result History::loadSession(const juce::File&file){
    if(!file.existsAsFile()||file.getSize()>64*1024*1024)return fail("Missing or oversized project");juce::var state;auto r=juce::JSON::parse(file.loadFileAsString(),state);return r.failed()?r:restore(state);
}
History::Snapshot History::snapshot(const Project& p){return {p,size_t(juce::JSON::toString(encode(p),true).getNumBytesAsUTF8())};}
void History::trimHistory(){
    size_t bytes=0;for(const auto&s:past)bytes+=s.bytes;for(const auto&s:future)bytes+=s.bytes;
    // Prefer retaining the nearest undo/redo states on both sides of the cursor.
    while(past.size()+future.size()>64||bytes>budget){
        auto&stack=past.size()>=future.size()?past:future;
        if(stack.empty())break;
        bytes-=stack.front().bytes;stack.erase(stack.begin());memoryTrimmed=true;
    }
}
juce::Result History::apply(Project p){
    auto v=validate(p);if(v.failed())return v;
    auto before=juce::JSON::toString(encode(current),true);
    if(before==juce::JSON::toString(encode(p),true))return juce::Result::ok();
    past.push_back({current,size_t(before.getNumBytesAsUTF8())});current=std::move(p);future.clear();trimHistory();return juce::Result::ok();
}
bool History::undo(){if(past.empty())return false;future.push_back(snapshot(current));current=std::move(past.back().project);past.pop_back();trimHistory();return true;}
bool History::redo(){if(future.empty())return false;past.push_back(snapshot(current));current=std::move(future.back().project);future.pop_back();trimHistory();return true;}

}
