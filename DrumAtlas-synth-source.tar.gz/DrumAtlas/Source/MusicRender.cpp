#include "MusicRender.h"
#include "TempoMap.h"
#include "MidiGlide.h"
#include "InstrumentRender.h"
#include "Formats.h"
#include "MixBalance.h"
#include <cmath>
#include <juce_cryptography/juce_cryptography.h>
namespace atlas::music {
static juce::Result renderPart(const Project&p,const juce::File&file,double rate,const std::function<bool()>&cancel,
    const std::vector<size_t>*selection=nullptr,int bits=24,float fixedGain=-1,float*measuredPeak=nullptr,const instruments::Cache*instruments=nullptr){
    auto cancelled=[&]{return cancel&&cancel();};
    if(cancelled())return juce::Result::fail("Render cancelled");
    if(!measuredPeak&&!file.getParentDirectory().isDirectory())return juce::Result::fail("Output folder does not exist");
    auto valid=validate(p);if(valid.failed())return valid;for(auto&t:p.tracks)if(t.liveDevice.isNotEmpty())return juce::Result::fail("Native Live instruments must be rendered in Ableton");
    if(!std::isfinite(rate)||rate<22050||rate>96000)return juce::Result::fail("Unsupported sample rate");
    TempoMap timeline(p);auto closures=hatClosures(p);const double seconds=timeline.seconds(barTicks(p.settings)*p.settings.bars);
    const int64_t total=instruments?instruments->frames:int64_t(std::ceil((seconds+2)*rate));
    // Only this fixed-size mix buffer scales with channels, never song duration.
    constexpr int blockSize=4096;juce::AudioBuffer<float>mix(2,blockSize),instrumentAudio(2,blockSize);
    struct Source{juce::AudioBuffer<float>audio;double rate=44100;};
    struct Voice{size_t track;Note note;int64_t start,length,cutoff;double step,duration,frequency;uint32_t seed;};
    std::vector<Source>sources(p.tracks.size());std::vector<Voice>voices;
    juce::AudioFormatManager fm;registerFormats(fm);
    std::vector<std::unique_ptr<juce::AudioFormatReader>> rendered(p.tracks.size());
    if(instruments)for(size_t i=0;i<p.tracks.size();++i)if(i<instruments->files.size()&&instruments->files[i].existsAsFile()){
        rendered[i].reset(fm.createReaderFor(instruments->files[i]));if(!rendered[i])return juce::Result::fail("Cannot read instrument cache");
    }
    uint32_t seed=p.settings.seed;auto next=[&]{seed=seed*1664525u+1013904223u;return seed;};
    for(size_t track=0;track<p.tracks.size();++track){
        if(cancelled())return juce::Result::fail("Render cancelled");
        const auto&t=p.tracks[track];if(t.instrument.isVoid()&&!t.controls.empty()&&(!selection||std::find(selection->begin(),selection->end(),track)!=selection->end()))return juce::Result::fail("MIDI controls require a configured VST for audio rendering; MIDI export remains available: "+t.role);auto&source=sources[track];source.rate=rate;
        if(t.instrument.isVoid()&&!rendered[track]&&t.soundPath.isNotEmpty()){
            if(!juce::File::isAbsolutePath(t.soundPath))return juce::Result::fail("Invalid assigned sample path");
            std::unique_ptr<juce::AudioFormatReader>reader(fm.createReaderFor(ioFile(juce::File(t.soundPath))));
            if(!reader||reader->lengthInSamples<1||reader->sampleRate<1000||reader->lengthInSamples>reader->sampleRate*30||reader->lengthInSamples>INT_MAX||reader->numChannels<1||reader->numChannels>2)return juce::Result::fail("Assigned sample missing or unsuitable for one-shot render: "+t.role);
            source.rate=reader->sampleRate;source.audio.setSize(2,int(reader->lengthInSamples));
            if(!reader->read(&source.audio,0,source.audio.getNumSamples(),0,true,true))return juce::Result::fail("Cannot decode assigned sample");
        }
        for(const auto&n:t.notes){
            next();if(!playsNote(p.settings.seed,n))continue;
            auto cutTick=hatCut(t,n,closures);if(cutTick==n.tick+n.microtiming){next();continue;}auto cutoff=cutTick<0?int64_t(-1):int64_t(std::llround(timeline.seconds(cutTick)*rate));
            const auto start=int64_t(std::llround(timeline.seconds(n.tick+n.microtiming)*rate));
            const double duration=(timeline.seconds(n.tick+n.microtiming+n.duration)-timeline.seconds(n.tick+n.microtiming)),frequency=440*std::pow(2.,(n.pitch-69)/12.);
            const bool drum=n.channel==10;const double step=source.rate/rate*(drum?1:std::pow(2.,(n.pitch-t.sampleRoot)/12.));
            auto length=std::min(total-start,source.audio.getNumSamples()>0?int64_t(std::ceil(source.audio.getNumSamples()/(step*std::min(1.,std::pow(2.,n.glideFrom/12.))))):int64_t(rate*(drum?(t.role=="Open Hat"?.4:.25):duration+.12)));
            if(cutoff>=0)length=std::min(length,std::max<int64_t>(0,cutoff-start));auto voiceSeed=next();if(t.instrument.isVoid()&&!rendered[track])voices.push_back({track,n,start,length,cutoff,step,duration,frequency,voiceSeed});
        }
    }
    std::vector<std::vector<int64_t>> hatStarts(p.tracks.size());if(p.hatChoke)for(size_t i=0;i<p.tracks.size();++i)if(p.tracks[i].role=="Open Hat")for(auto&n:p.tracks[i].notes)if(playsNote(p.settings.seed,n))hatStarts[i].push_back(n.tick+n.microtiming);for(auto&starts:hatStarts)std::sort(starts.begin(),starts.end());
    std::stable_sort(voices.begin(),voices.end(),[](const Voice&a,const Voice&b){return a.start<b.start;});
    float peak=0;
    // Two deterministic streaming passes retain whole-song peak normalization
    // without buffering the song or using block-dependent gain changes.
    auto pass=[&](juce::AudioFormatWriter*writer,float gain){
        struct State{double phase=0,position=0;uint32_t noise=0;};std::vector<State>states(voices.size());
        for(size_t i=0;i<voices.size();++i)states[i].noise=voices[i].seed;
        std::vector<size_t>active;size_t upcoming=0;
        for(int64_t offset=0;offset<total;offset+=blockSize){
            if(cancelled())return juce::Result::fail("Render cancelled");
            int count=int(std::min<int64_t>(blockSize,total-offset));mix.clear();
            for(size_t i=0;i<rendered.size();++i)if(rendered[i]&&(!selection||std::find(selection->begin(),selection->end(),i)!=selection->end())){
                instrumentAudio.clear();if(!rendered[i]->read(&instrumentAudio,0,count,offset,true,true))return juce::Result::fail("Cannot stream instrument audio");
                if(p.hatChoke&&!p.tracks[i].instrument.isVoid()&&p.tracks[i].role=="Open Hat")for(int frame=0;frame<count;++frame){double tick=timeline.ticks((offset+frame)/rate);auto&starts=hatStarts[i];auto onset=std::upper_bound(starts.begin(),starts.end(),tick);float gain=0;if(onset!=starts.begin()){--onset;auto cut=std::lower_bound(closures.begin(),closures.end(),*onset);gain=cut==closures.end()?1.f:float(juce::jlimit(0.,1.,(timeline.seconds(*cut)-timeline.seconds(tick))/.005));}for(int ch=0;ch<2;++ch)instrumentAudio.setSample(ch,frame,instrumentAudio.getSample(ch,frame)*gain);}
                const float trackGain=instruments&&i<instruments->mixGains.size()?instruments->mixGains[i]:1.f;
                for(int ch=0;ch<2;++ch)mix.addFrom(ch,0,instrumentAudio,ch,0,count,trackGain);
            }
            active.erase(std::remove_if(active.begin(),active.end(),[&](size_t i){return voices[i].start+voices[i].length<=offset;}),active.end());
            while(upcoming<voices.size()&&voices[upcoming].start<offset+count)active.push_back(upcoming++);
            for(auto index:active){
                if(selection&&std::find(selection->begin(),selection->end(),voices[index].track)==selection->end())continue;
                const auto&v=voices[index];auto&state=states[index];const auto&source=sources[v.track].audio;const auto&role=p.tracks[v.track].role;
                auto begin=std::max(offset,v.start),end=std::min(offset+count,v.start+v.length);
                for(auto frame=begin;frame<end;++frame){
                    auto i=frame-v.start;int destination=int(frame-offset);double time=i/rate;float velocity=v.note.velocity/127.f;if(v.cutoff>=0)velocity*=float(juce::jlimit(0.,1.,(v.cutoff-frame)/(rate*.005)));
                    double ratio=glideRatio(v.note.glideFrom,v.note.glideTicks,v.note.bendRange,timeline.ticks(frame/rate)-(v.note.tick+v.note.microtiming));
                    if(source.getNumSamples()>0){double pos=state.position;state.position+=v.step*ratio;int a=int(pos);if(a>=source.getNumSamples())break;int b=std::min(a+1,source.getNumSamples()-1);
                        for(int ch=0;ch<2;++ch){float sample=source.getSample(ch,a)+float(pos-a)*(source.getSample(ch,b)-source.getSample(ch,a));if(!std::isfinite(sample))return juce::Result::fail("Non-finite source audio");mix.addSample(ch,destination,sample*velocity*.3f);}
                    }else{
                        double value;
                        if(role=="Kick"){state.phase+=juce::MathConstants<double>::twoPi*(48+95*std::exp(-time*35))/rate;value=std::sin(state.phase)*std::exp(-time*19);}
                        else if(v.note.channel==10){state.noise=state.noise*1664525u+1013904223u;value=(double(state.noise)/2147483648.-1.)*std::exp(-time*(role=="Open Hat"?15:role=="Closed Hat"?65:24));}
                        else{double env=std::min(1.,time/.005)*std::min(1.,std::max(0.,(v.duration+.12-time)/.12));value=std::sin(state.phase)*env*(role=="Chords"?.2:.55);state.phase+=juce::MathConstants<double>::twoPi*v.frequency*ratio/rate;}
                        for(int ch=0;ch<2;++ch)mix.addSample(ch,destination,float(value)*velocity*.32f);
                    }
                }
            }
            float magnitude=mix.getMagnitude(0,count);if(!std::isfinite(magnitude))return juce::Result::fail("Invalid render");
            if(writer){mix.applyGain(gain);if(!writer->writeFromAudioSampleBuffer(mix,0,count))return juce::Result::fail("Cannot write beat WAV: check free disk space");}
            else peak=std::max(peak,magnitude);
        }
        return juce::Result::ok();
    };
    auto result=juce::Result::ok();
    if(fixedGain<0||measuredPeak){result=pass(nullptr,1);if(result.failed())return result;}
    if(measuredPeak){*measuredPeak=peak;return result;}
    juce::TemporaryFile tmp(file);auto stream=tmp.getFile().createOutputStream();if(!stream||stream->failedToOpen())return juce::Result::fail("Cannot open output WAV");juce::WavAudioFormat wav;
    // JUCE automatically promotes large WAV files to RF64.
    std::unique_ptr<juce::AudioFormatWriter>writer;
    if(bits==32){std::unique_ptr<juce::OutputStream>floatStream(std::move(stream));writer=wav.createWriterFor(floatStream,juce::AudioFormatWriterOptions{}.withSampleRate(rate).withNumChannels(2).withBitsPerSample(32).withSampleFormat(juce::AudioFormatWriterOptions::SampleFormat::floatingPoint));}
    else writer.reset(wav.createWriterFor(stream.release(),rate,2,bits,{},0));
    if(!writer)return juce::Result::fail("Cannot create WAV writer");
    result=pass(writer.get(),fixedGain>=0?fixedGain:peak>.95f?.95f/peak:1.f);if(result.failed())return result;
    if(!writer->flush())return juce::Result::fail("Cannot finish WAV: check free disk space");writer.reset();
    if(cancelled())return juce::Result::fail("Render cancelled");
    return tmp.overwriteTargetFileWithTemporary()?juce::Result::ok():juce::Result::fail("Cannot commit beat WAV");
}
static juce::Result prepareRenderCache(instruments::Cache&cache,const Project&p,double rate,const std::function<bool()>&cancel){
 return cache.prepare(p,rate,cancel,[&](size_t index,const juce::File&file){auto dry=p;for(auto&track:dry.tracks)track.effects=juce::var();std::vector<size_t>selection{index};return renderPart(dry,file,rate,cancel,&selection,32,1.f);});
}
juce::Result renderWav(const Project&p,const juce::File&file,double rate,const std::function<bool()>&cancel,juce::StringArray*warnings){
    if(warnings)warnings->clear();instruments::Cache cache;auto r=prepareRenderCache(cache,p,rate,cancel);if(r.failed())return r;if(warnings)*warnings=cache.warnings;return renderPart(p,file,rate,cancel,nullptr,24,-1,nullptr,&cache);
}

juce::Result renderStems(const Project&p,const juce::File&destination,const StemExportOptions&options,const std::function<bool()>&cancel,juce::StringArray*warnings){
    if(warnings)warnings->clear();
    auto cancelled=[&]{return cancel&&cancel();};
    if(cancelled())return juce::Result::fail("Render cancelled");
    auto valid=validate(p);if(valid.failed())return valid;for(auto&t:p.tracks)if(t.liveDevice.isNotEmpty())return juce::Result::fail("Native Live instruments must be rendered in Ableton");
    if(options.sampleRate!=44100&&options.sampleRate!=48000&&options.sampleRate!=96000)return juce::Result::fail("Choose 44.1, 48 or 96 kHz");
    if(options.bits!=16&&options.bits!=24)return juce::Result::fail("Choose 16 or 24 bit PCM");
    if(destination.exists()||!destination.getParentDirectory().isDirectory())return juce::Result::fail("Choose a new export folder inside an existing folder");
    struct Part{juce::String name;std::vector<size_t>tracks;};
    std::vector<Part>parts;
    if(options.perTrack){
        for(size_t i=0;i<p.tracks.size();++i)parts.push_back({juce::String(int(i)+1).paddedLeft('0',3)+"-"+juce::File::createLegalFileName(trackName(p.tracks[i])).substring(0,60),{i}});
    }else{
        for(auto name:{"Drums","Bass","Chords","Melody","Other"}){
            Part part{name,{}};
            for(size_t i=0;i<p.tracks.size();++i){const auto&role=p.tracks[i].role;
                auto group=juce::StringArray{"Kick","Snare","Clap","Closed Hat","Open Hat","Percussion"}.contains(role)?juce::String("Drums"):
                    juce::StringArray{"Bass","Chords","Melody"}.contains(role)?role:juce::String("Other");
                if(group==name)part.tracks.push_back(i);
            }
            if(!part.tracks.empty())parts.push_back(std::move(part));
        }
    }
    if(parts.empty())return juce::Result::fail("No tracks to export");
    auto hash=[](const juce::File&f){juce::FileInputStream input(f);return input.openedOk()?juce::SHA256(input).toHexString():juce::String();};
    juce::Array<juce::var>outputs,sources;
    // Fingerprint before all passes; reject samples changed during rendering.
    for(const auto&t:p.tracks)if(t.instrument.isVoid()&&t.soundPath.isNotEmpty()){
        if(cancelled())return juce::Result::fail("Render cancelled");
        if(!juce::File::isAbsolutePath(t.soundPath))return juce::Result::fail("Invalid assigned sample path");
        auto digest=hash(ioFile(juce::File(t.soundPath)));if(digest.isEmpty())return juce::Result::fail("Cannot fingerprint source sample");
        auto*entry=new juce::DynamicObject;entry->setProperty("track_id",t.id);entry->setProperty("path",t.soundPath);entry->setProperty("sha256",digest);sources.add(juce::var(entry));
    }
    // One gain for every file, including stems whose peaks cancel in the mix.
    instruments::Cache cache;cache.unknownTailSeconds=options.unknownTailSeconds;auto prepared=prepareRenderCache(cache,p,options.sampleRate,cancel);if(prepared.failed())return prepared;
    juce::Array<juce::var> balanceReport;
    if(options.balanceRoles){
        cache.mixGains.resize(p.tracks.size(),1.f);juce::WavAudioFormat wav;
        auto made=cache.folder.createDirectory();if(made.failed())return made;
        for(size_t i=0;i<p.tracks.size();++i){
            // Measure the real rendered signal for both sources, including any
            // effects. Cache samples too, to apply one constant gain exactly once.
            if(!cache.files[i].existsAsFile()){
                auto file=cache.folder.getChildFile("sample-"+juce::String(int(i))+".wav");std::vector<size_t> single{i};
                auto dry=renderPart(p,file,options.sampleRate,cancel,&single,32,1.f);if(dry.failed())return dry;cache.files[i]=file;
            }
            std::unique_ptr<juce::AudioFormatReader> reader(wav.createReaderFor(cache.files[i].createInputStream().release(),true));
            if(!reader)return juce::Result::fail("Cannot read track for mix balancing");balance::Measurement m;auto measured=balance::measure(*reader,m,cancel);if(measured.failed())return measured;
            cache.mixGains[i]=balance::gain(p.tracks[i].role,m);
            auto fixed=options.fixedBalance[juce::Identifier(p.tracks[i].id)];
            if(!fixed.isVoid()){
                if(!(fixed.isDouble()||fixed.isInt())||!std::isfinite(double(fixed))||double(fixed)<=0||double(fixed)>4)return juce::Result::fail("Invalid saved mix gain");
                cache.mixGains[i]=float(fixed);
            }
            auto* row=new juce::DynamicObject;row->setProperty("track_id",p.tracks[i].id);row->setProperty("active_rms",m.activeRms);row->setProperty("peak",m.peak);row->setProperty("gain",cache.mixGains[i]);balanceReport.add(juce::var(row));
        }
    }
    float maximum=0,peak=0;auto r=renderPart(p,{},options.sampleRate,cancel,nullptr,options.bits,-1,&maximum,&cache);if(r.failed())return r;
    for(const auto&part:parts){r=renderPart(p,{},options.sampleRate,cancel,&part.tracks,options.bits,-1,&peak,&cache);if(r.failed())return r;maximum=std::max(maximum,peak);}
    const float gain=maximum>.95f?.95f/maximum:1.f;
    const auto staging=destination.getParentDirectory().getChildFile(".drumatlas-export-"+juce::Uuid().toString());
    r=staging.createDirectory();if(r.failed())return r;
    struct Cleanup{juce::File folder;~Cleanup(){folder.deleteRecursively();}}cleanup{staging};
    auto output=[&](const juce::String&name,const std::vector<size_t>*tracks){
        auto file=staging.getChildFile(name+".wav");auto result=renderPart(p,file,options.sampleRate,cancel,tracks,options.bits,gain,nullptr,&cache);if(result.failed())return result;
        // Verify the committed file, not just the requested writer settings.
        juce::WavAudioFormat format;
        auto verificationInput=file.createInputStream();
        if(!verificationInput)return juce::Result::fail("Cannot reopen exported WAV: "+file.getFileName());
        std::unique_ptr<juce::AudioFormatReader> verified(format.createReaderFor(verificationInput.release(),true));
        if(!verified||verified->lengthInSamples!=cache.frames||verified->sampleRate!=options.sampleRate||verified->numChannels!=2||verified->bitsPerSample!=options.bits)
            return juce::Result::fail("Exported WAV is incomplete or misaligned: "+file.getFileName());
        verified.reset();
        auto digest=hash(file);if(digest.isEmpty())return juce::Result::fail("Cannot fingerprint output");
        auto*entry=new juce::DynamicObject;entry->setProperty("file",file.getFileName());entry->setProperty("sha256",digest);
        juce::Array<juce::var>ids;for(size_t i=0;i<p.tracks.size();++i)if(!tracks||std::find(tracks->begin(),tracks->end(),i)!=tracks->end())ids.add(p.tracks[i].id);
        entry->setProperty("track_ids",ids);outputs.add(juce::var(entry));return juce::Result::ok();
    };
    r=output("Mix",nullptr);if(r.failed())return r;
    for(const auto&part:parts){r=output(part.name,&part.tracks);if(r.failed())return r;}
    for(const auto&source:sources)if(hash(ioFile(juce::File(source["path"].toString())))!=source["sha256"].toString())return juce::Result::fail("Source changed during export; retry");
    auto*manifest=new juce::DynamicObject;juce::var data(manifest);
    manifest->setProperty("schema_version",1);manifest->setProperty("renderer","one-shot-synthesis-vst3-2");manifest->setProperty("project",encode(p));
    manifest->setProperty("sample_rate",options.sampleRate);manifest->setProperty("bits_per_sample",options.bits);manifest->setProperty("channels",2);
    manifest->setProperty("frames",cache.frames);
    manifest->setProperty("instruments",cache.reports);manifest->setProperty("tail_seconds",cache.frames/options.sampleRate-TempoMap(p).seconds(barTicks(p.settings)*p.settings.bars));manifest->setProperty("latency_frames",0);manifest->setProperty("common_gain",double(gain));
    manifest->setProperty("per_track",options.perTrack);manifest->setProperty("outputs",outputs);manifest->setProperty("sources",sources);manifest->setProperty("warnings",juce::var(cache.warnings));if(warnings)*warnings=cache.warnings;
    if(options.balanceRoles){manifest->setProperty("balance_version",1);manifest->setProperty("track_balance",balanceReport);}
    if(!staging.getChildFile("manifest.json").replaceWithText(juce::JSON::toString(data)))return juce::Result::fail("Cannot write export manifest");
    if(cancelled())return juce::Result::fail("Render cancelled");
    if(destination.exists()||!staging.moveFileTo(destination))return juce::Result::fail("Cannot commit export folder");
    return juce::Result::ok();
}
}
