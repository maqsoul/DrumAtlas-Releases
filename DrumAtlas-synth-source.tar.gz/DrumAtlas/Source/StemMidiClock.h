#pragma once
#include <juce_core/juce_core.h>

namespace atlas::stemnotes {
// A reference owns one export clock. Never sample a changing DAW tempo for
// each stem, or derive MIDI time from an individually stretched preview.
inline juce::String clockKey(const juce::File& reference){
    return reference.getFullPathName()+"|"+juce::String(reference.getSize())+"|"+
           juce::String(reference.getLastModificationTime().toMilliseconds());
}
inline double savedClock(const juce::File& store,const juce::File& reference){
    auto data=juce::JSON::parse(store);double value=double(data.getProperty(juce::Identifier(clockKey(reference)),0));
    return std::isfinite(value)&&value>=20&&value<=400?value:0;
}
inline juce::Result saveClock(const juce::File& store,const juce::File& reference,double bpm){
    if(!std::isfinite(bpm)||bpm<20||bpm>400)return juce::Result::fail("MIDI tempo must be between 20 and 400 BPM");
    auto data=juce::JSON::parse(store);if(!data.isObject())data=juce::var(new juce::DynamicObject);
    data.getDynamicObject()->setProperty(clockKey(reference),bpm);
    auto made=store.getParentDirectory().createDirectory();if(made.failed())return made;
    juce::TemporaryFile temporary(store);
    if(!temporary.getFile().replaceWithText(juce::JSON::toString(data))||!temporary.overwriteTargetFileWithTemporary())return juce::Result::fail("Cannot save the shared MIDI tempo");
    return juce::Result::ok();
}
}
