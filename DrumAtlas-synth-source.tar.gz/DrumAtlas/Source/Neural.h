#pragma once
#include "Analysis.h"
#include <memory>
#include <functional>
namespace atlas {
struct NeuralResult {
    std::vector<std::pair<juce::String, float>> instruments;
    juce::StringArray genres;
    std::vector<uint8_t> embedding;
    bool valid = false;
};
// The requested filter is deliberately not an input: selecting Rim must not
// turn a generic snare estimate into a positive rimshot detection.
inline juce::String detailedHitCategory(const juce::String&stem,const Features&features,const NeuralResult&result){
 if(stem=="Hi Hat")return features.duration>.24f?"Open Hat":"Closed Hat";
 if(stem!="Snare")return stem;
 float snare=0,rim=0,clap=0;for(const auto&c:result.instruments){if(c.first=="Snare")snare=c.second;else if(c.first=="Rim")rim=c.second;else if(c.first=="Clap")clap=c.second;}
 if(rim>=.2f&&rim>std::max(snare,clap)*1.2f)return "Rim";
 if(clap>=.2f&&clap>std::max(snare,rim)*1.2f)return "Clap";
 return stem;
}
class Neural {
public:
    Neural(); ~Neural();
    bool available() const;
    juce::String error() const;
    NeuralResult analyse(const std::vector<float>& audio);
private:
    struct Impl; std::unique_ptr<Impl> impl;
};
juce::StringArray genreNames();
juce::File vocalGpuResources();
juce::StringArray genreTags(const juce::String& name);
class DetailSeparator {
public:
 enum Mode{Drums,Percussion};explicit DetailSeparator(Mode);~DetailSeparator();
 bool available()const;juce::String error()const;juce::String backend()const;
 // Drums: planar stereo 44100 Hz, 130560 frames, 6 outputs.
 // Percussion: mono 32000 Hz, arbitrary segment, one query-conditioned output.
 std::vector<std::vector<float>> drums(const std::vector<float>&,const std::vector<int>& selected = {0,1,2,3,4,5},bool cleanBleed=false);
 std::vector<float> percussion(const std::vector<float>&,const juce::String&);
 // Same float32 inference per query, sharing the input spectrum and normalization.
 std::vector<std::vector<float>> percussionMany(const std::vector<float>&,const juce::StringArray&,const std::function<bool()>& cancelled = {});
private:struct Impl;std::unique_ptr<Impl>impl;
};
class StemSeparator {
public:
 static constexpr int frames=343980;
 enum Model{General,FineDrums,FineBass,FineVocals,CleanVocals};
 explicit StemSeparator(bool drumsSpecialist=false);~StemSeparator();
 explicit StemSeparator(Model,int cpuThreads=0,bool allowGpu=true);
 bool available()const;juce::String error()const;
 bool usesGpu()const;
 // Six output slots; specialists fill only drums 0 / bass 1 / vocals 3.
 // CleanVocals adapts the 8-second RoFormer to the shared 7.8-second OLA grid.
 std::vector<std::vector<float>> process(const std::vector<float>& stereo,const std::function<bool()>& cancelled={});
private:struct Impl;std::unique_ptr<Impl>impl;
};
}
