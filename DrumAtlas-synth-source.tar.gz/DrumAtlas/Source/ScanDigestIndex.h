#pragma once
#include "ContentHash.h"
#include "MemoryAdmission.h"
#include <map>
#include <mutex>

namespace atlas::hosting {
// A hint for reusing SHA-256, separate from the class and quarantine records.
// Only NTFS provides the change-time semantics we rely on here.
inline juce::String scanChangeStamp(const juce::File& file){
#if JUCE_WINDOWS
    auto h=CreateFileW(file.getFullPathName().toWideCharPointer(),FILE_READ_ATTRIBUTES,
                       FILE_SHARE_READ|FILE_SHARE_DELETE,nullptr,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,nullptr);
    if(h==INVALID_HANDLE_VALUE)return {};
    struct Close { HANDLE h; ~Close(){CloseHandle(h);} } close{h};
    BY_HANDLE_FILE_INFORMATION info{};FILE_BASIC_INFO basic{};wchar_t fs[32]{};
    if(!GetFileInformationByHandle(h,&info)||!GetFileInformationByHandleEx(h,FileBasicInfo,&basic,sizeof(basic))
       ||!GetVolumeInformationByHandleW(h,nullptr,0,nullptr,nullptr,nullptr,fs,32)||_wcsicmp(fs,L"NTFS")!=0
       ||!basic.ChangeTime.QuadPart||(!info.nFileIndexHigh&&!info.nFileIndexLow))return {};
    juce::StringArray parts;
    for(auto value:{(juce::int64)info.dwVolumeSerialNumber,(juce::int64)info.nFileIndexHigh,(juce::int64)info.nFileIndexLow,
                    (juce::int64)basic.CreationTime.QuadPart,(juce::int64)basic.ChangeTime.QuadPart,(juce::int64)basic.LastWriteTime.QuadPart,
                    (juce::int64)info.nFileSizeHigh,(juce::int64)info.nFileSizeLow})parts.add(juce::String::toHexString(value));
    return parts.joinIntoString(":");
#else
    juce::ignoreUnused(file);return {};
#endif
}

class ScanDigestIndex {
public:
    explicit ScanDigestIndex(const juce::File&cache):file(cache.getChildFile("indices/ntfs-digests-v1.json")){
        if(!file.existsAsFile()||file.getSize()>16*1024*1024)return;
        auto data=juce::JSON::parse(file);
        if(auto* rows=data.getArray();rows&&rows->size()<=32768)for(auto& row:*rows){
            if(!row.isArray()||row.size()!=3||!row[0].isString()||!row[1].isString())continue;
            auto digest=row[2].toString();
            if(digest.length()==64&&digest.containsOnly("0123456789abcdef"))
                entries.emplace(row[0].toString(),Entry{row[1].toString(),digest});
        }
    }
    juce::String digest(const juce::File& f,const juce::String& path,const std::function<bool()>&cancel){
        auto stamp=scanChangeStamp(f);
        if(stamp.isNotEmpty()){
            std::lock_guard<std::mutex> lock(mutex);
            auto i=entries.find(path);if(i!=entries.end()&&i->second.stamp==stamp)return i->second.digest;
        }
        auto hash=contentSHA256(f,cancel);
        if(stamp.isNotEmpty()){
            if(stamp!=scanChangeStamp(f))return {};
            std::lock_guard<std::mutex> lock(mutex);
            if(entries.size()<32768||entries.count(path)){entries[path]={stamp,hash};dirty=true;}
        }
        return hash;
    }
    void save() const { // Called after all scan threads have joined. A missing hint is harmless.
        if(!dirty||file.getParentDirectory().createDirectory().failed())return;
        juce::Array<juce::var> rows;for(auto& item:entries)rows.add(juce::Array<juce::var>{item.first,item.second.stamp,item.second.digest});
        juce::TemporaryFile tmp(file);if(tmp.getFile().replaceWithText(juce::JSON::toString(rows,true)))tmp.overwriteTargetFileWithTemporary();
    }
private:
    struct Entry {juce::String stamp,digest;};
    juce::File file;std::mutex mutex;std::map<juce::String,Entry> entries;bool dirty=false;
};
}
