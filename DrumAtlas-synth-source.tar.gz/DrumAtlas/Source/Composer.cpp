#include "Composer.h"
#include "OpenAIPlanner.h"
#include "ComposerHook.h"
#include "ReferenceBrief.h"
#include "TempoDetector.h"
#include "ReferenceKey.h"
#include "ReferenceMusic.h"
#include "ComposerGroove.h"
#include "ReferencePulse.h"
#include "MusicHarmony.h"
#include "MusicRender.h"
#include "SongArrangement.h"
#include "ComposerArrangement.h"
#include "InstrumentScanner.h"
#include "InstrumentRender.h"
#include "AudioEdit.h"
#include <numeric>

namespace atlas::composer {
namespace {
juce::var object(std::initializer_list<std::pair<juce::String,juce::var>> fields) {
    auto* o=new juce::DynamicObject; for(auto&f:fields)o->setProperty(f.first,f.second);return juce::var(o);
}
void require(bool ok,const juce::String&message){if(!ok)throw std::runtime_error(message.toStdString());}
void checked(const juce::Result&r){require(r.wasOk(),r.getErrorMessage());}
bool number(const juce::var&v){return (v.isInt()||v.isInt64()||v.isDouble())&&std::isfinite(double(v));}
bool integer(const juce::var&v){return v.isInt()||v.isInt64();}
juce::var planSchema(const music::ProfileRegistry&registry,int instrumentCount){
    auto textEnum=[](const juce::Array<juce::var>&values){return object({{"type","string"},{"enum",values}});};
    auto schemaObject=[](const juce::var&properties){juce::Array<juce::var>required;for(auto&p:properties.getDynamicObject()->getProperties())required.add(p.name.toString());return object({{"type","object"},{"properties",properties},{"required",required},{"additionalProperties",false}});};
    juce::Array<juce::var>genres,moods,roles,indices;for(auto&g:registry.genres())genres.add(g.id);for(auto&m:registry.moods())moods.add(m.id);for(auto&r:music::generationRoles())roles.add(r);for(int i=0;i<instrumentCount;++i)indices.add(i);
    auto unit=object({{"type","number"},{"minimum",0},{"maximum",1}});
    auto pattern=object({{"type","array"},{"items",unit},{"minItems",16},{"maxItems",16}});
    auto stylePattern=schemaObject(object({{"kick",pattern},{"snare",pattern},{"hat",pattern},{"swing",unit}}));
    auto instrument=schemaObject(object({{"role",textEnum(roles)},{"index",object({{"type","integer"},{"enum",indices.isEmpty()?juce::Array<juce::var>{0}:indices}})}}));
    auto section=schemaObject(object({{"active_roles",object({{"type","array"},{"items",textEnum(roles)},{"minItems",1},{"maxItems",11}})},{"name",textEnum({"Intro","Verse","Chorus","Bridge","Outro","Drop","Breakdown","Build"})},{"bars",object({{"type","integer"},{"minimum",1},{"maximum",64}})}}));
    auto whole=[](int lo,int hi){return object({{"type","integer"},{"minimum",lo},{"maximum",hi}});};
    auto hookNote=schemaObject(object({{"step",whole(0,31)},{"length",whole(1,32)},{"degree",whole(0,13)},{"velocity",whole(1,127)}}));
    return schemaObject(object({{"requested_style",object({{"type","string"},{"maxLength",128},{"description","Short genre label only, e.g. UK Garage. Do not repeat the prompt or arrangement instructions. Maximum 128 characters."}})},{"hook",object({{"type","array"},{"items",hookNote},{"maxItems",24}})},{"genre",textEnum(genres)},{"style_pattern",stylePattern},{"progression",object({{"type","string"},{"maxLength",256}})},{"mood",textEnum(moods)},{"bpm",object({{"type","number"},{"minimum",30},{"maximum",300}})},{"tonic",object({{"type","integer"},{"minimum",0},{"maximum",11}})},{"scale",textEnum({"minor","major"})},{"energy",unit},{"density",unit},{"complexity",unit},{"darkness",unit},{"groove",unit},{"melodic_density",unit},{"roles",object({{"type","array"},{"items",textEnum(roles)},{"minItems",1},{"maxItems",11}})},{"sections",object({{"type","array"},{"items",section},{"minItems",1},{"maxItems",32}})},{"instruments",object({{"type","array"},{"items",instrument},{"maxItems",instrumentCount?11:0}})}}));
}
juce::File resampleLoop(const juce::File&input,const juce::File&folder,const std::function<bool()>&cancel){
    juce::AudioFormatManager fm;registerFormats(fm);auto*reader=fm.createReaderFor(ioFile(input));require(reader!=nullptr,"Cannot open aligned loop");
    const auto rate=reader->sampleRate;const auto count=juce::int64(std::llround(reader->lengthInSamples*44100./rate));
    if(rate==44100){delete reader;return input;}
    juce::AudioFormatReaderSource source(reader,true);juce::ResamplingAudioSource resampler(&source,false,2);resampler.setResamplingRatio(rate/44100.);resampler.prepareToPlay(4096,44100);
    auto file=folder.getChildFile("loop-44100.wav");auto stream=std::unique_ptr<juce::OutputStream>(file.createOutputStream());juce::WavAudioFormat wav;auto writer=wav.createWriterFor(stream,juce::AudioFormatWriterOptions{}.withSampleRate(44100).withNumChannels(2).withBitsPerSample(24));require(bool(writer),"Cannot convert loop sample rate");juce::AudioBuffer<float>buffer(2,4096);
    for(juce::int64 at=0;at<count;at+=4096){require(!(cancel&&cancel()),"Cancelled");int n=int(std::min<juce::int64>(4096,count-at));buffer.clear();resampler.getNextAudioBlock({&buffer,0,n});require(writer->writeFromAudioSampleBuffer(buffer,0,n),"Loop conversion write failed");}resampler.releaseResources();return file;
}
int sampleRoot(const Sample&s){
    // Estimate an actual MIDI octave as well as pitch class. Treating every
    // labelled 808_C as C4 would transpose real bass samples two octaves too far.
    juce::AudioFormatManager fm;registerFormats(fm);auto audio=decode(fm,juce::File(s.path),0,.6);if(audio.error.isNotEmpty()||audio.mono.size()<1500)return -1;
    int named=-1;auto tokens=juce::StringArray::fromTokens(juce::File(s.path).getFileNameWithoutExtension().toUpperCase()," _-[]().","");
    const juce::StringArray names{"C","C#","D","D#","E","F","F#","G","G#","A","A#","B"};
    for(auto&token:tokens){int found=names.indexOf(token);if(found>=0)named=found;}
    const int maxLag=std::min(882,int(audio.mono.size()/3)),window=std::min(4096,int(audio.mono.size())-maxLag);if(window<512)return -1;
    double best=0;int pitch=-1;
    // Evaluate equal-tempered candidate periods; normalized correlation tolerates
    // the decay of one-shots. Uncertain/polyphonic roots remain unassigned.
    for(int note=24;note<=96;++note){if(named>=0&&note%12!=named)continue;int lag=int(std::round(analysisRate/(440*std::pow(2.,(note-69)/12.))));if(lag<12||lag>maxLag)continue;double cross=0,first=0,second=0;for(int i=0;i<window;++i){double a=audio.mono[size_t(i)],b=audio.mono[size_t(i+lag)];cross+=a*b;first+=a*a;second+=b*b;}double score=cross/std::sqrt(std::max(1e-20,first*second));
        if(score>best+.01||(score>=best-.01&&score>.85&&note>pitch)){best=score;pitch=note;}}
    return best>=.78?pitch:-1;
}
}
juce::File dataDirectory(){auto p=juce::SystemStats::getEnvironmentVariable("DRUMATLAS_CACHE_DIR",{});return p.isNotEmpty()?juce::File(p):juce::File::getSpecialLocation(juce::File::userApplicationDataDirectory).getChildFile("DrumAtlas");}
juce::var Analysis::json()const{
    juce::Array<juce::var> levels;for(double e:energy)levels.add(e);
    juce::StringArray detected;for(auto&h:timbres)detected.addIfNotAlreadyThere(h.category);
    return object({{"duration_seconds",duration},{"bpm",bpm},{"tempo_confidence",tempoConfidence},{"tonic",tonic},{"minor",minor},{"key_confidence",keyConfidence},{"source_frames",frames},{"analysed_frames",analysedFrames},{"energy_per_second",levels},{"estimated_instruments",detected},{"estimated_genres",genres},{"musical_guide",musicalGuide},{"tempo_candidates",tempoCandidates}});
}
juce::Result Analysis::restore(const juce::var&v,Analysis&out){
    if(v.isVoid())return juce::Result::ok();
    if(!v.isObject())return juce::Result::fail("Invalid saved reference analysis");
    Analysis a;
    for(auto key:{"duration_seconds","bpm","tempo_confidence","key_confidence"})
        if(!number(v[key])||double(v[key])<0)return juce::Result::fail("Invalid saved reference value");
    a.duration=double(v["duration_seconds"]);a.bpm=double(v["bpm"]);a.tempoConfidence=double(v["tempo_confidence"]);a.keyConfidence=double(v["key_confidence"]);
    if(a.bpm>300||a.tempoConfidence>1||a.keyConfidence>1||!integer(v["tonic"])||int(v["tonic"])<-1||int(v["tonic"])>11)return juce::Result::fail("Invalid saved reference range");
    a.tonic=int(v["tonic"]);a.minor=bool(v["minor"]);a.frames=juce::int64(v["source_frames"]);a.analysedFrames=juce::int64(v["analysed_frames"]);
    if(a.frames<0||a.analysedFrames<0||a.analysedFrames>a.frames)return juce::Result::fail("Invalid saved reference frames");
    if(auto*levels=v["energy_per_second"].getArray()){if(levels->size()>86400)return juce::Result::fail("Saved reference is too large");for(auto&e:*levels){if(!number(e)||double(e)<0)return juce::Result::fail("Invalid reference energy");a.energy.push_back(double(e));}}
    a.musicalGuide=v["musical_guide"].clone();a.tempoCandidates=v["tempo_candidates"].clone();
    if(auto*values=v["estimated_genres"].getArray())for(auto&g:*values)a.genres.add(g.toString());
    if(auto*values=v["timbres"].getArray()){if(values->size()>4096)return juce::Result::fail("Too many saved reference timbres");for(auto&h:*values){Hit hit;hit.category=h["category"].toString();hit.time=double(h["time"]);hit.confidence=float(h["confidence"]);hit.features=fromJson(h["features"]);a.timbres.push_back(std::move(hit));}}
    out=std::move(a);return juce::Result::ok();
}
juce::Result analyseWholeFile(const juce::File&file,Analysis&output,const std::function<bool()>&cancel,const std::function<void(double)>&progress){
    try{
        juce::AudioFormatManager fm;registerFormats(fm);std::unique_ptr<juce::AudioFormatReader>reader(fm.createReaderFor(ioFile(file)));
        require(reader&&reader->sampleRate>=8000&&reader->sampleRate<=384000&&reader->lengthInSamples>0&&reader->numChannels>0,"Cannot decode reference or loop");
        ReferencePulse pulse;referenceMusic::Evidence evidence;tempo_detail::DrumEventSource beatSource;
        Analysis a;a.frames=reader->lengthInSamples;a.duration=a.frames/reader->sampleRate;beatSource.end=a.duration;
        // Every source frame is read. Memory is bounded to a 20-second context,
        // regardless of reference duration. No selected-region or first-minute shortcut.
        const int chunk=int(reader->sampleRate*20);juce::AudioBuffer<float>raw(2,chunk);
        std::array<double,12>chroma{};int chromaFrames=0;juce::dsp::FFT fft(12);std::array<float,8192>frame{};
        std::map<int,double>tempoVotes;double tempoWeight=0;double secondEnergy=0;juce::int64 secondFrames=0,nextSecond=juce::int64(reader->sampleRate);Neural classifier;
        auto remember=[&](Hit hit){std::vector<size_t>same;for(size_t i=0;i<a.timbres.size();++i)if(a.timbres[i].category==hit.category)same.push_back(i);if(same.size()<12)a.timbres.push_back(std::move(hit));else{auto index=*std::min_element(same.begin(),same.end(),[&](size_t l,size_t r){return a.timbres[l].confidence<a.timbres[r].confidence;});if(hit.confidence>a.timbres[index].confidence)a.timbres[index]=std::move(hit);}};
        for(juce::int64 start=0;start<a.frames;start+=chunk){
            require(!(cancel&&cancel()),"Cancelled");int count=int(std::min<juce::int64>(chunk,a.frames-start));raw.clear();if(!reader->read(&raw,0,count,start,true,true))throw std::runtime_error(("Reference decoding failed before the end of the file: "+decoderError()).toStdString());
            int chosen=0;if(reader->numChannels>1&&raw.getRMSLevel(1,0,count)>raw.getRMSLevel(0,0,count))chosen=1;
            const auto*mono=raw.getReadPointer(chosen);
            for(int i=0;i<count;++i){float v=mono[i];require(std::isfinite(v),"Reference contains invalid samples");secondEnergy+=double(v)*v;++secondFrames;if(start+i+1>=nextSecond){a.energy.push_back(std::sqrt(secondEnergy/std::max<juce::int64>(1,secondFrames)));secondEnergy=0;secondFrames=0;nextSecond=juce::int64((a.energy.size()+1)*reader->sampleRate);}}
            std::vector<float>audio(size_t(std::ceil(count*analysisRate/reader->sampleRate)));
            for(size_t i=0;i<audio.size();++i){double position=i*reader->sampleRate/analysisRate;int left=std::min(count-1,int(position)),right=std::min(count-1,left+1);audio[i]=mono[left]+float(position-left)*(mono[right]-mono[left]);}
            pulse.append(audio);
            auto separated=separate(audio);
            auto tempo=estimateTempo(separated.percussive);if(tempo.bpm>0&&tempo.confidence>0){double weight=tempo.confidence*count/reader->sampleRate;tempoVotes[int(std::round(tempo.bpm))]+=weight;tempoWeight+=weight;}
            auto attacks=onsets(separated.percussive);
            for(auto attack:attacks){
                require(!(cancel&&cancel()),"Cancelled");frame.fill(0);int available=std::min(2048,int(separated.percussive.size())-attack);double peak=0;
                for(int i=0;i<available;++i){float value=separated.percussive[size_t(attack+i)];peak=std::max(peak,double(std::abs(value)));frame[size_t(i)]=value*float(.5-.5*std::cos(juce::MathConstants<double>::twoPi*i/2047));}
                if(peak<1e-5)continue;require(beatSource.events.size()<100000,"Reference has too many rhythmic events");beatSource.events.push_back({start/reader->sampleRate+attack/analysisRate,1.,peak});fft.performFrequencyOnlyForwardTransform(frame.data());double low=0,mid=0,high=0,total=1e-16;
                for(int k=4;k<2048;++k){double hz=k*analysisRate/4096,value=double(frame[size_t(k)])*frame[size_t(k)];total+=value;if(hz<180)low+=value;else if(hz<2500)mid+=value;else if(hz>4000)high+=value;}
                low/=total;mid/=total;high/=total;int lane=low>.72&&high<.12?0:high>.72&&low<.08?2:mid>.45&&high>.2&&low<.2?1:-1;
                if(lane>=0){require(evidence.attacks.size()<250000,"Reference has too many transient events");evidence.attacks.push_back({start/reader->sampleRate+attack/analysisRate,std::min(1.,peak),lane});}
            }
            // Sample timbre candidates across each complete context, not just its
            // opening transient. These are estimates, not isolated ground-truth stems.
            const size_t stride=std::max<size_t>(1,(attacks.size()+7)/8);
            for(size_t j=0;j<attacks.size();j+=stride){require(!(cancel&&cancel()),"Cancelled");size_t begin=size_t(attacks[j]),end=std::min(separated.percussive.size(),begin+size_t(analysisRate*.35));if(end<=begin+220)continue;std::vector<float>cut(separated.percussive.begin()+begin,separated.percussive.begin()+end);auto features=describe(cut);if(features.peak<1e-5f)continue;auto category=classify({},features,cut.size()/analysisRate,{}).category;float confidence=.12f;if(classifier.available()){auto estimate=classifier.analyse(cut);features.embedding=std::move(estimate.embedding);for(auto&v:estimate.instruments)if(isDrum(v.first)&&v.second>confidence){category=v.first;confidence=v.second;}}if(isDrum(category))remember({start/reader->sampleRate+begin/analysisRate,category,features,confidence});}
            if(classifier.available()){auto estimate=classifier.analyse(separated.harmonic);auto features=describe(separated.harmonic);features.embedding=std::move(estimate.embedding);for(auto&v:estimate.instruments)if(!isDrum(v.first)&&v.second>=.3f)remember({start/reader->sampleRate,v.first,features,v.second});auto style=classifier.analyse(audio);for(auto&g:style.genres)a.genres.addIfNotAlreadyThere(g);}
            for(size_t pos=0;pos+4096<=audio.size();pos+=2048){
                frame.fill(0);for(int i=0;i<4096;++i)frame[size_t(i)]=separated.harmonic[pos+size_t(i)]*float(.5-.5*std::cos(juce::MathConstants<double>::twoPi*i/4095));fft.performFrequencyOnlyForwardTransform(frame.data());
                double sum=0;std::array<double,12>local{};float maximum=0;for(int k=10;k<380;++k)maximum=std::max(maximum,frame[size_t(k)]);
                for(int k=10;k<380;++k){double left=frame[size_t(k-1)],centre=frame[size_t(k)],right=frame[size_t(k+1)];if(centre<maximum*.03||centre<=left||centre<right)continue;double denominator=left-2*centre+right,offset=denominator< -1e-12?juce::jlimit(-.5,.5,.5*(left-right)/denominator):0;double hz=(k+offset)*analysisRate/4096,midi=69+12*std::log2(hz/440);int note=int(std::round(midi));double value=std::pow(centre,.7)*std::max(0.,1-2*std::abs(midi-note));local[size_t((note%12+12)%12)]+=value;sum+=value;}
                if(sum>1e-6){double time=start/reader->sampleRate+(pos+2048)/analysisRate;int slot=int(time*2);if(evidence.tonal.empty()||int(evidence.tonal.back().time*2)!=slot){require(evidence.tonal.size()<500000,"Reference harmonic detail exceeds the analysis budget");evidence.tonal.push_back({slot*.5,{}});}for(int i=0;i<12;++i){chroma[size_t(i)]+=local[size_t(i)]/sum;evidence.tonal.back().chroma[size_t(i)]+=local[size_t(i)]/sum;}++chromaFrames;}
            }
            a.analysedFrames+=count;if(progress)progress(double(a.analysedFrames)/a.frames);
        }
        if(secondFrames)a.energy.push_back(std::sqrt(secondEnergy/secondFrames));
        double best=0;int winner=0;for(auto&v:tempoVotes){double sum=0;for(auto&w:tempoVotes)if(std::abs(v.first-w.first)<=2)sum+=w.second;if(sum>best){best=sum;winner=v.first;}}
        if(winner){double weighted=0,weights=0;for(auto&v:tempoVotes)if(std::abs(v.first-winner)<=2){weighted+=v.first*v.second;weights+=v.second;}a.bpm=weighted/weights;a.tempoConfidence=best/std::max(tempoWeight,1e-9);}
        tempo_detail::ReferenceTempo wholeTempo;if(tempo_detail::estimateReferenceTempo(beatSource,0,a.duration,0,wholeTempo).wasOk()){
            if(a.bpm<=0){a.bpm=wholeTempo.bpm;a.tempoConfidence=wholeTempo.score;}juce::Array<juce::var>candidates;candidates.add(object({{"bpm",a.bpm},{"support",1.}}));if(std::abs(a.bpm-wholeTempo.bpm)>1)candidates.add(object({{"bpm",wholeTempo.bpm},{"support",wholeTempo.score}}));for(auto&candidate:wholeTempo.alternatives)candidates.add(object({{"bpm",candidate.bpm},{"support",candidate.relativeSupport}}));a.tempoCandidates=candidates;
        }
        // Only choose a pulse also supported by the independent onset estimator.
        double perceived=pulse.estimate(cancel);double nearest=1.5;juce::var selectedTempo;
        if(auto*choices=a.tempoCandidates.getArray())for(auto&candidate:*choices){double delta=std::abs(perceived-double(candidate["bpm"]));if(double(candidate["support"])>=.75&&delta<nearest){nearest=delta;selectedTempo=candidate;}}
        if(selectedTempo.isObject())a.bpm=double(selectedTempo["bpm"]);
        auto key=estimateReferenceKey(chroma,chromaFrames);a.tonic=key.tonic;a.minor=key.minor;a.keyConfidence=key.confidence;
        a.musicalGuide=referenceMusic::build(evidence,a.bpm,a.duration,a.energy);a.musicalEvidence=std::move(evidence);
        require(a.analysedFrames==a.frames,"Incomplete reference analysis");output=std::move(a);return juce::Result::ok();
    }catch(const std::exception&e){return juce::Result::fail(juce::String::fromUTF8(e.what()));}
}

juce::Result planProject(const Request&r,const Analysis&a,const juce::var&plan,music::Project&output,juce::StringArray&notices){
    try{
        require(plan.isObject(),"AI returned no composition plan");auto registry=music::ProfileRegistry::builtIn();
        auto genre=plan["genre"].toString();bool supported=false;for(auto&g:registry.genres())if(g.id==genre)supported=true;
        require(supported,"AI selected an unknown base genre; retry with a catalog genre");
        auto requested=r.genre.trim();
        if(requested.isEmpty()&&plan["requested_style"].isString())requested=plan["requested_style"].toString().trim();
        // The model sometimes echoes the entire brief here. The base genre is
        // already validated; the rhythm and arrangement are separate fields.
        if(requested.isEmpty()||requested.length()>128)requested=genre;
        bool custom=true;for(auto&g:registry.genres())if(g.id.equalsIgnoreCase(requested)){custom=false;requested=g.id;break;}
        if(custom||plan["style_pattern"].isObject()){
            auto pattern=plan["style_pattern"];require(pattern.isObject(),"AI must provide a custom rhythm for the requested style; retry");
            auto encoded=registry.encode();juce::var customProfile;for(auto&g:*encoded["genres"].getArray())if(g["id"].toString()==genre){customProfile=g.clone();break;}
            auto*profile=customProfile.getDynamicObject();require(profile!=nullptr,"Custom profile base missing");genre=requested;profile->setProperty("id",genre);profile->setProperty("revision","ai-custom-1");
            for(auto key:{"kick","snare","hat"}){auto values=pattern[key];require(values.isArray()&&values.size()==16,"Custom style needs 16-step rhythm distributions");for(auto&v:*values.getArray())require(number(v)&&double(v)>=0&&double(v)<=1,"Invalid custom rhythm probability");profile->setProperty(key,values.clone());}
            require(number(pattern["swing"])&&double(pattern["swing"])>=0&&double(pattern["swing"])<=1,"Invalid custom swing");profile->setProperty("swing",pattern["swing"]);profile->setProperty("bpm_min",30);profile->setProperty("bpm_max",300);profile->setProperty("tags",juce::StringArray{genre,"AI custom style"});
            auto* profiles=encoded["genres"].getArray();for(int i=profiles->size();--i>=0;)if((*profiles)[i]["id"].toString()==genre)profiles->remove(i);profiles->add(customProfile);checked(registry.decode(encoded));notices.add("Custom style: "+genre+". AI-generated rhythm saved with this song; genre authenticity still requires listening.");
        }else if(r.genre.isNotEmpty()&&!genre.equalsIgnoreCase(r.genre))notices.add("Requested style: "+r.genre+"; selected profile: "+genre);
        music::Settings settings;settings.genre=genre;settings.mood=plan["mood"].toString();bool mood=false;for(auto&m:registry.moods())if(m.id==settings.mood)mood=true;require(mood,"Invalid AI mood");
        require(number(plan["bpm"])&&double(plan["bpm"])>=30&&double(plan["bpm"])<=300,"AI tempo must be between 30 and 300");settings.bpm=double(plan["bpm"]);
        if(a.bpm>0&&r.reference!=juce::File()){
            bool supportedTempo=std::abs(settings.bpm-a.bpm)<=1;
            if(auto*candidates=a.tempoCandidates.getArray())for(auto&candidate:*candidates)if(double(candidate["support"])>=.65&&std::abs(settings.bpm-double(candidate["bpm"]))<=1){settings.bpm=double(candidate["bpm"]);supportedTempo=true;break;}
            if(!supportedTempo)settings.bpm=a.bpm;
            if(a.tempoCandidates.size()>1)notices.add("Reference pulse has alternative beat levels; selected "+juce::String(settings.bpm,1)+" BPM from measured candidates.");
        }
        require(integer(plan["tonic"])&&int(plan["tonic"])>=0&&int(plan["tonic"])<=11,"Invalid AI tonic");settings.tonic=int(plan["tonic"]);settings.scale=plan["scale"].toString();require(settings.scale=="minor"||settings.scale=="major","Use a major or minor scale");
        if(a.tonic>=0&&r.reference!=juce::File()){settings.tonic=a.tonic;settings.scale=a.minor?"minor":"major";if(a.keyConfidence<.3)notices.add("Reference key is uncertain; the detected key is a starting point.");}
        for(auto field:std::initializer_list<std::pair<const char*,double*>>{{"energy",&settings.energy},{"density",&settings.density},{"complexity",&settings.complexity},{"darkness",&settings.darkness},{"groove",&settings.groove},{"melodic_density",&settings.melodicDensity}}){require(number(plan[field.first])&&double(plan[field.first])>=0&&double(plan[field.first])<=1,juce::String("Invalid AI value: ")+field.first);*field.second=double(plan[field.first]);}
        settings.seed=uint32_t(juce::Random::getSystemRandom().nextInt());settings.bars=16;settings.activeRoles.clear();auto roles=plan["roles"].getArray();require(roles&&!roles->isEmpty()&&roles->size()<=11,"AI must select 1 to 11 musical roles");auto allowed=music::generationRoles();for(auto&role:*roles){require(role.isString()&&allowed.contains(role.toString()),"Invalid AI track role");settings.activeRoles.addIfNotAlreadyThere(role.toString());}
        checked(music::generateStyled(settings,registry,{{genre,1}},{{settings.mood,1}},output));
        music::HarmonyOptions harmony;harmony.progression=music::suggestHarmony(settings,0);if(plan.hasProperty("progression")&&plan["progression"].toString().trim().isNotEmpty()){auto progression=plan["progression"].toString();require(progression.length()<=256,"Chord progression is too long");std::vector<music::ChordSpec>chords;checked(music::parseChords(progression,chords));harmony.progression=progression;}harmony.chords=settings.activeRoles.contains("Chords");harmony.bass=settings.activeRoles.contains("Bass");harmony.melody=settings.activeRoles.contains("Melody");harmony.phraseMelody=true;if(harmony.chords||harmony.bass||harmony.melody)checked(music::applyHarmony(output,harmony));
        std::vector<music::SongSection>sections;auto rows=plan["sections"].getArray();require(rows&&rows->size()>0&&rows->size()<=32,"AI must provide song sections");
        int total=0;const juce::StringArray names{"Intro","Verse","Chorus","Bridge","Outro","Drop","Breakdown","Build"};
        for(auto&row:*rows){auto name=row["name"].toString();require(names.contains(name)&&integer(row["bars"])&&int(row["bars"])>=1&&int(row["bars"])<=64,"Invalid AI song section");int bars=int(row["bars"]);require(total+bars<=4096,"Composition exceeds 4096 bars; choose a shorter arrangement");sections.push_back({name,bars,31,false,(name=="Chorus"||name=="Drop")?8:0,8});total+=bars;}
        if(r.reference!=juce::File()){
            const int target=std::max(1,int(std::ceil(a.duration*settings.bpm/240)));require(target<=4096,"The complete reference exceeds the current 4096-bar arrangement capacity; it was analysed in full but has not been truncated into a song");
            // Fit the complete reference without stretching every phrase into
            // odd lengths (e.g. 16 -> 13 bars). Only the ending may be partial.
            if(target>=int(sections.size())*4){
                const int units=target/4;std::vector<int> allocation(sections.size(),1);int assigned=int(sections.size());
                while(assigned<units){size_t best=0;double deficit=-1.e9;for(size_t i=0;i<sections.size();++i){double d=double(sections[i].bars)*units/total-allocation[i];if(d>deficit){deficit=d;best=i;}}++allocation[best];++assigned;}
                for(size_t i=0;i<sections.size();++i)sections[i].bars=4*allocation[i];sections.back().bars+=target%4;
            }else{
                int previous=0,original=0;for(auto& section:sections){original+=section.bars;int boundary=int(std::llround(double(original)*target/total));section.bars=boundary-previous;previous=boundary;}
            }
            notices.add("Full reference analysed. Arrangement labels are suggestions, not a verified transcription.");
        }
        checked(applyHook(output,plan["hook"],std::any_of(sections.begin(),sections.end(),[](const auto& s){return s.name=="Chorus"||s.name=="Drop";})));
        checked(music::buildArrangement(output,0,8,sections));output.hatChoke=true;
        // Full-mixture transient detection has no reliable source identity.
        // Keep it as planner evidence, never overwrite the written drum part.
        if(r.reference!=juce::File())checked(referenceMusic::apply(output,a.musicalEvidence.tonal.empty()?a.musicalGuide:referenceMusic::build(a.musicalEvidence,settings.bpm,a.duration,a.energy),notices,false));
        int sectionStart=0,markerIndex=0;const auto barTicks=music::barTicks(output.settings);
        for(size_t i=0;i<sections.size();++i){
            if(sections[i].bars==0)continue;auto& marker=output.sections.getArray()->getReference(markerIndex++);const auto& active=(*rows)[int(i)]["active_roles"];auto end=sectionStart+sections[i].bars;
            if(auto* list=active.getArray()){
                marker.getDynamicObject()->setProperty("active_roles",active.clone());require(!list->isEmpty(),"Section needs at least one active role");juce::StringArray heard;
                for(auto& role:*list){require(settings.activeRoles.contains(role.toString()),"Section specifies an unselected role");heard.add(role.toString());}
                for(auto& t:output.tracks)if(!heard.contains(t.role)){
                    auto inside=[&](const auto& event){return event.tick>=sectionStart*barTicks&&event.tick<end*barTicks;};
                    t.notes.erase(std::remove_if(t.notes.begin(),t.notes.end(),inside),t.notes.end());
                    t.controls.erase(std::remove_if(t.controls.begin(),t.controls.end(),inside),t.controls.end());
                }
            }
            sectionStart=end;
        }
        groove::arrange(output,plan["style_pattern"],notices);
        // Preserve the written syncopation while removing small, late offsets
        // from a generated answering phrase. Drums retain their own swing.
        const auto grid=barTicks/16;
        const auto lateLimit=std::min<int64_t>(grid/4,std::llround(music::ppq*settings.bpm*.020/60.));
        for(auto& track:output.tracks)if(track.role=="Countermelody"){
            for(auto& note:track.notes){
                const auto onset=note.tick+note.microtiming;
                const auto anchor=(onset/grid)*grid;
                if(onset-anchor<=lateLimit && anchor/barTicks==note.tick/barTicks){
                    note.tick=anchor;note.microtiming=0;
                }
            }
        }
        auto assignments=plan["instruments"].getArray();if(assignments)for(auto&row:*assignments){require(integer(row["index"]),"Invalid instrument choice");int index=int(row["index"]);require(index>=0&&index<r.instruments.size(),"AI requested an instrument outside the allowed list");auto role=row["role"].toString();auto track=std::find_if(output.tracks.begin(),output.tracks.end(),[&](const auto&t){return t.role==role;});require(track!=output.tracks.end(),"Instrument assigned to a missing track");if(r.instruments[index]["format"].toString()=="Live"){auto name=r.instruments[index]["name"].toString();require(music::validLiveDevice(name),"Unsupported Live instrument");track->liveDevice=name;}else track->instrument=r.instruments[index].clone();}
        return juce::Result::ok();
    }catch(const std::exception&e){return juce::Result::fail(juce::String::fromUTF8(e.what()));}
}

namespace {
// A loop is a phrase. Trigger it once per phrase, and only across bars where
// the arrangement actually calls for percussion.
bool assignPercussionLoop(music::Project& p,music::Track& track,const std::vector<Sample>& library,juce::StringArray& notices,const juce::File& alignedLoops,const std::function<bool()>& cancel){
    if(track.role!="Percussion" || track.notes.empty() || track.midiLocked || track.soundLocked || !p.tempos.empty())return false;
    const auto ticks=music::barTicks(p.settings);
    const double seconds=double(ticks)/music::ppq*60./p.settings.bpm;
    std::vector<int> hits(size_t(p.settings.bars),0);
    for(const auto& note:track.notes)if(music::playsNote(p.settings.seed,note))++hits[size_t(note.tick/ticks)];
    if(std::none_of(hits.begin(),hits.end(),[](int count){return count>0;}))return false;
    int runFactor=4;
    for(size_t i=0;i<hits.size();){
        if(!hits[i]){++i;continue;}
        auto first=i;while(i<hits.size()&&hits[i])++i;
        runFactor=std::gcd(runFactor,int(i-first));
    }
    std::vector<std::pair<double,const Sample*>> candidates;
    for(const auto& sample:library){
        if(sample.kind!="Loop"||sample.error.isNotEmpty()||sample.duration<=0||sample.duration>30)continue;
        if(sample.category!="Shaker"&&sample.category!="Tambourine"&&sample.category!="Percussion")continue;
        const auto bars=juce::roundToInt(sample.duration/seconds);
        if(bars!=1&&bars!=2&&bars!=4)continue;
        if(alignedLoops==juce::File()?std::abs(sample.duration-bars*seconds)>.012:std::abs(sample.duration/(bars*seconds)-1.)>.05)continue;
        // Exclude full drum kits and bass-heavy loops from this texture lane.
        const auto& f=sample.features;
        double low=0;for(int i=0;i<4;++i)low+=f.bands[size_t(i)]*f.bands[size_t(i)];
        if(f.peak<.01||low>.15||f.centroid<1100)continue;
        if(runFactor%bars!=0)continue;
        double rank=1.-low+std::min(.5,double(f.flatness))+
            .05*double(uint32_t(sample.path.hashCode())^p.settings.seed)/4294967296.;
        candidates.emplace_back(rank,&sample);
    }
    const size_t limit=std::min<size_t>(12,candidates.size());
    std::partial_sort(candidates.begin(),candidates.begin()+limit,candidates.end(),[](auto&a,auto&b){return a.first>b.first;});
    juce::AudioFormatManager fm;registerFormats(fm);
    for(size_t i=0;i<limit;++i){
        const auto& sample=*candidates[i].second;
        std::unique_ptr<juce::AudioFormatReader> reader(fm.createReaderFor(ioFile(juce::File(sample.path))));
        if(!reader||reader->numChannels<1||reader->numChannels>2)continue;
        reader.reset();
        auto decoded=decode(fm,juce::File(sample.path),0,30);
        if(decoded.error.isNotEmpty()||std::abs(decoded.duration-sample.duration)>.012)continue;
        const auto attacks=onsets(decoded.mono);
        const int bars=juce::roundToInt(sample.duration/seconds);
        const double grid=sample.duration/(bars*16.);
        int aligned=0;
        for(auto onset:attacks){double phase=onset/(analysisRate*grid);if(std::abs(phase-std::round(phase))<.25)++aligned;}
        if(int(attacks.size())<bars*3||aligned<int(std::ceil(.65*attacks.size())))continue;
        std::vector<music::Note> triggers;
        for(size_t bar=0;bar<hits.size();){
            if(!hits[bar]){++bar;continue;}
            auto n=track.notes.front();n.id=juce::Uuid().toString();n.tick=int64_t(bar)*ticks;
            n.duration=bars*ticks;n.microtiming=0;n.probability=1;n.velocity=76;
            triggers.push_back(n);bar+=bars;
        }
        juce::File audio(sample.path);
        if(alignedLoops!=juce::File()&&std::abs(sample.duration-bars*seconds)>1./44100.){
            checked(alignedLoops.createDirectory());
            const double sourceBpm=bars*240./sample.duration;
            audio=renderAudioEdit({audio,0,sourceBpm,p.settings.bpm},alignedLoops,cancel);
        }
        track.notes=std::move(triggers);track.soundPath=audio.getFullPathName();
        notices.add("Percussion loop: "+juce::File(sample.path).getFileName()+" ("+juce::String(bars)+" bars)");
        return true;
    }
    return false;
}
}

juce::Result selectSamples(music::Project&p,const std::vector<Sample>&samples,bool withLoop,juce::StringArray&notices,const std::vector<Hit>&reference,bool allowPercussionLoop,const juce::File& alignedLoops,const std::function<bool()>& cancel){
    juce::StringArray missing;
    for(auto&t:p.tracks){if(!t.instrument.isVoid()||t.liveDevice.isNotEmpty())continue;
        if(withLoop&&(t.role=="Chords"||t.role=="Melody"||t.role=="Countermelody")){t.notes.clear();continue;}
        if(allowPercussionLoop&&!withLoop&&assignPercussionLoop(p,t,samples,notices,alignedLoops,cancel))continue;
        std::vector<int64_t> spacings;
        for(size_t i=1;i<t.notes.size();++i){auto dt=t.notes[i].tick-t.notes[i-1].tick;if(dt>0)spacings.push_back(dt);}
        double spacing=60./p.settings.bpm;
        if(!spacings.empty()){
            const auto mid=spacings.begin()+spacings.size()/2;
            std::nth_element(spacings.begin(),mid,spacings.end());
            spacing=*mid*60./(music::ppq*p.settings.bpm);
        }
        const Sample*best=nullptr;std::vector<std::pair<double,const Sample*>>candidates;
        for(const auto&s:samples){if(s.error.isNotEmpty()||s.kind!="One-shot"||s.duration<=0||s.duration>30)continue;
            bool matches=s.category==t.role||(t.role=="Chords"&&(s.category=="Piano"||s.category=="Keys"||s.category=="Synth"||s.category=="Guitar"))||((t.role=="Melody"||t.role=="Countermelody")&&(s.category=="Synth"||s.category=="Keys"||s.category=="Piano"||s.category=="Guitar"||s.category=="Strings"));if(!matches)continue;
            if(t.role=="Closed Hat"){
                const auto tokens=juce::StringArray::fromTokens(juce::File(s.path).getFileNameWithoutExtension().toLowerCase()," _-.()[]", {});
                if(tokens.contains("open")||tokens.contains("openhat")||tokens.contains("oh"))continue;
            }
            double rank=.2*double(uint32_t(s.path.hashCode())^p.settings.seed)/4294967296.;
            // Prefer sounds that leave room for the next hit. Use the audible
            // envelope, since files can contain long stretches of digital silence.
            const auto& f=s.features;
            const double length=f.duration>0?f.duration:s.duration;
            if(t.role=="Kick"||t.role=="Snare"||t.role=="Clap"||t.role=="Closed Hat")
                rank-=2.*std::max(0.,std::log2(std::max(.001,length)/std::max(.04,spacing)));
            if(f.peak>0){
                if(t.role=="Kick"||t.role=="Bass")for(int i=0;i<3;++i)rank+=f.bands[size_t(i)]*f.bands[size_t(i)];
                if(t.role=="Closed Hat"||t.role=="Open Hat")rank+=std::min(1.,f.centroid/6500.);
                if(t.role=="Closed Hat"||t.role=="Snare")rank-=std::min(1.,double(f.tail));
            }
            if(t.role=="Closed Hat")rank-=std::max(0.,length-30./p.settings.bpm)*12.;
            float nearest=1e6f;for(auto&hit:reference)if(hit.category==s.category)nearest=std::min(nearest,referenceDistance(hit.features,s.features,s.category));if(nearest<1e6f)rank+=30./(1+std::max(0.f,nearest)*5);
            if(candidates.size()<12||rank>candidates.back().first){candidates.emplace_back(rank,&s);std::stable_sort(candidates.begin(),candidates.end(),[](auto&a,auto&b){return a.first>b.first;});if(candidates.size()>12)candidates.pop_back();}
        }
        for(auto&candidate:candidates){if(!ioFile(juce::File(candidate.second->path)).existsAsFile())continue;if(music::gmDrumNote(t.role)<0&&t.role!="FX"){int root=sampleRoot(*candidate.second);if(root<0)continue;t.sampleRoot=root;}best=candidate.second;break;}
        if(best){t.soundPath=best->path;}
        else {missing.add(t.role);t.notes.clear();}
    }
    if(!missing.isEmpty())notices.add("No suitable library sound or selected instrument for: "+missing.joinIntoString(", ")+". These tracks were omitted; no substitute synthesizer was used.");
    p.tracks.erase(std::remove_if(p.tracks.begin(),p.tracks.end(),[](auto&t){return t.notes.empty();}),p.tracks.end());
    // Apply arrangement density only after we know which sounds are available.
    // Otherwise a drum-only library could produce completely silent intros.
    if(auto*sections=p.sections.getArray())for(auto&section:*sections){auto name=section["name"].toString();if(section.hasProperty("active_roles"))continue;bool gentle=name=="Intro"||name=="Outro"||name=="Bridge"||name=="Breakdown";if(!gentle)continue;
        juce::StringArray keep;for(auto&t:p.tracks)if(music::gmDrumNote(t.role)<0)keep.add(t.id);for(auto&t:p.tracks)if(t.role=="Closed Hat"||t.role=="Percussion")keep.add(t.id);if(keep.isEmpty())for(auto&t:p.tracks)keep.add(t.id);
        auto begin=juce::int64(int(section["start"]))*music::barTicks(p.settings),end=begin+juce::int64(int(section["bars"]))*music::barTicks(p.settings);
        for(auto&t:p.tracks){if(!keep.contains(t.id))t.notes.erase(std::remove_if(t.notes.begin(),t.notes.end(),[&](auto&n){return n.tick>=begin&&n.tick<end;}),t.notes.end());else for(auto&n:t.notes)if(n.tick>=begin&&n.tick<end)n.velocity=std::max(1,int(n.velocity*.78));}
    }
    return p.tracks.empty()?juce::Result::fail("No usable sounds. Scan sample folders or allow a VST instrument first."):music::validate(p);
}

juce::Result applyEdits(const music::Project&base,const juce::var&plan,music::Project&output,bool hasLoop,const std::map<juce::String,music::Track>&assets){
    try{
        auto operations=plan["operations"].getArray();require(operations&&!operations->isEmpty()&&operations->size()<=16,"No supported edit was requested. Ask to remove, vary, transpose, change velocity or change tempo.");
        auto next=base;next.sections=base.sections.clone();int operationIndex=0;
        for(auto&op:*operations){
            auto prepared=assets.find(juce::String(operationIndex++));
            auto action=op["action"].toString(),id=op["track"].toString();
            require(number(op["amount"])&&integer(op["first_bar"])&&integer(op["end_bar"]),"Invalid edit values");
            const double amount=double(op["amount"]);int first=int(op["first_bar"]),end=int(op["end_bar"]);
            require(first>=0&&end>first&&end<=next.settings.bars,"Edit bar range is outside the song");
            if(action=="add_track"){
                require(id.isEmpty()&&prepared!=assets.end(),"New track sound is not prepared");auto track=prepared->second;require(music::generationRoles().contains(track.role)&&track.role==op["role"].toString(),"Invalid new track role");
                track.notes.erase(std::remove_if(track.notes.begin(),track.notes.end(),[&](auto&n){return n.tick<first*music::barTicks(next.settings)||n.tick>=end*music::barTicks(next.settings);}),track.notes.end());next.settings.activeRoles.addIfNotAlreadyThere(track.role);next.tracks.push_back(std::move(track));continue;
            }
            if(action=="rename_section"){
                auto name=op["section_name"].toString().trim();require(name.isNotEmpty()&&name.length()<=64,"Invalid section name");bool found=false;if(auto*sections=next.sections.getArray())for(auto&section:*sections)if(int(section["start"])==first&&int(section["bars"])==end-first){section.getDynamicObject()->setProperty("name",name);found=true;}require(found,"Choose one complete section to rename");continue;
            }
            if(action=="duplicate_section"||action=="delete_section"){
                require(operations->size()==1,"Change section positions in a separate message before editing other parts");require(!hasLoop,"Section editing with a source audio loop requires audio clip editing");auto destination=op.hasProperty("destination_bar")?op["destination_bar"]:op["amount"];require(number(destination)&&double(destination)==std::floor(double(destination)),"Section destination must be a bar boundary");checked(spliceArrangement(next,first,end,action=="duplicate_section"?int(destination):0,action=="duplicate_section"));continue;
            }
            if(action=="tempo"){
                require(id.isEmpty()&&first==0&&end==next.settings.bars&&amount>=30&&amount<=300,"Tempo must apply to the whole song (30..300)");
                require(!hasLoop,"Tempo editing with an audio loop is not supported yet; the existing beat was preserved");
                require(next.tempos.empty(),"Edit the tempo map separately");next.settings.bpm=amount;continue;
            }
            auto track=std::find_if(next.tracks.begin(),next.tracks.end(),[&](const auto&t){return t.id==id;});
            require(track!=next.tracks.end(),"Edit refers to a missing track");
            if(action=="replace_sound"||action=="add_effect"||action=="remove_effect"){
                require(!track->soundLocked,"Track sound is locked");require(first==0&&end==next.settings.bars,"Sound and effect changes apply to the whole track");
                if(action=="replace_sound"){require(prepared!=assets.end(),"Replacement sound is not prepared");auto&sound=prepared->second;track->soundPath=sound.soundPath;track->sampleRoot=sound.sampleRoot;track->instrument=sound.instrument.clone();track->liveDevice=sound.liveDevice;require(track->liveDevice.isEmpty()||track->effects.isVoid()||track->effects.size()==0,"Remove local effects before switching to a native Live instrument");}
                else{require(track->liveDevice.isEmpty(),"Native Live effects must be configured through the bridge");juce::Array<juce::var>chain;if(auto*current=track->effects.getArray())chain=*current;
                    if(action=="add_effect"){require(prepared!=assets.end()&&prepared->second.effects.size()==1&&chain.size()<8,"Effect is not prepared or chain is full");chain.add(prepared->second.effects[0].clone());}
                    else{require(amount==std::floor(amount)&&amount>=0&&amount<chain.size(),"Invalid effect position");chain.remove(int(amount));}track->effects=chain;
                }continue;
            }
            require(!track->midiLocked,"Track MIDI is locked");
            auto from=first*music::barTicks(next.settings),to=end*music::barTicks(next.settings);
            if(action=="remove"){
                if(first==0&&end==next.settings.bars){require(!track->soundLocked,"Track sound is locked");next.tracks.erase(track);}
                else{track->notes.erase(std::remove_if(track->notes.begin(),track->notes.end(),[&](const auto&n){return n.tick>=from&&n.tick<to;}),track->notes.end());track->controls.erase(std::remove_if(track->controls.begin(),track->controls.end(),[&](const auto&c){return c.tick>=from&&c.tick<to;}),track->controls.end());}
            }else if(action=="regenerate"){
                checked(music::regenerate(next,id,first,end,uint32_t(juce::Random::getSystemRandom().nextInt())));
            }else if(action=="transpose"){
                require(amount==std::floor(amount)&&amount>=-24&&amount<=24&&music::gmDrumNote(track->role)<0,"Transpose requires a pitched track and -24..24 semitones");
                for(auto&n:track->notes)if(n.tick>=from&&n.tick<to){require(n.pitch+amount>=0&&n.pitch+amount<=127,"Transposition exceeds MIDI range");n.pitch+=int(amount);}
            }else if(action=="velocity"){
                require(amount>=.1&&amount<=2,"Velocity multiplier must be 0.1..2");for(auto&n:track->notes)if(n.tick>=from&&n.tick<to)n.velocity=juce::jlimit(1,127,int(std::lround(n.velocity*amount)));
            }else require(false,"Unsupported edit action");
        }
        require(!next.tracks.empty(),"Keep at least one generated track");checked(music::validate(next));checked(music::verifyLockedContent(base,next));
        output=std::move(next);return juce::Result::ok();
    }catch(const std::exception&e){return juce::Result::fail(juce::String::fromUTF8(e.what()));}
}

juce::Result applyMidiChanges(const music::Project&base,const std::vector<MidiChange>&changes,music::Project&output){
    if(changes.empty()||changes.size()>4096)return juce::Result::fail("Apply between 1 and 4096 MIDI edits at a time");
    auto next=base;
    for(auto&change:changes){
        auto track=std::find_if(next.tracks.begin(),next.tracks.end(),[&](const auto&t){return t.id==change.track;});
        if(track==next.tracks.end()||track->midiLocked)return juce::Result::fail("Missing or locked MIDI track");
        auto note=std::find_if(track->notes.begin(),track->notes.end(),[&](const auto&n){return n.id==change.note.id;});
        if(change.kind==MidiChange::Insert){if(note!=track->notes.end()||change.note.id.isEmpty())return juce::Result::fail("Duplicate or empty note ID");track->notes.push_back(change.note);}
        else{if(note==track->notes.end())return juce::Result::fail("Note no longer exists");if(change.kind==MidiChange::Remove)track->notes.erase(note);else if(change.kind==MidiChange::Replace)*note=change.note;else return juce::Result::fail("Unknown MIDI edit");}
    }
    for(auto&t:next.tracks)std::stable_sort(t.notes.begin(),t.notes.end(),[](const auto&a,const auto&b){return a.tick<b.tick;});
    auto valid=music::validate(next);if(valid.failed())return valid;valid=music::verifyLockedContent(base,next);if(valid.failed())return valid;output=std::move(next);return juce::Result::ok();
}

Service::Service(Planner provider):juce::Thread("DrumAtlas composer"),planner(std::move(provider)){
    auto registry=juce::JSON::parse(dataDirectory().getChildFile("composer-instruments.json"));if(auto*rows=registry.getArray())state.instruments=*rows;auto fx=juce::JSON::parse(dataDirectory().getChildFile("composer-effects.json"));if(auto*rows=fx.getArray())state.effects=*rows;startThread();
}
Service::~Service(){cancel();signalThreadShouldExit();notify();stopThread(-1);}
State Service::snapshot(){std::lock_guard<std::mutex>lock(mutex);return state;}
void Service::setDraft(juce::var value){std::lock_guard<std::mutex>lock(mutex);state.draft=value.clone();}
void Service::setMidiDraft(juce::var value){std::lock_guard<std::mutex>lock(mutex);state.midiDraft=value.clone();}
void Service::report(const juce::String&s){std::lock_guard<std::mutex>lock(mutex);state.status=s;++state.revision;}
void Service::cancel(){stop=true;std::shared_ptr<LocalModelRequest>job;{std::lock_guard<std::mutex>lock(mutex);job=modelRequest;}if(job)job->cancel();}
bool Service::generate(Request r){std::lock_guard<std::mutex>lock(mutex);if(state.busy||(r.editExisting&&(!state.song||state.song->audioBeat)))return false;stop=false;pending=std::move(r);state.busy=true;state.error.clear();state.status="Preparing composition";++state.revision;notify();return true;}
void Service::commitSong(const std::shared_ptr<Song>&song){
    std::lock_guard<std::mutex>lock(mutex);if(state.song)past.push_back(state.song);future.clear();
    size_t bytes=0;size_t keep=0;for(auto it=past.rbegin();it!=past.rend()&&keep<8;++it){auto size=juce::JSON::toString(music::encode((*it)->project),true).getNumBytesAsUTF8();if(bytes+size>64u*1024u*1024u)break;bytes+=size;++keep;}
    past.erase(past.begin(),past.end()-std::ptrdiff_t(keep));state.song=song;state.midiDraft=juce::var();state.canUndo=!past.empty();state.canRedo=false;state.status="Composition ready";
}
bool Service::moveHistory(bool backwards){
    std::lock_guard<std::mutex>lock(mutex);auto&from=backwards?past:future;auto&to=backwards?future:past;if(state.busy||from.empty())return false;
    if(state.song)to.push_back(state.song);state.song=from.back();state.midiDraft=juce::var();from.pop_back();state.canUndo=!past.empty();state.canRedo=!future.empty();state.error.clear();state.status="Previous version restored in DrumAtlas; existing Live tracks are unchanged";++state.revision;return true;
}
bool Service::undo(){return moveHistory(true);}bool Service::redo(){return moveHistory(false);}
bool Service::changeMidi(const juce::String&id,std::vector<MidiChange>changes){Request r;r.midiBase=id;r.midiChanges=std::move(changes);r.prompt="Manual MIDI edit";return generate(std::move(r));}
bool Service::changeAudio(const juce::String&id,const AudioRegionEdit&edit){Request r;r.audioBase=id;r.audioEdit=edit;r.prompt="Audio region edit: "+edit.action;return generate(std::move(r));}
bool Service::scan(const juce::Array<juce::File>&roots){std::lock_guard<std::mutex>lock(mutex);if(state.busy)return false;stop=false;scanRoots=roots;pendingScan=true;state.busy=true;state.error.clear();++state.revision;notify();return true;}
bool Service::liveCommand(const juce::String&command){std::lock_guard<std::mutex>lock(mutex);if(state.busy||!state.song||state.song->audioBeat||!juce::StringArray{"import","play","stop","render"}.contains(command))return false;pendingLive=command;stop=false;state.busy=true;state.error.clear();++state.revision;notify();return true;}
void Service::run(){while(!threadShouldExit()){
    std::optional<Request>job;juce::Array<juce::File>roots;juce::String liveAction;std::shared_ptr<const Song>liveSong;bool scanning=false;{std::lock_guard<std::mutex>lock(mutex);job=std::move(pending);pending.reset();liveAction=pendingLive;pendingLive.clear();liveSong=state.song;scanning=pendingScan;pendingScan=false;if(scanning)roots=scanRoots;}
    if(!job&&!scanning&&liveAction.isEmpty()){wait(100);continue;}
    try{if(scanning)scanNow(roots);else if(liveAction=="render"&&liveSong){captureLive(liveSong);}else if(liveAction.isNotEmpty()&&liveSong){report("Sending to Ableton Live");auto payload=liveAction=="import"?live::arrangement(liveSong->project,liveSong->folder,liveSong->loopAudio):live::command(liveAction,liveSong->project.id);juce::var answer;checked(live::request(dataDirectory(),payload,answer,[this]{return cancelled();}));report("Ableton Live: "+liveAction+" complete");}else if(job->audioBase.isNotEmpty())editAudio(*job);else if(job->midiBase.isNotEmpty())editMidi(*job);else if(job->editExisting)edit(*job);else if(job->audioBeat)composeAudio(*job);else compose(*job);}catch(const std::exception&e){std::lock_guard<std::mutex>lock(mutex);state.error=juce::String::fromUTF8(e.what());state.status=cancelled()?"Cancelled":"Could not finish";}
    {std::lock_guard<std::mutex>lock(mutex);state.busy=false;modelRequest.reset();++state.revision;}
}}
void Service::captureLive(const std::shared_ptr<const Song>&before){
    require(live::native(before->project),"This song is already rendered locally");report("Rendering the complete mix in Live in real time");juce::var answer;checked(live::request(dataDirectory(),live::command("render",before->project.id),answer,[this]{return cancelled();}));
    auto path=answer["result"]["file"].toString();require(juce::File::isAbsolutePath(path),"Live returned an invalid audio path");juce::File source(path);require(source.isAChildOf(before->folder)&&source.existsAsFile(),"Live capture is outside this composition");
    juce::AudioFormatManager formats;registerFormats(formats);std::unique_ptr<juce::AudioFormatReader>reader(formats.createReaderFor(ioFile(source)));require(reader&&reader->lengthInSamples>0&&reader->sampleRate>=8000&&reader->sampleRate<=384000&&reader->numChannels<=2,"Cannot decode the Live recording");
    auto song=std::make_shared<Song>(*before);song->mix=before->folder.getChildFile("native-mix-"+juce::Uuid().toString().removeCharacters("-")+".wav");auto stream=std::unique_ptr<juce::OutputStream>(song->mix.createOutputStream());juce::WavAudioFormat wav;auto writer=wav.createWriterFor(stream,juce::AudioFormatWriterOptions{}.withSampleRate(reader->sampleRate).withNumChannels(reader->numChannels).withBitsPerSample(24));require(bool(writer),"Cannot save complete Live mix");juce::AudioBuffer<float>buffer(int(reader->numChannels),4096);float peak=0;
    for(juce::int64 at=0;at<reader->lengthInSamples;at+=4096){require(!cancelled(),"Cancelled");int count=int(std::min<juce::int64>(4096,reader->lengthInSamples-at));require(reader->read(&buffer,0,count,at,true,true),"Cannot read complete Live mix");for(int ch=0;ch<buffer.getNumChannels();++ch)for(int i=0;i<count;++i){float sample=buffer.getSample(ch,i);require(std::isfinite(sample)&&std::abs(sample)<=1.f,"Live mix clipped; reduce track levels and render again");peak=std::max(peak,std::abs(sample));}require(writer->writeFromAudioSampleBuffer(buffer,0,count),"Cannot write complete Live mix");}
    require(peak>1.e-7f,"Live rendered silence; check instrument content and routing");writer.reset();song->nativeMix=true;song->messages.add("Complete Live mix recorded, including native instruments and four beats of tail. WAV is ready to drag.");commitSong(song);
}
void Service::scanNow(const juce::Array<juce::File>&roots){
    juce::Array<juce::File>files;auto cancellation=[this]{return cancelled();};report("Discovering VST2 / VST3 instruments");checked(hosting::discover(roots,files,cancellation));juce::Array<juce::var>found,effects;juce::StringArray errors;
    std::vector<hosting::ScanResult> results;
    checked(hosting::scanCatalogue(music::instruments::workerFile(),files,dataDirectory().getChildFile("Composer/scan"),results,cancellation,
        [this,total=files.size()](int done,const juce::String&name){report("Scanned "+juce::String(done)+" / "+juce::String(total)+": "+name);}));
    require(!cancelled(),"Cancelled");
    for(int i=0;i<files.size();++i){const auto&f=files.getReference(i);auto&result=results[size_t(i)];
        if(auto*rows=result.plugins.getArray())for(auto&row:*rows){if(bool(row["instrument"]))found.add(row.clone());else effects.add(row.clone());}if(result.error.isNotEmpty())errors.add(f.getFileName()+": "+result.error);
    }
    auto destination=dataDirectory().getChildFile("composer-instruments.json");checked(destination.getParentDirectory().createDirectory());require(destination.replaceWithText(juce::JSON::toString(found)),"Cannot save instrument list");
    require(dataDirectory().getChildFile("composer-effects.json").replaceWithText(juce::JSON::toString(effects)),"Cannot save effect list");
    {std::lock_guard<std::mutex>lock(mutex);state.instruments=found;state.effects=effects;state.status="Found "+juce::String(found.size())+" instruments";if(!errors.isEmpty())state.error=errors.joinIntoString("\n");}
}

void Service::editMidi(const Request&r){
    auto before=snapshot().song;require(before&&before->project.id==r.midiBase,"The song changed; reopen its piano roll before applying notes");require(!cancelled(),"Cancelled");
    auto song=std::make_shared<Song>();checked(applyMidiChanges(before->project,r.midiChanges,song->project));
    song->project.id=juce::Uuid().toString().removeCharacters("-");song->folder=dataDirectory().getChildFile("Composer/songs/"+song->project.id);checked(song->folder.createDirectory());song->prompt=r.prompt;song->reference=before->reference;song->loopAudio=before->loopAudio;
    song->messages.add("Applied "+juce::String(int(r.midiChanges.size()))+" MIDI edits. Previous version preserved.");
    renderSong(song,r,{},object({{"manual_midi_edits",int(r.midiChanges.size())}}),true);
}

void Service::editAudio(const Request&r){
    auto before=snapshot().song;require(before&&before->project.id==r.audioBase,"The song changed; reopen its audio editor");require(before->loopAudio.existsAsFile(),"The song has no source audio track");
    auto song=std::make_shared<Song>();song->project=before->project;song->project.id=juce::Uuid().toString().removeCharacters("-");song->folder=dataDirectory().getChildFile("Composer/songs/"+song->project.id);checked(song->folder.createDirectory());song->reference=before->reference;song->prompt=r.prompt;song->loopAudio=song->folder.getChildFile("edited-source.wav");
    report("Editing selected audio region");checked(editAudioRegion(before->loopAudio,song->loopAudio,r.audioEdit,[this]{return cancelled();}));song->messages.add("Audio region edited; MIDI and original recording preserved. Undo restores the previous version.");renderSong(song,r,{},object({{"audio_region_edit",r.audioEdit.action}}),true);
}

void Service::edit(const Request&r){
    auto before=snapshot().song;require(bool(before),"Create a beat first");require(!cancelled(),"Cancelled");require(r.prompt.trim().isNotEmpty()&&r.prompt.length()<=4096,"Describe the edit in up to 4096 characters");
    juce::Array<juce::var>tracks,ids;ids.add("");for(auto&t:before->project.tracks){ids.add(t.id);juce::Array<juce::var>fx;for(int i=0;i<t.effects.size();++i)fx.add(object({{"slot",i},{"name",t.effects[i]["name"]}}));tracks.add(object({{"id",t.id},{"role",t.role},{"notes",int(t.notes.size())},{"effects",fx}}));}
    juce::Array<juce::var>instruments,effects,roles;for(int i=0;i<r.instruments.size();++i)instruments.add(object({{"index",i},{"name",r.instruments[i]["name"]}}));for(int i=0;i<r.effects.size();++i)effects.add(object({{"index",i},{"name",r.effects[i]["name"]}}));for(auto&role:music::generationRoles())roles.add(role);
    auto context=object({{"request",r.prompt},{"allowed_instruments",instruments},{"allowed_effects",effects},{"available_roles",roles},{"bpm",before->project.settings.bpm},{"bars",before->project.settings.bars},{"tracks",tracks},{"sections",before->project.sections},{"has_audio_loop",before->loopAudio!=juce::File()}});
    auto props=object({{"action",object({{"type","string"},{"enum",juce::Array<juce::var>{"remove","regenerate","transpose","velocity","tempo","add_track","replace_sound","add_effect","remove_effect","rename_section","duplicate_section","delete_section"}}})},{"track",object({{"type","string"},{"enum",ids}})},{"amount",object({{"type","number"},{"minimum",-24},{"maximum",4096}})},{"role",object({{"type","string"},{"maxLength",32}})},{"source_index",object({{"type","integer"},{"minimum",-1},{"maximum",std::max(0,std::max(r.instruments.size(),r.effects.size())-1)}})},{"section_name",object({{"type","string"},{"maxLength",64}})},{"first_bar",object({{"type","integer"},{"minimum",0},{"maximum",before->project.settings.bars-1}})},{"end_bar",object({{"type","integer"},{"minimum",1},{"maximum",before->project.settings.bars}})}});
    juce::Array<juce::var>variants;auto existingIds=ids;existingIds.remove(0);
    for(auto name:{"remove","regenerate","transpose","velocity","tempo","add_track","replace_sound","add_effect","remove_effect","rename_section","duplicate_section","delete_section"}){
        auto fields=props.clone();auto action=juce::String(name);auto global=action=="tempo"||action=="add_track"||action.endsWith("_section");
        if(action=="add_effect"&&r.effects.isEmpty())continue;
        fields.getDynamicObject()->setProperty("action",object({{"const",action}}));fields.getDynamicObject()->setProperty("track",object({{"type","string"},{"enum",global?juce::Array<juce::var>{""}:existingIds}}));
        if(action=="add_track")fields.getDynamicObject()->setProperty("role",object({{"type","string"},{"enum",roles}}));
        juce::Array<juce::var>sources;if(action!="add_effect")sources.add(-1);if(action=="add_track"||action=="replace_sound"||action=="add_effect")for(int i=0;i<(action=="add_effect"?r.effects.size():r.instruments.size());++i)sources.add(i);fields.getDynamicObject()->setProperty("source_index",object({{"type","integer"},{"enum",sources}}));
        juce::Array<juce::var>required{"action","track","amount","first_bar","end_bar","role","source_index","section_name"};
        if(action=="duplicate_section"){juce::Array<juce::var>boundaries;if(auto*sections=before->project.sections.getArray())for(auto&section:*sections)boundaries.add(int(section["start"]));boundaries.add(before->project.settings.bars);fields.getDynamicObject()->setProperty("destination_bar",object({{"type","integer"},{"enum",boundaries},{"description","Insertion bar, zero-based. To append at the end use the song bars value."}}));required.add("destination_bar");fields.getDynamicObject()->setProperty("amount",object({{"const",0}}));}
        variants.add(object({{"type","object"},{"properties",fields},{"required",required},{"additionalProperties",false}}));
    }
    auto operation=object({{"anyOf",variants}});
    auto schema=object({{"type","object"},{"properties",object({{"operations",object({{"type","array"},{"items",operation},{"maxItems",16}})}})},{"required",juce::Array<juce::var>{"operations"}},{"additionalProperties",false}});
    auto system=juce::String("Edit an existing beat. Return ONLY JSON operations, never a new song. Target only requested track IDs. Use zero-based first_bar inclusive and end_bar exclusive; without an explicit section use the whole song. For a named section use its start and bars. remove clears a part; regenerate creates a new MIDI variation preserving its sound; transpose changes pitched notes by integer semitones (-24..24); velocity scales note velocity (0.1..2, e.g. softer=0.75); tempo sets whole-song BPM (30..300), track empty. For remove/regenerate use amount=0. Keep unrelated tracks AND all unrequested sections untouched. Do NOT add compensating operations: making chorus softer never means making verse louder. Unchanged sections require NO operation. Example: for Verse start=0 bars=4 and Chorus start=4 bars=4, request make Snare half velocity only in chorus means exactly one operation: action velocity, track Snare ID, amount 0.5, first_bar 4, end_bar 8. If asked to remove hats, target existing Closed Hat and Open Hat tracks. Tempo with audio loops is unsupported. add_track creates the requested role on a NEW track, track empty, role from available_roles, source_index=-1 for automatic library sound or an allowed_instruments index. replace_sound retains MIDI and uses the same source_index rules. add_effect uses an allowed_effects index; remove_effect amount is its zero-based chain slot. Sound/effect edits apply to the entire track. rename_section changes one exact section range using section_name. duplicate_section copies a whole section range and inserts before destination_bar (zero-based). To append at the END set destination_bar to the whole song bars value, e.g. bars=8 means destination_bar=8, never 1; amount=0. delete_section removes whole sections. Section duplication/deletion must be the only operation in a message and is unsupported with audio loops. Unused role/section_name must be empty strings, source_index=-1, amount=0. Never invent plugin indices. For an unsupported or ambiguous request return operations:[] and do not substitute a different action. /no_think");
    auto payload=object({{"messages",juce::Array<juce::var>{object({{"role","system"},{"content",system}}),object({{"role","user"},{"content",juce::JSON::toString(context,true)}})}},{"temperature",.1},{"max_tokens",1600},{"response_format",object({{"type","json_schema"},{"json_schema",object({{"name","edit"},{"strict",true},{"schema",schema}})}})},{"chat_template_kwargs",object({{"enable_thinking",false}})}});
    report(r.model=="openai"?"OpenAI is editing the beat":"Local AI is editing the current beat");auto job=std::make_shared<LocalModelRequest>();{std::lock_guard<std::mutex>lock(mutex);modelRequest=job;if(cancelled())job->cancel();}
    juce::String response;checked(r.model=="openai"?openai::predict(payload,response,job):runtime->predict(r.model,juce::JSON::toString(payload,true),response,job));if(r.model!="openai")runtime->release();require(!cancelled(),"Cancelled");juce::var plan;checked(juce::JSON::parse(response,plan));
    auto song=std::make_shared<Song>();song->folder=dataDirectory().getChildFile("Composer/songs/"+juce::Uuid().toString().removeCharacters("-"));checked(song->folder.createDirectory());
    require(song->folder.getChildFile("edit-plan.json").replaceWithText(juce::JSON::toString(plan)),"Cannot save edit plan");
    std::map<juce::String,music::Track>assets;auto*operations=plan["operations"].getArray();require(operations&&operations->size()<=16,"Invalid edit operations");
    for(int index=0;index<operations->size();++index){auto&op=(*operations)[index];auto action=op["action"].toString();if(action!="add_track"&&action!="replace_sound"&&action!="add_effect")continue;require(integer(op["source_index"]),"Invalid sound source");int source=int(op["source_index"]);music::Track prepared;auto current=std::find_if(before->project.tracks.begin(),before->project.tracks.end(),[&](auto&t){return t.id==op["track"].toString();});
        if(action=="add_track"){
            auto role=op["role"].toString();require(music::generationRoles().contains(role),"Unknown new track role");auto settings=before->project.settings;settings.activeRoles={role};settings.seed=uint32_t(juce::Random::getSystemRandom().nextInt());music::ProfileRegistry registry;checked(registry.decode(before->project.styleSnapshot["registry"]));music::Project generated;checked(music::generateStyled(settings,registry,{{settings.genre,1}},{{settings.mood,1}},generated));require(generated.tracks.size()==1,"Cannot generate requested track");if(role=="Bass"||role=="Chords"||role=="Melody"||role=="Countermelody"){music::HarmonyOptions harmony;if(!before->project.harmony.isVoid())checked(music::decodeHarmony(before->project.harmony,harmony));else harmony.progression=music::suggestHarmony(before->project.settings,0);harmony.chords=role=="Chords";harmony.bass=role=="Bass";harmony.melody=role=="Melody"||role=="Countermelody";harmony.melodyTarget=role;checked(music::applyHarmony(generated,harmony));}juce::StringArray guidance;checked(referenceMusic::apply(generated,before->reference.musicalGuide,guidance,false));prepared=generated.tracks.front();prepared.id="track-"+juce::Uuid().toString().removeCharacters("-");for(auto&note:prepared.notes)note.id=prepared.id+":"+note.id;
        }else{require(current!=before->project.tracks.end()&&!current->soundLocked,"Missing or sound-locked track");prepared=*current;}
        if(action=="add_effect"){
            require(source>=0&&source<r.effects.size(),"Effect is outside the allowed list");require(prepared.liveDevice.isEmpty(),"Native Live effects require bridge configuration");auto config=r.effects[source].clone();config.getDynamicObject()->setProperty("effect",true);config.getDynamicObject()->setProperty("xml",config["description_xml"]);juce::var answer;report("Preparing effect "+config["name"].toString());checked(music::instruments::request(object({{"instrument",config},{"sample_rate",44100},{"parameters",juce::Array<juce::var>{}}}),song->folder.getChildFile("effect-"+juce::String(index)),false,answer,[this]{return cancelled();},true));prepared.effects=juce::Array<juce::var>{answer["instrument"].clone()};
        }else{
            auto oldPath=prepared.soundPath;prepared.soundPath={};prepared.instrument=juce::var();prepared.liveDevice={};
            if(source>=0){require(source<r.instruments.size(),"Instrument is outside the allowed list");auto config=r.instruments[source].clone();if(config["format"].toString()=="Live"){require(music::validLiveDevice(config["name"].toString()),"Unsupported Live device");prepared.liveDevice=config["name"].toString();}
                else{config.getDynamicObject()->setProperty("xml",config["description_xml"]);juce::var answer;report("Auditioning "+prepared.role+" sound");auto payload=object({{"instrument",config},{"sample_rate",44100},{"parameters",juce::Array<juce::var>{}},{"auto_program_role",prepared.role},{"require_sound_audition",true},{"sound_genre",before->project.settings.genre},{"preset_roots",juce::JSON::parse(dataDirectory().getChildFile("composer-preset-folders.json"))}});checked(music::instruments::request(payload,song->folder.getChildFile("sound-"+juce::String(index)),false,answer,[this]{return cancelled();},true));prepared.instrument=answer["instrument"].clone();song->messages.add(answer["program_notice"].toString());}
            }else{require(source==-1&&r.samples!=nullptr,"Library is unavailable for sound selection");auto selection=before->project;selection.sections=juce::var();selection.tracks={prepared};std::vector<Sample>available;for(auto&sample:*r.samples)if(action!="replace_sound"||sample.path!=oldPath)available.push_back(sample);juce::StringArray notices;checked(selectSamples(selection,available,false,notices,before->reference.timbres));require(selection.tracks.size()==1,"No suitable new sound found");prepared=selection.tracks.front();}
        }
        assets.emplace(juce::String(index),std::move(prepared));
    }
    checked(applyEdits(before->project,plan,song->project,before->loopAudio!=juce::File(),assets));
    song->project.id=song->folder.getFileName();song->prompt=r.prompt;song->reference=before->reference;song->loopAudio=before->loopAudio;
    for(auto&op:*plan["operations"].getArray()){juce::String role="Song";for(auto&t:before->project.tracks)if(t.id==op["track"].toString())role=t.role;song->messages.add(role+": "+op["action"].toString()+" / bars "+juce::String(int(op["first_bar"])+1)+"-"+op["end_bar"].toString()+" / "+op["amount"].toString());}
    song->messages.add("Previous version preserved. Undo / Redo restores versions in DrumAtlas.");
    auto clean=r;clean.reference={};clean.loop={};renderSong(song,clean,{},plan,true);
}

void Service::composeAudio(const Request& r) {
    require(r.prompt.trim().isNotEmpty() && r.prompt.length() <= 4096, "Describe the beat in up to 4096 characters");
    const auto location = dataDirectory().getChildFile("audio-engine.txt").loadFileAsString().trim();
    require(juce::File::isAbsolutePath(location), "Select the ACE-Step engine folder in AI Chat first");
    const juce::File root(location);
    auto executable = root.getChildFile("bin/ace-synth.exe");
    auto models = root.getChildFile("models");
    require(executable.existsAsFile() && models.isDirectory(), "ACE-Step is missing. Select its installation folder.");
    auto song = std::make_shared<Song>();
    song->audioBeat = true;
    song->prompt = r.prompt;
    song->project.id = juce::Uuid().toString().removeCharacters("-");
    song->folder = dataDirectory().getChildFile("Composer/songs").getChildFile(song->project.id);
    checked(song->folder.createDirectory());
    auto source = r.reference != juce::File() ? r.reference : r.loop;
    auto jobFile = song->folder.getChildFile("beat.json");
    juce::StringArray args {executable.getFullPathName(), "--models", models.getFullPathName(),
                            "--request", jobFile.getFullPathName(), "--vae-chunk", "256"};
    double duration = 64.;
    juce::TemporaryFile referenceCopy(".wav", juce::TemporaryFile::useHiddenFile);
    if (source != juce::File()) {
        report("Analysing full audio reference");
        checked(analyseWholeFile(source, song->reference, [this]{ return cancelled(); }));
        if (r.reference != juce::File()) duration = song->reference.duration;
        juce::AudioFormatManager formats;
        registerFormats(formats);
        std::unique_ptr<juce::AudioFormatReader> reader(formats.createReaderFor(ioFile(source)));
        require(reader && reader->numChannels >= 1 && reader->numChannels <= 2, "Cannot decode audio reference");
        std::unique_ptr<juce::OutputStream> stream = referenceCopy.getFile().createOutputStream();
        juce::WavAudioFormat wav;
        auto writer = wav.createWriterFor(stream, juce::AudioFormatWriterOptions{}.withSampleRate(reader->sampleRate)
                                             .withNumChannels(reader->numChannels).withBitsPerSample(16));
        require(bool(writer), "Cannot prepare audio reference");
        for (juce::int64 at = 0; at < reader->lengthInSamples; at += 65536) {
            require(!cancelled(), "Cancelled");
            require(writer->writeFromAudioReader(*reader, at, std::min<juce::int64>(65536, reader->lengthInSamples-at)), "Cannot write audio reference");
        }
        writer.reset();
        args.add("--ref-audio");
        args.add(referenceCopy.getFile().getFullPathName());
    }
    const auto bpm = song->reference.bpm;
    auto payload = object({{"caption", "Instrumental beat, no vocals. " + r.prompt.trim()},
                           {"lyrics", "[Instrumental]"}, {"duration", duration}, {"output_format", "wav24"}});
    if (bpm > 0) payload.getDynamicObject()->setProperty("bpm", juce::roundToInt(bpm));
    require(jobFile.replaceWithText(juce::JSON::toString(payload)), "Cannot save generation request");
    report("Generating stereo audio with ACE-Step");
    juce::ChildProcess child;
    require(!cancelled(), "Cancelled");
    require(child.start(args, 0), "Cannot launch ACE-Step");
    while (child.isRunning()) {
        if (cancelled()) {
            child.kill();
            child.waitForProcessToFinish(5000);
            require(false, "Cancelled");
        }
        juce::Thread::sleep(100);
    }
    require(child.getExitCode()==0, "ACE-Step could not render audio. Check the engine, models and available GPU memory.");
    auto output = song->folder.getChildFile("beat0.wav");
    juce::WavAudioFormat wav;
    std::unique_ptr<juce::AudioFormatReader> reader(wav.createReaderFor(output.createInputStream().release(),true));
    require(reader && reader->numChannels==2 && reader->sampleRate>0 && reader->lengthInSamples>0,
            "ACE-Step did not produce a readable stereo WAV");
    const auto seconds = reader->lengthInSamples/reader->sampleRate;
    require(std::abs(seconds-duration) < std::max(1., duration*.02), "Audio generator returned a different duration");
    song->mix = output;
    song->messages.add("ACE-Step / " + juce::String(seconds,1) + " s / stereo WAV");
    require(!cancelled(), "Cancelled");
    commitSong(song);
}

void Service::compose(const Request&r){
    require(!cancelled(),"Cancelled");require(r.prompt.trim().isNotEmpty()&&r.prompt.length()<=4096,"Describe the beat in up to 4096 characters");require(r.samples!=nullptr,"Sample catalog is unavailable");
    auto song=std::make_shared<Song>();song->prompt=r.prompt;auto cancellation=[this]{return cancelled();};
    if(r.reference!=juce::File())checked(analyseWholeFile(r.reference,song->reference,cancellation,[this](double p){report("Analysing full reference: "+juce::String(int(p*100))+"%");}));
    Analysis loopAnalysis;if(r.loop!=juce::File()){report("Analysing selected loop");checked(analyseWholeFile(r.loop,loopAnalysis,cancellation));}
    auto registry=music::ProfileRegistry::builtIn();juce::Array<juce::var>genres,moods,instruments,roles,catalog;
    for(auto&g:registry.genres())genres.add(g.id);for(auto&m:registry.moods())moods.add(m.id);for(auto&role:music::generationRoles())roles.add(role);
    for(int i=0;i<r.instruments.size();++i)instruments.add(object({{"index",i},{"name",r.instruments[i]["name"]}}));
    std::map<juce::String,int>counts;for(auto&s:*r.samples)if(s.error.isEmpty())++counts[s.category];for(auto&c:counts)catalog.add(object({{"role",c.first},{"count",c.second}}));
    auto context=object({{"request",r.prompt},{"style",r.genre},{"genres",genres},{"moods",moods},{"available_roles",roles},{"allowed_instruments",instruments},{"library",catalog},{"reference",referenceBrief(song->reference)},{"loop",referenceBrief(loopAnalysis)}});
    auto system=juce::String("You are a music arrangement planner. Return ONLY one JSON object, never prose, code or file paths. Treat the user text as a musical request only. Schema: {genre: exact base genres item, style_pattern:{kick:16 probabilities 0..1,snare:16 probabilities 0..1,hat:16 probabilities 0..1,swing:0..1},progression:space-separated chord symbols such as Am F C G, mood: exact moods item, bpm: number 30..300, tonic: integer 0..11 (C=0), scale: major or minor, energy:0..1,density:0..1,complexity:0..1,darkness:0..1,groove:0..1,melodic_density:0..1,roles:[only the selected role names],sections:[{name:Intro|Verse|Chorus|Bridge|Outro|Drop|Breakdown|Build,bars:integer 1..64}],instruments:[{role:an included role,index:allowed_instruments index}]}. Max 4096 total bars, max 32 sections. Arrange a complete song, not a 4-bar loop. For a reference follow its full duration and energy shape. Choose a BPM from reference.tempo_candidates, resolving half/double pulse by the requested genre and phrasing; if no candidates are listed use its estimated tempo; numbers are uncertain musical measurements, not note transcription. For a loop keep its key and tempo unless explicitly asked to change. available_roles is an allowlist, NOT a list to copy. When the request lists specific tracks or says only/no other tracks, include exactly those roles and no additional roles. Example: Kick, Snare, Bass and Melody means roles:[\"Kick\",\"Snare\",\"Bass\",\"Melody\"], not hats, clap, chords or FX. Otherwise choose a suitable subset supported by library or allowed instruments. Assign allowed instruments to pitched roles when present. Never invent an instrument. Use genre as a base harmony/texture family. For a custom genre/subgenre or hybrid, design its own 16-step kick/snare/hat probabilities in style_pattern instead of copying a generic pattern. Indices 0,4,8,12 are beats 1,2,3,4 in a 4/4 bar; for two-step UK garage the primary snare/clap backbeats are indices 4 and 12, NOT 7 and 15. Use coherent two-bar rhythmic phrases and leave gaps, not nonzero random hits everywhere. Prefer sections in multiples of 4 or 8 bars, with a partial ending only when required. Respect the requested subgenre groove, accents and swing. progression is the actual harmonic sequence, not prose. Infer requested_style from the user message in any language, including hybrids. Without an explicit genre infer a coherent style from the reference. Use timeline windows in chronological order: rms for dynamic contrast, estimated_chords for harmonic movement and kick/snare/hat arrays for accents. Zero or missing estimates may mean uncertain evidence. Write a distinctive original two-bar hook (sorted step 0..31, length in sixteenth notes, diatonic degree 0..13, velocity 1..127; no overlap). Use an empty hook without Melody. Give each section active_roles from the chosen roles, with entrances, a sparser verse and a returning hook where appropriate. Respect user instructions about which instrument plays which part. /no_think");
    juce::Array<juce::var>messages{object({{"role","system"},{"content",system}}),object({{"role","user"},{"content",juce::JSON::toString(context,true)}})};
    auto payload=object({{"messages",messages},{"temperature",.35},{"max_tokens",2400},{"response_format",object({{"type","json_schema"},{"json_schema",object({{"name","composition"},{"strict",true},{"schema",planSchema(registry,r.instruments.size())}})}})},{"chat_template_kwargs",object({{"enable_thinking",false}})}});
    report(r.model=="openai"?"OpenAI is arranging the song":"Local AI is arranging the song");auto job=std::make_shared<LocalModelRequest>();{std::lock_guard<std::mutex>lock(mutex);modelRequest=job;if(cancelled())job->cancel();}juce::String response;checked(planner?planner(payload,response):r.model=="openai"?openai::predict(payload,response,job):runtime->predict(r.model,juce::JSON::toString(payload,true),response,job));require(!cancelled(),"Cancelled");
    juce::var plan;checked(juce::JSON::parse(response,plan));if(r.model!="openai")runtime->release();checked(planProject(r,song->reference,plan,song->project,song->messages));
    song->folder=dataDirectory().getChildFile("Composer/songs/"+song->project.id);checked(song->folder.createDirectory());
    // Audition compatible sounds outside the DAW, preserving the winning state.
    for(auto&t:song->project.tracks)if(!t.instrument.isVoid()){
        report("Preparing "+t.role+" / "+t.instrument["name"].toString());auto config=t.instrument.clone();if(auto*o=config.getDynamicObject();o&&config["description_xml"].toString().isNotEmpty())o->setProperty("xml",config["description_xml"]);
        auto request=object({{"instrument",config},{"sample_rate",44100},{"parameters",juce::Array<juce::var>{}},{"auto_program_role",t.role},{"require_sound_audition",true},{"sound_genre",song->project.settings.genre},{"preset_roots",juce::JSON::parse(dataDirectory().getChildFile("composer-preset-folders.json"))}});juce::var answer;
        const Hit* target=nullptr;for(const auto&hit:song->reference.timbres){bool matching=hit.category==t.role||(t.role=="Chords"&&(hit.category=="Piano"||hit.category=="Keys"))||((t.role=="Melody"||t.role=="Countermelody")&&hit.category=="Synth");if(matching&&(!target||hit.confidence>target->confidence))target=&hit;}
        if(target)request.getDynamicObject()->setProperty("target_features",toJson(target->features));
        checked(music::instruments::request(request,song->folder.getChildFile("instrument-"+t.id),false,answer,cancellation,true));t.instrument=answer["instrument"].clone();
        song->messages.add(t.role+": "+answer["program_notice"].toString());
        checked(song->folder.getChildFile("sound-"+t.id+".json").replaceWithText(juce::JSON::toString(answer["sound_auditions"]))?juce::Result::ok():juce::Result::fail("Cannot save sound audition report"));
    }
    checked(selectSamples(song->project,*r.samples,r.loop!=juce::File(),song->messages,song->reference.timbres,true,song->folder.getChildFile("aligned-loops"),cancellation));
    renderSong(song,r,loopAnalysis,plan);
}
void Service::renderSong(const std::shared_ptr<Song>&song,const Request&r,const Analysis&loopAnalysis,const juce::var&plan,bool edited){
    auto cancellation=[this]{return cancelled();};const bool preservedLoop=song->loopAudio!=juce::File();const bool hasLoop=preservedLoop||r.loop!=juce::File();
    require(!cancelled(),"Cancelled");report("Rendering MIDI and audio tracks");checked(music::save(song->project,song->folder.getChildFile("song.drumatlas")));checked(music::exportMidi(song->project,song->folder.getChildFile("song.mid")));
    for(auto&t:song->project.tracks)checked(music::exportMidi(song->project,song->folder.getChildFile("track-"+t.id+".mid"),t.id));
    auto base=song->folder.getChildFile("tracks/Mix.wav");juce::StringArray renderNotices;music::StemExportOptions options;options.perTrack=true;options.balanceRoles=true;options.unknownTailSeconds=juce::jlimit(8.,32.,1920./song->project.settings.bpm);auto renderProject=song->project;renderProject.tracks.erase(std::remove_if(renderProject.tracks.begin(),renderProject.tracks.end(),[](const auto&t){return t.liveDevice.isNotEmpty();}),renderProject.tracks.end());
    // A MIDI/velocity edit must not be cancelled out by automatic rebalancing.
    // Keep the saved gain for unchanged sound sources; measure only new sounds.
    if(edited){auto previous=snapshot().song;if(previous){
        auto manifest=juce::JSON::parse(previous->folder.getChildFile("tracks/manifest.json"));auto* gains=new juce::DynamicObject;options.fixedBalance=juce::var(gains);
        for(auto& t:renderProject.tracks)for(auto& old:previous->project.tracks)if(t.id==old.id&&t.soundPath==old.soundPath&&t.sampleRoot==old.sampleRoot&&juce::JSON::toString(t.instrument)==juce::JSON::toString(old.instrument)&&juce::JSON::toString(t.effects)==juce::JSON::toString(old.effects)){
            if(auto* rows=manifest["track_balance"].getArray())for(auto& row:*rows)if(row["track_id"].toString()==t.id)gains->setProperty(t.id,row["gain"]);
        }
    }}
    if(!renderProject.tracks.empty()){checked(music::renderStems(renderProject,song->folder.getChildFile("tracks"),options,cancellation,&renderNotices));song->mix=base;}
    else if(hasLoop){checked(base.getParentDirectory().createDirectory());auto stream=std::unique_ptr<juce::OutputStream>(base.createOutputStream());juce::WavAudioFormat format;auto writer=format.createWriterFor(stream,juce::AudioFormatWriterOptions{}.withSampleRate(44100).withNumChannels(2).withBitsPerSample(24));require(bool(writer),"Cannot prepare loop audio");juce::AudioBuffer<float>silence(2,4096);silence.clear();auto frames=juce::int64(song->project.settings.bars*240/song->project.settings.bpm*44100);for(juce::int64 at=0;at<frames;at+=4096){require(!cancelled(),"Cancelled");require(writer->writeFromAudioSampleBuffer(silence,0,int(std::min<juce::int64>(4096,frames-at))),"Cannot prepare loop audio");}}
    song->messages.addArray(renderNotices);
    if(hasLoop){
        int loopBars=0;
        if(!preservedLoop){
        report("Placing the loop on an audio track");require(loopAnalysis.bpm>0,"Could not determine the loop tempo. The generated MIDI is saved; use a rhythmic loop with a detectable tempo.");
        loopBars=std::max(1,int(std::round(loopAnalysis.duration*loopAnalysis.bpm/240)));
        const double exactSourceBpm=loopBars*240/loopAnalysis.duration;
        song->loopAudio=resampleLoop(renderAudioEdit({r.loop,0,exactSourceBpm,song->project.settings.bpm},song->folder,cancellation),song->folder,cancellation);
        }
        juce::AudioFormatManager fm;registerFormats(fm);std::unique_ptr<juce::AudioFormatReader>musicReader(fm.createReaderFor(base)),loopReader(fm.createReaderFor(song->loopAudio));require(musicReader&&loopReader,"Cannot read loop arrangement audio");
        song->mix=song->folder.getChildFile("song.wav");auto stream=std::unique_ptr<juce::OutputStream>(song->mix.createOutputStream());juce::WavAudioFormat wav;auto writer=wav.createWriterFor(stream,juce::AudioFormatWriterOptions{}.withSampleRate(44100).withNumChannels(2).withBitsPerSample(24));require(bool(writer),"Cannot write loop mix");
        auto loopTrack=song->folder.getChildFile("loop-track.wav");auto loopStream=std::unique_ptr<juce::OutputStream>(loopTrack.createOutputStream());auto loopWriter=wav.createWriterFor(loopStream,juce::AudioFormatWriterOptions{}.withSampleRate(44100).withNumChannels(2).withBitsPerSample(24));require(bool(loopWriter),"Cannot write loop track");
        // Streaming loop reader: no whole-song allocation and no 120-second limit.
        juce::AudioBuffer<float>mix(2,4096),loop(2,4096);double ratio=loopReader->sampleRate/44100;require(std::abs(ratio-1)<.00001,"Loop sample rate conversion is required for this file; MIDI remains available");
        juce::int64 loopLength=loopReader->lengthInSamples,loopPosition=0,activeFrames=juce::int64(song->project.settings.bars*240/song->project.settings.bpm*44100);
        require(loopLength>0,"Empty loop");for(juce::int64 position=0;position<musicReader->lengthInSamples;){require(!cancelled(),"Cancelled");int count=int(std::min<juce::int64>({4096,musicReader->lengthInSamples-position,loopLength-loopPosition}));mix.clear();loop.clear();require(musicReader->read(&mix,0,count,position,true,true)&&loopReader->read(&loop,0,count,loopPosition,true,true),"Cannot decode loop mix");
            for(int i=0;i<count;++i)for(int ch=0;ch<2;++ch){double fade=std::min({1.,double(loopPosition+i)/128.,double(loopLength-loopPosition-i)/128.});float loopValue=position+i<activeFrames?(preservedLoop?1.f:.3f*float(fade))*loop.getSample(ch,i):0.f;loop.setSample(ch,i,loopValue);mix.setSample(ch,i,.65f*mix.getSample(ch,i)+loopValue);}require(writer->writeFromAudioSampleBuffer(mix,0,count)&&loopWriter->writeFromAudioSampleBuffer(loop,0,count),"Cannot write loop mix");position+=count;loopPosition=(loopPosition+count)%loopLength;}
        writer.reset();loopWriter.reset();song->loopAudio=loopTrack;song->messages.add(preservedLoop?"Existing loop audio preserved at its original gain":"Loop repeated as audio, aligned to "+juce::String(loopBars)+" bars; pitched loop content is preserved.");
    }
    auto metadata=object({{"schema",1},{"prompt",r.prompt},{"reference_path",r.reference.getFullPathName()},{"reference_analysis",song->reference.json()},{"loop_path",r.loop.getFullPathName()},{"loop_audio",song->loopAudio.getFullPathName()},{"mix",song->mix.getFullPathName()},{"plan",plan},{"notices",song->messages}});
    require(!cancelled(),"Cancelled");
    if(live::native(song->project)){song->messages.add("Native instruments play in Ableton. Exported WAVs contain only locally rendered tracks; render the complete song in Live.");if(edited)song->messages.add("Use Send to Live to append this edited version. Previous Live tracks are unchanged.");else {report("Sending native instruments and arrangement to Ableton");juce::var answer;auto transferred=live::request(dataDirectory(),live::arrangement(song->project,song->folder,song->loopAudio),answer,cancellation);if(transferred.failed())song->messages.add("Live transfer: "+transferred.getErrorMessage()+". The generated song is saved; use Send to Live to retry.");else song->messages.add("Created "+answer["result"]["tracks"].toString()+" tracks in Ableton.");}}
    metadata.getDynamicObject()->setProperty("notices",song->messages);
    require(song->folder.getChildFile("composition.json").replaceWithText(juce::JSON::toString(metadata)),"Cannot save composition details");
    require(!cancelled(),"Cancelled");commitSong(song);
}
juce::String Service::serialise(){
    std::lock_guard<std::mutex>lock(mutex);auto v=object({{"schema",1},{"draft",state.draft},{"midi_draft",state.midiDraft}});
    if(state.song){auto*o=v.getDynamicObject();o->setProperty("folder",state.song->folder.getFullPathName());o->setProperty("project",music::encode(state.song->project));o->setProperty("mix",state.song->mix.getFullPathName());o->setProperty("native_mix",state.song->nativeMix);o->setProperty("audio_beat",state.song->audioBeat);o->setProperty("loop_audio",state.song->loopAudio.getFullPathName());o->setProperty("prompt",state.song->prompt);
        auto analysis=state.song->reference.json();juce::Array<juce::var>timbres;
        for(auto&h:state.song->reference.timbres)timbres.add(object({{"time",h.time},{"category",h.category},{"confidence",h.confidence},{"features",toJson(h.features)}}));
        analysis.getDynamicObject()->setProperty("timbres",timbres);o->setProperty("reference_analysis",analysis);o->setProperty("messages",state.song->messages);
    }return juce::JSON::toString(v,true);
}
juce::Result Service::restore(const juce::String&text){
    if(text.isEmpty())return juce::Result::ok();juce::var v;auto result=juce::JSON::parse(text,v);if(result.failed()||int(v["schema"])!=1)return juce::Result::fail("Invalid composer session");std::shared_ptr<Song>song;
    if(v.hasProperty("project")){song=std::make_shared<Song>();result=music::decode(v["project"],song->project);if(result.failed())return result;
        for(auto field:{"folder","mix","loop_audio"})if(v[field].toString().isNotEmpty()&&!juce::File::isAbsolutePath(v[field].toString()))return juce::Result::fail("Invalid composer asset path");
        song->folder=juce::File(v["folder"].toString());song->mix=juce::File(v["mix"].toString());song->nativeMix=bool(v["native_mix"]);song->audioBeat=bool(v["audio_beat"]);song->loopAudio=juce::File(v["loop_audio"].toString());song->prompt=v["prompt"].toString();
        result=Analysis::restore(v["reference_analysis"],song->reference);if(result.failed())return result;
        if(auto*messages=v["messages"].getArray())for(auto&m:*messages)song->messages.add(m.toString());}
    cancel();std::lock_guard<std::mutex>lock(mutex);state.song=song;past.clear();future.clear();state.canUndo=false;state.canRedo=false;state.draft=v["draft"].clone();state.midiDraft=v["midi_draft"].clone();++state.revision;return juce::Result::ok();
}
}
