#pragma once
#include "MusicCore.h"
#include "MusicHarmony.h"
#include <array>
#include <cmath>
#include <set>

namespace atlas::composer::referenceMusic {
struct TonalFrame {double time=0;std::array<double,12>chroma{};};
struct Attack {double time=0,strength=0;int lane=-1;}; // Kick, Snare, Closed Hat; -1 means uncertain.
struct Evidence {std::vector<TonalFrame> tonal;std::vector<Attack> attacks;};
struct Chord {juce::String name;double confidence=0;};
inline Chord chord(const std::array<double,12>&chroma){
    double energy=0;for(auto v:chroma){if(!std::isfinite(v)||v<0)return {};energy+=v*v;}if(energy<1e-10)return {};
    double best=0,second=0,coverage=0;int root=-1;bool minor=false;
    for(int key=0;key<12;++key)for(bool m:{false,true}){
        const int third=(key+(m?3:4))%12,fifth=(key+7)%12;
        double score=(chroma[size_t(key)]+.9*chroma[size_t(third)]+.8*chroma[size_t(fifth)])/std::sqrt(energy*2.45);
        if(score>best){second=best;best=score;root=key;minor=m;coverage=(chroma[size_t(key)]*chroma[size_t(key)]+chroma[size_t(third)]*chroma[size_t(third)]+chroma[size_t(fifth)]*chroma[size_t(fifth)])/energy;}else second=std::max(second,score);
    }
    // A single bass note or an ambiguous mixture must never become a confident chord.
    double confidence=juce::jlimit(0.,1.,(best-second)*5);if(root<0||coverage<.72||best<.84||confidence<.3)return {};
    return {juce::MidiMessage::getMidiNoteName(root,true,false,3)+(minor?"m":""),confidence};
}
inline juce::var build(const Evidence&e,double bpm,double duration,const std::vector<double>&energy){
    auto*root=new juce::DynamicObject;juce::var result(root);root->setProperty("schema",1);root->setProperty("bpm",bpm);
    if(!std::isfinite(bpm)||bpm<30||bpm>300||!std::isfinite(duration)||duration<=0)return result;
    const double barSeconds=240/bpm;const int count=int(std::ceil(duration/barSeconds));if(count>4096)return result;
    std::vector<std::array<double,12>>chroma(size_t(count),std::array<double,12>{});
    for(auto&f:e.tonal){int b=int(f.time/barSeconds);if(b<0||b>=count)continue;for(int k=0;k<12;++k)chroma[size_t(b)][size_t(k)]+=f.chroma[size_t(k)];}
    using Lanes=std::array<std::array<double,16>,3>;std::vector<Lanes>rhythm(size_t(count),Lanes{});
    double phaseX=0,phaseY=0;for(auto&hit:e.attacks)if(hit.lane>=0){auto angle=hit.time*bpm/60*juce::MathConstants<double>::twoPi;phaseX+=std::cos(angle)*hit.strength;phaseY+=std::sin(angle)*hit.strength;}
    double phase=std::atan2(phaseY,phaseX)/juce::MathConstants<double>::twoPi*60/bpm;if(phase<0)phase+=60/bpm;if(phase>60/bpm*.95)phase=0;
    // A global beat phase only aligns the quantisation grid; preserve each bar's own pattern.
    for(auto&hit:e.attacks)if(hit.lane>=0&&hit.lane<3){double position=(hit.time-phase)/barSeconds*16;auto step=int(std::llround(position));if(std::abs(position-step)>.32||step<0||step>=count*16)continue;auto&value=rhythm[size_t(step/16)][size_t(hit.lane)][size_t(step%16)];value=std::max(value,hit.strength);}
    juce::Array<juce::var>bars;double maxEnergy=1e-9;for(double v:energy)maxEnergy=std::max(maxEnergy,v);
    for(int b=0;b<count;++b){auto*c=new juce::DynamicObject;auto detected=chord(chroma[size_t(b)]);c->setProperty("bar",b);c->setProperty("chord",detected.name);c->setProperty("chord_confidence",detected.confidence);double sum=0;int n=0;for(int sec=int(b*barSeconds);sec<std::min(int(energy.size()),int(std::ceil((b+1)*barSeconds)));++sec){sum+=energy[size_t(sec)];++n;}c->setProperty("energy",n?sum/n/maxEnergy:0.);
        for(int lane=0;lane<3;++lane){juce::Array<juce::var>values;for(double value:rhythm[size_t(b)][size_t(lane)])values.add(value);c->setProperty(lane==0?"kick":lane==1?"snare":"hat",values);}bars.add(juce::var(c));
    }
    root->setProperty("phase_seconds",phase);root->setProperty("bars",bars);return result;
}
inline juce::Result apply(music::Project&project,const juce::var&guide,juce::StringArray&notices,bool replaceDrums=true){
    auto*bars=guide["bars"].getArray();if(!bars||bars->isEmpty())return juce::Result::ok();auto next=project;const auto ticks=music::barTicks(next.settings);int harmonised=0,rhythmic=0;
    for(int b=0;b<std::min(next.settings.bars,bars->size());++b){auto&row=(*bars)[b];std::vector<music::ChordSpec>chords;bool known=double(row["chord_confidence"])>=.3&&row["chord"].toString().isNotEmpty()&&music::parseChords(row["chord"].toString(),chords).wasOk()&&!chords.empty();bool changed=false;
        for(auto&track:next.tracks){if(track.midiLocked)continue;
            if(known&&(track.role=="Bass"||track.role=="Chords"||track.role=="Melody"||track.role=="Countermelody")){auto&c=chords.front();for(auto&note:track.notes)if(note.tick>=b*ticks&&note.tick<(b+1)*ticks){if((track.role=="Melody"||track.role=="Countermelody")&&note.tick%music::ppq!=0)continue;int best=note.pitch,distance=128;for(int pitch=track.role=="Bass"?24:48;pitch<=(track.role=="Bass"?60:84);++pitch){bool fits=track.role=="Bass"?(pitch%12==c.root):std::find(c.intervals.begin(),c.intervals.end(),(pitch-c.root+12)%12)!=c.intervals.end();int d=std::abs(pitch-note.pitch);if(fits&&d<distance){best=pitch;distance=d;}}note.pitch=best;changed=true;}}
            if(!replaceDrums)continue;
            const char*key=track.role=="Kick"?"kick":track.role=="Snare"?"snare":track.role=="Closed Hat"?"hat":nullptr;if(!key)continue;auto*pattern=row[key].getArray();if(!pattern||pattern->size()!=16)continue;int hits=0;for(auto&v:*pattern)if(double(v)>.05)++hits;if(hits<2)continue;
            track.notes.erase(std::remove_if(track.notes.begin(),track.notes.end(),[&](auto&n){return n.tick>=b*ticks&&n.tick<(b+1)*ticks;}),track.notes.end());
            for(int step=0;step<16;++step)if(double((*pattern)[step])>.05){music::Note note;note.id=track.id+":reference:"+juce::String(b)+":"+juce::String(step);note.pitch=music::gmDrumNote(track.role);note.channel=10;note.tick=b*ticks+step*ticks/16;note.duration=ticks/32;note.velocity=juce::jlimit(45,120,int(70+40*std::sqrt(double((*pattern)[step]))));track.notes.push_back(note);}++rhythmic;
        }if(changed)++harmonised;
    }
    // Keep note ordering deterministic for renderers and manual editing.
    for(auto&track:next.tracks){if(track.midiLocked)continue;std::stable_sort(track.notes.begin(),track.notes.end(),[](auto&a,auto&b){return a.tick<b.tick;});if(track.role=="Chords"){
        std::set<std::pair<int64_t,int>>seen;track.notes.erase(std::remove_if(track.notes.begin(),track.notes.end(),[&](auto&n){return !seen.emplace(n.tick,n.pitch).second;}),track.notes.end());}}
    auto result=music::validate(next);if(result.failed())return result;result=music::verifyLockedContent(project,next);if(result.failed())return result;project=std::move(next);notices.add("Reference guidance: "+juce::String(harmonised)+" harmonic bars and "+juce::String(rhythmic)+" drum-bar patterns. Uncertain passages retain the generated arrangement; this is not exact transcription.");return juce::Result::ok();
}
}
