#pragma once
#include <juce_core/juce_core.h>
#include <array>
#include <cstdint>
#include <cstring>
#include <cmath>
#include <type_traits>
#include <limits>
#if JUCE_WINDOWS
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
namespace atlas::hosting::audioipc {
constexpr uint32_t version=3,magic=0x44414131,capacity=16,maxFrames=1024,maxMidi=256,maxAutomation=64,pipelineBlocks=4;
struct alignas(64) Counter {volatile LONG value;};
inline uint32_t load(Counter&value)noexcept{return uint32_t(InterlockedCompareExchange(&value.value,0,0));}
inline void store(Counter&value,uint32_t next)noexcept{InterlockedExchange(&value.value,LONG(next));}
inline void increment(Counter&value)noexcept{InterlockedIncrement(&value.value);}
struct MidiEvent {uint16_t offset;uint8_t size;uint8_t data[3];};
struct AutomationEvent {uint32_t parameter;uint16_t offset,rampSamples;float value;};
struct Transport {int64_t samplePosition;double seconds,ppq,bpm,loopStart,loopEnd;uint32_t numerator,denominator,playing,recording,looping;};
inline int64_t advanceHostPosition(int64_t position, int frames) noexcept {
    const auto count = int64_t(std::max(0, frames));
    return position > std::numeric_limits<int64_t>::max() - count ? std::numeric_limits<int64_t>::max() : position + count;
}
struct Packet {uint64_t blockId;uint32_t epoch,frames,midiCount,automationCount;Transport transport;std::array<MidiEvent,maxMidi>midi;std::array<AutomationEvent,maxAutomation>automation;float audio[2][maxFrames];};
template<class T>struct Queue {Counter written,read;std::array<T,capacity>slots;};
struct Region {uint32_t magicValue,protocol,bytes,blockSize;double sampleRate;Counter ready,epoch,underruns,overruns,invalidSamples,clippedSamples,midiDrops,protocolErrors,pluginFailures,heartbeat,processing,lastBlockMicros,peakBlockMicros,overBudgetBlocks,timedBlocks;Queue<Packet>input,output;};
// Single worker writer. Wall time includes plugin/effect processing and callback-lock waits,
// but excludes idle queue waits. Exceeding a block budget does not itself prove an underrun.
inline void recordBlockTime(Region& region, double milliseconds) noexcept {
    if (!std::isfinite(milliseconds) || milliseconds < 0) return;
    const double micros = std::ceil(milliseconds * 1000.);
    const auto bounded = micros >= double(std::numeric_limits<uint32_t>::max()) ? std::numeric_limits<uint32_t>::max() : uint32_t(micros);
    store(region.lastBlockMicros,bounded);
    if (bounded > load(region.peakBlockMicros)) store(region.peakBlockMicros,bounded);
    if (std::isfinite(region.sampleRate) && region.sampleRate > 0 && region.blockSize > 0
        && milliseconds > 1000. * region.blockSize / region.sampleRate) increment(region.overBudgetBlocks);
    increment(region.timedBlocks);
}
static_assert(std::is_standard_layout_v<Region>&&std::is_trivially_copyable_v<Region>);
static_assert(sizeof(LONG)==4&&alignof(Counter)>=4);
// Wire layout must be identical for the x64 DAW and the x86 bridge.
static_assert(sizeof(Transport)==72 && sizeof(Packet)==10592);
static_assert(offsetof(Packet,audio)==2400 && sizeof(Region)==340224);
template<class T>inline bool push(Queue<T>&queue,const T&packet)noexcept{
    auto written=load(queue.written),read=load(queue.read);if(uint32_t(written-read)>=capacity)return false;
    queue.slots[written%capacity]=packet;store(queue.written,written+1);return true;
}
template<class T>inline bool pop(Queue<T>&queue,T&packet)noexcept{
    auto read=load(queue.read),written=load(queue.written);auto count=uint32_t(written-read);if(!count||count>capacity)return false;
    packet=queue.slots[read%capacity];store(queue.read,read+1);return true;
}
inline bool valid(const Packet&p,uint32_t blockSize)noexcept{
    if(p.frames<1||p.frames>blockSize||p.frames>maxFrames||p.midiCount>maxMidi||p.automationCount>maxAutomation)return false;
    if(!std::isfinite(p.transport.bpm)||p.transport.bpm<1||p.transport.bpm>1000||!std::isfinite(p.transport.seconds)||!std::isfinite(p.transport.ppq)||!std::isfinite(p.transport.loopStart)||!std::isfinite(p.transport.loopEnd)||p.transport.numerator<1||p.transport.numerator>32||p.transport.denominator<1||p.transport.denominator>64)return false;
    if((p.transport.denominator&(p.transport.denominator-1))!=0||p.transport.playing>1||p.transport.recording>1||p.transport.looping>1)return false;
    if(p.transport.looping&&p.transport.loopEnd<=p.transport.loopStart)return false;
    for(uint32_t i=0;i<p.midiCount;++i){const auto&e=p.midi[i];auto type=e.data[0]&0xf0;auto expected=type==0xc0||type==0xd0?2:3;if(e.offset>=p.frames||e.size!=expected||type<0x80||type>0xe0||e.data[1]>127||(e.size==3&&e.data[2]>127))return false;}
    for(uint32_t i=0;i<p.automationCount;++i){const auto&e=p.automation[i];if(e.offset>=p.frames||!std::isfinite(e.value)||e.value<0||e.value>1||uint32_t(e.offset)+e.rampSamples>p.frames)return false;}
    return true;
}
class Mapping {
public:
    ~Mapping(){close();}
    Mapping()=default;Mapping(const Mapping&)=delete;Mapping&operator=(const Mapping&)=delete;
    juce::Result create(double rate,uint32_t block){
        close();if(!format(rate,block))return juce::Result::fail("Unsupported shared audio format");name="Local\\DrumAtlas-audio-"+juce::Uuid().toString();
        handle=CreateFileMappingW(INVALID_HANDLE_VALUE,nullptr,PAGE_READWRITE,0,DWORD(sizeof(Region)),name.toWideCharPointer());if(!handle||GetLastError()==ERROR_ALREADY_EXISTS){close();return juce::Result::fail("Cannot create unique shared audio mapping");}
        region=static_cast<Region*>(MapViewOfFile(handle,FILE_MAP_READ|FILE_MAP_WRITE,0,0,sizeof(Region)));if(!region){close();return juce::Result::fail("Cannot map audio buffers");}
        auto eventName=name+".wake";wakeEvent=CreateEventW(nullptr,FALSE,FALSE,eventName.toWideCharPointer());if(!wakeEvent){close();return juce::Result::fail("Cannot create audio wake event");}
        std::memset(region,0,sizeof(Region));region->magicValue=magic;region->protocol=version;region->bytes=sizeof(Region);region->sampleRate=rate;region->blockSize=block;store(region->epoch,1);store(region->ready,1);return juce::Result::ok();
    }
    juce::Result open(const juce::String&mappingName,double rate,uint32_t block){
        close();if(!mappingName.startsWith("Local\\DrumAtlas-audio-")||mappingName.length()>100||!format(rate,block))return juce::Result::fail("Invalid shared audio mapping request");
        handle=OpenFileMappingW(FILE_MAP_READ|FILE_MAP_WRITE,FALSE,mappingName.toWideCharPointer());if(!handle)return juce::Result::fail("Shared audio mapping is missing");region=static_cast<Region*>(MapViewOfFile(handle,FILE_MAP_READ|FILE_MAP_WRITE,0,0,sizeof(Region)));if(!region){close();return juce::Result::fail("Cannot open shared audio buffers");}
        if(load(region->ready)!=1||region->magicValue!=magic||region->protocol!=version||region->bytes!=sizeof(Region)||region->sampleRate!=rate||region->blockSize!=block){close();return juce::Result::fail("Shared audio protocol or format mismatch");}auto eventName=mappingName+".wake";wakeEvent=OpenEventW(SYNCHRONIZE|EVENT_MODIFY_STATE,FALSE,eventName.toWideCharPointer());if(!wakeEvent){close();return juce::Result::fail("Audio wake event is missing");}name=mappingName;return juce::Result::ok();
    }
    void wake()noexcept{if(wakeEvent)SetEvent(wakeEvent);}
    void wait(int milliseconds)noexcept{if(wakeEvent)WaitForSingleObject(wakeEvent,DWORD(milliseconds));}
    void close(){if(wakeEvent){CloseHandle(wakeEvent);wakeEvent=nullptr;}if(region){UnmapViewOfFile(region);region=nullptr;}if(handle){CloseHandle(handle);handle=nullptr;}name.clear();}
    Region*get()const noexcept{return region;}
    juce::String getName()const{return name;}
private:
    static bool format(double rate,uint32_t block){return (rate==44100||rate==48000||rate==96000)&&(block==64||block==128||block==256||block==512||block==1024);}
    HANDLE handle=nullptr,wakeEvent=nullptr;Region*region=nullptr;juce::String name;
};
}
#endif
