#pragma once
#include <juce_core/juce_core.h>
#include <optional>
#include <vector>
#include <cstring>

namespace atlas::hosting {
// Inspect PE exports without executing the DLL. Dependent runtime DLLs must not
// become catalogue entries simply because they share a plugin directory.
inline bool hasVst2EntryPoint(const juce::File& file) {
    juce::FileInputStream input(file);
    const auto length = file.getSize();
    if (!input.openedOk() || length < 64 || input.readShort() != 0x5a4d) return false;
    input.setPosition(0x3c);
    const auto pe = juce::uint32(input.readInt());
    if (pe > length - 24 || !input.setPosition(pe) || input.readInt() != 0x4550) return false;
    input.readShort();
    const auto sections = juce::uint16(input.readShort());
    input.setPosition(pe + 20);
    const auto optionalSize = juce::uint16(input.readShort());
    const auto flags = juce::uint16(input.readShort());
    const auto optional = juce::int64(pe) + 24;
    if (!(flags & 0x2000) || sections == 0 || sections > 96 || optionalSize < 112
        || optional + optionalSize + sections * 40 > length) return false;
    const auto magic = juce::uint16(input.readShort());
    const int directoryOffset = magic == 0x20b ? 112 : magic == 0x10b ? 96 : -1;
    if (directoryOffset < 0 || optionalSize < directoryOffset + 8) return false;
    input.setPosition(optional + directoryOffset - 4);
    if (juce::uint32(input.readInt()) < 1) return false;
    const auto exportsRva = juce::uint32(input.readInt());
    struct Section { juce::uint32 rva, bytes, offset; };
    std::vector<Section> map;
    for (int i = 0; i < sections; ++i) {
        input.setPosition(optional + optionalSize + i * 40 + 12);
        Section section;
        section.rva = juce::uint32(input.readInt());
        section.bytes = juce::uint32(input.readInt());
        section.offset = juce::uint32(input.readInt());
        if (juce::int64(section.offset) + section.bytes > length) return false;
        map.push_back(section);
    }
    auto offsetFor = [&](juce::uint32 rva, juce::uint32 count) -> std::optional<juce::int64> {
        for (const auto& section : map) {
            if (rva >= section.rva && juce::uint64(rva - section.rva) + count <= section.bytes)
                return juce::int64(section.offset) + (rva - section.rva);
        }
        return {};
    };
    auto exports = offsetFor(exportsRva, 40);
    if (!exports) return false;
    input.setPosition(*exports + 24);
    const auto names = juce::uint32(input.readInt());
    input.readInt();
    const auto namesRva = juce::uint32(input.readInt());
    if (names > 65536) return false;
    auto table = offsetFor(namesRva, names * 4);
    if (!table) return false;
    for (juce::uint32 i = 0; i < names; ++i) {
        input.setPosition(*table + i * 4);
        const auto nameRva = juce::uint32(input.readInt());
        for (const auto* expected : {"VSTPluginMain", "main"}) {
            const auto size = int(std::strlen(expected)) + 1;
            auto position = offsetFor(nameRva, juce::uint32(size));
            if (!position) continue;
            input.setPosition(*position);
            char buffer[14]{};
            if (input.read(buffer, size) == size && std::memcmp(buffer, expected, size) == 0) return true;
        }
    }
    return false;
}
}
