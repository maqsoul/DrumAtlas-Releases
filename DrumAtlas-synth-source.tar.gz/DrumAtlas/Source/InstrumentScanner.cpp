#include "InstrumentScanner.h"
#include "WorkerArchitecture.h"
#include "Vst2Module.h"
#include "InstrumentProbeCache.h"
#include <juce_cryptography/juce_cryptography.h>
#include <set>
#include <filesystem>
#include <future>
#include "ScanDigestIndex.h"
namespace atlas::hosting {
ScanResult scan(const juce::File&worker,const juce::File&plugin,const juce::File&scratch,int timeout,bool probe,const std::function<bool()>&cancel,const std::function<void()>&slow,const juce::String&probeUid){
    if(cancel&&cancel())return {"cancelled","Scan cancelled",{}};
    if(!worker.existsAsFile()||!plugin.exists()||timeout<1||timeout>120000)return {"error","Worker/plugin missing or invalid timeout",{}};
    if(scratch.createDirectory().failed())return {"error","Cannot create scanner scratch directory",{}};
    const auto selectedWorker=workerForModule(worker,plugin);if(!selectedWorker.existsAsFile())return {"error","AtlasWorker32.exe is missing; install the x86 bridge",{}};
    const auto id=juce::Uuid().toString();const auto output=scratch.getChildFile("scan-"+id+".json");struct Cleanup{juce::File file;~Cleanup(){file.deleteFile();}}cleanup{output};juce::ChildProcess child;
    // No shell string: paths containing spaces are separate process arguments.
    juce::StringArray arguments{selectedWorker.getFullPathName(),probe?"--probe":"--scan",plugin.getFullPathName(),output.getFullPathName(),id};if(probe&&probeUid.isNotEmpty())arguments.add(probeUid);
    if(!child.start(arguments,0))return {"error","Cannot launch scanner",{}};
    auto started=juce::Time::getMillisecondCounterHiRes();bool notified=false;
    while(!child.waitForProcessToFinish(20)){if(cancel&&cancel()){child.kill();child.waitForProcessToFinish(2000);return {"cancelled","Scan cancelled",{}};}double elapsed=juce::Time::getMillisecondCounterHiRes()-started;if(!notified&&elapsed>5000){notified=true;if(slow)slow();}if(elapsed>=timeout){child.kill();child.waitForProcessToFinish(2000);return {"quarantined","Scanner timed out",{}};}}

    if(child.getExitCode()!=0)return {"quarantined","Scanner exited abnormally: "+juce::String(child.getExitCode()),{}};
    if(!output.existsAsFile()||output.getSize()>4*1024*1024)return {"error","Invalid scanner response size",{}};
    auto response=juce::JSON::parse(output);output.deleteFile();
    if(int(response["protocol"])!=1||response["request_id"].toString()!=id||response["operation"].toString()!=(probe?"PROBE":"SCAN"))return {"error","Scanner protocol mismatch",{}};
    const auto status=response["status"].toString();if(status!="scanned"&&status!="not_found"&&status!="error"&&status!="probed"&&status!="silent")return {"error","Invalid scanner status",{}};
    return {status,response["error"].toString(),response["plugins"],response};
}

namespace {
juce::String canonicalPath(const juce::File&file){std::error_code error;auto path=std::filesystem::weakly_canonical(std::filesystem::u8path(file.getFullPathName().toStdString()),error);auto result=error?file.getFullPathName():juce::String::fromUTF8(path.u8string().c_str());
#if JUCE_WINDOWS
return result.toLowerCase();
#else
return result;
#endif
}
juce::String fingerprint(const juce::File&plugin,const std::function<bool()>&cancel,ScanDigestIndex* index=nullptr){
 juce::Array<juce::File>files;juce::StringArray metadata;std::set<juce::String>visited;files.add(plugin);juce::int64 hashedBytes=0;
 for(int i=0;i<files.size();++i){if((cancel&&cancel())||files.size()>100000)return {};auto file=files[i];auto path=canonicalPath(file);if(!visited.insert(path).second)continue;
  if(file.isDirectory()){for(auto child:file.findChildFiles(juce::File::findFilesAndDirectories,false))files.add(child);}
  else if(file.existsAsFile()){
   const auto size=file.getSize(),modified=file.getLastModificationTime().toMilliseconds();auto entry=path+"|"+juce::String(size)+"|"+juce::String(modified);
#if JUCE_WINDOWS
   // Explicit background VST scan only. Sample libraries are not read here.
   // Byte signatures detect a replacement that preserves size and timestamp.
   if(file.hasFileExtension("vst3;dll;exe")){
    if(size<0||size>4LL*1024*1024*1024-hashedBytes)return {};hashedBytes+=size;
    juce::String digest;
    try{digest=index?index->digest(file,path,cancel):contentSHA256(file,cancel);}catch(const std::exception&){return {};}
    if(digest.isEmpty()||(cancel&&cancel())||file.getSize()!=size||file.getLastModificationTime().toMilliseconds()!=modified)return {};entry+="|sha256:"+digest;
   }
#endif
   metadata.add(entry);
  }
 }
 metadata.sort(false);auto text="module-signature-v2\n"+metadata.joinIntoString("\n");return juce::SHA256(text.toRawUTF8(),size_t(text.getNumBytesAsUTF8())).toHexString();
}
}
static ProbeContext workerContext(const juce::File&worker,const std::function<bool()>&cancel,ScanDigestIndex*index){auto stamp=worker.existsAsFile()?fingerprint(worker,cancel,index):juce::String();
#if JUCE_WINDOWS
if(stamp.isNotEmpty()){auto bridge=worker32File(worker);auto bridgeStamp=bridge.existsAsFile()?fingerprint(bridge,cancel,index):juce::String("missing-x86");auto combined=stamp+"|"+bridgeStamp;stamp=juce::SHA256(combined.toRawUTF8(),size_t(combined.getNumBytesAsUTF8())).toHexString();}
#endif
return {stamp,juce::SystemStats::getOperatingSystemName()+" / "+juce::SystemStats::getCpuVendor()+" / "+juce::String(int(sizeof(void*)*8))+" bit / "+juce::SystemStats::getJUCEVersion()};}
ProbeContext probeContext(const juce::File&worker,const std::function<bool()>&cancel){return workerContext(worker,cancel,nullptr);}
juce::Array<juce::File>defaultRoots(){
#if JUCE_WINDOWS
juce::Array<juce::File> roots{juce::File::getSpecialLocation(juce::File::windowsProgramFilesCommon).getChildFile("VST3"),juce::File::getSpecialLocation(juce::File::windowsLocalAppData).getChildFile("Programs/Common/VST3"),juce::File::getSpecialLocation(juce::File::globalApplicationsDirectory).getChildFile("VstPlugins"),juce::File::getSpecialLocation(juce::File::globalApplicationsDirectory).getChildFile("Steinberg/VstPlugins")};
auto x86=juce::SystemStats::getEnvironmentVariable("ProgramFiles(x86)",{});
if(juce::File::isAbsolutePath(x86)){roots.addIfNotAlreadyThere(juce::File(x86).getChildFile("VstPlugins"));roots.addIfNotAlreadyThere(juce::File(x86).getChildFile("Steinberg/VstPlugins"));}
return roots;
#elif JUCE_MAC
return {juce::File::getSpecialLocation(juce::File::userHomeDirectory).getChildFile("Library/Audio/Plug-Ins/VST3"),juce::File("/Library/Audio/Plug-Ins/VST3")};
#else
return {};
#endif
}
juce::Result discover(const juce::Array<juce::File>&roots,juce::Array<juce::File>&modules,const std::function<bool()>&cancel){
    juce::Array<juce::File> pending=roots,found;std::set<juce::String> seen;
    for(int i=0;i<pending.size();++i){
        if(cancel&&cancel())return juce::Result::fail("Scan cancelled");
        if(pending.size()>100000)return juce::Result::fail("Discovery exceeded 100000 candidate paths; choose a smaller plugin folder");
        const auto file=pending[i];
        if(!file.exists()||!seen.insert(canonicalPath(file)).second)continue;
        if(file.hasFileExtension("vst3")){found.add(file);continue;}
        if(file.isDirectory()){
            for(const auto& child:juce::RangedDirectoryIterator(file,false,"*",juce::File::findFilesAndDirectories)){
                if(cancel&&cancel())return juce::Result::fail("Scan cancelled");
                const auto path=child.getFile();
                if(child.isDirectory()||path.hasFileExtension("vst3")
#if JUCE_WINDOWS
                   ||path.hasFileExtension("dll")
#endif
                )pending.add(path);
            }
        }
#if JUCE_WINDOWS
        else if(file.hasFileExtension("dll")&&hasVst2EntryPoint(file))found.add(file);
#endif
    }
    modules.swapWith(found);return juce::Result::ok();
}
static ScanResult scanOne(const juce::File&worker,const juce::File&plugin,const juce::File&cache,bool force,int timeout,const std::function<bool()>&cancel,const std::function<void()>&slow,bool probe,const juce::String&probeUid,ScanDigestIndex*index,const ProbeContext*batchContext){
 if(cancel&&cancel())return {"cancelled","Scan cancelled",{}};if(!plugin.exists())return {"error","Plugin missing",{}};auto path=canonicalPath(plugin);auto stamp=fingerprint(plugin,cancel,index);if(stamp.isEmpty())return {cancel&&cancel()?"cancelled":"error","Cannot fingerprint plugin",{}};
 auto context=batchContext?*batchContext:probeContext(worker,cancel);auto workerStamp=context.workerFingerprint;auto environment=context.environment;if(cancel&&cancel())return {"cancelled","Scan cancelled",{}};
 auto key=juce::SHA256(path.toRawUTF8(),size_t(path.getNumBytesAsUTF8())).toHexString();auto recordFile=cache.getChildFile(key+".json");
 juce::var previous;if(recordFile.existsAsFile()&&recordFile.getSize()<=4*1024*1024)previous=juce::JSON::parse(recordFile);
 bool sameContext=workerStamp.isNotEmpty()&&previous["worker_fingerprint"].toString()==workerStamp&&previous["environment"].toString()==environment;
 if(!force&&!probe&&previous.isObject()){auto record=previous;auto status=record["status"].toString();if(int(record["schema"])==2&&record["path"].toString()==path&&record["fingerprint"].toString()==stamp&&(sameContext||workerStamp.isEmpty())&&(status=="quarantined"||((status=="scanned"||status=="not_found")&&record["plugins"].isArray()))){auto rows=record["plugins"].clone();auto report=record["report"].clone();if(!sameContext){invalidateProbeContext(rows,"The current DrumAtlas worker cannot be verified.");report=juce::var();}return {status,record["error"].toString(),rows,report,true};}}
 auto result=scan(worker,plugin,cache.getChildFile("scratch"),timeout,probe,cancel,slow,probeUid);if(result.status=="probed"||result.status=="silent")result.status="scanned";if(probe&&result.status=="error"&&markFailedProbe(result.plugins,probeUid,result.error))result.status="scanned";if(result.status!="scanned"&&result.status!="not_found"&&result.status!="quarantined")return result;
 if(cancel&&cancel())return {"cancelled","Scan cancelled",{}};if(stamp!=fingerprint(plugin,cancel,index))return {"error","Plugin changed while scanning; scan again",{}};if(workerStamp.isEmpty()||workerStamp!=workerContext(worker,cancel,index).workerFingerprint)return {cancel&&cancel()?"cancelled":"error","Worker changed or could not be verified; scan again",{}};
 if(result.status=="scanned"){
  if(probe&&result.plugins.isArray())for(auto&row:*result.plugins.getArray())if(row.hasProperty("probe_status")&&row["probe_status"].toString()!="retest_required"&&(probeUid.isEmpty()||row["uid"].toString()==probeUid)){auto*object=row.getDynamicObject();object->setProperty("probe_worker_fingerprint",workerStamp);object->setProperty("probe_environment",environment);object->setProperty("probe_checked_at",juce::Time::getCurrentTime().toISO8601(true));object->removeProperty("probe_retest_reason");}
 auto evidence=previous.clone();if(!sameContext&&evidence.isObject()){auto rows=evidence["plugins"].clone();invalidateProbeContext(rows,"The DrumAtlas worker or operating environment changed since the previous check.");evidence.getDynamicObject()->setProperty("plugins",rows);}retainUnchangedProbeEvidence(evidence,path,stamp,result.plugins);markChangedProbeEvidence(evidence,path,stamp,result.plugins);

 }if(auto*report=result.report.getDynamicObject()){report->setProperty("worker_fingerprint",workerStamp);report->setProperty("environment",environment);}
 auto*o=new juce::DynamicObject;juce::var record(o);o->setProperty("schema",2);o->setProperty("worker_fingerprint",workerStamp);o->setProperty("environment",environment);o->setProperty("path",path);o->setProperty("fingerprint",stamp);o->setProperty("status",result.status);o->setProperty("error",result.error);o->setProperty("plugins",result.plugins.clone());o->setProperty("report",result.report.clone());o->setProperty("checked_at",juce::Time::getCurrentTime().toISO8601(true));auto text=juce::JSON::toString(record);if(text.getNumBytesAsUTF8()>4*1024*1024||cache.createDirectory().failed())return {"error","Cannot save scanner cache",{}};juce::TemporaryFile temporary(recordFile);if(!temporary.getFile().replaceWithText(text)||!temporary.overwriteTargetFileWithTemporary())return {"error","Cannot commit scanner cache",{}};return result;
}
ScanResult scanCached(const juce::File&worker,const juce::File&plugin,const juce::File&cache,bool force,int timeout,const std::function<bool()>&cancel,const std::function<void()>&slow,bool probe,const juce::String&probeUid){return scanOne(worker,plugin,cache,force,timeout,cancel,slow,probe,probeUid,nullptr,nullptr);}
juce::Result scanCatalogue(const juce::File&worker,const juce::Array<juce::File>&modules,const juce::File&cache,
                           std::vector<ScanResult>&results,const std::function<bool()>&cancel,
                           const std::function<void(int,const juce::String&)>&progress){
    if(modules.isEmpty()){results.clear();return juce::Result::ok();}
    ScanDigestIndex index(cache);
    const auto context=workerContext(worker,cancel,&index);
    std::vector<ScanResult> scanned(size_t(modules.size()));
    std::atomic<int> next{0};std::mutex progressLock;int finished=0;
    auto run=[&]{
        while(!cancel||!cancel()){
            int i=next.fetch_add(1);if(i>=modules.size())break;
            auto& file=modules.getReference(i);
            scanned[size_t(i)]=scanOne(worker,file,cache,false,30000,cancel,{},false,{},&index,&context);
            std::lock_guard<std::mutex> lock(progressLock);++finished;
            if(progress)progress(finished,file.getFileName());
        }
    };
    int lanes=std::min({3,modules.size(),std::max(1,juce::SystemStats::getNumCpus()/2)});
    if(MemoryAdmission::check(3LL*1024*1024*1024).failed())lanes=1;
    std::vector<std::future<void>> jobs;
    for(int i=1;i<lanes;++i)jobs.push_back(std::async(std::launch::async,run));
    run();for(auto& job:jobs)job.get();
    index.save();
    if(cancel&&cancel())return juce::Result::fail("Scan cancelled");
    if(workerContext(worker,cancel,&index).workerFingerprint!=context.workerFingerprint)
        return juce::Result::fail("Worker changed during discovery; scan again");
    results.swap(scanned);return juce::Result::ok();
}
juce::Result testIsolation(const juce::File&worker){
    juce::ChildProcess crash;if(!crash.start(juce::StringArray{worker.getFullPathName(),"--test-crash"},0)||!crash.waitForProcessToFinish(5000)||crash.getExitCode()!=66)return juce::Result::fail("Crash fixture failed");
    juce::ChildProcess hang;if(!hang.start(juce::StringArray{worker.getFullPathName(),"--test-hang"},0))return juce::Result::fail("Hang fixture failed");
    if(hang.waitForProcessToFinish(200))return juce::Result::fail("Hang fixture exited unexpectedly");if(!hang.kill()||!hang.waitForProcessToFinish(3000))return juce::Result::fail("Watchdog could not terminate worker");return juce::Result::ok();
}
}
