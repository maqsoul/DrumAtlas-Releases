#pragma once
#include <juce_audio_formats/juce_audio_formats.h>
#include <cmath>
#include <vector>
#include <limits>
#include <stdexcept>

namespace atlas {
// Seconds from integer source frames may round a few ULPs above that integer
// on multiplication back to samples. Do not append a spurious silent sample.
inline juce::int64 stemFrameCount(double duration,double rate){
 const double frames=duration*rate;
 if(!std::isfinite(frames)||frames<0||frames>double(std::numeric_limits<juce::int64>::max())/2)throw std::runtime_error("Invalid stem duration");
 const double nearest=std::round(frames),tolerance=4*std::numeric_limits<double>::epsilon()*std::max(1.0,frames);
 return juce::int64(std::abs(frames-nearest)<=tolerance?nearest:std::ceil(frames));
}
// Band-limited, zero-phase conversion for model input. Absolute output positions
// keep overlapping chunks sample-aligned; the reader never accesses audio outside
// the selection. Storage is bounded by a model chunk, not by the song duration.
class StemResampler {
public:
 StemResampler(juce::AudioFormatReader& source, double outputRate, double start, double end)
 : reader(source), ratio(source.sampleRate/outputRate), origin(start*source.sampleRate) {
  if(!std::isfinite(ratio)||ratio<=0||ratio>32||!std::isfinite(origin)||start<0||!std::isfinite(end)||end<start
      ||end*source.sampleRate>double(std::numeric_limits<juce::int64>::max())/2)
   throw std::runtime_error("Invalid stem sample rate or selection");
  first=std::max<juce::int64>(0,juce::int64(std::ceil(origin)));
  last=std::min(source.lengthInSamples,juce::int64(std::ceil(end*source.sampleRate)));
  direct=ratio==1.0 && origin==std::floor(origin);
  if(direct)return;
  const double cutoff=std::min(1.0,1.0/ratio)*.94;
  radius=int(std::ceil(48/cutoff)); taps=2*radius;
  kernel.resize(size_t(phases+1)*taps);
  for(int phase=0;phase<=phases;++phase){
   double sum=0,frac=double(phase)/phases;
   for(int j=0;j<taps;++j){double x=j-radius+1-frac, y=x/radius;
    double w=std::abs(y)<1?.42+.5*std::cos(pi*y)+.08*std::cos(2*pi*y):0;
    double value=std::abs(x)<1e-12?cutoff:std::sin(pi*cutoff*x)/(pi*x);
    kernel[size_t(phase)*taps+j]=float(value*w);sum+=value*w;
   }
   for(int j=0;j<taps;++j)kernel[size_t(phase)*taps+j]/=float(sum);
  }
 }
 std::vector<float> read(juce::int64 position,int count,int padded,int channels){
  if(position<0||count<0||padded<count||(channels!=1&&channels!=2))throw std::runtime_error("Invalid stem input block");
  std::vector<float> result(size_t(padded)*channels,0.f);if(count==0)return result;
  const double begin=origin+double(position)*ratio;
  const auto base=juce::int64(std::floor(begin))-radius;
  const auto finish=juce::int64(std::floor(origin+double(position+count-1)*ratio))+radius+2;
  if(finish-base>std::numeric_limits<int>::max())throw std::runtime_error("Stem input block too large");
  juce::AudioBuffer<float> raw(2,int(finish-base));raw.clear();
  auto lo=std::max(first,base),hi=std::min(last,finish);
  if(hi>lo&&!reader.read(&raw,int(lo-base),int(hi-lo),lo,true,true))throw std::runtime_error("Cannot read stem source");
  if(channels==1)for(int i=0;i<raw.getNumSamples();++i)raw.setSample(0,i,.5f*(raw.getSample(0,i)+raw.getSample(1,i)));
  for(int i=0;i<count;++i){
   const double at=origin+double(position+i)*ratio;const auto center=juce::int64(std::floor(at));
   if(direct){for(int c=0;c<channels;++c)result[size_t(c)*padded+i]=raw.getSample(c,int(center-base));continue;}
   double phase=(at-double(center))*phases;int p=std::min(phases-1,int(phase));float mix=float(phase-p);
   const float* a=kernel.data()+size_t(p)*taps;const float* b=a+taps;
   for(int c=0;c<channels;++c){const float* src=raw.getReadPointer(c,int(center-radius+1-base));double sum=0;
    for(int j=0;j<taps;++j)sum+=double(src[j])*(a[j]+mix*(b[j]-a[j]));
    result[size_t(c)*padded+i]=float(sum);
   }
  }
  return result;
 }
private:
 static constexpr int phases=2048;static constexpr double pi=3.14159265358979323846;
 juce::AudioFormatReader& reader;double ratio,origin;juce::int64 first,last;
 bool direct=false;int radius=0,taps=0;std::vector<float>kernel;
};
}
