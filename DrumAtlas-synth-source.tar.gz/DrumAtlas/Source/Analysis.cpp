#include "Analysis.h"
#include <cmath>
#include <algorithm>
#include <numeric>

namespace atlas {
Decoded decode(juce::AudioFormatManager& fm, const juce::File& file, double start, double limit) {
    Decoded out;
    if(!ioFile(file).existsAsFile()){out.error="File is missing or unavailable";return out;}
    if(ioFile(file).getSize()==0){out.error="File is empty (0 bytes)";return out;}
    std::unique_ptr<juce::AudioFormatReader> reader(fm.createReaderFor(ioFile(file)));
    if (!reader || reader->sampleRate < 1000 || reader->sampleRate > 768000 || reader->numChannels == 0) {
        out.error = decoderError().isNotEmpty()?decoderError():"Unsupported codec or damaged audio header"; return out;
    }
    out.duration = double(reader->lengthInSamples) / reader->sampleRate;
    const auto offset = juce::jlimit<juce::int64>(0, reader->lengthInSamples, juce::int64(start * reader->sampleRate));
    const auto count = int(std::min<juce::int64>(reader->lengthInSamples - offset, juce::int64(limit * reader->sampleRate)));
    if (count < 1) { out.error = "Empty audio segment"; return out; }
    juce::AudioBuffer<float> raw(2, count);
    if (!reader->read(&raw, 0, count, offset, true, true)) { out.error = "Audio read failed"; return out; }
    // Use the channel with most energy: avoids cancellation in out-of-phase stereo.
    const int channel = raw.getRMSLevel(1, 0, count) > raw.getRMSLevel(0, 0, count) ? 1 : 0;
    const auto* p = raw.getReadPointer(channel);
    const int n = std::max(1, int(double(count) * analysisRate / reader->sampleRate));
    out.mono.resize(size_t(n));
    for (int i = 0; i < n; ++i) {
        const double pos = i * reader->sampleRate / analysisRate;
        const int a = std::min(count - 1, int(pos)), b = std::min(count - 1, a + 1);
        out.mono[size_t(i)] = float(p[a] + (p[b] - p[a]) * (pos - a));
    }
    return out;
}

Features describe(const std::vector<float>& input) {
    Features f;
    if (input.empty()) return f;
    for (auto v : input) f.peak = std::max(f.peak, std::abs(v));
    if (f.peak < 1.0e-6f) return f;
    size_t first = 0, last = input.size();
    while (first < last && std::abs(input[first]) < f.peak * 0.015f) ++first;
    while (last > first && std::abs(input[last - 1]) < f.peak * 0.008f) --last;
    f.duration = float(last - first) / float(analysisRate);
    const size_t n = std::min(last - first, size_t(analysisRate * 0.75));
    if (n < 16) return f;
    double early = 0, late = 0;
    int crossings = 0;
    for (size_t i = 0; i < n; ++i) {
        const double v = input[first + i] / f.peak;
        (i < n / 3 ? early : late) += v * v;
        if (i && (input[first + i] >= 0) != (input[first + i - 1] >= 0)) ++crossings;
    }
    f.tail = float(late / (2 * early + 1e-12));
    f.zcr = float(crossings) / float(n);
    constexpr int size = 2048;
    thread_local juce::dsp::FFT fft(11);
    std::array<float, size * 2> data{};
    std::array<double, size / 2 + 1> spectrum{};
    const int frames = std::min(24, std::max(1, int(n / 512)));
    for (int frame = 0; frame < frames; ++frame) {
        data.fill(0);
        const size_t pos = frames == 1 ? 0 : size_t(frame) * (n > size ? n - size : 0) / size_t(frames - 1);
        for (int i = 0; i < size && pos + size_t(i) < n; ++i)
            data[size_t(i)] = input[first + pos + size_t(i)] / f.peak * float(0.5 - 0.5 * std::cos(juce::MathConstants<double>::twoPi * i / (size - 1)));
        fft.performFrequencyOnlyForwardTransform(data.data());
        for (int k = 1; k <= size / 2; ++k) spectrum[size_t(k)] += double(data[size_t(k)]) * data[size_t(k)];
    }
    constexpr std::array<double, 13> edges{20, 60, 100, 180, 300, 500, 800, 1300, 2200, 3600, 5600, 8000, 11026};
    double total = 1e-18, weighted = 0, logs = 0;
    for (int k = 1; k <= size / 2; ++k) {
        const double hz = k * analysisRate / size, e = spectrum[size_t(k)] + 1e-18;
        total += e; weighted += hz * e; logs += std::log(e);
        for (size_t b = 0; b < f.bands.size(); ++b)
            if (hz >= edges[b] && hz < edges[b + 1]) { f.bands[b] += float(e); break; }
    }
    for (auto& v : f.bands) v = float(std::sqrt(v / total));
    f.centroid = float(weighted / total);
    f.flatness = float(std::exp(logs / (size / 2)) / (total / (size / 2)));
    return f;
}

std::vector<int> onsets(const std::vector<float>& x) {
    constexpr int hop = 220;
    std::vector<float> envelope;
    for (size_t p = 0; p + hop <= x.size(); p += hop) {
        double sum = 0;
        for (int i = 0; i < hop; ++i) sum += double(x[p + size_t(i)]) * x[p + size_t(i)];
        envelope.push_back(float(std::sqrt(sum / hop)));
    }
    std::vector<int> result;
    if (envelope.empty()) return result;
    const auto peak = *std::max_element(envelope.begin(), envelope.end());
    if (peak < 1e-6f) return result;
    float baseline = 0;
    int last = -12;
    for (int i = 0; i < int(envelope.size()); ++i) {
        const auto v = envelope[size_t(i)];
        const auto prev = i ? envelope[size_t(i - 1)] : 0.0f;
        if (v > peak * 0.06f && v > baseline * 1.6f && v - prev > peak * 0.035f && i - last >= 9) {
            result.push_back(std::max(0, (i - 1) * hop)); last = i;
        }
        baseline = 0.85f * baseline + 0.15f * v;
    }
    return result;
}

juce::StringArray categories() {
    return {"Kick", "Snare", "Clap", "Closed Hat", "Open Hat", "Tom", "Rim", "Cymbal", "Percussion",
            "Bass", "Keys", "Guitar", "Strings", "Brass", "Synth", "Vocal", "Instrument", "FX", "Other", "Ride", "Crash", "Shaker", "Conga", "Bongo", "Tambourine", "Cowbell", "Claves", "Guiro", "Woodblock"};
}
bool isDrum(const juce::String& s) { const int i = categories().indexOf(s); return (i >= 0 && i < 9) || i >= 19; }

Label classify(const juce::String& filename, const Features& f, double duration, const std::vector<int>& hits) {
    Label label;
    auto name = filename.toLowerCase();
    for (auto ch : juce::String("_-./\\()[]0123456789")) name = name.replaceCharacter(ch, ' ');
    const auto words = juce::StringArray::fromTokens(name, " ", "");
    const auto has = [&](std::initializer_list<const char*> list) { for (auto* w : list) if (words.contains(w)) return true; return false; };
    bool regular = false;
    if (hits.size() >= 4 && duration > 1.2) {
        double mean = double(hits.back() - hits.front()) / (hits.size() - 1), variance = 0;
        for (size_t i = 1; i < hits.size(); ++i) variance += std::pow(hits[i] - hits[i - 1] - mean, 2);
        regular = std::sqrt(variance / (hits.size() - 1)) / std::max(1.0, mean) < 0.25;
    }
    if (has({"loop", "loops", "bpm", "groove", "break", "breakbeat"})) label.kind = "Loop";
    else if (regular) label.kind = "Loop?";
    else if (duration > 12) label.kind = "Long sample";
    const auto named=nameLabel(filename);
    if(named.method=="Filename tag"||named.method=="Ambiguous tag"){label.category=named.category;label.method=named.method;return label;}
    if (f.peak < 1e-6f) { label.method = "Silent / unknown"; return label; }
    float low = 0, high = 0;
    for (size_t i = 0; i < 4; ++i) low += f.bands[i] * f.bands[i];
    for (size_t i = 8; i < 12; ++i) high += f.bands[i] * f.bands[i];
    if (low > 0.70f && f.centroid < 650) label.category = f.duration < 0.85f && f.tail < 0.8f ? "Kick" : "Bass";
    else if (high > 0.62f && f.zcr > 0.20f) label.category = f.duration < 0.22f ? "Closed Hat" : "Open Hat";
    else if (f.flatness > 0.06f && f.duration < 0.9f && f.tail < 0.9f) label.category = "Snare";
    else if (f.flatness < 0.025f && f.duration > 0.3f) label.category = "Instrument";
    else if (f.duration < 1.0f && f.tail < 0.7f) label.category = "Percussion";
    if(excludedCategories(filename).contains(label.category)){label.category="Other";label.method="Excluded tag";}
    return label;
}

float distance(const Features& a, const Features& b) {
    if (a.peak < 1e-6f || b.peak < 1e-6f) return 1000;
    float d = 0;
    for (size_t i = 0; i < a.bands.size(); ++i) d += std::pow(a.bands[i] - b.bands[i], 2.0f);
    d += 0.12f * std::abs(a.zcr - b.zcr);
    d += 0.07f * std::abs(std::log1p(a.tail) - std::log1p(b.tail));
    d += 0.05f * std::abs(std::log(0.03f + a.duration) - std::log(0.03f + b.duration));
    if (a.embedding.size() == 1024 && b.embedding.size() == 1024) {
        double dot = 0, aa = 0, bb = 0;
        for (size_t i = 0; i < 1024; ++i) { const double x = a.embedding[i], y = b.embedding[i]; dot += x * y; aa += x * x; bb += y * y; }
        const float cosineDistance = float(1.0 - dot / std::sqrt(std::max(1e-20, aa * bb)));
        d = 0.65f * cosineDistance + 0.35f * std::min(1.0f, d);
    }
    return d;
}
float referenceDistance(const Features&a,const Features&b,const juce::String&category){
 if(!isDrum(category))return distance(a,b);
 // YAMNet describes the sound class; the spectrum/envelope distinguishes timbres within it.
 auto x=a,y=b;x.embedding.clear();y.embedding.clear();
 auto focus=[&](Features&f){double sum=0;for(size_t i=0;i<f.bands.size();++i){float weight=1;if(category=="Kick"&&i>=4)weight=.1f;else if((category=="Closed Hat"||category=="Open Hat"||category=="Cymbal")&&i<8)weight=.1f;f.bands[i]*=weight;sum+=f.bands[i]*f.bands[i];}for(auto&v:f.bands)v/=float(std::sqrt(std::max(1e-10,sum)));};focus(x);focus(y);
 return .8f*distance(x,y)+.2f*distance(a,b);
}
juce::var toJson(const Features& f) {
    auto* o = new juce::DynamicObject(); juce::Array<juce::var> bands;
    for (auto v : f.bands) bands.add(v);
    o->setProperty("bands", bands); o->setProperty("centroid", f.centroid); o->setProperty("flatness", f.flatness);
    o->setProperty("zcr", f.zcr); o->setProperty("tail", f.tail); o->setProperty("duration", f.duration); o->setProperty("peak", f.peak);
    if (!f.embedding.empty()) o->setProperty("embedding", juce::Base64::toBase64(f.embedding.data(), f.embedding.size()));
    return o;
}
Features fromJson(const juce::var& v) {
    Features f;
    if (auto* a = v["bands"].getArray()) for (int i = 0; i < std::min(12, a->size()); ++i) f.bands[size_t(i)] = float((*a)[i]);
    f.centroid = float(v["centroid"]); f.flatness = float(v["flatness"]); f.zcr = float(v["zcr"]);
    f.tail = float(v["tail"]); f.duration = float(v["duration"]); f.peak = float(v["peak"]);
    juce::MemoryOutputStream stream;
    if (juce::Base64::convertFromBase64(stream, v["embedding"].toString()) && stream.getDataSize() == 1024) {
        const auto* bytes = static_cast<const uint8_t*>(stream.getData()); f.embedding.assign(bytes, bytes + 1024);
    }
    return f;
}
}
