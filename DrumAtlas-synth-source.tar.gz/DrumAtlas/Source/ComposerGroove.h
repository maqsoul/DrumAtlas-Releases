#pragma once
#include "MusicCore.h"
#include <set>

namespace atlas::composer::groove {
// Only the explicit two-step family uses this grammar. Hybrids and other
// genres retain their own model pattern; a substring match would be too broad.
inline bool twoStep(const juce::String& style) {
    auto s=style.toLowerCase().trim().replace("-"," ");
    return s=="uk garage"||s=="ukg"||s=="2 step garage"||s=="two step garage"||s=="2 step";
}
inline void arrange(music::Project& p,const juce::var& pattern,juce::StringArray& notices) {
    if(!twoStep(p.settings.genre)||p.settings.numerator!=4||p.settings.denominator!=4)return;
    const auto bar=music::barTicks(p.settings),step=bar/16;
    const double swing=juce::jlimit(.12,.30,double(pattern["swing"]));
    auto section=[&](int b){if(auto* rows=p.sections.getArray())for(auto& s:*rows)if(b>=int(s["start"])&&b<int(s["start"])+int(s["bars"]))return s["name"].toString();return juce::String();};
    // Rank accents once per two-bar phrase, not independently on every bar.
    auto kicks=[&](int parity,bool chorus){
        std::vector<int> candidates{3,6,7,8,10,11,14,15};
        std::stable_sort(candidates.begin(),candidates.end(),[&](int a,int b){
            auto score=[&](int n){return double(pattern["kick"][n])+.16*double((p.settings.seed+uint32_t(n*13+parity*19))%11)/10.;};
            return score(a)>score(b);
        });
        std::vector<int> result{0};
        for(int n:candidates){bool space=true;for(int old:result)space&=std::abs(n-old)>1;if(space)result.push_back(n);if(result.size()==size_t(chorus?4:3))break;}
        // A syncopated answer must survive even with a four-on-the-floor plan.
        if(std::none_of(result.begin(),result.end(),[](int n){return n%4!=0;}))result.back()=parity?11:7;
        std::sort(result.begin(),result.end());return result;
    };
    for(auto& track:p.tracks) {
        if(track.midiLocked||track.notes.empty())continue;
        const auto old=track.notes;
        const bool drum=juce::StringArray{"Kick","Snare","Clap","Closed Hat","Open Hat","Percussion"}.contains(track.role);
        if(!drum&&track.role!="Bass"&&track.role!="Chords")continue;
        track.notes.clear();
        for(int b=0;b<p.settings.bars;++b){
            std::vector<music::Note> source;for(auto& n:old)if(n.tick>=b*bar&&n.tick<(b+1)*bar)source.push_back(n);
            if(source.empty()){
                // A random miss in the seed must not create a hole in a drum
                // phrase that the planner explicitly enabled for this section.
                bool enabled=false;if(drum)if(auto* rows=p.sections.getArray())for(auto& s:*rows)if(b>=int(s["start"])&&b<int(s["start"])+int(s["bars"]))if(auto* roles=s["active_roles"].getArray())for(auto& role:*roles)enabled|=role.toString()==track.role;
                if(!enabled)continue;
            }
            const auto name=section(b);const bool chorus=name=="Chorus"||name=="Drop";
            const bool light=name=="Intro"||name=="Outro"||name=="Breakdown";
            auto add=[&](int at,int velocity,int pitch,int64_t length,bool shuffled){
                music::Note n;n.id=track.id+":groove:"+juce::String(b)+":"+juce::String(int(track.notes.size()));
                n.tick=b*bar+at*step;n.microtiming=shuffled&&at%2?int64_t(step*swing):0;
                n.pitch=pitch;n.channel=drum?10:1;n.velocity=velocity;n.probability=1;
                n.duration=std::max<int64_t>(1,std::min(length,(b+1)*bar-n.tick-n.microtiming));track.notes.push_back(n);
            };
            auto kick=kicks(b%2,chorus);
            if(track.role=="Kick"){for(int n:kick)if(!light||n==0)add(n,n==0?108:94,36,step/2,true);}
            else if(track.role=="Snare"||track.role=="Clap"){
                for(int n:{4,12})add(n,track.role=="Clap"?70:104,music::gmDrumNote(track.role),step/2,false);
                if(chorus&&track.role=="Snare"&&b%4==3&&p.settings.complexity>.6)add(15,47,38,step/3,true);
            }else if(track.role=="Closed Hat"){
                std::set<int> hits{2,6,10,14};if(!light){hits.insert(0);hits.insert(8);hits.insert(b%2?11:3);}if(chorus){hits.insert(b%2?3:11);hits.insert(15);}
                for(int n:hits)add(n,n%4==2?78:n%2?48:62,42,step/3,true);
            }else if(track.role=="Open Hat"){if(chorus)add(b%2?14:6,65,46,step,true);}
            else if(track.role=="Percussion"){if(!light){add(b%2?11:3,58,64,step/2,true);if(chorus)add(15,46,64,step/2,true);}}
            else if(track.role=="Bass"){
                // Follow the kick phrase, leave gaps, and keep the planned harmony.
                std::vector<int> slots=light?std::vector<int>{0}:kick;
                if(chorus&&slots.back()<14)slots.push_back(14);
                for(size_t i=0;i<slots.size();++i){int n=slots[i];auto nearest=std::min_element(source.begin(),source.end(),[&](auto&a,auto&c){return std::abs(a.tick-(b*bar+n*step))<std::abs(c.tick-(b*bar+n*step));});
                    int next=i+1<slots.size()?slots[i+1]:16;add(n,n==0?95:84,nearest->pitch,std::min<int64_t>(step*(chorus?3:2),step*(next-n)-step/3),true);}
            }else if(track.role=="Chords"){
                // Reuse the actual voicing, with short syncopated stabs instead
                // of a sustained chord competing with every bass/hook event.
                std::vector<int> slots=light?std::vector<int>{2}:chorus?std::vector<int>{2,7,10}:std::vector<int>{2,10};
                for(int n:slots){auto nearest=std::min_element(source.begin(),source.end(),[&](auto&a,auto&c){return std::abs(a.tick-(b*bar+n*step))<std::abs(c.tick-(b*bar+n*step));});std::set<int> pitches;
                    for(auto& note:source)if(note.tick==nearest->tick)pitches.insert(note.pitch);
                    for(int pitch:pitches)add(n,chorus?73:62,pitch,step*(light?2:1),true);
                }
            }
        }
        std::stable_sort(track.notes.begin(),track.notes.end(),[](auto&a,auto&b){return a.tick+a.microtiming<b.tick+b.microtiming;});
    }
    notices.add("Two-step arrangement: stable two-bar drum phrases, backbeat on beats 2/4, swung subdivisions, sparse bass and short chord stabs. Sound and style quality still require listening.");
}
}
