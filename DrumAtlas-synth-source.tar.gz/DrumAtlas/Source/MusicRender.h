#pragma once
#include "MusicCore.h"
namespace atlas::music {
// Offline: assigned one-shots, isolated VST3 instruments, or original synthesis.
juce::Result renderWav(const Project&,const juce::File&,double sampleRate=44100,const std::function<bool()>&cancel={},juce::StringArray* warnings=nullptr);
struct StemExportOptions { double sampleRate=44100; int bits=24; bool perTrack=false; double unknownTailSeconds=0; bool balanceRoles=false; juce::var fixedBalance; };
// New folder only; aligned files, common gain and manifest. No partial bundle on failure.
juce::Result renderStems(const Project&,const juce::File&,const StemExportOptions& options={},const std::function<bool()>&cancel={},juce::StringArray* warnings=nullptr);
}
