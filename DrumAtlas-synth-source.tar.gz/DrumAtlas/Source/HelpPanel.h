#pragma once
#include "Locale.h"
#include "EmberTheme.h"
namespace atlas {
// Local illustrations are captured from real controls when help is opened.
// They are read-only pictures: clicking a guide never starts an audio job.
struct HelpExample {
 int topic=1;juce::String title,description;juce::Image image;bool selection=false;
};
class HelpPictureCard:public juce::Component {
public:
 HelpExample example;int number;
 HelpPictureCard(HelpExample e,int n):example(std::move(e)),number(n){setInterceptsMouseClicks(false,false);}
 void descriptionLayout(juce::TextLayout&layout,int width)const{juce::AttributedString text;text.append(example.description,ember::font(13),ember::muted);layout.createLayout(text,float(std::max(1,width)));}
 bool stacked(int width)const{return width<600||(example.image.isValid()&&example.image.getWidth()>example.image.getHeight()*7);}
 int heightFor(int width)const{juce::TextLayout layout;const bool narrow=stacked(width);descriptionLayout(layout,width-(narrow?32:266));return std::max(narrow?260:166,(narrow?144:64)+int(std::ceil(layout.getHeight())));}
 void paint(juce::Graphics&g)override{
  auto bounds=getLocalBounds().toFloat().reduced(.5f);ember::card(g,bounds,14);
  const bool narrow=stacked(getWidth());
  auto picture=narrow?juce::Rectangle<float>(16,48,float(getWidth()-32),66):juce::Rectangle<float>(16,44,210,100);
  g.setColour(ember::orange);g.fillEllipse(16,12,24,24);g.setColour(ember::background);g.setFont(ember::headingFont(12));g.drawText(juce::String(number),16,12,24,24,juce::Justification::centred);
  g.setColour(ember::text);g.setFont(ember::headingFont(15));g.drawFittedText(example.title,50,10,getWidth()-66,28,juce::Justification::centredLeft,1,.85f);
  if(example.selection){
   g.setColour(ember::muted.withAlpha(.8f));
   for(int i=0;i<48;++i){float x=picture.getX()+picture.getWidth()*i/48.f;float h=(.2f+.75f*std::abs(std::sin(i*.7f)))*picture.getHeight()*.65f;g.drawLine(x,picture.getCentreY()-h/2,x,picture.getCentreY()+h/2,2);}
   auto selected=picture.withTrimmedLeft(picture.getWidth()*.25f).withWidth(picture.getWidth()*.5f);g.setColour(ember::orange.withAlpha(.18f));g.fillRect(selected);g.setColour(ember::orange);g.drawRect(selected,1);
   const float y=picture.getBottom()-4;g.drawArrow(juce::Line<float>(selected.getX()+4,y,selected.getRight()-4,y),1.5f,7,7);
  }else if(example.image.isValid()){
   const float factor=std::min({picture.getWidth()/example.image.getWidth(),picture.getHeight()/example.image.getHeight(),.75f});
   auto target=juce::Rectangle<float>(example.image.getWidth()*factor,example.image.getHeight()*factor).withCentre(picture.getCentre());g.setOpacity(1);g.drawImage(example.image,target);
  }else{g.setColour(ember::orange);g.setFont(ember::font(14));g.drawFittedText(example.title,picture.toNearestInt(),juce::Justification::centred,2);}
  auto text=narrow?juce::Rectangle<int>(16,128,getWidth()-32,getHeight()-144):juce::Rectangle<int>(246,48,getWidth()-266,getHeight()-64);
  juce::TextLayout layout;descriptionLayout(layout,text.getWidth());layout.draw(g,text.toFloat());
 }
};
class HelpPictures:public juce::Component {
public:
 std::vector<HelpExample> examples;juce::OwnedArray<HelpPictureCard>cards;
 void showTopic(int topic){cards.clear();int number=0;for(auto&e:examples)if(e.topic==topic){auto*c=cards.add(new HelpPictureCard(e,++number));addAndMakeVisible(c);}layout(getWidth());}
 void layout(int width){int y=0;for(auto*c:cards){int h=c->heightFor(width);c->setBounds(0,y,width,h);y+=h+12;}setSize(width,std::max(1,y));}
};
class HelpPanel:public juce::Component {
public:
 std::function<void()>onClose;juce::TextButton close;juce::ComboBox topics;juce::TextEditor content;
 explicit HelpPanel(const juce::String&language,std::vector<HelpExample> examples={}):lang(language){
  pictures.examples=std::move(examples);addAndMakeVisible(viewport);viewport.setViewedComponent(&pictures,false);viewport.setScrollBarsShown(true,false);addAndMakeVisible(details);details.setButtonText(lang=="ru"?juce::String::fromUTF8("Подробный текст"):"Detailed text");details.setClickingTogglesState(true);details.onClick=[this]{resized();};addAndMakeVisible(hint);hint.setText(lang=="ru"?juce::String::fromUTF8("Картинки показывают элементы плагина. Листайте вниз — под каждым есть пояснение."):"Pictures show plugin controls. Scroll down to see what each one does.",juce::dontSendNotification);hint.setFont(ember::font(12));hint.setColour(juce::Label::textColourId,ember::muted);
  addAndMakeVisible(close);addAndMakeVisible(topics);addAndMakeVisible(content);close.setButtonText(tr("close",lang));close.onClick=[this]{if(onClose)onClose();};
  content.setMultiLine(true);content.setReadOnly(true);content.setScrollbarsShown(true);content.setCaretVisible(false);content.setFont(lang=="kk"?ember::font(15.f,lang):juce::Font(juce::FontOptions(15.f)));content.setColour(juce::TextEditor::backgroundColourId,juce::Colour(0xff181310));content.setColour(juce::TextEditor::textColourId,juce::Colour(0xfffff1e3));content.setIndents(18,16);
  for(auto title:{"guideStart","guideLibrary","guideReference","guideAudio","guideWindow"})topics.addItem(tr(title,lang),topics.getNumItems()+1);
  topics.addItem(tr("stemMidi",lang)+" / "+tr("exportStems",lang),6);
  topics.onChange=[this]{auto text=tr("guideBody"+juce::String(topics.getSelectedId()),lang);if(topics.getSelectedId()==3)text+="\n\n"+tr("guideSynth",lang);if(topics.getSelectedId()==5)text+="\n\n"+(lang=="ru"?juce::String::fromUTF8("Редактирование интерфейса: Вид / панели → Редактировать интерфейс (Ctrl+Alt+L). Выберите кнопку, подпись или панель и перетащите. Нижний правый угол меняет размер; X/Y/W/H задают точные координаты и размеры внутри родительской панели. Ползунок со знаком % меняет размер шрифта. Стрелки сдвигают элемент; Shift увеличивает шаг. Сохранить применяет изменения для текущего оформления, Отмена или Esc возвращает сохранённый вариант. Сброс темы восстанавливает исходное расположение только этой темы. Расположение сохраняется в настройках и проекте DAW."):juce::String("Interface editing: View / panels > Edit interface (Ctrl+Alt+L). Drag a button, caption or panel; drag its lower-right corner to resize. X/Y/W/H edit exact bounds within the parent panel. The % slider changes font size. Arrow keys nudge; Shift increases the step. Save applies the current theme, Cancel or Esc restores saved settings. Reset theme restores only this theme's defaults. Layouts persist in preferences and DAW projects."));if(topics.getSelectedId()==6)text=lang=="ru"?juce::String::fromUTF8("После разделения выберите стем. «Стем в MIDI» сохраняет ноты или удары. MIDI BPM — общий сохранённый темп для всех стемов данного референса: укажите темп проекта DAW и импортируйте клипы в одну позицию. Начальная и конечная тишина сохраняются. MIDI использует исходный стем, независимо от крутилок Pitch/Tempo предпрослушки."):juce::String("Select a separated stem. Stem to MIDI saves notes or drum hits. MIDI BPM is shared and remembered for all stems of the reference: use your DAW project tempo and place clips at the same position. Leading and trailing silence are kept. MIDI uses the original stem, independently of preview Pitch/Tempo knobs.");content.setText(text,false);content.moveCaretToTop(false);pictures.showTopic(topics.getSelectedId());viewport.setViewPosition(0,0);resized();};topics.setSelectedId(1);setComponentID("help-panel");
 }
 ~HelpPanel()override{topics.onChange=nullptr;details.onClick=nullptr;close.onClick=nullptr;viewport.setViewedComponent(nullptr,false);}
 void paint(juce::Graphics&g)override{g.fillAll(juce::Colour(0xff100d0c));}
 void resized()override{
  const int w=getWidth(),h=getHeight();topics.setBounds(16,12,std::max(80,w-152),34);close.setBounds(w-124,12,108,34);
  details.setBounds(16,54,154,30);hint.setBounds(180,50,std::max(0,w-196),40);hint.setVisible(w>=600);
  const bool text=details.getToggleState();content.setVisible(text);viewport.setVisible(!text);
  content.setBounds(16,98,w-32,std::max(1,h-114));viewport.setBounds(content.getBounds());pictures.layout(std::max(1,viewport.getWidth()-viewport.getScrollBarThickness()-4));
 }
 int illustratedCount()const{return pictures.cards.size();}
private:
 HelpPictures pictures;juce::Viewport viewport;juce::TextButton details;juce::Label hint;

 juce::String lang;
};
}
