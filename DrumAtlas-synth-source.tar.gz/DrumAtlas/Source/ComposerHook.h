#pragma once
#include "MusicCore.h"
namespace atlas::composer {
inline juce::Result applyHook(music::Project& project,const juce::var& hook,bool hasChorus) {
    if(hook.isVoid())return juce::Result::ok(); // Earlier saved plans.
    auto* events=hook.getArray();
    if(!events||events->size()>24)return juce::Result::fail("Invalid melody hook");
    if(events->isEmpty())return juce::Result::ok();
    auto track=std::find_if(project.tracks.begin(),project.tracks.end(),[](const auto& t){return t.role=="Melody";});
    if(track==project.tracks.end())return juce::Result::ok();
    const int major[]{0,2,4,5,7,9,11},minor[]{0,2,3,5,7,8,10};
    const int* scale=project.settings.scale=="minor"?minor:major;
    auto ticks=music::barTicks(project.settings)/16;
    const auto firstBar=hasChorus?8:0;
    std::vector<music::Note> phrase;int lastEnd=0;
    for(auto& event:*events){
        for(auto key:{"step","length","degree","velocity"})if(!event[key].isInt()&&!event[key].isInt64())return juce::Result::fail("Invalid hook note");
        int step=int(event["step"]),length=int(event["length"]),degree=int(event["degree"]),velocity=int(event["velocity"]);
        if(step<lastEnd||step>31||length<1||length>32-step||degree<0||degree>13||velocity<1||velocity>127)return juce::Result::fail("Hook notes must fit two bars without overlap");
        music::Note n;n.pitch=60+project.settings.tonic+scale[degree%7]+12*(degree/7);n.velocity=velocity;n.tick=step*ticks;n.duration=length*ticks;phrase.push_back(n);lastEnd=step+length;
    }
    auto& notes=track->notes;
    notes.erase(std::remove_if(notes.begin(),notes.end(),[&](const auto& n){return n.tick>=firstBar*16*ticks;}),notes.end());
    for(int bar=firstBar;bar<project.settings.bars;bar+=2)for(auto n:phrase){
        n.id=juce::Uuid().toString();n.tick+=bar*16*ticks;notes.push_back(n);
    }
    return music::validate(project);
}
}
