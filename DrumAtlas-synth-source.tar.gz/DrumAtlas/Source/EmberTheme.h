#pragma once
#include <juce_gui_basics/juce_gui_basics.h>
#include <BinaryData.h>

namespace atlas::ember {
inline const juce::Colour background{0xff121212}, panel{0xff1b1511}, edge{0xff63432e},
    text{0xfff3eee9}, muted{0xffc2b4a9}, orange{0xffff9a55}, gold{0xffffc373};
inline constexpr float glow = .39f;
inline juce::Typeface::Ptr bodyFace(const juce::String& ={}){static auto face=[] {auto original=juce::Typeface::createSystemTypefaceFor(AtlasFonts::UbuntuSans_ttf,AtlasFonts::UbuntuSans_ttfSize);const std::array<juce::FontVariableSetting,1> weight{{{"wght",400.f}}};auto configured=original->cloneWithVariableSettings(weight);return configured?configured:original;}();return face;}
inline juce::Typeface::Ptr kazakhFace(){return bodyFace();}
inline juce::Typeface::Ptr brandFace(){static auto face=[] {auto original=juce::Typeface::createSystemTypefaceFor(AtlasFonts::UbuntuSans_ttf,AtlasFonts::UbuntuSans_ttfSize);const std::array<juce::FontVariableSetting,1> weight{{{"wght",600.f}}};auto configured=original->cloneWithVariableSettings(weight);return configured?configured:original;}();return face;}
// CSS font-size is an em size; JUCE height is ascent + descent. Keep the
// approved Ubuntu typography legible instead of shrinking it to legacy metrics.
inline juce::Font font(float size,const juce::String&language={}) { return juce::Font(juce::FontOptions(bodyFace(language)).withHeight(size*1.45f)); }
inline juce::Font headingFont(float size) { return juce::Font(juce::FontOptions(brandFace()).withHeight(size*1.32f)); }
inline juce::Font logoFont(float size) { return juce::Font(juce::FontOptions(brandFace()).withHeight(size*1.32f)).withExtraKerningFactor(-.025f); }
inline juce::StringArray styleNames(){return {"EMBER"};}
inline int styleOf(const juce::Component& c){for(auto*p=&c;p;p=p->getParentComponent())if(p->getProperties().contains("atlasStyle"))return int(p->getProperties()["atlasStyle"]);return 0;}
inline float radius(int style){return style==1?7.f:style==6?10.f:style==7?28.f:style==9?20.f:16.f;}
inline juce::Colour hot(int){return orange;}


inline void card(juce::Graphics& g, juce::Rectangle<float> b, float radius=16.f) {
    g.setColour(panel);
    g.fillRoundedRectangle(b,radius);g.setColour(edge);g.drawRoundedRectangle(b.reduced(.5f),radius,1.f);
}

// Visual decoration only. Audio thumbnails and selection coordinates are never changed.
// Fixed, bounded geometry; called solely on the message thread for visible editors.
inline void waves(juce::Graphics& g,juce::Rectangle<float> b,double phase,bool hasAudio,int style=0,float energy=0,float bass=0,float treble=0,float peak=0) {
    if(b.isEmpty())return;
    juce::Graphics::ScopedSaveState saved(g);g.reduceClipRegion(b.toNearestInt());
    const auto accent=hot(style);
    for(int layer=2;layer>=0;--layer){
        juce::Path crest,fill;
        for(int i=0;i<=96;++i){
            const float u=float(i)/96.f;
            const float y=b.getY()+b.getHeight()*(.58f+float((.12+.09*energy+.055*bass)*std::sin(u*7.0-phase*.7+layer*.8)+(.055+.03*treble)*std::sin(u*13.0+phase*.4+layer)));
            const float x=b.getX()+u*b.getWidth();
            if(i==0){crest.startNewSubPath(x,y);fill.startNewSubPath(x,b.getBottom());fill.lineTo(x,y);}else{crest.lineTo(x,y);fill.lineTo(x,y);}
        }
        fill.lineTo(b.getRight(),b.getBottom());fill.closeSubPath();
        const auto hot=layer==0?gold:layer==1?accent:juce::Colour(0xffed3d25);
        const float opacity=(.70f+.15f*energy+.10f*peak)*(.85f-layer*.18f);
        juce::ColourGradient ribbon(juce::Colour(0xffffd476).withAlpha(opacity*.53f),b.getCentreX(),b.getY()+b.getHeight()*.18f,juce::Colour(0xff9a1f08).withAlpha(0.f),b.getCentreX(),b.getBottom(),false);
        ribbon.addColour(.45,juce::Colour(0xffed6928).withAlpha(opacity*.30f));g.setGradientFill(ribbon);g.fillPath(fill);
        g.setColour(hot.withAlpha(opacity*.15f));g.strokePath(crest,juce::PathStrokeType(10.f));
        g.setColour(hot.withAlpha(opacity*.35f));g.strokePath(crest,juce::PathStrokeType(4.f));
        g.setColour(gold.withAlpha(opacity));g.strokePath(crest,juce::PathStrokeType(1.3f));
    }
}

inline void sampleArt(juce::Graphics&g,juce::Rectangle<float>b,const juce::String&category,int style){
 if(style==0){
   // One centred 24-unit drawing space. Never mix fixed steps with reduced
   // row bounds: at compact sizes that pushed strokes outside the old badge.
   juce::Graphics::ScopedSaveState saved(g);
   const float size=std::min(24.f,std::min(b.getWidth(),b.getHeight())-4.f);
   if(size<=0)return;
   g.addTransform(juce::AffineTransform::scale(size/24.f).translated(b.getCentreX()-size/2,b.getCentreY()-size/2));
   g.setColour(juce::Colour(0xffffb168));
   const juce::PathStrokeType stroke(1.6f,juce::PathStrokeType::curved,juce::PathStrokeType::rounded);
   juce::Path mark;
   const auto type=category.toLowerCase();
   auto line=[&](float x,float y,float xx,float yy){mark.startNewSubPath(x,y);mark.lineTo(xx,yy);};
   auto oval=[&](float x,float y,float w,float h){mark.addEllipse(x,y,w,h);};
   auto box=[&](float x,float y,float w,float h,float r=1.5f){mark.addRoundedRectangle(x,y,w,h,r);};
   auto drum=[&](float x,float y,float w,float h){oval(x,y,w,4);line(x,y+2,x,y+h-2);line(x+w,y+2,x+w,y+h-2);mark.startNewSubPath(x,y+h-2);mark.quadraticTo(x+w/2,y+h+2,x+w,y+h-2);};
   if(type=="kick"){
     oval(3,3,18,18);oval(6,6,12,12);line(5,19,3,22);line(19,19,21,22);line(12,18,12,22);line(10,22,14,22);
   }else if(type=="snare"||type=="rim"||type=="rimshot"){
     drum(3,8,18,11);for(float x:{6.f,12.f,18.f})line(x,12,x,18);
     line(5,2,17,8);if(type=="snare")line(18,2,8,7);else line(19,4,21,8);
   }else if(type=="tom"||type=="toms"){
     drum(4,3,16,17);line(7,9,7,17);line(17,9,17,17);line(5,19,4,22);line(19,19,20,22);
   }else if(type.contains("hat")){
     const bool open=type.contains("open");oval(2,open?5:8,20,3);oval(2,open?12:12,20,3);line(12,2,12,5);line(12,15,12,21);line(12,20,7,22);line(12,20,17,22);
   }else if(type=="ride"||type=="crash"||type=="cymbal"){
     mark.startNewSubPath(2,11);mark.lineTo(8,9);mark.quadraticTo(12,4,16,9);mark.lineTo(22,11);mark.quadraticTo(12,15,2,11);mark.closeSubPath();line(12,13,12,21);line(12,20,6,22);line(12,20,18,22);
     if(type=="crash"){line(4,3,6,6);line(20,3,18,6);}else if(type=="ride")oval(10,8,4,3);
   }else if(type=="drums"){
     oval(7,11,10,10);drum(2,3,8,7);drum(14,3,8,7);line(4,13,4,20);line(20,13,20,20);
   }else if(type=="clap"){
     mark.startNewSubPath(10,22);mark.lineTo(5,17);mark.lineTo(3,11);mark.quadraticTo(3,9,5,10);mark.lineTo(8,14);mark.lineTo(8,6);mark.quadraticTo(9,4,10,6);mark.lineTo(10,12);mark.lineTo(12,4);mark.quadraticTo(13,2,14,5);mark.lineTo(13,12);mark.lineTo(16,6);mark.quadraticTo(18,5,18,7);mark.lineTo(16,14);mark.lineTo(19,11);mark.quadraticTo(21,10,21,13);mark.lineTo(18,20);mark.lineTo(15,22);line(3,3,5,5);line(7,1,8,3);line(20,2,19,4);
   }else if(type=="shaker"){
     box(5,2,14,20,6);line(5,9,19,9);line(5,15,19,15);oval(9,11,1,1);oval(14,12,1,1);
   }else if(type=="conga"||type=="congas"){
     oval(5,2,14,4);mark.startNewSubPath(5,4);mark.cubicTo(3,12,7,22,9,22);mark.lineTo(15,22);mark.cubicTo(17,22,21,12,19,4);line(8,8,9,18);line(16,8,15,18);
   }else if(type=="bongo"||type=="bongos"||type=="percussion"){
     drum(2,4,9,15);drum(13,7,9,12);line(11,11,13,11);
   }else if(type=="tambourine"){
     oval(2,2,20,20);oval(6,6,12,12);for(auto point:{juce::Point<float>(12,4),{20,12},{12,20},{4,12}})oval(point.x-2,point.y-2,4,4);
   }else if(type=="cowbell"){
     mark.startNewSubPath(8,4);mark.lineTo(16,4);mark.lineTo(22,20);mark.lineTo(2,20);mark.closeSubPath();oval(8,1,8,3);line(4,16,20,16);
   }else if(type=="claves"){
     box(3,2,5,20,2);box(15,2,5,20,2);
   }else if(type=="guiro"){
     box(6,2,12,20,5);for(float y:{7.f,10.f,13.f,16.f})line(9,y,15,y);line(2,6,3,20);
   }else if(type=="woodblock"){
     box(2,9,20,12,2);box(5,13,14,3,1);line(7,2,17,7);oval(16,5,4,4);
   }else if(type=="bass"||type=="sub"||type=="808"){
     box(4,2,16,20,2);oval(8,5,8,8);oval(10,7,4,4);line(8,17,16,17);line(9,20,15,20);
   }else if(type=="piano"||type=="keys"){
     mark.startNewSubPath(3,14);mark.lineTo(3,8);mark.cubicTo(3,1,12,1,14,7);mark.cubicTo(15,10,21,7,21,14);mark.closeSubPath();
     box(2,14,20,8);for(float x:{6.f,10.f,14.f,18.f})line(x,14,x,19);
   }else if(type=="guitar"){
     mark.startNewSubPath(11,10);mark.cubicTo(5,6,7,13,4,13);mark.cubicTo(-1,17,5,25,10,20);mark.cubicTo(12,18,10,16,14,15);mark.cubicTo(17,14,14,10,11,10);mark.closeSubPath();oval(7,13,4,4);line(10,13,19,4);line(13,13,21,5);box(18,2,4,4,1);line(5,18,8,20);
   }else if(type=="strings"||type=="violin"){
     mark.startNewSubPath(10,7);mark.cubicTo(3,6,4,11,7,12);mark.cubicTo(2,16,5,22,10,22);mark.cubicTo(15,22,18,16,13,12);mark.cubicTo(16,11,17,6,10,7);mark.closeSubPath();line(9,2,9,17);line(11,2,11,17);line(7,17,13,17);line(21,2,18,22);
   }else if(type=="brass"){
     mark.startNewSubPath(3,10);mark.lineTo(16,10);mark.lineTo(21,5);mark.lineTo(21,19);mark.lineTo(16,14);mark.lineTo(6,14);mark.cubicTo(2,14,2,20,6,20);mark.lineTo(13,20);mark.quadraticTo(16,20,16,16);line(7,7,7,13);line(11,7,11,13);line(5,7,9,7);line(9,7,13,7);line(2,8,2,12);
   }else if(type.startsWith("synth")){
     box(2,3,20,18,2);oval(5,6,3,3);oval(12,6,3,3);line(2,13,22,13);for(float x:{6.f,10.f,14.f,18.f})line(x,13,x,21);
   }else if(type=="vocal"||type=="vocals"){
     box(8,2,8,13,4);mark.startNewSubPath(5,10);mark.lineTo(5,12);mark.cubicTo(5,22,19,22,19,12);mark.lineTo(19,10);line(12,19,12,22);line(8,22,16,22);
   }else if(type=="fx"){
     mark.startNewSubPath(12,2);mark.lineTo(15,9);mark.lineTo(22,12);mark.lineTo(15,15);mark.lineTo(12,22);mark.lineTo(9,15);mark.lineTo(2,12);mark.lineTo(9,9);mark.closeSubPath();
   }else if(type=="instrument"){
     oval(3,16,6,5);oval(15,13,6,5);line(9,18,9,5);line(21,15,21,2);line(9,5,21,2);line(9,9,21,6);
   }else{
     // Unknown category stays neutral instead of inventing an instrument.
     line(4,10,4,14);line(8,6,8,18);line(12,3,12,21);line(16,7,16,17);line(20,10,20,14);
   }
   g.strokePath(mark,stroke);return;
 }
 juce::Graphics::ScopedSaveState saved(g);const auto colour=hot(style);card(g,b,8.f);b=b.reduced(5.f);
 auto c=b.getCentre();float r=std::min(b.getWidth(),b.getHeight())*.42f;
 g.setGradientFill(juce::ColourGradient(gold,c.x,c.y+r,colour,c.x,c.y-r,true));
 if(category=="Kick"||category=="Bass"||category=="Tom"){g.fillEllipse(c.x-r,c.y-r,r*2,r*2);g.setColour(background.withAlpha(.7f));g.fillEllipse(c.x-r*.75f,c.y-r*.8f,r*1.5f,r*1.4f);}
 else if(category.contains("Hat")||category=="Shaker"||category=="Snare"||category=="Percussion"){for(int i=0;i<7;++i){float h=b.getHeight()*(.25f+.65f*float(std::sin(i*.45)));g.fillRoundedRectangle(b.getX()+i*b.getWidth()/7,b.getCentreY()-h/2,std::max(2.f,b.getWidth()/12),h,1.f);}}
 else if(category=="Keys"||category=="Piano"){for(int i=0;i<5;++i)g.fillRoundedRectangle(b.getX()+i*b.getWidth()/5,b.getY(),b.getWidth()/6,b.getHeight(),1.f);g.setColour(background);for(int i:{0,1,3})g.fillRect(b.getX()+(i+.65f)*b.getWidth()/5,b.getY(),b.getWidth()/10,b.getHeight()*.55f);}
 else {juce::Path wave;for(int i=0;i<=32;++i){float x=b.getX()+b.getWidth()*i/32.f,y=c.y+std::sin(i*.24f)*b.getHeight()*.3f;if(i==0)wave.startNewSubPath(x,y);else wave.lineTo(x,y);}g.strokePath(wave,juce::PathStrokeType(2.5f));}
}

class Look:public juce::LookAndFeel_V4,private juce::Timer {
public:
 Look(){
    setDefaultSansSerifTypeface(bodyFace());
    setColour(juce::TextButton::buttonColourId,panel);setColour(juce::TextButton::textColourOffId,text);
    setColour(juce::Slider::textBoxTextColourId,text);setColour(juce::Slider::textBoxBackgroundColourId,juce::Colours::transparentBlack);
    setColour(juce::Slider::trackColourId,orange);setColour(juce::Slider::backgroundColourId,edge);
    setColour(juce::TextEditor::highlightColourId,orange.withAlpha(.3f));setColour(juce::TextEditor::focusedOutlineColourId,orange);
    setColour(juce::PopupMenu::highlightedBackgroundColourId,juce::Colour(0xff593224));setColour(juce::PopupMenu::highlightedTextColourId,text);
    setColour(juce::ScrollBar::thumbColourId,orange.withAlpha(.65f));
 }
 juce::String language;
 void setLanguage(const juce::String&value){language=value;setDefaultSansSerifTypeface(bodyFace(language));}
 juce::Font getPopupMenuFont()override{return font(14.f,language);}
 ~Look()override{stopTimer();}
 void triggerHalo(juce::Button&b){b.getProperties().set("atlasHaloStart",juce::Time::getMillisecondCounterHiRes());bool found=false;for(auto&button:haloButtons)if(button.getComponent()==&b)found=true;if(!found)haloButtons.emplace_back(&b);startTimerHz(30);}
 void drawButtonBackground(juce::Graphics& g,juce::Button& b,const juce::Colour&,bool over,bool down)override{
    const auto bounds=b.getLocalBounds().toFloat().reduced(1.f);auto&properties=b.getProperties();const bool focus=b.hasKeyboardFocus(false);
    if(b.isEnabled()&&((over&&!bool(properties["atlasWasOver"]))||(down&&!bool(properties["atlasWasDown"]))||(focus&&!bool(properties["atlasWasFocused"]))))triggerHalo(b);
    properties.set("atlasWasOver",over);properties.set("atlasWasDown",down);properties.set("atlasWasFocused",focus);
    const bool primary=bool(b.getProperties().getWithDefault("emberPrimary",false));
    const float alpha=b.isEnabled()?1.f:.4f;
    g.setColour((down?juce::Colour(0xff4a2c1a):primary?juce::Colour(0xff372215):juce::Colour(0xff201a16)).withAlpha(alpha));g.fillRoundedRectangle(bounds,9.f);
    if(primary){g.setGradientFill(juce::ColourGradient(orange.withAlpha(.08f*alpha),bounds.getCentreX(),bounds.getY(),juce::Colours::transparentBlack,bounds.getCentreX(),bounds.getBottom(),false));g.fillRoundedRectangle(bounds,9.f);}
    g.setColour((focus||over?juce::Colour(0xffffc88c):primary?juce::Colour(0xffffad67):juce::Colour(0xffa67652)).withAlpha(alpha));g.drawRoundedRectangle(bounds,9.f,1.f);
    if(properties.contains("atlasHaloStart")){const float progress=float((juce::Time::getMillisecondCounterHiRes()-double(properties["atlasHaloStart"]))/440.);if(progress>=0&&progress<1){g.setColour(juce::Colour(0xfff9b66e).withAlpha(.8f*(1-progress)*alpha));g.drawRoundedRectangle(bounds.reduced(4.f*(1-progress)),8.f,1.2f);}}
 }
 void drawButtonText(juce::Graphics& g,juce::TextButton& b,bool,bool)override{
    const bool primary=bool(b.getProperties().getWithDefault("emberPrimary",false));
    g.setColour((primary?juce::Colour(0xffffd5ab):text).withAlpha(b.isEnabled()?1.f:.6f));g.setFont(font((styleOf(b)==0?14.f:14.f)*float(b.getProperties().getWithDefault("layoutFontScale",1.)),language));
    g.drawFittedText(b.getButtonText(),b.getLocalBounds().reduced(8,2),juce::Justification::centred,2,.95f);
 }
 juce::Font getComboBoxFont(juce::ComboBox&b)override{return font((styleOf(b)==0?14.f:14.f)*float(b.getProperties().getWithDefault("layoutFontScale",1.)),language);}
 void positionComboBoxText(juce::ComboBox& b,juce::Label& l)override{l.setBounds(12,1,b.getWidth()-39,b.getHeight()-2);l.setFont(getComboBoxFont(b));l.setMinimumHorizontalScale(1.f);l.setJustificationType(juce::Justification::centredLeft);}
 void drawComboBoxTextWhenNothingSelected(juce::Graphics&g,juce::ComboBox&b,juce::Label&l)override{
    g.setColour(b.findColour(juce::ComboBox::textColourId).withMultipliedAlpha(.5f));g.setFont(getComboBoxFont(b));
    auto area=getLabelBorderSize(l).subtractedFrom(l.getBounds());
    g.drawFittedText(b.getTextWhenNothingSelected(),area,l.getJustificationType(),1,l.getMinimumHorizontalScale());
 }
 void drawComboBox(juce::Graphics& g,int w,int h,bool,int,int,int,int,juce::ComboBox& b)override{
    card(g,juce::Rectangle<float>(.5f,.5f,float(w)-1,float(h)-1),9.f);
    g.setColour((b.hasKeyboardFocus(true)?orange:muted).withAlpha(b.isEnabled()?1.f:.4f));
    juce::Path arrow;arrow.startNewSubPath(float(w)-23,h*.44f);arrow.lineTo(float(w)-18,h*.58f);arrow.lineTo(float(w)-13,h*.44f);g.strokePath(arrow,juce::PathStrokeType(1.7f));
 }
 void fillTextEditorBackground(juce::Graphics& g,int w,int h,juce::TextEditor&)override{card(g,juce::Rectangle<float>(0,0,float(w),float(h)),9.f);}
 void drawTextEditorOutline(juce::Graphics& g,int w,int h,juce::TextEditor& e)override{g.setColour(e.hasKeyboardFocus(true)?orange:edge);g.drawRoundedRectangle(.5f,.5f,float(w)-1,float(h)-1,9.f,1.f);}
private:
 std::vector<juce::Component::SafePointer<juce::Button>>haloButtons;
 void timerCallback()override{const double now=juce::Time::getMillisecondCounterHiRes();for(auto it=haloButtons.begin();it!=haloButtons.end();){auto*b=it->getComponent();if(!b){it=haloButtons.erase(it);continue;}b->repaint();if(now-double(b->getProperties().getWithDefault("atlasHaloStart",0.))>=440)it=haloButtons.erase(it);else ++it;}if(haloButtons.empty())stopTimer();}
};
}
