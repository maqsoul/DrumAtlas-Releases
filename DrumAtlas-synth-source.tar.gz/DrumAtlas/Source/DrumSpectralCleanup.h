#pragma once
#include <algorithm>
#include <cmath>
#include <stdexcept>
#include <vector>

namespace atlas {
// Stereo-linked soft competition between the six jointly estimated drum sources.
// No gate, transient relocation, extra inference or per-channel image changes.
struct DrumSpectralCleanup {
    std::vector<float> gain;
    static std::vector<float> smooth(const std::vector<float>& x,int frames,int bins,int radiusF,int radiusT){
        const size_t plane=size_t(frames)*bins;
        std::vector<float> horizontal(x.size()),out(x.size());
        for(size_t source=0;source<x.size()/plane;++source)for(int t=0;t<frames;++t)for(int f=0;f<bins;++f){
            float sum=0;for(int d=-radiusF;d<=radiusF;++d)sum+=x[source*plane+size_t(t)*bins+std::clamp(f+d,0,bins-1)];
            horizontal[source*plane+size_t(t)*bins+f]=sum/float(2*radiusF+1);
        }
        for(size_t source=0;source<x.size()/plane;++source)for(int t=0;t<frames;++t)for(int f=0;f<bins;++f){
            float sum=0;for(int d=-radiusT;d<=radiusT;++d)sum+=horizontal[source*plane+size_t(std::clamp(t+d,0,frames-1))*bins+f];
            out[source*plane+size_t(t)*bins+f]=sum/float(2*radiusT+1);
        }
        return out;
    }
    DrumSpectralCleanup(const std::vector<float>& power,int frames,int bins){
        const size_t plane=size_t(frames)*bins;
        if(frames<=0||bins<=0||power.size()!=6*plane)throw std::runtime_error("Invalid drum cleanup shape");
        for(float p:power)if(!std::isfinite(p)||p<0)throw std::runtime_error("Invalid drum cleanup power");
        gain.resize(power.size());auto energy=smooth(power,frames,bins,2,1);
        for(size_t i=0;i<plane;++i){
            for(int s=0;s<6;++s){
                const auto index=s*plane+i;float other=0;
                for(int j=0;j<6;++j)if(s!=j)other=std::max(other,energy[j*plane+i]);
                const float x=std::clamp(energy[index]/std::max(1.e-20f,.03f*other),0.f,1.f);
                gain[index]=.1f+.9f*x*x*(3-2*x);
            }
        }
        gain=smooth(gain,frames,bins,1,1);
    }
};
}
