#pragma once
#include "Formats.h"

namespace atlas::composer {
struct AudioRegionEdit { juce::String action="gain"; double first=0,end=0,gainDb=0,destination=0; };
inline juce::Result editAudioRegion(const juce::File&source,const juce::File&target,const AudioRegionEdit&edit,const std::function<bool()>&cancel={}){
    auto fail=[](const char*text){return juce::Result::fail(text);};
    if(source==target||!source.existsAsFile()||target.existsAsFile())return fail("Audio edits require a new output file");
    if(!juce::StringArray{"gain","mute","reverse","copy"}.contains(edit.action)||!std::isfinite(edit.first)||!std::isfinite(edit.end)||!std::isfinite(edit.gainDb)||!std::isfinite(edit.destination)||edit.first<0||edit.end<=edit.first||edit.destination<0||edit.gainDb<-60||edit.gainDb>12)return fail("Invalid audio selection or edit");
    juce::AudioFormatManager formats;registerFormats(formats);std::unique_ptr<juce::AudioFormatReader>reader(formats.createReaderFor(ioFile(source)));if(!reader||reader->sampleRate<=0||reader->numChannels<1||reader->numChannels>2)return fail("Cannot read audio track");
    auto first=juce::int64(std::llround(edit.first*reader->sampleRate)),end=juce::int64(std::llround(edit.end*reader->sampleRate)),destination=juce::int64(std::llround(edit.destination*reader->sampleRate));
    if(first<0||end<=first||end>reader->lengthInSamples||destination>reader->lengthInSamples||(edit.action=="copy"&&end-first>reader->lengthInSamples-destination))return fail("Audio edit exceeds the track duration");
    auto from=edit.action=="copy"?destination:first,to=edit.action=="copy"?destination+end-first:end;auto result=target.getParentDirectory().createDirectory();if(result.failed())return result;
    auto stream=std::unique_ptr<juce::OutputStream>(target.createOutputStream());juce::WavAudioFormat wav;auto writer=wav.createWriterFor(stream,juce::AudioFormatWriterOptions{}.withSampleRate(reader->sampleRate).withNumChannels(reader->numChannels).withBitsPerSample(24));if(!writer)return fail("Cannot write edited audio");
    juce::AudioBuffer<float>buffer(int(reader->numChannels),4096);double gain=std::pow(10.,edit.gainDb/20.);
    for(juce::int64 at=0;at<reader->lengthInSamples;){if(cancel&&cancel())return fail("Cancelled");bool inside=at>=from&&at<to;int count=int(std::min<juce::int64>(4096,(at<from?from:inside?to:reader->lengthInSamples)-at));juce::int64 input=at;if(inside&&edit.action=="copy")input=first+at-from;if(inside&&edit.action=="reverse")input=end-(at-first)-count;
        if(!reader->read(&buffer,0,count,input,true,true))return fail("Cannot decode audio edit");
        if(inside){if(edit.action=="reverse")buffer.reverse(0,count);else if(edit.action=="mute")buffer.clear(0,count);else if(edit.action=="gain")buffer.applyGain(0,count,float(gain));}
        for(int ch=0;ch<buffer.getNumChannels();++ch)for(int i=0;i<count;++i)if(!std::isfinite(buffer.getSample(ch,i))||std::abs(buffer.getSample(ch,i))>1.f)return fail("Gain would clip the audio; reduce it and apply again");
        if(!writer->writeFromAudioSampleBuffer(buffer,0,count))return fail("Cannot write audio edit");at+=count;
    }
    return juce::Result::ok();
}
}
