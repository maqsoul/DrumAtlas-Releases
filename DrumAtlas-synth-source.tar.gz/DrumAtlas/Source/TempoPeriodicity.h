#pragma once
#include <juce_core/juce_core.h>
#include <vector>
#include <algorithm>
#include <array>
#include <cmath>
namespace atlas::tempo_detail {
struct Attack {double time=0,confidence=1,peak=1;};
struct DrumEventSource {std::vector<Attack>events;double start=0,end=0;bool busy=false,truncated=false;};
struct TempoCandidate {double bpm=0,relativeSupport=0;};
// Circular phase concentration across short windows: straight and triplet grids.
// Subtract the finite-sample noise expectation; zero means no stable grid evidence.
inline double tempoGridAgreement(const std::vector<double>& times,double start,double end,double bpm,bool preferSimplePulse=false){
 std::array<double,4> sums{};int windows=0;
 // Visit only occupied 8-second windows. Long silent gaps must not increase work.
 auto first=std::lower_bound(times.begin(),times.end(),start);
 while(first!=times.end()&&*first<end){
   const double from=start+std::floor((*first-start)/8.)*8.;
   const double finish=std::min(end,from+8.);
   auto last=std::lower_bound(first,times.end(),finish);
   if(last==first){++first;continue;}
   const auto n=std::distance(first,last);
   if(n>=8){std::array<double,4> re{},im{};for(auto hit=first;hit!=last;++hit)for(int h=1;h<=4;++h){double angle=juce::MathConstants<double>::twoPi*(*hit-from)*bpm*h/60.;re[size_t(h-1)]+=std::cos(angle);im[size_t(h-1)]+=std::sin(angle);}
     ++windows;for(size_t h=0;h<4;++h)sums[h]+=juce::jlimit(0.,1.,(re[h]*re[h]+im[h]*im[h]-double(n))/(double(n)*double(n-1)));
   }
   first=last;
 }
 if(windows<2)return -1.;
 // A candidate explained only by its third harmonic must not have the same
 // evidence as a direct beat pulse. Keep the untapered score for diagnostics
 // and explicit triplet-grid checks; use 1/h support only for ranking.
 if(preferSimplePulse)for(size_t h=0;h<sums.size();++h)sums[h]/=double(h+1);
 return *std::max_element(sums.begin(),sums.end())/windows;
}
struct ReferenceTempo {double bpm=0,score=0;int events=0;bool limited=false;std::vector<TempoCandidate> alternatives;bool ambiguous=false;double gridAgreement=0;bool gridUsed=false;};
// Interval periodicity, not a calibrated probability or a musical beat/downbeat classifier.
inline juce::Result estimateReferenceTempo(const DrumEventSource&source,double start,double length,double threshold,ReferenceTempo&out){
 if(source.busy||!std::isfinite(start)||!std::isfinite(length)||!std::isfinite(threshold)||!std::isfinite(source.start)||!std::isfinite(source.end)||length<=0||start<source.start||start+length>source.end+1e-6||threshold<0||threshold>1||source.events.size()>100000)return juce::Result::fail("Choose a completed, valid reference interval.");
 std::vector<std::pair<double,double>>times;const auto end=start+length;
 for(const auto&e:source.events){if(!std::isfinite(e.time)||!std::isfinite(e.confidence)||e.confidence<0||e.confidence>1||!std::isfinite(e.peak)||e.peak<0)return juce::Result::fail("Invalid reference events.");if(e.time>=start&&e.time<end&&e.confidence>=threshold)times.emplace_back(e.time,e.peak);}
 std::sort(times.begin(),times.end());std::vector<double>unique,strengths;for(auto hit:times)if(unique.empty()||hit.first-unique.back()>=.03){unique.push_back(hit.first);strengths.push_back(hit.second);}else strengths.back()=std::max(strengths.back(),hit.second);
 bool limited=source.truncated||unique.size()>4000;
 // Keep local rhythmic intervals intact, spread across the entire selection.
 // Uniformly dropping individual hits would create an artificial slower pulse.
 if(unique.size()>4000){std::vector<double>sampled,sampledStrengths;sampled.reserve(4000);sampledStrengths.reserve(4000);constexpr size_t blocks=16,blockSize=250;
   for(size_t block=0;block<blocks;++block){const size_t offset=block*(unique.size()-blockSize)/(blocks-1);sampled.insert(sampled.end(),unique.begin()+offset,unique.begin()+offset+blockSize);sampledStrengths.insert(sampledStrengths.end(),strengths.begin()+offset,strengths.begin()+offset+blockSize);}
   unique=std::move(sampled);strengths=std::move(sampledStrengths);
 }
 if(unique.size()<8||unique.back()-unique.front()<3)return juce::Result::fail("Not enough rhythmic evidence: select at least 3 seconds with 8 distinct hits.");
 // Preserve accent evidence: weak subdivisions should not vote as strongly as
 // recurring main attacks. Normalize per file so level changes do not set BPM.
 double meanStrength=0;for(auto strength:strengths)meanStrength+=strength;meanStrength/=strengths.size();double strengthEnergy=0;
 for(auto&strength:strengths){strength=meanStrength>1.e-12?juce::jlimit(.1,4.,strength/meanStrength):1.;strengthEnergy+=strength*strength;}
 constexpr double step=.001;std::array<double,4100>hist{};
 for(size_t i=0;i<unique.size();++i)for(size_t j=i+1;j<unique.size();++j){double d=unique[j]-unique[i];if(d>=4.09)break;int bin=int(std::lround(d/step));hist[size_t(bin)]+=strengths[i]*strengths[j];}
 auto support=[&](double lag){double value=0,tolerance=std::max(.015,lag*.025);int lo=std::max(0,int((lag-tolerance)/step)),hi=std::min(4099,int(std::ceil((lag+tolerance)/step)));for(int k=lo;k<=hi;++k)value+=hist[size_t(k)]*std::max(0.,1.-std::pow((k*step-lag)/tolerance,2));return value;};
 std::array<double,561> scores{};double best=0,bpm=0;for(int q=240;q<=800;++q){double candidate=q*.25,beat=60./candidate;double value=support(beat)+.5*support(beat*2)+.25*support(beat*4);scores[size_t(q-240)]=value;if(value>best){best=value;bpm=candidate;}}
 const double rawScore=juce::jlimit(0.,1.,best/(strengthEnergy*1.75));if(rawScore<.15)return juce::Result::fail("No stable tempo found. Set BPM manually or choose a steadier interval.");
 struct Ranked {double bpm=0,raw=0,grid=0,rank=0;};std::vector<Ranked> peaks;
 for(size_t i=0;i<scores.size();++i)if((i==0||scores[i]>=scores[i-1])&&(i+1==scores.size()||scores[i]>=scores[i+1])&&scores[i]>=best*.65){double candidate=60.+double(i)*.25;double grid=tempoGridAgreement(unique,start,end,candidate);double pulse=tempoGridAgreement(unique,start,end,candidate,true);double factor=pulse<0?1.:std::sqrt(std::max(1.e-9,pulse));peaks.push_back({candidate,scores[i],grid,scores[i]*factor});}
 std::stable_sort(peaks.begin(),peaks.end(),[](const auto&a,const auto&b){return a.rank>b.rank;});
 if(peaks.empty())return juce::Result::fail("No tempo candidates available.");
 const auto selected=peaks.front();bpm=selected.bpm;
 ReferenceTempo next{bpm,juce::jlimit(0.,1.,selected.raw/(strengthEnergy*1.75)),int(unique.size()),limited};next.gridUsed=selected.grid>=0;next.gridAgreement=std::max(0.,selected.grid);
 for(const auto& peak:peaks){if(std::abs(peak.bpm-bpm)<bpm*.03)continue;bool nearby=false;for(const auto& saved:next.alternatives)if(std::abs(peak.bpm-saved.bpm)<saved.bpm*.03)nearby=true;if(nearby)continue;next.alternatives.push_back({peak.bpm,peak.rank/selected.rank});if(next.alternatives.size()==4)break;}
 next.ambiguous=!next.alternatives.empty()&&next.alternatives.front().relativeSupport>=.9;
 // Harmonic tapering is a ranking preference, not evidence resolving the
 // musical beat level. An interval-supported half/double pulse remains ambiguous.
 for(const auto&peak:peaks)if(peak.raw>=selected.raw*.9&&
   (std::abs(peak.bpm-bpm*.5)<bpm*.015||std::abs(peak.bpm-bpm*2)<bpm*.06))next.ambiguous=true;
 out=std::move(next);return juce::Result::ok();
}
}
