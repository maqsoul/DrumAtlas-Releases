#include "MusicHarmony.h"
#include <algorithm>
#include <map>
#include <limits>
#include <set>
namespace atlas::music {
namespace {
const std::map<juce::String,std::vector<int>> qualities{
 {"",{0,4,7}},{"maj",{0,4,7}},{"m",{0,3,7}},{"dim",{0,3,6}},{"aug",{0,4,8}},
 {"7",{0,4,7,10}},{"maj7",{0,4,7,11}},{"m7",{0,3,7,10}},{"dim7",{0,3,6,9}},{"m7b5",{0,3,6,10}},
 {"9",{0,4,7,10,14}},{"maj9",{0,4,7,11,14}},{"m9",{0,3,7,10,14}},
 {"11",{0,4,7,10,14,17}},{"m11",{0,3,7,10,14,17}},
 {"13",{0,4,7,10,14,17,21}},{"m13",{0,3,7,10,14,17,21}},
 {"sus2",{0,2,7}},{"sus4",{0,5,7}},{"7sus4",{0,5,7,10}},
 {"add9",{0,4,7,14}},{"madd9",{0,3,7,14}},{"6",{0,4,7,9}},{"m6",{0,3,7,9}},
 {"7b9",{0,4,7,10,13}},{"7#9",{0,4,7,10,15}},{"7b5",{0,4,6,10}},{"7#5",{0,4,8,10}}
};
int rootOf(juce::String& token){
 if(token.isEmpty())return -1;auto c=juce::CharacterFunctions::toUpperCase(token[0]);int root=-1;
 switch(c){case 'C':root=0;break;case 'D':root=2;break;case 'E':root=4;break;case 'F':root=5;break;case 'G':root=7;break;case 'A':root=9;break;case 'B':root=11;break;default:return -1;}
 token=token.substring(1);if(token.startsWithChar('#')){++root;token=token.substring(1);}else if(token.startsWithChar('b')){--root;token=token.substring(1);}return (root+12)%12;
}
juce::Result validOptions(const HarmonyOptions&o){
 std::vector<ChordSpec> chords;auto r=parseChords(o.progression,chords);if(r.failed())return r;
 if(o.low<24||o.high>108||o.high-o.low<12||o.maxLeap<1||o.maxLeap>48)return juce::Result::fail("Chord register must span at least 12 semitones within MIDI 24..108; max leap 1..48");
 if(!juce::StringArray{"808","Sub","Reese","Synth","Acoustic"}.contains(o.bassRole)||!juce::StringArray{"Main","Counter","Arpeggio","Texture"}.contains(o.melodyRole))return juce::Result::fail("Unknown bass or melody role");
 if(o.glideTicks<0||o.glideTicks>960||o.bendRange<1||o.bendRange>48)return juce::Result::fail("Glide must be 0..960 ticks; pitch bend range 1..48 semitones");
 if(o.melodyTarget!="Melody"&&o.melodyTarget!="Countermelody")return juce::Result::fail("Unknown melodic target");
 if(o.bassLow<0||o.bassHigh>127||o.bassHigh-o.bassLow<12)return juce::Result::fail("Bass register must span at least 12 semitones within MIDI 0..127");
 if(!juce::StringArray{"Gated","Connected","Legato"}.contains(o.bassConnection))return juce::Result::fail("Unknown bass note connection");
 if(o.bassConnection=="Legato"&&o.glideTicks>0)return juce::Result::fail("Overlapping legato cannot share channel-wide Pitch Bend. Set Glide to 0 and use the instrument's mono-legato mode, or choose Gated / Connected.");
 if(o.melodyLow<0||o.melodyHigh>127||o.melodyHigh-o.melodyLow<12)return juce::Result::fail("Melody register must span at least 12 semitones within MIDI 0..127");
 if(!o.chords&&!o.bass&&!o.melody)return juce::Result::fail("Select at least one target part");return juce::Result::ok();
}
juce::Result voice(const ChordSpec&c,const HarmonyOptions&o,const std::vector<int>&previous,std::vector<int>&out){
 double best=std::numeric_limits<double>::max();auto shape=c.intervals;
 for(size_t inversion=0;inversion<(o.voiceLeading?shape.size():1);++inversion){
  for(int octave=-2;octave<10;++octave){std::vector<int> candidate;for(int n:shape)candidate.push_back(c.root+12*octave+n);
   if(c.bass>=0&&(candidate.front()%12+12)%12!=c.bass)continue;
   if(candidate.front()<o.low||candidate.back()>o.high)continue;
   double cost=std::abs((candidate.front()+candidate.back())*.5-(o.low+o.high)*.5)*.1;bool allowed=true;
   if(o.voiceLeading&&!previous.empty())for(size_t i=0;i<candidate.size();++i){int distance=128;
    if(previous.size()==candidate.size())distance=std::abs(candidate[i]-previous[i]);else for(int n:previous)distance=std::min(distance,std::abs(candidate[i]-n));
    if(distance>o.maxLeap)allowed=false;cost+=distance;
    if(std::find(previous.begin(),previous.end(),candidate[i])!=previous.end())cost-=3;
   }
   if(allowed&&cost<best){best=cost;out=candidate;}
  }
  int moved=shape.front();shape.erase(shape.begin());while(moved<=shape.back())moved+=12;shape.push_back(moved);
 }
 return out.empty()?juce::Result::fail("No voicing fits "+c.name+". Widen the register / leap limit or disable voice leading."):juce::Result::ok();
}
}
juce::Result parseChords(const juce::String&text,std::vector<ChordSpec>&out){
 if(text.length()>4096)return juce::Result::fail("Progression is too long");auto tokens=juce::StringArray::fromTokens(text.replace("(","").replace(")","")," ,|;\t\r\n","");tokens.removeEmptyStrings();
 if(tokens.isEmpty()||tokens.size()>64)return juce::Result::fail("Enter 1..64 chords, one chord per bar");std::vector<ChordSpec> result;
 for(auto token:tokens){ChordSpec c;c.name=token;auto slash=token.indexOfChar('/');if(slash>=0){auto bass=token.substring(slash+1);c.bass=rootOf(bass);if(c.bass<0||bass.isNotEmpty())return juce::Result::fail("Invalid inversion bass: "+c.name);token=token.substring(0,slash);}c.root=rootOf(token);auto q=qualities.find(token);if(c.root<0||q==qualities.end())return juce::Result::fail("Unsupported chord: "+c.name);c.intervals=q->second;
  if(c.bass>=0){bool found=false;for(int interval:c.intervals)found|=(c.root+interval)%12==c.bass;if(!found)return juce::Result::fail("Inversion bass must be a chord tone: "+c.name);while((c.root+c.intervals.front())%12!=c.bass){int moved=c.intervals.front();c.intervals.erase(c.intervals.begin());while(moved<=c.intervals.back())moved+=12;c.intervals.push_back(moved);}}
  result.push_back(c);}out=std::move(result);return juce::Result::ok();
}
juce::var encodeHarmony(const HarmonyOptions&o){
 auto*d=new juce::DynamicObject;bool bassOptions=o.bassLow!=12||o.bassHigh!=72||o.bassConnection!="Gated";if(bassOptions){d->setProperty("bass_low",o.bassLow);d->setProperty("bass_high",o.bassHigh);d->setProperty("bass_connection",o.bassConnection);}bool extended=bassOptions||o.melodyTarget!="Melody"||o.progression.containsChar('/');if(extended)d->setProperty("melody_target",o.melodyTarget);bool modern=extended||o.phraseMelody||o.melodyLow!=48||o.melodyHigh!=96;d->setProperty("version",bassOptions?5:extended?4:modern?3:o.glideTicks>0?2:1);if(modern){d->setProperty("phrase_melody",o.phraseMelody);d->setProperty("melody_low",o.melodyLow);d->setProperty("melody_high",o.melodyHigh);}if(o.glideTicks>0||modern){d->setProperty("glide_ticks",o.glideTicks);d->setProperty("bend_range",o.bendRange);}d->setProperty("progression",o.progression);d->setProperty("voice_leading",o.voiceLeading);d->setProperty("low",o.low);d->setProperty("high",o.high);d->setProperty("max_leap",o.maxLeap);d->setProperty("bass_role",o.bassRole);d->setProperty("melody_role",o.melodyRole);d->setProperty("chords",o.chords);d->setProperty("bass",o.bass);d->setProperty("melody",o.melody);return juce::var(d);
}
juce::Result decodeHarmony(const juce::var&v,HarmonyOptions&target){
 if(!v.isObject()||!v["version"].isInt()||(int(v["version"])<1||int(v["version"])>5))return juce::Result::fail("Unsupported harmony version");
 for(auto key:{"low","high","max_leap"})if(!v[key].isInt())return juce::Result::fail("Invalid harmony range");
 for(auto key:{"voice_leading","chords","bass","melody"})if(!v[key].isBool())return juce::Result::fail("Invalid harmony switch");
 for(auto key:{"progression","bass_role","melody_role"})if(!v[key].isString())return juce::Result::fail("Invalid harmony text");
 HarmonyOptions o;if(int(v["version"])==5){if(!v["bass_low"].isInt()||!v["bass_high"].isInt()||!v["bass_connection"].isString())return juce::Result::fail("Invalid bass range or connection");o.bassLow=int(v["bass_low"]);o.bassHigh=int(v["bass_high"]);o.bassConnection=v["bass_connection"].toString();}else if(v.hasProperty("bass_low")||v.hasProperty("bass_high")||v.hasProperty("bass_connection"))return juce::Result::fail("Bass range and connection require harmony version 5");if(int(v["version"])>=4){if(!v["melody_target"].isString())return juce::Result::fail("Missing melodic target");o.melodyTarget=v["melody_target"].toString();}else if(v.hasProperty("melody_target")||v["progression"].toString().containsChar('/'))return juce::Result::fail("Melodic targets and explicit inversions require harmony version 4");if(int(v["version"])>=3){if(!v["phrase_melody"].isBool()||!v["melody_low"].isInt()||!v["melody_high"].isInt())return juce::Result::fail("Invalid melody phrase options");o.phraseMelody=bool(v["phrase_melody"]);o.melodyLow=int(v["melody_low"]);o.melodyHigh=int(v["melody_high"]);}else if(v.hasProperty("phrase_melody")||v.hasProperty("melody_low")||v.hasProperty("melody_high"))return juce::Result::fail("Melody phrase options require harmony version 3");if(int(v["version"])>=2){if(!v["glide_ticks"].isInt()||!v["bend_range"].isInt())return juce::Result::fail("Invalid glide settings");o.glideTicks=int(v["glide_ticks"]);o.bendRange=int(v["bend_range"]);}o.progression=v["progression"].toString();o.voiceLeading=bool(v["voice_leading"]);o.low=int(v["low"]);o.high=int(v["high"]);o.maxLeap=int(v["max_leap"]);o.bassRole=v["bass_role"].toString();o.melodyRole=v["melody_role"].toString();o.chords=bool(v["chords"]);o.bass=bool(v["bass"]);o.melody=bool(v["melody"]);auto r=validOptions(o);if(r.wasOk())target=o;return r;
}
juce::String suggestHarmony(const Settings&s,int variation){
 static const int patterns[][4]{{0,5,3,4},{0,3,6,4},{5,3,0,4},{0,6,5,4}};
 auto*degrees=scaleDegrees(s.scale);if(!degrees)return {};const auto&scale=*degrees;juce::StringArray names;int pattern=int((uint32_t(variation)+s.seed)%4);
 for(int d:patterns[pattern]){int root=(s.tonic+scale[d])%12;auto name=juce::MidiMessage::getMidiNoteName(root,true,false,3);int third=(scale[(d+2)%7]-scale[d]+12)%12;
  int fifth=(scale[(d+4)%7]-scale[d]+12)%12,seventh=(scale[(d+6)%7]-scale[d]+12)%12;
  bool ninth=s.complexity>.65&&(scale[(d+1)%7]-scale[d]+12)%12==2;
  juce::String quality=third==3?(fifth==6?"m7b5":ninth?"m9":"m7"):(seventh==11?(ninth?"maj9":"maj7"):(ninth?"9":"7"));names.add(name+quality);
 }return names.joinIntoString(" ");
}
juce::Result applyHarmony(Project&target,const HarmonyOptions&o){
 auto r=validate(target);if(r.failed())return r;r=validOptions(o);if(r.failed())return r;
 auto p=target;auto find=[&](const char*role)->Track*{for(auto&t:p.tracks)if(t.customName.isEmpty()&&t.role==role)return &t;return nullptr;};
 auto*chords=find("Chords"),*bass=find("Bass"),*melody=find(o.melodyTarget.toRawUTF8()),*kick=find("Kick");
 for(auto entry:{std::make_pair(chords,o.chords),std::make_pair(bass,o.bass),std::make_pair(melody,o.melody)})if(entry.second&&(!entry.first||entry.first->midiLocked))return juce::Result::fail("A selected harmony track is missing or MIDI-locked");
 std::vector<ChordSpec> sequence;parseChords(o.progression,sequence);std::vector<std::vector<int>> voices;std::vector<int> previous;
 for(int b=0;b<p.settings.bars;++b){std::vector<int> v;r=voice(sequence[size_t(b)%sequence.size()],o,previous,v);if(r.failed())return r;voices.push_back(v);previous=v;}
 if(o.chords)chords->notes.clear();if(o.bass)bass->notes.clear();if(o.melody)melody->notes.clear();
 const auto bar=barTicks(p.settings);uint32_t random=p.settings.seed;auto next=[&]{random=random*1664525u+1013904223u;return random;};int motif[4];for(auto&n:motif)n=int(next()%5);bool rhythm[8]{};if(o.phraseMelody)for(int i=0;i<8;++i)rhythm[i]=i==0||double(next())/4294967296.<p.settings.melodicDensity;
 auto inRegister=[&](int pitch){while(pitch>o.melodyHigh)pitch-=12;while(pitch<o.melodyLow)pitch+=12;return pitch;};
 auto add=[&](Track&t,int b,int64_t offset,int pitch,int64_t length,int velocity){Note n;n.id=t.id+":harmony:"+juce::String(b)+":"+juce::String(int(t.notes.size()));n.channel=1;n.pitch=juce::jlimit(0,127,pitch);n.tick=b*bar+offset;n.duration=std::min(length,bar-offset);n.velocity=juce::jlimit(1,127,velocity);t.notes.push_back(n);};
 for(int b=0;b<p.settings.bars;++b){const auto&c=sequence[size_t(b)%sequence.size()];auto&v=voices[size_t(b)];
  if(o.chords)for(int n:v)add(*chords,b,0,n,bar-std::min<int64_t>(120,bar/8),65+int(p.settings.energy*20));
  if(o.bass){std::set<int64_t> hits;
   if(o.bassRole=="Acoustic")for(int i=0;i<p.settings.numerator;++i)hits.insert(bar*i/p.settings.numerator);
   else if(o.bassRole=="Reese")hits.insert(0);
   else if(kick)for(auto&n:kick->notes)if(n.tick+n.microtiming>=b*bar&&n.tick+n.microtiming<(b+1)*bar)hits.insert(n.tick+n.microtiming-b*bar);
   if(hits.empty()){hits.insert(0);hits.insert(bar/2);}std::vector<int64_t> onsets(hits.begin(),hits.end());
   for(size_t i=0;i<onsets.size();++i){auto space=(i+1<onsets.size()?onsets[i+1]:bar)-onsets[i];int pitch=24+(c.bass>=0?c.bass:c.root);
    if(o.bassRole=="Acoustic")pitch=36+c.root+c.intervals[i%c.intervals.size()]%12;
    if(o.bassRole=="Synth")pitch+=12;
    auto duration=std::max<int64_t>(1,space-(o.bassRole=="808"?std::max<int64_t>(1,bar/64):1));if(o.bassRole=="Synth"||o.bassRole=="Acoustic")duration=std::max<int64_t>(1,std::min(duration,bar/8));
    while(pitch<o.bassLow)pitch+=12;while(pitch>o.bassHigh)pitch-=12;
    add(*bass,b,onsets[i],pitch,duration,90+int(p.settings.energy*15));
   }
  }
  if(o.melody&&o.phraseMelody&&(o.melodyRole=="Main"||o.melodyRole=="Counter")){
   int phase=b%4;for(int i=0;i<8;++i){bool cadence=phase==3&&i==4;if(phase==3&&i>=5)continue;if(!cadence&&i!=0&&!rhythm[(i+(phase==2?2:0))%8])continue;
    int index=motif[(i+(phase==2?1:0))%4];int pitch=cadence?60+c.root:v[size_t(index)%v.size()]+(o.melodyRole=="Counter"?0:12);
    int64_t offset=bar*i/8+(o.melodyRole=="Counter"?bar/16:0);auto length=std::max<int64_t>(1,bar/16);int velocity=65+int(p.settings.energy*20)+(i==0?10:i%2?0:4);
    add(*melody,b,offset,inRegister(pitch),length,velocity);
   }
  }else if(o.melody){int steps=o.melodyRole=="Arpeggio"?8:4;
   for(int i=0;i<steps;++i){if(o.melodyRole=="Texture"&&i>0)break;if(i>0&&double(next())/4294967296.>p.settings.melodicDensity)continue;
    int index=o.melodyRole=="Arpeggio"?i:motif[i%4]+(b%4==3?1:0);int pitch=v[size_t(index)%v.size()]+(o.melodyRole=="Counter"?0:12);pitch=inRegister(pitch);
    auto length=o.melodyRole=="Texture"?bar-1:std::max<int64_t>(1,bar/(steps*2));
    add(*melody,b,bar*i/steps,pitch,length,70+int(p.settings.energy*20));
   }
  }
 }
 if(o.bass&&o.bassConnection!="Gated")for(size_t i=0;i+1<bass->notes.size();++i){auto&n=bass->notes[i];const auto&nextNote=bass->notes[i+1];const auto gap=nextNote.tick-n.tick;const bool samePitch=n.pitch==nextNote.pitch;const auto overlap=o.bassConnection=="Legato"&&!samePitch?std::min<int64_t>(12,std::max<int64_t>(1,nextNote.duration/2)):0;n.duration=std::min<int64_t>(gap+overlap,bar*p.settings.bars-n.tick);}
 if(o.bass&&o.glideTicks>0){int previous=-1;for(auto&n:bass->notes){n.channel=2;if(previous>=0&&previous!=n.pitch){n.glideFrom=previous-n.pitch;n.glideTicks=int(std::min<int64_t>(o.glideTicks,n.duration));n.bendRange=o.bendRange;if(std::abs(n.glideFrom)>o.bendRange)return juce::Result::fail("Bass interval exceeds Pitch Bend range. Increase the range or disable Glide.");}previous=n.pitch;}}
 p.harmony=encodeHarmony(o);r=validate(p);if(r.wasOk())r=verifyLockedContent(target,p);if(r.wasOk())target=std::move(p);return r;
}
}
