#pragma once
#include "MusicCore.h"
#include "TempoMap.h"
namespace atlas::music {
struct SongSection{juce::String name;int bars=4;unsigned parts=31;bool fill=false;int sourceFirst=-1,sourceBars=0;};
inline juce::Result buildArrangement(Project&p,int first,int length,const std::vector<SongSection>&sections,const juce::String&fillTrack={},int fillBeats=1,int fillSteps=4){
 auto r=validate(p);if(r.failed())return r;
 if(first<0||length<1||length>p.settings.bars||first>p.settings.bars-length||sections.empty()||sections.size()>64)return juce::Result::fail("Choose a source range inside the current song");
 int total=0;for(const auto&s:sections){if(s.name.trim().isEmpty()||s.name.length()>64||s.bars<0||s.bars>4096-total||s.parts>31)return juce::Result::fail("Invalid section; song limit is 4096 bars");if(s.sourceFirst < -1||s.sourceBars<0)return juce::Result::fail("Invalid section source range");
  if(s.bars){const int begin=s.sourceFirst<0?first:s.sourceFirst,count=s.sourceBars==0?length:s.sourceBars;if(count<1||count>p.settings.bars||begin>p.settings.bars-count)return juce::Result::fail("Section source range is outside the current song: "+s.name);}
  total+=s.bars;}if(!total)return juce::Result::fail("Enable at least one section");
 for(const auto&t:p.tracks)if(t.midiLocked&&(!t.notes.empty()||!t.controls.empty()))return juce::Result::fail("Unlock MIDI tracks before arranging the song");
 auto next=p;next.settings.bars=total;const auto bar=barTicks(p.settings);juce::Array<juce::var>markers;
 TempoMap sourceTempo(p);next.tempos.clear();int tempoPosition=0;double currentTempo=p.settings.bpm;
 auto addTempo=[&](int64_t tick,double bpm){if(tick==0){next.settings.bpm=bpm;currentTempo=bpm;}else if(bpm!=currentTempo){next.tempos.push_back({tick,bpm});currentTempo=bpm;}};
 for(const auto&s:sections){if(!s.bars)continue;int count=s.sourceBars==0?length:s.sourceBars;int64_t sourceStart=int64_t(s.sourceFirst<0?first:s.sourceFirst)*bar;for(int repeat=0;repeat<s.bars;repeat+=count){int64_t destination=int64_t(tempoPosition+repeat)*bar;addTempo(destination,sourceTempo.bpmAt(sourceStart));for(const auto&t:p.tempos)if(t.tick>sourceStart&&t.tick<sourceStart+int64_t(std::min(count,s.bars-repeat))*bar)addTempo(destination+t.tick-sourceStart,t.bpm);}tempoPosition+=s.bars;}
 int position=0;for(const auto&s:sections){if(!s.bars)continue;auto*o=new juce::DynamicObject;o->setProperty("name",s.name.trim());o->setProperty("start",position);o->setProperty("bars",s.bars);markers.add(juce::var(o));position+=s.bars;}next.sections=markers;
 for(size_t ti=0;ti<p.tracks.size();++ti){const auto&t=p.tracks[ti];auto&target=next.tracks[ti];target.notes.clear();target.controls.clear();unsigned group=gmDrumNote(t.role)>=0?1:t.role=="Bass"?2:t.role=="Chords"?4:t.role=="Melody"?8:16;position=0;
  for(size_t si=0;si<sections.size();++si){const auto&s=sections[si];const int sourceBars=s.sourceBars==0?length:s.sourceBars;const auto sourceStart=int64_t(s.sourceFirst<0?first:s.sourceFirst)*bar,sourceLength=int64_t(sourceBars)*bar;
   if(s.parts&group)for(int repeat=0;repeat<s.bars;repeat+=sourceBars)for(auto n:t.notes)if(n.tick>=sourceStart&&n.tick<sourceStart+sourceLength){
    auto relative=n.tick-sourceStart;if(relative>=int64_t(s.bars-repeat)*bar)continue;auto localEnd=std::min(sourceLength,int64_t(s.bars-repeat)*bar);n.microtiming=std::max(n.microtiming,-relative);if(relative+n.microtiming>=localEnd)continue;
    n.duration=std::min({n.duration,localEnd-relative,localEnd-relative-n.microtiming});n.glideTicks=std::min(n.glideTicks,int(n.duration));n.tick=int64_t(position+repeat)*bar+relative;
    n.id=p.id+":section:"+juce::String(int(si))+":"+juce::String(repeat)+":"+n.id;target.notes.push_back(n);if(target.notes.size()>100000)return juce::Result::fail("Arrangement exceeds the per-track note limit");
   }
   if(s.parts&group)for(int repeat=0;repeat<s.bars;repeat+=sourceBars)for(auto e:t.controls)if(e.tick>=sourceStart&&e.tick<sourceStart+sourceLength){auto relative=e.tick-sourceStart;if(relative>=int64_t(s.bars-repeat)*bar)continue;e.tick=int64_t(position+repeat)*bar+relative;e.id=p.id+":section:"+juce::String(int(si))+":"+juce::String(repeat)+":"+e.id;target.controls.push_back(e);}
   position+=s.bars;
  }
 }
 position=0;for(const auto&s:sections){position+=s.bars;if(!s.bars||!s.fill)continue;
  if(position==total)return juce::Result::fail("A transition fill needs a following nonempty section");
  if(!(s.parts&1))return juce::Result::fail("Enable Drums in the outgoing section before adding its fill");
  if(fillTrack.isEmpty())return juce::Result::fail("Choose a drum lane for transition fills");
  r=fillDrums(next,fillTrack,position-1,fillBeats,fillSteps,p.settings.seed^(uint32_t(position)*0x9e3779b9u));if(r.failed())return r;
 }
 r=validate(next);if(r.failed())return r;p=std::move(next);return juce::Result::ok();
}
}
