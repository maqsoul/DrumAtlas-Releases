#pragma once
#include "Analysis.h"
#include "TempoPeriodicity.h"
#include <mutex>
#include <map>
#include <deque>

namespace atlas {
struct TempoEstimate {double bpm=0,confidence=0;bool ready=false,periodic=false;};
// Detect periodic spectral attacks, rather than mistaking pitch for tempo.
inline TempoEstimate estimateTempo(const std::vector<float>& audio){
    TempoEstimate result;result.ready=true;
    constexpr int size=1024,hop=220;
    if(audio.size()<size_t(analysisRate*2.5))return result;
    tempo_detail::DrumEventSource beatEvents;beatEvents.end=audio.size()/analysisRate;
    for(int hit:onsets(audio)){double peak=0;for(size_t k=size_t(hit);k<std::min(audio.size(),size_t(hit)+1100);++k)peak=std::max(peak,double(std::abs(audio[k])));beatEvents.events.push_back({hit/analysisRate,1.,peak});}
    tempo_detail::ReferenceTempo periodic;
    if(tempo_detail::estimateReferenceTempo(beatEvents,0,beatEvents.end,0,periodic).wasOk()){
        double bpm=periodic.bpm;
        if(bpm>160&&periodic.ambiguous&&periodic.score<.65)for(auto alternative:periodic.alternatives)
            if(std::abs(alternative.bpm*2-bpm)<bpm*.025&&alternative.relativeSupport>.9){bpm=alternative.bpm;break;}
        return {bpm,periodic.score,true,true};
    }
    juce::dsp::FFT fft(10);std::array<float,size*2> frame{};std::array<float,size/2> last{};
    std::vector<double> flux;
    for(size_t pos=0;pos+size<audio.size();pos+=hop){
        frame.fill(0);for(int k=0;k<size;++k)frame[size_t(k)]=audio[pos+size_t(k)]*float(.5-.5*std::cos(juce::MathConstants<double>::twoPi*k/(size-1)));
        fft.performFrequencyOnlyForwardTransform(frame.data());double energy=0;
        for(int k=2;k<size/2;++k){const float v=std::log1p(frame[size_t(k)]*10);energy+=std::max(0.f,v-last[size_t(k)]);last[size_t(k)]=v;}flux.push_back(energy);
    }
    if(flux.size()<100)return result;
    double mean=0;for(auto v:flux)mean+=v;mean/=flux.size();double max=0,energy=0;
    for(auto&v:flux){v=std::max(0.,v-mean*.65);max=std::max(max,v);energy+=v*v;}
    if(max<.001||energy<.001)return result;
    int attacks=0;for(size_t i=2;i+2<flux.size();++i)if(flux[i]>max*.12&&flux[i]>flux[i-1]&&flux[i]>=flux[i+1])++attacks;
    if(attacks<5)return result;
    const double rate=analysisRate/hop;
    auto correlate=[&](double lag){double sum=0,e1=0,e2=0;const int lo=int(lag);const double f=lag-lo;
        for(size_t i=size_t(lo+1);i<flux.size();++i){double a=flux[i],b=flux[i-size_t(lo)]*(1-f)+flux[i-size_t(lo)-1]*f;sum+=a*b;e1+=a*a;e2+=b*b;}return sum/std::sqrt(e1*e2+1.e-20);};
    double best=0;std::array<double,561>scores{};
    for(int q=240;q<=800;++q){double bpm=q*.25,lag=rate*60/bpm;
        double score=correlate(lag)+.45*correlate(2*lag)+.18*correlate(3*lag);scores[size_t(q-240)]=score;
        if(score>best){best=score;result.bpm=bpm;}}
    // Interpolated short lags have slightly lower correlation. Resolve a strong
    // double-tempo local peak rather than always preferring its smoother subharmonic.
    for(size_t i=1;i+1<scores.size();++i){double candidate=60.+i*.25;
        if(scores[i]>=scores[i-1]&&scores[i]>=scores[i+1]&&scores[i]>=best*.94&&std::abs(candidate/result.bpm-2.)<.025)result.bpm=candidate;}
    result.confidence=best/1.63;
    if(result.confidence<.19)result.bpm=0;
    return result;
}

class TempoDetector:private juce::Thread {
public:
 TempoDetector():juce::Thread("DrumAtlas tempo"){startThread(juce::Thread::Priority::low);}
 ~TempoDetector()override{signalThreadShouldExit();notify();stopThread(-1);}
 TempoEstimate get(const juce::File& file){
    if(file==juce::File())return {0,0,true};
    const auto key=signature(file);std::lock_guard<std::mutex>lock(mutex);
    if(auto it=cache.find(key);it!=cache.end())return it->second;
    cache[key]={};queue.emplace_back(file,key);while(queue.size()>8){cache.erase(queue.front().second);queue.pop_front();}notify();return {};
 }
private:
 static juce::String signature(const juce::File& file){auto f=ioFile(file);return f.getFullPathName()+"|"+juce::String(f.getSize())+"|"+juce::String(f.getLastModificationTime().toMilliseconds());}
 void run()override{
    juce::AudioFormatManager fm;registerFormats(fm);
    while(!threadShouldExit()){
        std::pair<juce::File,juce::String>job;
        {std::lock_guard<std::mutex>lock(mutex);if(!queue.empty()){job=queue.back();queue.pop_back();}}
        if(job.second.isEmpty()){wait(150);continue;}
        TempoEstimate chosen{0,0,true};
        try{auto decoded=decode(fm,job.first,0,24);chosen=estimateTempo(decoded.mono);
            // A quiet intro must not decide the whole track's tempo.
            if(decoded.duration>35&&!threadShouldExit()){
                auto middle=decode(fm,job.first,std::max(0.,decoded.duration*.45-12.),24);auto candidate=estimateTempo(middle.mono);
                if((candidate.periodic&&!chosen.periodic)||(candidate.periodic==chosen.periodic&&candidate.confidence>chosen.confidence))chosen=candidate;
            }
        }catch(...){chosen={0,0,true};}
        if(threadShouldExit())break;
        {std::lock_guard<std::mutex>lock(mutex);cache[job.second]=chosen;if(cache.size()>1024){auto keep=cache[job.second];cache.clear();cache[job.second]=keep;}}
    }
 }
 std::mutex mutex;std::map<juce::String,TempoEstimate>cache;std::deque<std::pair<juce::File,juce::String>>queue;
};
}
