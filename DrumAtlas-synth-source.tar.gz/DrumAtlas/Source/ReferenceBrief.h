#pragma once
#include "Composer.h"

namespace atlas::composer {
inline juce::var referenceBrief(const Analysis& a) {
    auto brief=a.json();
    auto* root=brief.getDynamicObject();
    root->removeProperty("energy_per_second");
    root->removeProperty("musical_guide");
    auto* bars=a.musicalGuide["bars"].getArray();
    juce::Array<juce::var> timeline;
    const int count=bars?bars->size():0;
    const int spans=count?std::min(16,count):int(std::min<size_t>(16,a.energy.size()));
    for(int span=0;span<spans;++span){
        int first=span*count/spans,end=(span+1)*count/spans;
        auto* part=new juce::DynamicObject;timeline.add(juce::var(part));
        part->setProperty("from_seconds",a.duration*span/spans);
        part->setProperty("to_seconds",a.duration*(span+1)/spans);
        auto lo=a.energy.size()*span/spans,hi=a.energy.size()*(span+1)/spans;
        double energy=0;for(auto i=lo;i<hi;++i)energy+=a.energy[i];
        part->setProperty("rms",hi>lo?energy/(hi-lo):0.);
        if(first==end)continue;
        juce::StringArray chords;
        for(int b=first;b<end&&chords.size()<8;++b){
            auto& row=(*bars)[b];auto chord=row["chord"].toString();
            if(double(row["chord_confidence"])>=.3&&chord.isNotEmpty()&&(chords.isEmpty()||chords[chords.size()-1]!=chord))chords.add(chord);
        }
        part->setProperty("estimated_chords",chords);
        for(auto lane:{"kick","snare","hat"}){
            std::array<double,16> hits{};
            for(int b=first;b<end;++b){auto pattern=(*bars)[b][lane];if(pattern.size()==16)for(int step=0;step<16;++step)hits[step]+=double(pattern[step]);}
            juce::Array<juce::var> percentages;
            for(double hit:hits)percentages.add(juce::roundToInt(100.*hit/(end-first)));
            part->setProperty(lane,percentages);
        }
    }
    root->setProperty("timeline",timeline);return brief;
}
}
