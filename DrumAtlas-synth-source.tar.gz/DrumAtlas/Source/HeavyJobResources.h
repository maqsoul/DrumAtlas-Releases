#pragma once
#include <juce_core/juce_core.h>
#include <mutex>
#include "MemoryAdmission.h"

namespace atlas {
// Admission only: resident models and Live instruments are not memory-capped.
// Use on background/control threads, never the audio callback. No waiting queue.
class HeavyJobResources {
public:
    HeavyJobResources() : local(mutex(), std::try_to_lock), process("DrumAtlas-heavy-job-v1") {
        owned = local.owns_lock() && process.enter(0);
    }
    ~HeavyJobResources() { if (owned) process.exit(); }
    bool acquired() const { return owned; }
    static juce::Result busy() {
        return juce::Result::fail("Another DrumAtlas AI, stem separation or instrument render job is running. Wait for it to finish or cancel it, then retry.");
    }
private:
    static std::mutex& mutex() { static std::mutex value; return value; }
    std::unique_lock<std::mutex> local;
    juce::InterProcessLock process;
    bool owned = false;
    JUCE_DECLARE_NON_COPYABLE(HeavyJobResources)
};
}
