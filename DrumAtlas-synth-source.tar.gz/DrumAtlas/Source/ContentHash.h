#pragma once
#include <juce_cryptography/juce_cryptography.h>
namespace atlas {
juce::String contentSHA256(const juce::File& file,const std::function<bool()>& cancel={});
}
