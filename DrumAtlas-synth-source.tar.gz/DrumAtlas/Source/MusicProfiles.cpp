#include "MusicProfiles.h"
#include "MusicProfileData.h"
#include <algorithm>
#include <cmath>
#include <map>
#include <set>

namespace atlas::music {
namespace {
bool numeric(const juce::var&v){return v.isInt()||v.isInt64()||v.isDouble();}
bool bounded(const juce::var&v,double lo,double hi){return numeric(v)&&std::isfinite(double(v))&&double(v)>=lo&&double(v)<=hi;}
bool text(const juce::var&v){return v.isString()&&v.toString().trim().isNotEmpty()&&v.toString().length()<=128;}
bool strings(const juce::var&v,juce::StringArray&out){
    if(!v.isArray()||v.size()<1||v.size()>64)return false;
    for(const auto&x:*v.getArray()){if(!text(x)||out.contains(x.toString()))return false;out.add(x.toString());}return true;
}
bool distribution(const juce::var&v,std::array<double,16>&out){
    if(!v.isArray()||v.size()!=16)return false;for(int i=0;i<16;++i){if(!bounded(v[i],0,1))return false;out[size_t(i)]=double(v[i]);}return true;
}
juce::Result fail(const juce::String&s){return juce::Result::fail(s);}
template<class T> const T* find(const std::vector<T>&v,const juce::String&id){for(const auto&p:v)if(p.id==id)return &p;return nullptr;}
template<class T> juce::Result normalise(std::vector<StyleWeight>&weights,const std::vector<T>&profiles){
    if(weights.empty()||weights.size()>64)return fail("Select 1..64 profiles");
    std::map<juce::String,double> merged;double total=0;
    for(const auto&w:weights){if(!find(profiles,w.id)||!std::isfinite(w.weight)||w.weight<0||w.weight>100)return fail("Unknown profile or invalid weight");merged[w.id]+=w.weight;total+=w.weight;}
    if(total<=0)return fail("At least one profile weight must be positive");
    weights.clear();for(const auto&[id,w]:merged)if(w>0)weights.push_back({id,w/total});return juce::Result::ok();
}
template<class T> const T& dominant(const std::vector<StyleWeight>&weights,const std::vector<T>&profiles){
    const StyleWeight*best=&weights.front();for(const auto&w:weights)if(w.weight>best->weight)best=&w;return *find(profiles,best->id);
}
juce::var object(){return new juce::DynamicObject;}
void put(juce::var&v,const char*k,juce::var x){v.getDynamicObject()->setProperty(k,x);}
juce::var array(const juce::StringArray&a){juce::Array<juce::var>v;for(const auto&s:a)v.add(s);return v;}
juce::var array(const std::array<double,16>&a){juce::Array<juce::var>v;for(double x:a)v.add(x);return v;}
}
juce::Result ProfileRegistry::load(const juce::File&file){
    if(!file.existsAsFile()||file.getSize()>4*1024*1024)return fail("Missing or oversized profile registry");
    juce::var value;auto r=juce::JSON::parse(file.loadFileAsString(),value);return r.failed()?r:decode(value);
}
ProfileRegistry ProfileRegistry::builtIn(){ProfileRegistry r;r.decode(juce::JSON::parse(juce::String::fromUTF8(musicProfileData)));return r;}
juce::Result ProfileRegistry::decode(const juce::var&v){
    if(!v.isObject()||!v["schema_version"].isInt()||int(v["schema_version"])!=1||!text(v["revision"])||!v["genres"].isArray()||!v["moods"].isArray())return fail("Unsupported profile registry schema");
    if(v["genres"].size()<1||v["genres"].size()>512||v["moods"].size()<1||v["moods"].size()>512)return fail("Invalid profile count");
    ProfileRegistry next;next.registryRevision=v["revision"].toString();std::set<juce::String>ids;
    for(const auto&x:*v["genres"].getArray()){
        GenreProfile p;if(!x.isObject()||!text(x["id"])||!text(x["revision"])||!ids.insert(x["id"].toString()).second)return fail("Invalid genre identity");
        p.id=x["id"].toString();p.revision=x["revision"].toString();
        if(!bounded(x["bpm_min"],20,300)||!bounded(x["bpm_max"],20,300)||double(x["bpm_min"])>double(x["bpm_max"]))return fail("Invalid genre BPM range");
        for(auto key:{"swing","microtiming","density"})if(!bounded(x[key],0,1))return fail("Invalid genre control");
        p.bpmMin=double(x["bpm_min"]);p.bpmMax=double(x["bpm_max"]);p.swing=double(x["swing"]);p.microtiming=double(x["microtiming"]);p.density=double(x["density"]);
        if(!distribution(x["kick"],p.kick)||!distribution(x["snare"],p.snare)||!distribution(x["hat"],p.hat)||!strings(x["roles"],p.roles)||!strings(x["scales"],p.scalePreferences)||!strings(x["arrangement"],p.arrangement)||!strings(x["tags"],p.tags))return fail("Invalid genre patterns or rules");
        if(x.hasProperty("facets")){
            auto facets=x["facets"];auto*o=facets.getDynamicObject();if(!o)return fail("Invalid genre facets");
            for(const auto&property:o->getProperties())if(!juce::StringArray{"era","region","subgenre","texture"}.contains(property.name.toString()))return fail("Unknown genre facet");
            auto read=[&](const char*key,juce::StringArray&values){if(!facets.hasProperty(key))return true;auto v=facets[key];if(!v.isArray()||v.size()>32)return false;for(auto&item:*v.getArray()){if(!text(item)||item.toString()!=item.toString().trim()||values.contains(item.toString(),true))return false;values.add(item.toString());}return true;};
            if(!read("era",p.eras)||!read("region",p.regions)||!read("subgenre",p.subgenres)||!read("texture",p.textures))return fail("Invalid genre facet values");
        }
        next.genreProfiles.push_back(p);
    }
    ids.clear();for(const auto&x:*v["moods"].getArray()){
        MoodProfile p;if(!x.isObject()||!text(x["id"])||!text(x["revision"])||!ids.insert(x["id"].toString()).second)return fail("Invalid mood identity");
        p.id=x["id"].toString();p.revision=x["revision"].toString();
        for(auto key:{"energy","darkness","complexity","groove","melodic_density","articulation"})if(!bounded(x[key],0,1))return fail("Invalid mood control");
        p.energy=double(x["energy"]);p.darkness=double(x["darkness"]);p.complexity=double(x["complexity"]);p.groove=double(x["groove"]);p.melodicDensity=double(x["melodic_density"]);p.articulation=double(x["articulation"]);
        if(!strings(x["scales"],p.scalePreferences)||!strings(x["timbres"],p.timbres))return fail("Invalid mood harmony or timbres");next.moodProfiles.push_back(p);
    }
    *this=std::move(next);return juce::Result::ok();
}
juce::var ProfileRegistry::encode()const{
    auto v=object();put(v,"schema_version",1);put(v,"revision",registryRevision);juce::Array<juce::var>genres,moods;
    for(const auto&p:genreProfiles){auto x=object();put(x,"id",p.id);put(x,"revision",p.revision);put(x,"bpm_min",p.bpmMin);put(x,"bpm_max",p.bpmMax);put(x,"swing",p.swing);put(x,"microtiming",p.microtiming);put(x,"density",p.density);put(x,"kick",array(p.kick));put(x,"snare",array(p.snare));put(x,"hat",array(p.hat));put(x,"roles",array(p.roles));put(x,"scales",array(p.scalePreferences));put(x,"arrangement",array(p.arrangement));put(x,"tags",array(p.tags));
        if(!p.eras.isEmpty()||!p.regions.isEmpty()||!p.subgenres.isEmpty()||!p.textures.isEmpty()){
            auto facets=object();if(!p.eras.isEmpty())put(facets,"era",array(p.eras));if(!p.regions.isEmpty())put(facets,"region",array(p.regions));if(!p.subgenres.isEmpty())put(facets,"subgenre",array(p.subgenres));if(!p.textures.isEmpty())put(facets,"texture",array(p.textures));put(x,"facets",facets);
        }genres.add(x);}
    for(const auto&p:moodProfiles){auto x=object();put(x,"id",p.id);put(x,"revision",p.revision);put(x,"energy",p.energy);put(x,"darkness",p.darkness);put(x,"complexity",p.complexity);put(x,"groove",p.groove);put(x,"melodic_density",p.melodicDensity);put(x,"articulation",p.articulation);put(x,"scales",array(p.scalePreferences));put(x,"timbres",array(p.timbres));moods.add(x);}
    put(v,"genres",genres);put(v,"moods",moods);return v;
}
juce::Result ProfileRegistry::blend(std::vector<StyleWeight>genres,std::vector<StyleWeight>moods,StyleBlend&target)const{
    auto r=normalise(genres,genreProfiles);if(r.failed())return r;r=normalise(moods,moodProfiles);if(r.failed())return r;
    StyleBlend b;b.genres=genres;b.moods=moods;b.genre=dominant(genres,genreProfiles);b.mood=dominant(moods,moodProfiles);
    b.notices.add("Discrete genre rules: "+b.genre.id+"; mood rules: "+b.mood.id+" (greatest weight, lexical tie-break)");
    auto&g=b.genre;g.swing=g.microtiming=g.density=0;g.kick.fill(0);g.snare.fill(0);g.hat.fill(0);
    double lo=20,hi=300;
    for(const auto&w:genres){auto&p=*find(genreProfiles,w.id);lo=std::max(lo,p.bpmMin);hi=std::min(hi,p.bpmMax);g.swing+=w.weight*p.swing;g.microtiming+=w.weight*p.microtiming;g.density+=w.weight*p.density;for(size_t i=0;i<16;++i){g.kick[i]+=w.weight*p.kick[i];g.snare[i]+=w.weight*p.snare[i];g.hat[i]+=w.weight*p.hat[i];}}
    if(lo<=hi){g.bpmMin=lo;g.bpmMax=hi;}else b.notices.add("BPM ranges do not intersect; using dominant genre range: "+g.id);
    auto&m=b.mood;m.energy=m.darkness=m.complexity=m.groove=m.melodicDensity=m.articulation=0;
    for(const auto&w:moods){auto&p=*find(moodProfiles,w.id);m.energy+=w.weight*p.energy;m.darkness+=w.weight*p.darkness;m.complexity+=w.weight*p.complexity;m.groove+=w.weight*p.groove;m.melodicDensity+=w.weight*p.melodicDensity;m.articulation+=w.weight*p.articulation;}
    target=std::move(b);return juce::Result::ok();
}
}
