#pragma once
#include "MusicCore.h"
namespace atlas::music {
struct HarmonyOptions {
    juce::String progression="Amadd9 Fmaj7 Dm9 Em7", bassRole="808", melodyRole="Main";
    juce::String melodyTarget="Melody";
    bool voiceLeading=true, chords=true, bass=true, melody=true;
    int low=48, high=84, maxLeap=12;
    int glideTicks=0, bendRange=12;
    bool phraseMelody=false;
    int melodyLow=48, melodyHigh=96;
    int bassLow=12,bassHigh=72;
    juce::String bassConnection="Gated"; // Gated, Connected, Legato (instrument-dependent).
};
struct ChordSpec { juce::String name; int root=0; std::vector<int> intervals; int bass=-1; };
juce::Result parseChords(const juce::String&,std::vector<ChordSpec>&);
juce::var encodeHarmony(const HarmonyOptions&);
juce::Result decodeHarmony(const juce::var&,HarmonyOptions&);
juce::Result applyHarmony(Project&,const HarmonyOptions&);
juce::String suggestHarmony(const Settings&,int variation);
}
