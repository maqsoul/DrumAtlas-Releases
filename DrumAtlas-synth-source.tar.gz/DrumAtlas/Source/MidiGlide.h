#pragma once
#include <juce_audio_basics/juce_audio_basics.h>
#include <cmath>
namespace atlas::music {
// Same stepped linear-semitone curve for MIDI and local audio (8 ticks, 960 PPQ).
inline int glideWheel(int from,int ticks,int range,double elapsed){
 if(ticks<=0||elapsed>=ticks)return 8192;
 double semitones=from*(1.-std::floor(std::max(0.,elapsed)/8.)*8./ticks);
 return juce::jlimit(0,16383,8192+int(std::lround(semitones/range*(semitones>=0?8191:8192))));
}
inline double glideRatio(int from,int ticks,int range,double elapsed){
 auto wheel=glideWheel(from,ticks,range,elapsed);return std::pow(2.,(wheel-8192)*double(range)/(wheel>=8192?8191:8192)/12.);
}
template<class Emit>void glideMidi(int channel,int from,int ticks,int range,Emit emit){
 if(ticks<=0)return;
 for(auto cc:{std::pair<int,int>{101,0},{100,0},{6,range},{38,0},{101,127},{100,127}})emit(0,juce::MidiMessage::controllerEvent(channel,cc.first,cc.second));
 for(int t=0;t<ticks;t+=8)emit(t,juce::MidiMessage::pitchWheel(channel,glideWheel(from,ticks,range,t)));
 emit(ticks,juce::MidiMessage::pitchWheel(channel,8192));
}
}
