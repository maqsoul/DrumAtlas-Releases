#pragma once
#include <juce_core/juce_core.h>
namespace atlas::hosting {
inline int moduleMachine(const juce::File& file) {
    if (!file.hasFileExtension("dll")) return 0;
    juce::FileInputStream input(file);
    if (!input.openedOk() || file.getSize()<64 || input.readShort()!=0x5a4d) return 0;
    input.setPosition(0x3c);auto pe=juce::uint32(input.readInt());
    if (pe>file.getSize()-24 || !input.setPosition(pe) || input.readInt()!=0x4550) return 0;
    return juce::uint16(input.readShort());
}
inline juce::File worker32File(const juce::File& primary) {
    auto overridePath=juce::SystemStats::getEnvironmentVariable("DRUMATLAS_WORKER_X86",{});
    return juce::File::isAbsolutePath(overridePath)?juce::File(overridePath):primary.getSiblingFile("AtlasWorker32.exe");
}
inline juce::File workerForModule(const juce::File& primary,const juce::File& plugin) {
#if JUCE_WINDOWS
    if(moduleMachine(plugin)==0x14c) return worker32File(primary);
#endif
    return primary;
}
inline juce::Result workerForChain(const juce::File& primary,const juce::var& instrument,
                                  const juce::var& effects,juce::File& result) {
    auto path=instrument["path"].toString();
    if(!juce::File::isAbsolutePath(path)) return juce::Result::fail("Absolute instrument path required");
    result=workerForModule(primary,juce::File(path));
    const bool x86=moduleMachine(juce::File(path))==0x14c;
    if(auto*chain=effects.getArray())for(const auto& effect:*chain) {
        if(bool(effect["bypass"]))continue;
        auto fxPath=effect["path"].toString();
        if(!juce::File::isAbsolutePath(fxPath))return juce::Result::fail("Absolute effect path required");
        if((moduleMachine(juce::File(fxPath))==0x14c)!=x86)
            return juce::Result::fail("Instrument and active effects must have the same bitness; render the instrument before applying effects of another bitness");
    }
    if(!result.existsAsFile())return juce::Result::fail(x86?"AtlasWorker32.exe is missing; install the 32-bit bridge alongside AtlasWorker.exe":"AtlasWorker is missing");
    return juce::Result::ok();
}
}
