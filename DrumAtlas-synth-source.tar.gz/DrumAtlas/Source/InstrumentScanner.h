#pragma once
#include <vector>
#include <juce_core/juce_core.h>
namespace atlas::hosting {
// Must be called from a background thread. Crash isolation is not a security sandbox.
struct ScanResult {juce::String status,error;juce::var plugins,report;bool cached=false;};
struct ProbeContext {juce::String workerFingerprint,environment;};
ProbeContext probeContext(const juce::File&worker,const std::function<bool()>&cancel={});
ScanResult scan(const juce::File& worker,const juce::File& plugin,const juce::File& scratch,int timeoutMs=30000,bool probe=false,const std::function<bool()>&cancel={},const std::function<void()>&slow={},const juce::String&probeUid={});
ScanResult scanCached(const juce::File&worker,const juce::File&plugin,const juce::File&cache,bool force=false,int timeoutMs=30000,const std::function<bool()>&cancel={},const std::function<void()>&slow={},bool probe=false,const juce::String&probeUid={});
juce::Result discover(const juce::Array<juce::File>&roots,juce::Array<juce::File>&modules,const std::function<bool()>&cancel={});
juce::Result scanCatalogue(const juce::File&worker,const juce::Array<juce::File>&modules,const juce::File&cache,
                           std::vector<ScanResult>&results,const std::function<bool()>&cancel,
                           const std::function<void(int,const juce::String&)>&progress);
juce::Array<juce::File>defaultRoots();
juce::Result testIsolation(const juce::File& worker);
}
