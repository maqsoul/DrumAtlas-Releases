#pragma once
#include "MusicCore.h"
#include <juce_core/juce_core.h>

namespace atlas::live {
inline juce::StringArray deviceNames(){return {"Analog","Collision","Drift","Electric","Meld","Operator","Tension","Wavetable"};}
inline bool native(const music::Project&p){for(auto&t:p.tracks)if(t.liveDevice.isNotEmpty())return true;return false;}
struct Connection {juce::String session,error;juce::StringArray devices;double bpm=0;};
inline Connection connection(const juce::File&root){
    Connection result;int active=0;auto now=juce::Time::currentTimeMillis();
    for(auto&file:root.getChildFile("LiveBridge/instances").findChildFiles(juce::File::findFiles,false,"*.json")){
        if(file.getSize()>65536)continue;auto data=juce::JSON::parse(file);auto age=now-juce::int64(data["heartbeat_ms"]);if(int(data["schema"])!=1||age<0||age>10000)continue;
        ++active;result.session=data["session"].toString();result.bpm=double(data["tempo"]);if(!bool(data["supported"]))result.error=data["status"].toString();
        if(auto*values=data["devices"].getArray())for(auto&value:*values)if(music::validLiveDevice(value.toString()))result.devices.addIfNotAlreadyThere(value.toString());
    }
    if(active!=1){result.error=active>1?"More than one Live bridge is active; keep one Live instance connected":"Enable DrumAtlasBridge in Live Settings > Link, Tempo & MIDI > Control Surface";result.session.clear();}
    if(result.session.length()!=32||!result.session.containsOnly("0123456789abcdef")){result.session.clear();if(result.error.isEmpty())result.error="Invalid Live bridge session";}
    return result;
}
inline juce::Array<juce::var> instruments(const juce::File&root){
    auto host=connection(root);juce::Array<juce::var>result;if(host.error.isNotEmpty())return result;
    for(auto&name:host.devices){auto*o=new juce::DynamicObject;o->setProperty("format","Live");o->setProperty("name",name);o->setProperty("uid","live:"+name);o->setProperty("instrument",true);result.add(juce::var(o));}return result;
}
inline juce::Result request(const juce::File&root,juce::var payload,juce::var&answer,const std::function<bool()>&cancel={}){
    auto host=connection(root);if(host.error.isNotEmpty())return juce::Result::fail(host.error);
    auto id=juce::Uuid().toString().removeCharacters("-");auto*o=payload.getDynamicObject();if(!o)return juce::Result::fail("Invalid bridge payload");
    o->setProperty("schema",1);o->setProperty("id",id);o->setProperty("session",host.session);o->setProperty("created_ms",juce::Time::currentTimeMillis());
    auto folder=root.getChildFile("LiveBridge/requests/"+host.session);auto result=folder.createDirectory();if(result.failed())return result;
    auto target=folder.getChildFile(id+".json");juce::TemporaryFile temp(target);if(!temp.getFile().replaceWithText(juce::JSON::toString(payload,true))||!temp.overwriteTargetFileWithTemporary())return juce::Result::fail("Cannot send arrangement to Live");
    auto response=root.getChildFile("LiveBridge/responses/"+host.session+"/"+id+".json");auto deadline=juce::Time::getMillisecondCounterHiRes()+(payload["command"].toString()=="render"?86400000.:90000.);
    auto nextHeartbeatCheck=juce::Time::getMillisecondCounterHiRes()+10000.;
    while(juce::Time::getMillisecondCounterHiRes()<deadline){
        if(response.existsAsFile()){answer=juce::JSON::parse(response);if(answer["id"].toString()!=id||answer["session"].toString()!=host.session)return juce::Result::fail("Live response identity mismatch");return bool(answer["ok"])?juce::Result::ok():juce::Result::fail(answer["error"].toString());}
        if(cancel&&cancel()){target.deleteFile();return juce::Result::fail("Live transfer cancelled; inspect Live in case import had already started");}
        auto now=juce::Time::getMillisecondCounterHiRes();if(now>=nextHeartbeatCheck){nextHeartbeatCheck=now+10000.;auto current=connection(root);if(current.session!=host.session||current.error.isNotEmpty()){target.deleteFile();return juce::Result::fail("Connection to Live was lost; inspect Live before retrying");}}
        juce::Thread::sleep(100);
    }
    target.deleteFile();return juce::Result::fail("Live did not acknowledge the transfer. Inspect Live before retrying; the request is not replayed automatically.");
}
inline juce::var command(const juce::String&name,const juce::String&song){auto*o=new juce::DynamicObject;o->setProperty("command",name);o->setProperty("song_id",song.removeCharacters("-"));return juce::var(o);}
inline juce::var arrangement(const music::Project&p,const juce::File&folder,const juce::File&loop){
    auto result=command("import",p.id);auto*o=result.getDynamicObject();o->setProperty("bpm",p.settings.bpm);o->setProperty("length",double(music::barTicks(p.settings)*p.settings.bars)/music::ppq);
    juce::Array<juce::var>tracks,sections;
    if(auto*source=p.sections.getArray())for(auto&section:*source){auto*v=new juce::DynamicObject;v->setProperty("name",section["name"]);v->setProperty("start",double(int(section["start"])*music::barTicks(p.settings))/music::ppq);v->setProperty("length",double(int(section["bars"])*music::barTicks(p.settings))/music::ppq);sections.add(juce::var(v));}
    for(auto&t:p.tracks)if(t.liveDevice.isNotEmpty()){
        auto*v=new juce::DynamicObject;v->setProperty("name",t.role);v->setProperty("kind","midi");v->setProperty("device",t.liveDevice);juce::Array<juce::var>notes;
        for(auto&n:t.notes)if(music::playsNote(p.settings.seed,n))notes.add(juce::Array<juce::var>{n.pitch,double(n.tick+n.microtiming)/music::ppq,double(n.duration)/music::ppq,n.velocity});v->setProperty("notes",notes);tracks.add(juce::var(v));
    }
    auto manifest=juce::JSON::parse(folder.getChildFile("tracks/manifest.json"));if(auto*outputs=manifest["outputs"].getArray())for(auto&output:*outputs)if(output["track_ids"].size()==1&&output["file"].toString()!="Mix.wav"){auto*v=new juce::DynamicObject;v->setProperty("name",output["track_ids"][0].toString());v->setProperty("kind","audio");v->setProperty("file",folder.getChildFile("tracks").getChildFile(output["file"].toString()).getFullPathName());v->setProperty("gain",loop==juce::File()?1.:.65);tracks.add(juce::var(v));}
    if(loop.existsAsFile()){auto*v=new juce::DynamicObject;v->setProperty("name","Loop");v->setProperty("kind","audio");v->setProperty("file",loop.getFullPathName());tracks.add(juce::var(v));}
    o->setProperty("tracks",tracks);o->setProperty("sections",sections);return result;
}
}
