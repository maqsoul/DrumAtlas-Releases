#pragma once
#include "StemNotes.h"
#include "InstrumentRender.h"
#include "InstrumentScanner.h"

namespace atlas::stemsounds {
inline juce::File root(){
    auto overridePath=juce::SystemStats::getEnvironmentVariable("DRUMATLAS_CACHE_DIR",{});
    return juce::File::isAbsolutePath(overridePath)?juce::File(overridePath):
        juce::File::getSpecialLocation(juce::File::userApplicationDataDirectory).getChildFile("DrumAtlas");
}
struct Match {juce::File preset,preview;juce::String description;};
inline juce::File soundLibrary(){return root().getChildFile("Sound presets");}
inline juce::Result rememberSound(const juce::var& config,const juce::String& label){
    juce::MemoryBlock state;
    if(config["uid"].toString().isEmpty()||config["class_id"].toString().isEmpty()||
       !state.fromBase64Encoding(config["state"].toString())||state.getSize()==0||state.getSize()>16*1024*1024||
       juce::SHA256(state).toHexString()!=config["sha256"].toString())return juce::Result::fail("Invalid saved instrument sound");
    auto folder=soundLibrary().getChildFile(juce::File::createLegalFileName(config["uid"].toString()));
    auto made=folder.createDirectory();if(made.failed())return made;
    auto file=folder.getChildFile(juce::File::createLegalFileName(label).substring(0,80)+"-"+config["sha256"].toString().substring(0,16)+".atlaspreset");
    return file.replaceWithText(juce::JSON::toString(config))?juce::Result::ok():juce::Result::fail("Cannot save sound for matching");
}
inline void collectPreviousSounds(const juce::var& instrument,const stemnotes::Cancel& cancel){
    // Reuse real sounds previously saved by this host, never its empty scanner
    // descriptors. Bounds keep migration from delaying the search indefinitely.
    auto songs=root().getChildFile("Composer/songs");int inspected=0;
    juce::StringArray seen;auto deadline=juce::Time::getMillisecondCounterHiRes()+3000;
    for(auto& entry:juce::RangedDirectoryIterator(songs,true,"response.json",juce::File::findFiles)){
        if(++inspected>2000||juce::Time::getMillisecondCounterHiRes()>deadline||(cancel&&cancel()))break;
        auto file=entry.getFile();if(file.getSize()>24*1024*1024)continue;
        auto response=juce::JSON::parse(file);auto config=response["instrument"];
        if(response["status"].toString()!="configured"||config["uid"].toString()!=instrument["uid"].toString()||
           config["class_id"].toString()!=instrument["class_id"].toString())continue;
        auto sha=config["sha256"].toString();if(sha.isEmpty()||seen.contains(sha))continue;seen.add(sha);
        bool audible=!response.hasProperty("sound_auditions");
        if(auto* rows=response["sound_auditions"].getArray())for(auto& row:*rows)audible|=double(row["peak"])>=1e-5;
        if(audible)rememberSound(config,config["name"].toString()+" saved sound");
    }
}
inline juce::File liveLibrary(){
    auto overridePath=juce::JSON::parse(root().getChildFile("stem-live-library.json")).toString();
    if(juce::File::isAbsolutePath(overridePath)&&juce::File(overridePath).isDirectory())return juce::File(overridePath);
    auto ableton=juce::File::getSpecialLocation(juce::File::commonApplicationDataDirectory).getChildFile("Ableton");
    auto installs=ableton.findChildFiles(juce::File::findDirectories,false,"Live*");
    installs.sort();
    for(int i=installs.size();--i>=0;){
        auto library=installs[i].getChildFile("Resources/Core Library");
        if(library.isDirectory())return library;
    }
    return {};
}
inline juce::Result findNative(const juce::File& library,const juce::String& device,const Features& target,Match& found,const stemnotes::Cancel& cancel){
    auto previews=library.getChildFile("Ableton Folder Info/Previews");
    auto folder=previews.getChildFile("Devices/Instruments").getChildFile(device);
    juce::AudioFormatManager formats;registerFormats(formats);
    double best=std::numeric_limits<double>::infinity();int checked=0;
    for(auto& entry:juce::RangedDirectoryIterator(folder,true,"*.adv.ogg;*.adg.ogg",juce::File::findFiles)){
        if(cancel&&cancel())return juce::Result::fail("Cancelled");
        auto audio=entry.getFile();
        auto preset=library.getChildFile(audio.getRelativePathFrom(previews)).withFileExtension("");
        if(!preset.existsAsFile())continue;
        auto decoded=decode(formats,audio,0,3);if(decoded.error.isNotEmpty())continue;
        auto features=describe(decoded.mono);if(features.peak<.0001f)continue;
        double distance=0;for(int b=0;b<12;++b)distance+=std::pow(target.bands[b]-features.bands[b],2);
        ++checked;if(distance<best){best=distance;found.preset=preset;found.preview=audio;}
    }
    if(!checked)return juce::Result::fail("No presets with audio previews for this instrument in the selected Live library");
    found.description=device+" / "+found.preset.getFileNameWithoutExtension()+" ("+juce::String(checked)+")";
    return juce::Result::ok();
}
inline juce::Result findVst(juce::var instrument,const stemnotes::Part& part,Match& match,const stemnotes::Cancel& cancel){
    collectPreviousSounds(instrument,cancel);
    auto folder=root().getChildFile("Stem sounds").getChildFile(juce::Uuid().toString());
    auto* obj=new juce::DynamicObject;juce::var payload(obj);
    if(instrument["description_xml"].toString().isNotEmpty())instrument.getDynamicObject()->setProperty("xml",instrument["description_xml"]);
    obj->setProperty("instrument",instrument);obj->setProperty("auto_program_role",part.role);
    obj->setProperty("sample_rate",44100);obj->setProperty("parameters",juce::Array<juce::var>{});
    obj->setProperty("require_sound_audition",true);obj->setProperty("export_matched_preset",true);
    juce::Array<juce::var> roots;roots.add(soundLibrary().getFullPathName());
    auto extra=juce::JSON::parse(root().getChildFile("composer-preset-folders.json"));
    if(auto* paths=extra.getArray())for(auto& path:*paths)roots.addIfNotAlreadyThere(path);
    obj->setProperty("preset_roots",roots);
    obj->setProperty("target_features",toJson(part.timbre));
    std::vector<int> pitches;for(const auto& n:part.notes)pitches.push_back(n.pitch);
    if(!pitches.empty()){std::nth_element(pitches.begin(),pitches.begin()+pitches.size()/2,pitches.end());obj->setProperty("audition_pitch",pitches[pitches.size()/2]);}
    juce::var response;auto result=music::instruments::request(payload,folder,false,response,cancel,true);
    if(result.failed()){
        if(result.getErrorMessage().contains("did not produce an audible preset"))return juce::Result::fail(
            instrument["name"].toString()+": no audible sound in the accessible preset library. The native factory browser may not expose its presets to VST hosts. Use Find Sound > instrument > Add sound from instrument, load a patch and save it. Add more sounds or a folder of .vstpreset/.fxp presets, then search again. Check that the instrument's sample library is connected.");
        return juce::Result::fail(instrument["name"].toString()+": "+result.getErrorMessage());
    }
    auto preset=folder.getChildFile(instrument["format"].toString()=="VST3"?"Match.vstpreset":"Match.fxp");
    if(!preset.existsAsFile())return juce::Result::fail("AtlasWorker did not export a preset");
    match.preset=preset;match.description=response["program_notice"].toString();
    if(part.notes.empty())return juce::Result::ok();
    auto* render=new juce::DynamicObject;juce::var preview(render);
    render->setProperty("sample_rate",44100);render->setProperty("instrument",response["instrument"]);
    juce::Array<juce::var> notes;double start=part.notes.front().start,length=0;
    for(const auto& n:part.notes){
        double at=n.start-start,end=std::min(8.,n.end-start);if(at>=8.)break;
        auto* event=new juce::DynamicObject;event->setProperty("start",juce::int64(std::round(at*44100)));
        event->setProperty("end",juce::int64(std::round(end*44100)));event->setProperty("channel",1);
        event->setProperty("pitch",n.pitch);event->setProperty("velocity",n.velocity);notes.add(juce::var(event));length=std::max(length,end);
    }
    render->setProperty("song_seconds",std::max(.1,length));render->setProperty("notes",notes);render->setProperty("bpm",120);render->setProperty("numerator",4);render->setProperty("denominator",4);
    auto previewFolder=folder.getChildFile("preview");
    result=music::instruments::request(preview,previewFolder,false,response,cancel);
    if(result.wasOk())match.preview=previewFolder.getChildFile("audio.wav");
    else match.description+="\nPreview: "+result.getErrorMessage();
    return juce::Result::ok();
}
}
