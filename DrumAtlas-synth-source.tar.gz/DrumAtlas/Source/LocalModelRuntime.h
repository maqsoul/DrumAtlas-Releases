#pragma once
#include <juce_core/juce_core.h>
#include <mutex>
#include <atomic>
#include "HeavyJobResources.h"
namespace atlas {
class LocalModelRequest {
public:
 void cancel(){cancelled=true;std::shared_ptr<juce::WebInputStream>copy;{std::lock_guard<std::mutex>lock(mutex);copy=stream;}if(copy)copy->cancel();}
 bool isCancelled()const{return cancelled.load();}
 void attach(std::shared_ptr<juce::WebInputStream>next){{std::lock_guard<std::mutex>lock(mutex);stream=next;}if(isCancelled())next->cancel();}
private:std::atomic<bool>cancelled{false};std::mutex mutex;std::shared_ptr<juce::WebInputStream>stream;
};
// One runtime shared by plugin editors in this loaded module. Never called on the audio thread.
class LocalModelRuntime {
public:
 static std::shared_ptr<LocalModelRuntime> shared(){static std::mutex sharedMutex;static std::weak_ptr<LocalModelRuntime>weak;std::lock_guard<std::mutex>lock(sharedMutex);auto instance=weak.lock();if(!instance){instance=std::make_shared<LocalModelRuntime>();weak=instance;}return instance;}
 static int workerThreads(int logicalCpus){return juce::jlimit(1,6,std::max(1,logicalCpus/2));}
 static juce::Result modelBudget(juce::int64 bytes,int memoryMB){juce::int64 limit=juce::int64(8)*1024*1024*1024;if(memoryMB>0)limit=std::min(limit,juce::int64(memoryMB)*1024*1024/2);return bytes>0&&bytes<=limit?juce::Result::ok():juce::Result::fail("Local model exceeds the resource budget (half installed RAM, at most 8 GiB of model weights). Choose a smaller model.");}
 juce::Result release(){std::unique_lock<std::mutex>guard(mutex,std::try_to_lock);if(!guard.owns_lock())return juce::Result::fail("Local AI is processing a request in another tool or instance; wait or cancel that request first");server.kill();if(!server.waitForProcessToFinish(1000)&&server.isRunning())return juce::Result::fail("Local model process has not exited yet");activeModel.clear();return juce::Result::ok();}
 ~LocalModelRuntime(){server.kill();}
 juce::Result predict(const juce::String&modelPath,const juce::String&request,juce::String&response,const std::shared_ptr<LocalModelRequest>&job){
  HeavyJobResources admission;if(!admission.acquired())return HeavyJobResources::busy();
  auto memory=MemoryAdmission::check();if(memory.failed())return memory;
  std::unique_lock<std::mutex>guard(mutex,std::try_to_lock);if(!guard.owns_lock())return juce::Result::fail("Local AI is handling another request. Wait or cancel that request first.");if(!job||job->isCancelled())return juce::Result::fail("Local AI request cancelled");if(request.length()>64000)return juce::Result::fail("Local AI context is too large");if(!juce::File::isAbsolutePath(modelPath)||!juce::File(modelPath).existsAsFile())return juce::Result::fail("Choose the downloaded local GGUF model in AI Chat first");juce::File model(modelPath);auto budget=modelBudget(model.getSize(),juce::SystemStats::getMemorySizeInMegabytes());if(budget.failed())return budget;auto executable=model.getSiblingFile("llama-server.exe");if(!executable.existsAsFile())executable=model.getParentDirectory().getChildFile("llama-b11715/llama-server.exe");if(!executable.existsAsFile())return juce::Result::fail("llama-server.exe is missing beside the model (or in llama-b11715)");
  if(activeModel!=modelPath){server.kill();server.waitForProcessToFinish(1000);if(server.isRunning())return juce::Result::fail("Previous local model has not exited. Retry after it stops; the requested model has not been loaded.");activeModel=modelPath;}
  if(!server.isRunning()){auto loadingMemory=MemoryAdmission::check(model.getSize()+MemoryAdmission::minimum);if(loadingMemory.failed())return loadingMemory;port=49152+juce::Random::getSystemRandom().nextInt(12000);token=juce::Uuid().toString();juce::StringArray args{executable.getFullPathName(),"-m",modelPath,"--host","127.0.0.1","--port",juce::String(port),"--api-key",token,"--ctx-size","8192","--threads",juce::String(workerThreads(juce::SystemStats::getNumCpus())),"--parallel","1","--no-warmup","--log-disable"};if(!server.start(args,0))return juce::Result::fail("Could not start local model process");}
  auto deadline=juce::Time::getMillisecondCounterHiRes()+90000;bool ready=false;while(!job->isCancelled()&&server.isRunning()&&juce::Time::getMillisecondCounterHiRes()<deadline){if(fetch("/health",{},500,job).isNotEmpty()){ready=true;break;}juce::Thread::sleep(200);}if(job->isCancelled())return juce::Result::fail("Local AI request cancelled");if(!ready)return juce::Result::fail("Local model did not become ready. Check model and runtime files");auto body=fetch("/v1/chat/completions",request,120000,job);if(job->isCancelled())return juce::Result::fail("Local AI request cancelled");if(body.isEmpty())return juce::Result::fail("Local model request failed or timed out. No changes made");juce::var parsed;if(juce::JSON::parse(body,parsed).failed()||!parsed["choices"].isArray()||parsed["choices"].size()!=1||!parsed["choices"][0]["message"]["content"].isString())return juce::Result::fail("Invalid local model transport response");response=parsed["choices"][0]["message"]["content"].toString();return juce::Result::ok();
 }
private:
 juce::String fetch(const juce::String&path,const juce::String&body,int timeout,const std::shared_ptr<LocalModelRequest>&job){auto url=juce::URL("http://127.0.0.1:"+juce::String(port)+path);if(body.isNotEmpty())url=url.withPOSTData(body);auto input=std::make_shared<juce::WebInputStream>(url,body.isNotEmpty());input->withConnectionTimeout(timeout).withNumRedirectsToFollow(0).withExtraHeaders("Content-Type: application/json\r\nAuthorization: Bearer "+token+"\r\n");job->attach(input);if(job->isCancelled())return {};if(!input->connect(nullptr)||input->getStatusCode()!=200||input->getTotalLength()>1024*1024)return {};const auto expected=input->getTotalLength();juce::MemoryOutputStream output;char buffer[4096];while(!job->isCancelled()&&!input->isExhausted()){auto count=input->read(buffer,sizeof(buffer));if(count<=0)break;if(output.getDataSize()+size_t(count)>1024*1024)return {};output.write(buffer,size_t(count));}return job->isCancelled()||input->isError()||(expected>=0&&juce::int64(output.getDataSize())!=expected)?juce::String():output.toUTF8();}
 std::mutex mutex;juce::ChildProcess server;juce::String activeModel,token;int port=0;
};
}
