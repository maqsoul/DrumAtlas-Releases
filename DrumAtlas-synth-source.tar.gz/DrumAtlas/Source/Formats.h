#pragma once
#include <juce_audio_formats/juce_audio_formats.h>
#include "PathIO.h"
namespace atlas {
inline std::string catalogPathKey(const juce::String&path){
#if JUCE_WINDOWS
 return path.toLowerCase().toStdString();
#else
 return path.toStdString();
#endif
}
void registerFormats(juce::AudioFormatManager&); juce::String decoderError();
}
