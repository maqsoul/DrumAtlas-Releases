#pragma once
#include "Composer.h"
#include "EmberTheme.h"
#include "ComposerLocale.h"
#include <juce_audio_utils/juce_audio_utils.h>

namespace atlas::composer {
class AudioRegionWave : public juce::Component,private juce::ChangeListener {
public:
    std::function<void()>changed;
    double first=0,end=0,duration=0;
    AudioRegionWave():thumbnail(512,formats,cache){registerFormats(formats);thumbnail.addChangeListener(this);}
    ~AudioRegionWave()override{thumbnail.removeChangeListener(this);}
    void load(const juce::File&file){first=end=duration=0;thumbnail.setSource(new juce::FileInputSource(file));duration=thumbnail.getTotalLength();repaint();}
    void paint(juce::Graphics&g)override{g.fillAll(ember::panel);if(duration<=0){g.setColour(ember::text);g.drawText("Loading waveform...",getLocalBounds(),juce::Justification::centred);return;}g.setColour(ember::orange);thumbnail.drawChannels(g,getLocalBounds().reduced(0,18),0,duration,.9f);g.setColour(ember::gold.withAlpha(.22f));g.fillRect(juce::Rectangle<float>(float(first/duration*getWidth()),0,float((end-first)/duration*getWidth()),float(getHeight())));g.setFont(ember::font(12));g.setColour(ember::text);g.drawText(juce::String(first,2)+" - "+juce::String(end,2)+" s",getLocalBounds().removeFromBottom(18),juce::Justification::centredLeft);}
    void mouseDown(const juce::MouseEvent&e)override{if(!isEnabled()||!e.mods.isLeftButtonDown()||duration<=0)return;anchor=position(e.x);first=end=anchor;repaint();if(changed)changed();}
    void mouseDrag(const juce::MouseEvent&e)override{if(!isEnabled()||!e.mods.isLeftButtonDown()||duration<=0)return;auto p=position(e.x);first=std::min(anchor,p);end=std::max(anchor,p);repaint();if(changed)changed();}
    void all(){first=0;end=duration;repaint();if(changed)changed();}
private:
    juce::AudioFormatManager formats;juce::AudioThumbnailCache cache{3};juce::AudioThumbnail thumbnail;double anchor=0;
    double position(int x)const{return juce::jlimit(0.,duration,x*duration/std::max(1,getWidth()));}
    void changeListenerCallback(juce::ChangeBroadcaster*)override{duration=thumbnail.getTotalLength();repaint();if(changed)changed();}
};
class AudioRegionEditor : public juce::Component {
public:
    std::function<void()>onClose,onPlay;
    std::function<void(const juce::String&,const AudioRegionEdit&)>onApply;
    AudioRegionWave wave;
    AudioRegionEditor(){setComponentID("composer-audio-editor");for(auto*c:std::initializer_list<juce::Component*>{&back,&apply,&play,&all,&operation,&gain,&destination,&gainLabel,&destinationLabel,&hint,&wave})addAndMakeVisible(c);int id=1;for(auto name:{"Gain","Mute","Reverse","Copy"})operation.addItem(name,id++);operation.setSelectedId(1);operation.onChange=[this]{refresh();};gain.setRange(-60,12,.1);gain.setValue(0);gain.setSliderStyle(juce::Slider::LinearHorizontal);gain.setTextBoxStyle(juce::Slider::TextBoxRight,false,70,24);gain.setTextValueSuffix(" dB");destination.setRange(1,4097,.01);destination.setValue(1);destination.setSliderStyle(juce::Slider::LinearHorizontal);destination.setTextBoxStyle(juce::Slider::TextBoxRight,false,70,24);gainLabel.setText("Region gain",juce::dontSendNotification);destinationLabel.setText("Copy to bar",juce::dontSendNotification);hint.setText("Hold and drag across the waveform to select. Copy overwrites the destination; song length stays unchanged. Undo restores the original.",juce::dontSendNotification);back.onClick=[this]{if(onClose)onClose();};all.onClick=[this]{wave.all();};play.onClick=[this]{if(onPlay)onPlay();};wave.changed=[this]{refresh();};apply.onClick=[this]{if(!song||!onApply)return;AudioRegionEdit edit;edit.action=juce::StringArray{"gain","mute","reverse","copy"}[operation.getSelectedId()-1];edit.first=wave.first;edit.end=wave.end;edit.gainDb=gain.getValue();edit.destination=(destination.getValue()-1)*240/song->project.settings.bpm;onApply(song->project.id,edit);};}
    void localise(const juce::String&language){hint.setText(ct("audioHint",language),juce::dontSendNotification);localiseComposerControls(*this,language);int selected=operation.getSelectedId();operation.clear(juce::dontSendNotification);int id=1;for(auto name:{"Gain","Mute","Reverse","Copy"})operation.addItem(ct(name,language),id++);operation.setSelectedId(selected,juce::dontSendNotification);gainLabel.setText(ct("Gain",language),juce::dontSendNotification);destinationLabel.setText(ct("Copy to bar",language),juce::dontSendNotification);play.setButtonText(ct("Play",language));}
    void open(std::shared_ptr<const Song>value){song=std::move(value);if(song){wave.load(song->loopAudio);destination.setRange(1,song->project.settings.bars+1,.01);}refresh();}
    void setBusy(bool value){busy=value;wave.setEnabled(!busy);refresh();}
    void resized()override{auto area=getLocalBounds();auto row=area.removeFromTop(32);back.setBounds(row.removeFromLeft(104));row.removeFromLeft(6);play.setBounds(row.removeFromLeft(82));row.removeFromLeft(6);all.setBounds(row.removeFromLeft(100));row.removeFromLeft(6);operation.setBounds(row.removeFromLeft(120));row.removeFromLeft(6);apply.setBounds(row);area.removeFromTop(8);row=area.removeFromTop(30);gainLabel.setBounds(row.removeFromLeft(100));gain.setBounds(row);row=area.removeFromTop(30);destinationLabel.setBounds(row.removeFromLeft(100));destination.setBounds(row);hint.setBounds(area.removeFromBottom(54));wave.setBounds(area.reduced(0,10));}
    void paint(juce::Graphics&g)override{g.fillAll(ember::background);}
private:
    std::shared_ptr<const Song>song;bool busy=false;juce::TextButton back{"Arrangement"},apply{"Apply audio"},play{"Play track"},all{"Select all"};juce::ComboBox operation;juce::Slider gain,destination;juce::Label gainLabel,destinationLabel,hint;
    void refresh(){apply.setEnabled(!busy&&song&&wave.end>wave.first);back.setEnabled(!busy);play.setEnabled(!busy&&song);all.setEnabled(!busy&&wave.duration>0);operation.setEnabled(!busy);gain.setEnabled(!busy&&operation.getSelectedId()==1);destination.setEnabled(!busy&&operation.getSelectedId()==4);}
};
}
