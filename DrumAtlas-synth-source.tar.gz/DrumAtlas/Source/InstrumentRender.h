#pragma once
#include "MusicCore.h"
#include "WorkerArchitecture.h"
#include "TempoMap.h"
#include "MidiGlide.h"
#include "HeavyJobResources.h"
#include <juce_audio_formats/juce_audio_formats.h>
#include <juce_cryptography/juce_cryptography.h>
#include <cmath>

namespace atlas::music::instruments {
inline juce::File workerFile(){
    auto overridePath=juce::SystemStats::getEnvironmentVariable("DRUMATLAS_WORKER",{});
    if(juce::File::isAbsolutePath(overridePath))return juce::File(overridePath);
    auto exe=juce::File::getSpecialLocation(juce::File::currentExecutableFile).getParentDirectory();
   #if JUCE_WINDOWS
    const juce::String name="AtlasWorker.exe";
    auto installed=juce::File::getSpecialLocation(juce::File::globalApplicationsDirectory).getChildFile("DrumAtlas/Tools/"+name);
   #else
    const juce::String name="AtlasWorker";
    auto installed=juce::File("/Library/Application Support/DrumAtlas/Tools/"+name);
   #endif
    for(auto file:{exe.getChildFile("Tools/"+name),exe.getParentDirectory().getChildFile("Tools/"+name),installed,exe.getParentDirectory().getParentDirectory().getChildFile("AtlasWorker_artefacts/Release/"+name)})if(file.existsAsFile())return file;
    auto ancestor=exe;for(int i=0;i<5;++i){auto candidate=ancestor.getChildFile("AtlasWorker_artefacts/Release/"+name);if(candidate.existsAsFile())return candidate;ancestor=ancestor.getParentDirectory();}
    return installed;
}
inline juce::Result request(juce::var payload,const juce::File&folder,bool configure,juce::var&response,const std::function<bool()>&cancel,bool capture=false){
    if(cancel&&cancel())return juce::Result::fail("Render cancelled");
    // Configuration/capture can hold an interactive editor open for a long time.
    // Only offline rendering participates in the shared background-job gate.
    std::unique_ptr<atlas::HeavyJobResources> admission;
    if(!configure&&!capture){admission=std::make_unique<atlas::HeavyJobResources>();if(!admission->acquired())return atlas::HeavyJobResources::busy();}
    auto memory=atlas::MemoryAdmission::check();if(memory.failed())return memory;
    juce::File worker;auto selection=hosting::workerForChain(workerFile(),payload["instrument"],payload["effects"],worker);if(selection.failed())return selection;
    auto result=folder.createDirectory();if(result.failed())return result;
    auto id=juce::Uuid().toString();payload.getDynamicObject()->setProperty("request_id",id);
    auto input=folder.getChildFile("request.json"),output=folder.getChildFile("response.json"),progress=folder.getChildFile("progress");
    if(!input.replaceWithText(juce::JSON::toString(payload)))return juce::Result::fail("Cannot write instrument request: "+input.getFullPathName());
    juce::ChildProcess child;
    if(!child.start(juce::StringArray{worker.getFullPathName(),capture?"--capture":configure?"--configure":"--render",input.getFullPathName(),output.getFullPathName(),id},0))return juce::Result::fail("Cannot start instrument worker");
    auto last=juce::Time::getMillisecondCounterHiRes();juce::String previous;
    while(child.isRunning()){
        auto now=juce::Time::getMillisecondCounterHiRes();auto current=progress.loadFileAsString();if(current!=previous){previous=current;last=now;}
        if((cancel&&cancel())||now-last>(configure?3600000.:120000.)){
            child.kill();child.waitForProcessToFinish(5000);
            return juce::Result::fail(cancel&&cancel()?"Render cancelled":"Instrument stopped responding");
        }
        juce::Thread::sleep(20);
    }
    if(child.getExitCode()!=0||!output.existsAsFile()||output.getSize()>32*1024*1024){
        if(output.existsAsFile()&&output.getSize()<=32*1024*1024){auto error=juce::JSON::parse(output);if(error["request_id"].toString()==id&&error["error"].toString().isNotEmpty())return juce::Result::fail(error["error"].toString());}
        auto name=payload["instrument"]["name"].toString();if(name.isEmpty())name=juce::File(payload["instrument"]["path"].toString()).getFileNameWithoutExtension();
        return juce::Result::fail(name+" worker exited (0x"+juce::String::toHexString(child.getExitCode())+")"+(previous.isEmpty()?juce::String():" / "+previous));
    }
    response=juce::JSON::parse(output);
    if(bool(payload["requires_glide"])&&int(response["glide_protocol"])!=1)return juce::Result::fail("AtlasWorker is too old for these MIDI controls; update plugin and worker together");
    bool requiresIdentity=payload["instrument"].hasProperty("class_id");if(auto*chain=payload["effects"].getArray())for(const auto&fx:*chain)requiresIdentity|=fx.hasProperty("class_id");if(requiresIdentity&&int(response["identity_protocol"])!=1)return juce::Result::fail("AtlasWorker is too old for plugin identity checks; update plugin and worker together");
    if(payload.hasProperty("source_audio")&&int(response["audio_source_protocol"])!=1)return juce::Result::fail("AtlasWorker needs audio-source effect support; update plugin and worker together");
    if(payload["instrument"].hasProperty("transition_preview")&&int(response["transition_protocol"])!=1)return juce::Result::fail("AtlasWorker needs smooth transition preview support; update plugin and worker together");
    if(bool(payload["require_sound_audition"])&&int(response["sound_audition_protocol"])!=1)return juce::Result::fail("AtlasWorker needs sound audition support; update plugin and worker together");
    if(capture&&int(response["parameter_protocol"])!=1)return juce::Result::fail("AtlasWorker is too old for safe parameter edits; update plugin and worker together");
    if(int(response["protocol"])!=2||response["request_id"].toString()!=id)return juce::Result::fail("Invalid instrument response");
    auto status=response["status"].toString();
    return status==((configure||capture)?"configured":"rendered")?juce::Result::ok():juce::Result::fail(status=="cancelled"?"Instrument setup cancelled":response.getProperty("error","Instrument render failed").toString());
}
struct Cache {
    double unknownTailSeconds=0;
    juce::File folder=juce::File::getSpecialLocation(juce::File::tempDirectory).getChildFile("DrumAtlas-instruments-"+juce::Uuid().toString());
    std::vector<juce::File> files;std::vector<float> mixGains;juce::Array<juce::var> reports;juce::StringArray warnings;juce::int64 frames=0;
    ~Cache(){if(folder.exists())folder.deleteRecursively();}
    juce::Result prepare(const Project&p,double rate,const std::function<bool()>&cancel,const std::function<juce::Result(size_t,const juce::File&)>&renderSource={}){
        auto valid=validate(p);if(valid.failed())return valid;
        if(!std::isfinite(rate)||rate<22050||rate>96000)return juce::Result::fail("Unsupported sample rate");
        TempoMap timeline(p);auto closures=hatClosures(p);const double seconds=timeline.seconds(barTicks(p.settings)*p.settings.bars);
        frames=juce::int64(std::ceil((seconds+2)*rate));files.resize(p.tracks.size());
        uint32_t seed=p.settings.seed;auto next=[&]{seed=seed*1664525u+1013904223u;return seed;};
        for(size_t i=0;i<p.tracks.size();++i){
            const auto&t=p.tracks[i];juce::Array<juce::var>notes,controls;
            for(const auto&n:t.notes){next();if(!playsNote(p.settings.seed,n))continue;next();
                if(t.instrument.isVoid())continue;auto cutoff=hatCut(t,n,closures);if(cutoff==n.tick+n.microtiming)continue;
                auto start=juce::int64(std::llround(timeline.seconds(n.tick+n.microtiming)*rate));
                auto end=std::min(juce::int64(std::ceil(seconds*rate)),juce::int64(std::llround(timeline.seconds(n.tick+n.microtiming+n.duration)*rate)));
                if(cutoff>=0)end=std::min(end,juce::int64(std::llround(timeline.seconds(cutoff)*rate)));if(end<=start)continue;
                glideMidi(n.channel,n.glideFrom,n.glideTicks,n.bendRange,[&](int tick,juce::MidiMessage m){auto*c=new juce::DynamicObject;c->setProperty("frame",juce::int64(std::llround(timeline.seconds(n.tick+n.microtiming+tick)*rate)));c->setProperty("channel",n.channel);c->setProperty("kind",m.isPitchWheel()?"bend":"cc");c->setProperty("number",m.isPitchWheel()?0:m.getControllerNumber());c->setProperty("value",m.isPitchWheel()?m.getPitchWheelValue():m.getControllerValue());controls.add(juce::var(c));});
                auto*o=new juce::DynamicObject;o->setProperty("start",start);o->setProperty("end",end);o->setProperty("pitch",n.pitch);o->setProperty("velocity",n.velocity);o->setProperty("channel",n.channel);notes.add(juce::var(o));
            }
            const bool audioSource=t.instrument.isVoid();juce::var sourceConfig=t.instrument.clone(),remainingEffects=t.effects.clone();
            if(audioSource){juce::Array<juce::var>active;if(auto*chain=t.effects.getArray())for(auto&fx:*chain)if(!bool(fx["bypass"]))active.add(fx.clone());if(active.isEmpty())continue;if(!renderSource)return juce::Result::fail("Audio source renderer is unavailable for this effect chain");sourceConfig=active.removeAndReturn(0);remainingEffects=active;}
            for(const auto&e:t.controls){auto*c=new juce::DynamicObject;c->setProperty("frame",juce::int64(std::llround(timeline.seconds(e.tick)*rate)));c->setProperty("channel",e.channel);c->setProperty("kind",e.kind);c->setProperty("number",e.number);c->setProperty("value",e.value);controls.add(juce::var(c));}
            if(p.hatChoke&&t.role=="Open Hat"){
                unsigned channels=0;for(const auto&n:t.notes)channels|=1u<<n.channel;
                for(auto tick:closures)for(int channel=1;channel<=16;++channel)if(channels&(1u<<channel)){
                    auto*c=new juce::DynamicObject;c->setProperty("frame",juce::int64(std::llround(timeline.seconds(tick)*rate)));c->setProperty("channel",channel);c->setProperty("kind","cc");c->setProperty("number",120);c->setProperty("value",0);controls.add(juce::var(c));
                }
            }
            auto*o=new juce::DynamicObject;juce::var payload(o);o->setProperty("instrument",sourceConfig);if(unknownTailSeconds>0)o->setProperty("unknown_tail_seconds",unknownTailSeconds);if(!remainingEffects.isVoid())o->setProperty("effects",remainingEffects);o->setProperty("sample_rate",rate);o->setProperty("song_seconds",seconds);o->setProperty("bpm",p.settings.bpm);if(!p.tempos.empty())o->setProperty("tempo_map",encode(p)["tempo_map"].clone());o->setProperty("numerator",p.settings.numerator);o->setProperty("denominator",p.settings.denominator);o->setProperty("notes",notes);o->setProperty("controls",controls);o->setProperty("requires_glide",!controls.isEmpty());
            auto directory=folder.getChildFile(juce::String(int(i)));if(audioSource){auto made=directory.createDirectory();if(made.failed())return made;auto dry=directory.getChildFile("source.wav");auto rendered=renderSource(i,dry);if(rendered.failed())return rendered;o->setProperty("source_audio",dry.getFullPathName());o->setProperty("source_sha256",juce::SHA256(dry).toHexString());}juce::var response;auto r=request(payload,directory,false,response,cancel);if(r.failed())return r;if(!t.effects.isVoid()&&int(response["effects_protocol"])!=1)return juce::Result::fail("Instrument worker needs effect-chain support; update the worker");if(!p.tempos.empty()&&int(response["tempo_protocol"])!=1)return juce::Result::fail("Instrument worker needs tempo-map support; rebuild or update the worker");
            auto file=directory.getChildFile("audio.wav");juce::AudioFormatManager fm;fm.registerBasicFormats();std::unique_ptr<juce::AudioFormatReader>reader(fm.createReaderFor(file));
            if(!reader||reader->sampleRate!=rate||reader->numChannels!=2||reader->lengthInSamples!=juce::int64(response["frames"])||reader->lengthInSamples<juce::int64(std::ceil((seconds+2)*rate))||reader->lengthInSamples>juce::int64(std::ceil((seconds+600)*rate)))return juce::Result::fail("Invalid instrument audio response");
            if(!audioSource&&!notes.isEmpty()&&response.hasProperty("peak")&&double(response["peak"])==0.){
                auto warning="No audio from "+t.role+" ("+sourceConfig["name"].toString()+"). Check the instrument, loaded library, MIDI channel and mute settings.";
                warnings.add(warning);response.getDynamicObject()->setProperty("warning",warning);
            }
            if(bool(response["tail_faded"]))warnings.add(t.role+": continuous instrument tail faded after "+juce::String(double(response["tail_seconds"]),1)+" seconds.");
            files[i]=file;frames=std::max(frames,reader->lengthInSamples);response.getDynamicObject()->setProperty("track_id",t.id);reports.add(response);
        }
        return juce::Result::ok();
    }
};
inline juce::Result configure(const juce::var&config,juce::var&saved,const std::function<bool()>&cancel){
    Cache temporary;auto*o=new juce::DynamicObject;juce::var payload(o);o->setProperty("instrument",config);o->setProperty("sample_rate",44100);juce::var response;
    auto r=request(payload,temporary.folder,true,response,cancel);if(r.wasOk())saved=response["instrument"].clone();return r;
}
inline juce::Result captureParameters(const juce::var&config,const juce::var&edits,const juce::String&expectedVersion,juce::var&saved,juce::var&capabilities,const std::function<bool()>&cancel){Cache temporary;auto*o=new juce::DynamicObject;juce::var payload(o);o->setProperty("instrument",config.clone());o->setProperty("sample_rate",44100);o->setProperty("parameters",edits.clone());if(expectedVersion.isNotEmpty())o->setProperty("expected_plugin_version",expectedVersion);juce::var response;auto result=request(payload,temporary.folder,false,response,cancel,true);if(result.wasOk()){saved=response["instrument"].clone();capabilities=response["capabilities"].clone();if(!saved.isObject()||int(capabilities["schema"])!=1||!capabilities["parameters"].isArray())return juce::Result::fail("Invalid parameter capability response");}return result;}

}
