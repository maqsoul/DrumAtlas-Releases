#include "ContentHash.h"
#include <juce_cryptography/juce_cryptography.h>
#include <stdexcept>
#if JUCE_WINDOWS
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#include <bcrypt.h>
#endif
namespace atlas {
// Keep SHA-256 integrity checks, but use Windows' optimized crypto provider for
// large model/audio files instead of hashing hundreds of MB in scalar code.
juce::String contentSHA256(const juce::File&file,const std::function<bool()>&cancel){
#if JUCE_WINDOWS
 struct Handles{BCRYPT_ALG_HANDLE algorithm=nullptr;BCRYPT_HASH_HANDLE hash=nullptr;
  ~Handles(){if(hash)BCryptDestroyHash(hash);if(algorithm)BCryptCloseAlgorithmProvider(algorithm,0);}}handles;
 auto check=[](NTSTATUS status){if(status<0)throw std::runtime_error("Cannot compute file SHA-256");};
 check(BCryptOpenAlgorithmProvider(&handles.algorithm,BCRYPT_SHA256_ALGORITHM,nullptr,0));
 check(BCryptCreateHash(handles.algorithm,&handles.hash,nullptr,0,nullptr,0,0));
 juce::FileInputStream input(file);if(input.failedToOpen())throw std::runtime_error("Cannot read file for SHA-256");
 juce::HeapBlock<unsigned char> buffer(1024*1024);
 const auto expected=input.getTotalLength();
 for(;;){if(cancel&&cancel())throw std::runtime_error("Hash cancelled");int read=input.read(buffer.getData(),1024*1024);if(read<=0)break;check(BCryptHashData(handles.hash,buffer.getData(),ULONG(read),0));}
 if(input.getPosition()!=expected)throw std::runtime_error("File changed during SHA-256");
 if(input.getStatus().failed())throw std::runtime_error("File SHA-256 read failed");
 unsigned char digest[32]{};check(BCryptFinishHash(handles.hash,digest,sizeof(digest),0));
 return juce::String::toHexString(digest,sizeof(digest),0);
#else
 juce::ignoreUnused(cancel);
 if(!file.existsAsFile())throw std::runtime_error("Cannot read file for SHA-256");
 return juce::SHA256(file).toHexString();
#endif
}
}
