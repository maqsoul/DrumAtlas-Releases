#pragma once
#include "EmberTheme.h"
#include <map>
#include <mutex>

namespace atlas {
struct LayoutPlacement {
    double x=0,y=0,w=0,h=0,font=1;
    bool operator==(const LayoutPlacement&o)const{return x==o.x&&y==o.y&&w==o.w&&h==o.h&&font==o.font;}
};
using LayoutItems=std::map<juce::String,LayoutPlacement>;
using LayoutStyles=std::map<int,LayoutItems>;

class UserLayouts {
public:
    UserLayouts(){auto f=file();if(f.existsAsFile()&&f.getSize()<1024*1024)restore(f.loadFileAsString());}
    static juce::File file(){auto path=juce::SystemStats::getEnvironmentVariable("DRUMATLAS_CACHE_DIR",{});return (path.isEmpty()?juce::File::getSpecialLocation(juce::File::userApplicationDataDirectory).getChildFile("DrumAtlas"):juce::File(path)).getChildFile("interface-layouts.json");}
    static juce::String encode(const LayoutStyles&styles){juce::Array<juce::var> entries;for(auto&style:styles)for(auto&[id,p]:style.second){auto*o=new juce::DynamicObject;o->setProperty("style",style.first);o->setProperty("id",id);o->setProperty("x",p.x);o->setProperty("y",p.y);o->setProperty("w",p.w);o->setProperty("h",p.h);o->setProperty("font",p.font);entries.add(o);}return juce::JSON::toString(juce::var(entries),true);}
    static LayoutStyles decode(const juce::String&text){LayoutStyles parsed;if(text.length()>1024*1024)return parsed;auto json=juce::JSON::parse(text);if(auto*a=json.getArray())for(auto&v:*a){if(parsed.size()>10)break;int style=int(v["style"]);auto id=v["id"].toString();LayoutPlacement p{double(v["x"]),double(v["y"]),double(v["w"]),double(v["h"]),double(v["font"])};if(style<0||style>9||id.isEmpty()||id.length()>100||parsed[style].size()>=128)continue;if(!std::isfinite(p.x)||!std::isfinite(p.y)||!std::isfinite(p.w)||!std::isfinite(p.h)||!std::isfinite(p.font)||p.w<=0||p.h<=0)continue;p.w=juce::jlimit(.005,1.,p.w);p.h=juce::jlimit(.005,1.,p.h);p.x=juce::jlimit(0.,1.-p.w,p.x);p.y=juce::jlimit(0.,1.-p.h,p.y);p.font=juce::jlimit(.6,2.,p.font);parsed[style][id]=p;}return parsed;}
    juce::String serialise()const{std::lock_guard<std::mutex>g(mutex);return encode(styles);}
    void restore(const juce::String&text){auto next=decode(text);std::lock_guard<std::mutex>g(mutex);styles=std::move(next);++revision;}
    LayoutItems get(int style)const{std::lock_guard<std::mutex>g(mutex);auto i=styles.find(style);return i==styles.end()?LayoutItems{}:i->second;}
    juce::Result save(int style,const LayoutItems&items){
        // Merge the current style into disk preferences so another instance's other styles survive.
        auto f=file();auto disk=f.existsAsFile()&&f.getSize()<1024*1024?decode(f.loadFileAsString()):LayoutStyles{};disk[style]=items;
        if(auto made=f.getParentDirectory().createDirectory();made.failed())return made;
        if(!f.replaceWithText(encode(disk)))return juce::Result::fail("Cannot save interface layout: "+f.getFullPathName());
        {std::lock_guard<std::mutex>g(mutex);styles[style]=items;++revision;}return juce::Result::ok();
    }
    std::atomic<int>revision{0};
private:mutable std::mutex mutex;LayoutStyles styles;
};

// Real components remain in their original parents. The overlay intercepts editing
// gestures, so moving Analyse, Delete or Play cannot invoke the underlying action.
class LayoutDesigner:public juce::Component {
public:
    using juce::Component::setBounds;
    struct Target {juce::String id;juce::Component*c;juce::Rectangle<int>base;juce::Font font;};
    LayoutDesigner(juce::Component&owner,UserLayouts&saved,std::function<juce::Point<int>()>size):host(owner),store(saved),rootSize(std::move(size)){
        setComponentID("layout-designer");save.setComponentID("layout-save");cancel.setComponentID("layout-cancel");resetAll.setComponentID("layout-reset-theme");undo.setComponentID("layout-undo");redo.setComponentID("layout-redo");picker.setComponentID("layout-picker");font.setComponentID("layout-font");setWantsKeyboardFocus(true);
        addAndMakeVisible(bar);for(auto*c:std::initializer_list<juce::Component*>{&picker,&save,&cancel,&undo,&redo,&resetOne,&resetAll,&snap,&position,&font,&fontCaption,&hint})bar.addAndMakeVisible(c);
        for(int i=0;i<4;++i){bar.addAndMakeVisible(numbers[size_t(i)]);bar.addAndMakeVisible(labels[size_t(i)]);labels[size_t(i)].setText(juce::StringArray{"X","Y","W","H"}[i],juce::dontSendNotification);labels[size_t(i)].setFont(ember::font(11));labels[size_t(i)].setBorderSize({});numbers[size_t(i)].setInputRestrictions(6,"0123456789");numbers[size_t(i)].onReturnKey=[this,i]{numeric(i);};numbers[size_t(i)].onFocusLost=[this,i]{numeric(i);};}
        picker.onChange=[this]{selected=picker.getSelectedId()-1;refresh();};
        save.onClick=[this]{commit();};cancel.onClick=[this]{discard();};
        undo.onClick=[this]{step(false);};redo.onClick=[this]{step(true);};resetOne.onClick=[this]{if(valid()){checkpoint();draft.erase(targets[size_t(selected)].id);applyAgain();}};
        resetAll.onClick=[this]{checkpoint();draft.clear();applyAgain();};
        snap.setToggleState(true,juce::dontSendNotification);position.onClick=[this]{barAtTop=!barAtTop;resized();};
        font.setRange(60,200,5);font.setTextBoxStyle(juce::Slider::TextBoxRight,false,54,24);font.setTextValueSuffix("%");font.setScrollWheelEnabled(false);
        font.onDragStart=[this]{checkpoint();fontDragging=true;};font.onDragEnd=[this]{fontDragging=false;};font.onValueChange=[this]{if(!refreshing&&valid()){if(!fontDragging)checkpoint();auto&t=targets[size_t(selected)];auto p=placement(t);p.font=font.getValue()/100.;draft[t.id]=p;applyAgain(false);}};
        hint.setFont(ember::font(11));hint.setJustificationType(juce::Justification::centredLeft);setVisible(false);
    }
    void add(juce::String id,juce::Component&c){juce::Font f=ember::font(14);if(auto*l=dynamic_cast<juce::Label*>(&c))f=l->getFont();else if(auto*e=dynamic_cast<juce::TextEditor*>(&c))f=e->getFont();targets.push_back({id,&c,{},f});c.getProperties().set("layoutName",id);}
    bool editing()const{return isVisible();}
    void layout(int currentStyle){
        if(editing()&&currentStyle!=style)discard();style=currentStyle;
        if(!editing()){draft=store.get(style);seen=store.revision.load();}
        for(auto&t:targets)t.base=t.c->getBounds();
        apply();if(editing()){toFront(false);refresh();}
    }
    bool needsRefresh()const{return !editing()&&seen!=store.revision.load();}
    void begin(const juce::String&language){ru=language=="ru";draft=store.get(style);back.clear();forward.clear();selected=-1;
        picker.clear();int index=1;for(auto&t:targets){juce::String name=t.id;if(auto*b=dynamic_cast<juce::Button*>(t.c);b&&b->getButtonText().isNotEmpty())name+="  |  "+b->getButtonText();else if(auto*l=dynamic_cast<juce::Label*>(t.c))name+="  |  "+l->getText();picker.addItem(name,index++);}picker.setText(ru?juce::String::fromUTF8("Выберите элемент"):"Select an element",juce::dontSendNotification);
        save.setButtonText(ru?juce::String::fromUTF8("Сохранить"):"Save");cancel.setButtonText(ru?juce::String::fromUTF8("Отмена"):"Cancel");undo.setButtonText(ru?juce::String::fromUTF8("Назад"):"Undo");redo.setButtonText(ru?juce::String::fromUTF8("Вперёд"):"Redo");resetOne.setButtonText(ru?juce::String::fromUTF8("Сброс элемента"):"Reset item");resetAll.setButtonText(ru?juce::String::fromUTF8("Сброс темы"):"Reset theme");snap.setButtonText(ru?juce::String::fromUTF8("Сетка"):"Snap");position.setButtonText(ru?juce::String::fromUTF8("Вверх / вниз"):"Top / bottom");
        fontCaption.setText(ru?juce::String::fromUTF8("Шрифт"):"Font",juce::dontSendNotification);fontCaption.setFont(ember::font(11));fontCaption.setBorderSize({});fontCaption.setJustificationType(juce::Justification::centredLeft);font.setValue(100,juce::dontSendNotification);
        font.setTooltip(ru?juce::String::fromUTF8("Размер шрифта выбранного элемента"):"Selected element font size");setVisible(true);toFront(true);refresh();
    }
    bool commit(){auto result=store.save(style,draft);if(result.failed()){hint.setText(result.getErrorMessage(),juce::dontSendNotification);return false;}setVisible(false);if(relayout)relayout();return true;}
    void discard(){setVisible(false);draft=store.get(style);if(relayout)relayout();}
    std::function<void()>relayout;
    void paint(juce::Graphics&g)override{g.setColour(juce::Colour(0xffffd680).withAlpha(.13f));for(auto&t:targets)if(t.c->isShowing())g.drawRect(visual(t),1);if(valid()){auto b=visual(targets[size_t(selected)]);g.setColour(juce::Colour(0xffffd680));g.drawRect(b,2);g.fillRoundedRectangle(handle(b).toFloat(),3);}}
    void resized()override{const int width=std::max(370,std::min(720,getWidth()-20));bar.setBounds(std::max(4,(getWidth()-width)/2),barAtTop?8:std::max(8,getHeight()-168),width,160);
        picker.setBounds(8,8,width-200,28);save.setBounds(width-186,8,85,28);cancel.setBounds(width-95,8,87,28);
        undo.setBounds(8,42,62,26);redo.setBounds(74,42,62,26);resetOne.setBounds(140,42,110,26);resetAll.setBounds(254,42,102,26);
        int field=(width-24)/4;for(int i=0;i<4;++i){int x=8+i*field;labels[size_t(i)].setBounds(x,75,15,24);numbers[size_t(i)].setBounds(x+16,75,field-20,24);}
        snap.setBounds(8,106,75,25);position.setBounds(85,106,108,25);fontCaption.setBounds(201,106,48,25);font.setBounds(251,106,width-259,25);hint.setBounds(8,136,width-16,20);
    }
    void mouseDown(const juce::MouseEvent&e)override{if(!e.mods.isLeftButtonDown())return;start=e.position;resizing=valid()&&handle(visual(targets[size_t(selected)])).expanded(3).contains(e.getPosition());if(!resizing){selected=-1;for(int i=int(targets.size())-1;i>=0;--i)if(targets[size_t(i)].c->isShowing()&&visual(targets[size_t(i)]).contains(e.getPosition())){selected=i;break;}}if(valid()){before=draft;startBounds=targets[size_t(selected)].c->getBounds();startParent=toParent(targets[size_t(selected)],start);moved=false;refresh();}grabKeyboardFocus();}
    void mouseDrag(const juce::MouseEvent&e)override{if(!valid()||!e.mods.isLeftButtonDown()||e.getDistanceFromDragStart()<3)return;auto&t=targets[size_t(selected)];auto delta=toParent(t,e.position)-startParent;const int grid=snap.getToggleState()?5:1;int dx=int(std::round(delta.x/grid))*grid,dy=int(std::round(delta.y/grid))*grid;auto b=resizing?startBounds.withSize(startBounds.getWidth()+dx,startBounds.getHeight()+dy):startBounds.translated(dx,dy);setBounds(t,b);moved=true;applyAgain();}
    void mouseUp(const juce::MouseEvent&)override{if(moved){back.push_back(before);trim();forward.clear();}moved=false;refresh();}
    bool keyPressed(const juce::KeyPress&key)override{if(key.getKeyCode()==juce::KeyPress::escapeKey){discard();return true;}if(!valid())return false;int x=0,y=0;if(key.getKeyCode()==juce::KeyPress::leftKey)x=-1;else if(key.getKeyCode()==juce::KeyPress::rightKey)x=1;else if(key.getKeyCode()==juce::KeyPress::upKey)y=-1;else if(key.getKeyCode()==juce::KeyPress::downKey)y=1;else return false;checkpoint();auto&t=targets[size_t(selected)];int step=key.getModifiers().isShiftDown()?10:1;setBounds(t,t.c->getBounds().translated(x*step,y*step));applyAgain();return true;}
    // Used by the same numeric fields and by integration checks.
    bool setItemBounds(const juce::String&id,juce::Rectangle<int>b){for(auto&t:targets)if(t.id==id){checkpoint();setBounds(t,b);applyAgain();return true;}return false;}
private:
    struct Bar:juce::Component{void paint(juce::Graphics&g)override{g.setColour(juce::Colour(0xff201813));g.fillRoundedRectangle(getLocalBounds().toFloat(),10);g.setColour(juce::Colour(0xffb87445));g.drawRoundedRectangle(getLocalBounds().toFloat().reduced(.5f),10,1);}}bar;
    bool fontEditable()const{if(!valid())return false;auto&t=targets[size_t(selected)];auto*b=dynamic_cast<juce::TextButton*>(t.c);return t.id=="logo"||dynamic_cast<juce::Label*>(t.c)||dynamic_cast<juce::ComboBox*>(t.c)||dynamic_cast<juce::TextEditor*>(t.c)||(b&&b->getButtonText().isNotEmpty());}
    bool valid()const{return juce::isPositiveAndBelow(selected,int(targets.size()));}
    juce::Point<int>parentSize(const Target&t)const{return t.c->getParentComponent()==&host?rootSize():juce::Point<int>{t.c->getParentWidth(),t.c->getParentHeight()};}
    juce::Rectangle<int>visual(const Target&t)const{return getLocalArea(t.c,t.c->getLocalBounds());}
    static juce::Rectangle<int>handle(juce::Rectangle<int>b){return {b.getRight()-10,b.getBottom()-10,13,13};}
    juce::Point<float>toParent(const Target&t,juce::Point<float>p)const{return t.c->getParentComponent()->getLocalPoint(this,p).transformedBy(t.c->getTransform().inverted());}
    LayoutPlacement placement(const Target&t)const{auto s=parentSize(t);auto b=t.c->getBounds();return {double(b.getX())/std::max(1,s.x),double(b.getY())/std::max(1,s.y),double(b.getWidth())/std::max(1,s.x),double(b.getHeight())/std::max(1,s.y),double(t.c->getProperties().getWithDefault("layoutFontScale",1.))};}
    void setBounds(Target&t,juce::Rectangle<int>b){auto s=parentSize(t);const int minW=dynamic_cast<juce::Label*>(t.c)?24:30,minH=dynamic_cast<juce::Label*>(t.c)?12:20;b.setSize(juce::jlimit(std::min(minW,s.x),std::max(minW,s.x),b.getWidth()),juce::jlimit(std::min(minH,s.y),std::max(minH,s.y),b.getHeight()));b.setPosition(juce::jlimit(0,std::max(0,s.x-b.getWidth()),b.getX()),juce::jlimit(0,std::max(0,s.y-b.getHeight()),b.getY()));auto p=placement(t);p.x=double(b.getX())/std::max(1,s.x);p.y=double(b.getY())/std::max(1,s.y);p.w=double(b.getWidth())/std::max(1,s.x);p.h=double(b.getHeight())/std::max(1,s.y);draft[t.id]=p;}
    void apply(){for(auto&t:targets){double scale=1;auto it=draft.find(t.id);if(it!=draft.end()){auto s=parentSize(t);auto p=it->second;int w=juce::jlimit(12,std::max(12,s.x),int(std::round(p.w*s.x))),h=juce::jlimit(10,std::max(10,s.y),int(std::round(p.h*s.y)));t.c->setBounds(juce::jlimit(0,std::max(0,s.x-w),int(std::round(p.x*s.x))),juce::jlimit(0,std::max(0,s.y-h),int(std::round(p.y*s.y))),w,h);scale=p.font;}t.c->getProperties().set("layoutFontScale",scale);if(auto*l=dynamic_cast<juce::Label*>(t.c))l->setFont(juce::Font(juce::FontOptions(ember::bodyFace(host.getProperties()["atlasLanguage"].toString())).withHeight(t.font.getHeight()*float(scale))));else if(auto*e=dynamic_cast<juce::TextEditor*>(t.c))e->setFont(juce::Font(juce::FontOptions(ember::bodyFace(host.getProperties()["atlasLanguage"].toString())).withHeight(t.font.getHeight()*float(scale))));else if(auto*b=dynamic_cast<juce::ComboBox*>(t.c))b->resized();t.c->repaint();}}
    void applyAgain(bool fields=true){if(relayout)relayout();if(fields)refresh();repaint();}
    void checkpoint(){back.push_back(draft);trim();forward.clear();}
    void trim(){if(back.size()>60)back.erase(back.begin());}
    void step(bool ahead){auto&from=ahead?forward:back;auto&to=ahead?back:forward;if(from.empty())return;to.push_back(draft);draft=from.back();from.pop_back();applyAgain();}
    void numeric(int field){if(refreshing||!valid())return;auto&t=targets[size_t(selected)];auto b=t.c->getBounds();int value=numbers[size_t(field)].getText().getIntValue();int old=field==0?b.getX():field==1?b.getY():field==2?b.getWidth():b.getHeight();if(value==old)return;checkpoint();if(field==0)b.setX(value);if(field==1)b.setY(value);if(field==2)b.setWidth(value);if(field==3)b.setHeight(value);setBounds(t,b);applyAgain();}
    void refresh(){refreshing=true;undo.setEnabled(!back.empty());redo.setEnabled(!forward.empty());resetOne.setEnabled(valid());font.setEnabled(fontEditable());for(auto&n:numbers)n.setEnabled(valid());if(valid()){auto&t=targets[size_t(selected)];auto b=t.c->getBounds();picker.setSelectedId(selected+1,juce::dontSendNotification);const int values[]={b.getX(),b.getY(),b.getWidth(),b.getHeight()};for(int i=0;i<4;++i)if(!numbers[size_t(i)].hasKeyboardFocus(true))numbers[size_t(i)].setText(juce::String(values[i]),false);font.setValue(double(t.c->getProperties().getWithDefault("layoutFontScale",1.))*100,juce::dontSendNotification);}hint.setText(ru?juce::String::fromUTF8("Тяните элемент; угол — размер. Стрелки — сдвиг. Esc — отмена."):"Drag to move; corner to resize. Arrows nudge. Esc cancels.",juce::dontSendNotification);refreshing=false;repaint();}
    juce::Component&host;UserLayouts&store;std::function<juce::Point<int>()>rootSize;std::vector<Target>targets;LayoutItems draft,before;std::vector<LayoutItems>back,forward;
    juce::ComboBox picker;juce::TextButton save,cancel,undo,redo,resetOne,resetAll,position;juce::ToggleButton snap;juce::Slider font;juce::Label hint,fontCaption;std::array<juce::TextEditor,4>numbers;std::array<juce::Label,4>labels;
    int selected=-1,style=0,seen=-1;bool fontDragging=false,ru=false,refreshing=false,resizing=false,moved=false,barAtTop=false;juce::Point<float>start,startParent;juce::Rectangle<int>startBounds;
};
}
