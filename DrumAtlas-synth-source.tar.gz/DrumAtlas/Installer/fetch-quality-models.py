"""Pinned quality models shared by Windows and macOS; no account credentials."""
import hashlib,pathlib,sys,urllib.request
root=pathlib.Path(sys.argv[1]);root.mkdir(parents=True,exist_ok=True)
assets=[
('htdemucs_ft_drums.onnx','StemSplitio/htdemucs-ft-drums-onnx','55f929d333054c69ae0e829b15e8f8826a39d6eb','f76b68af36066e38885b369299b5032a861038f9b49da5aa6cf1c31cfa69cf27'),
('htdemucs_ft_bass.onnx','StemSplitio/htdemucs-ft-bass-onnx','410457f134bf91cb3ecb74abf1a897882d26afa8','2a74d9283fc2336fcc58d50f87a7080aff57aea372f65cfe3f0211ea1ff16182'),
('htdemucs_ft_vocals.onnx','StemSplitio/htdemucs-ft-vocals-onnx','2ef0d757d3e226d0da85fb8c71514f464fcabdd0','8c5d5e2da1f27050240bb80236673307ee3b40d4b064066d9350f4d64bfd544d'),
('melband_roformer_vocals.onnx','smank/mel-band-roformer-vocals-onnx','60cb6b4b97e41b42f7ff16c2e386f47a8cc7e50a','64a4f3bee48fbe7d971b23875adc924ed004c3533f49672592641dddc0f6f561')]
def digest(path):
 h=hashlib.sha256()
 with path.open('rb') as f:
  while block:=f.read(1024*1024):h.update(block)
 return h.hexdigest()
for name,repo,rev,expected in assets:
 target=root/name
 if target.exists() and digest(target)==expected:continue
 part=root/(name+'.part')
 with urllib.request.urlopen(f'https://huggingface.co/{repo}/resolve/{rev}/{name}',timeout=120) as response,part.open('wb') as out:
  while block:=response.read(1024*1024):out.write(block)
 if digest(part)!=expected:raise RuntimeError('Hash mismatch: '+name)
 part.replace(target);print('Verified',name,flush=True)
