import pathlib,sys,hashlib,urllib.request,zipfile,io
root=pathlib.Path(sys.argv[1]);arch=sys.argv[2]
assets={
'arm64':('a0/e5/58fd1a8d7b26fc113af244f966ee3aecf03cb9293cb935daaddc1e455e18/soundfile-0.13.1-py2.py3-none-macosx_11_0_arm64.whl','743f12c12c4054921e15736c6be09ac26b3b3d603aef6fd69f9dde68748f2593'),
'x86_64':('ea/ab/73e97a5b3cc46bba7ff8650a1504348fa1863a6f9d57d7001c6b67c5f20e/soundfile-0.13.1-py2.py3-none-macosx_10_9_x86_64.whl','82dc664d19831933fe59adad199bf3945ad06d84bc111a5b4c0d3089a5b9ec33')}
path,expected=assets[arch]
data=urllib.request.urlopen('https://files.pythonhosted.org/packages/'+path,timeout=120).read()
assert hashlib.sha256(data).hexdigest()==expected,'Decoder wheel hash mismatch'
root.mkdir(parents=True,exist_ok=True)
with zipfile.ZipFile(io.BytesIO(data)) as z:
 libs=[n for n in z.namelist() if n.endswith('.dylib') and 'libsndfile' in n]
 assert len(libs)==1,libs
 (root/'libsndfile.dylib').write_bytes(z.read(libs[0]))
 for n in z.namelist():
  if 'COPYING' in n.upper() or 'LICENSE' in n.upper():
   (root/('soundfile-'+pathlib.Path(n).name)).write_bytes(z.read(n))
(root/'sndfile-provenance.txt').write_text('SoundFile 0.13.1 wheel: '+path+'\nSHA256: '+expected+'\nBundled libsndfile, LGPL-2.1-or-later. Source: https://github.com/libsndfile/libsndfile/tree/1.2.2\n')
