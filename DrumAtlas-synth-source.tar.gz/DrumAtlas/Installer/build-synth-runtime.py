"""Build a relocatable, offline MuS3D runtime. Never copies a user environment."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import tarfile
import urllib.request

SOURCE_REV = '308a785814f9bfc8563c9eb2fb1ccc9c502a0d9c'
MODEL_REV = 'ea60328e89e0cefaa8e3a2fcc6dfebdc286f897e'
DAC_REV = '414c20785fc3a28373073ea8ef7a1316eeeaca6e'
PYTHON = {
    'windows': ('x86_64-pc-windows-msvc', '590dfcbe3a34c07301e6332e13e2188b98655cd072b08afa45a7998dc4c22bc5'),
    'arm64': ('aarch64-apple-darwin', 'fbf4afef53c2a6b72bb741bc06d5671a9dfaf87bd84e5aa73ac9b3d0d589f14e'),
    'x86_64': ('x86_64-apple-darwin', 'a962e47df522889eaa7ff0d6a56203f1079f68aabb65ffdbe8455f362bc769f3'),
}

def sha(path):
    with path.open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()

def fetch(url, path, expected=None, local=None):
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists() and (expected is None or sha(path) == expected):
        return
    temporary = path.with_name(path.name + '.partial')
    if local and local.is_file() and expected and sha(local) == expected:
        shutil.copyfile(local, temporary)
    else:
        print('Fetching', path.name, flush=True)
        with urllib.request.urlopen(url, timeout=180) as src, temporary.open('wb') as dst:
            shutil.copyfileobj(src, dst, 4*1024*1024)
    if expected and sha(temporary) != expected:
        raise RuntimeError('Checksum mismatch: ' + path.name)
    temporary.replace(path)

def source_archive(repo, revision, cache):
    archive = cache / (repo.replace('/', '-') + '-' + revision + '.tar.gz')
    fetch(f'https://api.github.com/repos/{repo}/tarball/{revision}', archive)
    dest = cache / (repo.replace('/', '-') + '-' + revision)
    if not dest.exists():
        dest.mkdir()
        with tarfile.open(archive) as tar:
            tar.extractall(dest, filter='data')
    return next(p for p in dest.iterdir() if p.is_dir())

def patch(path, old, new):
    text = path.read_text(encoding='utf-8')
    if new in text:
        return
    if old not in text:
        raise RuntimeError('Source patch no longer applies: ' + str(path))
    path.write_text(text.replace(old, new), encoding='utf-8')

def build(args):
    root = args.output.resolve()
    cache = args.cache.resolve()
    root.mkdir(parents=True, exist_ok=True)
    cache.mkdir(parents=True, exist_ok=True)
    arch = 'windows' if os.name == 'nt' else platform.machine()
    triple, digest = PYTHON[arch]
    archive = cache / f'cpython-3.12.16+20261026-{triple}-install_only.tar.gz'
    fetch('https://github.com/astral-sh/python-build-standalone/releases/download/20261026/' + archive.name.replace('+', '%2B'), archive, digest)
    executable = root / ('python/python.exe' if arch == 'windows' else 'python/bin/python3')
    if not (root/'python-ready.txt').exists():
        with tarfile.open(archive) as tar:
            tar.extractall(root, filter='data')
        (root/'python-ready.txt').write_text(digest, encoding='ascii')
    environment = dict(os.environ, PYTHONNOUSERSITE='1', PIP_DISABLE_PIP_VERSION_CHECK='1',
                       PIP_CACHE_DIR=str(cache/'pip'), TMPDIR=str(cache/'tmp'), TEMP=str(cache/'tmp'), TMP=str(cache/'tmp'))
    (cache/'tmp').mkdir(exist_ok=True)
    def pip(*packages, extra=()):
        subprocess.run([str(executable), '-I', '-m', 'pip', 'install', '--no-cache-dir', '--no-compile', *extra, *packages], env=environment, check=True)
    if not (root/'dependencies-ready.json').exists():
        if arch == 'x86_64':
            pip('torch==2.2.2', 'torchaudio==2.2.2', 'torchvision==0.17.2')
        elif arch == 'windows':
            pip('torch==2.9.0', 'torchaudio==2.9.0', 'torchvision==0.24.0', extra=('--index-url','https://download.pytorch.org/whl/cu128'))
        else:
            pip('torch==2.9.0', 'torchaudio==2.9.0', 'torchvision==0.24.0')
        pip('numpy==1.26.4', 'scipy==1.14.1', 'soundfile==0.13.1', 'librosa==0.11.0',
            'numba==0.61.2', 'einops==0.8.1', 'hydra-core==1.3.2', 'omegaconf==2.3.0',
            'hear21passt==0.0.26', 'timm==1.0.22', 'descript-audiotools==0.7.2',
            'spafe==0.3.3', 'scikit-learn==1.6.1', 'huggingface-hub==0.36.0')
        installed = subprocess.check_output([str(executable), '-I', '-m', 'pip', 'list', '--format=json'],env=environment)
        (root/'dependencies-ready.json').write_bytes(installed)
    subprocess.run([str(executable), '-I', '-m', 'pip', 'check'], env=environment, check=True)
    mus = source_archive('REMUS-Aalto/Mus3D', SOURCE_REV, cache)
    dac = source_archive('facebookresearch/dacvae', DAC_REV, cache)
    shutil.copytree(mus/'src', root/'src', dirs_exist_ok=True, ignore=shutil.ignore_patterns('__pycache__'))
    shutil.copytree(dac/'dacvae', root/'src/dacvae', dirs_exist_ok=True, ignore=shutil.ignore_patterns('__pycache__'))
    notices = root/'Licenses'
    notices.mkdir(exist_ok=True)
    for name in ('LICENSE','LICENSE-APACHE'):
        shutil.copyfile(mus/name, notices/('MuS3D-'+name+'.txt'))
    shutil.copyfile(mus/'src/query_conditioned_dit/LICENSE', notices/'SAM-LICENSE.txt')
    shutil.copyfile(dac/'LICENSE', notices/'DACVAE-APACHE.txt')
    # Preserve the existing Windows adaptation: full attention, independent
    # batch chunks only, same model weights and same context length.
    bsl = root/'src/query_conditioned_bslocoformer/bslocoformer.py'
    patch(bsl, 'from torch.nn.attention import SDPBackend, sdpa_kernel', '''try:
    from torch.nn.attention import SDPBackend, sdpa_kernel
except ImportError:  # Official Intel macOS PyTorch 2.2.x
    from contextlib import contextmanager
    class SDPBackend:
        MATH, FLASH_ATTENTION, EFFICIENT_ATTENTION = range(3)
    @contextmanager
    def sdpa_kernel(backend):
        with torch.backends.cuda.sdp_kernel(enable_flash=False, enable_math=True, enable_mem_efficient=False):
            yield''')
    patch(bsl, '@torch.amp.autocast("cuda", enabled=False)', '@torch.autocast("cuda", enabled=False)')
    text = bsl.read_text()
    start = text.index('        with sdpa_kernel(', text.index('self.sdpa_kernel ='))
    end = text.index('        # Merge heads', start)
    text = text[:start] + '''        with sdpa_kernel(SDPBackend.MATH):
            output = torch.cat([
                F.scaled_dot_product_attention(
                    query=query[i:i + 8], key=key[i:i + 8], value=value[i:i + 8],
                    attn_mask=None, dropout_p=self.dropout if self.training else 0.0,
                ) for i in range(0, query.shape[0], 8)
            ], dim=0)

''' + text[end:]
    bsl.write_text(text)
    encoder = root/'src/source_embedding_generator/mixture_encoder.py'
    patch(encoder, '        from query_conditioned_dit.codec import DacVaeCodec',
          '        from query_conditioned_dit.codec import DacVaeCodec\n        from pathlib import Path\n        model_id = str(Path(__file__).resolve().parents[2] / "models/dacvae.pth")')
    # NumPy 2-generated pure-array pickle compatibility on the Intel runtime.
    for relative in ('query_conditioned_bslocoformer/query_model.py', 'classifiers/stem_classifier.py'):
        p = root/'src'/relative
        patch(p, 'import pickle', '''import pickle
import numpy
def _load_pickle_compat(stream):
    class ArrayUnpickler(pickle.Unpickler):
        def find_class(self, module, name):
            if numpy.__version__.startswith("1.") and module.startswith("numpy._core"):
                module = module.replace("numpy._core", "numpy.core", 1)
            return super().find_class(module, name)
    return ArrayUnpickler(stream).load()''')
        patch(p, 'pickle.load(', '_load_pickle_compat(')
    model_files = {
        'BS-Locoformer_query/model.pth':'465c2aaf8c84a971d8eac80578de01db06ad36ab8f528f059ca90e62feb90e33',
        'SEG_mixemb/model.pth':'309a4b366e4883dcc943f931da09fb2237520198bff38800d0ec1756e4fa9143',
        'classifiers/pca_params_train.pkl':'d101fc988d22e9bf2454b3380a8359e3e1525f390026f30131e04f53906fb979',
        'classifiers/stem_classifier_pcatrain.pkl':'b6ca1da4cb2aaea828497ac0475232d179a6bfe64b941cffe7c182a0c4320723',
        'BS-Locoformer_query/config.yaml':None, 'SEG_mixemb/config.yaml':None,
    }
    for name, digest in model_files.items():
        fetch(f'https://huggingface.co/remus-aalto/MuS3D/resolve/{MODEL_REV}/{name}',root/'models'/name,digest,
              args.local_work/'mus3d-models'/name if args.local_work else None)
    shutil.copyfile(root/'models/classifiers/pca_params_train.pkl',root/'src/query_conditioned_bslocoformer/pca_params_train.pkl')
    fetch('https://huggingface.co/facebook/dacvae-watermarked/resolve/8680102d141858a21bd533543966a2eb2e569f92/weights.pth',root/'models/dacvae.pth',
          '573cf4770ea4a25507f26965d05ae720bcd34295a9f60c06ef3c3805826b68e4',
          args.local_work/'synth-runtime-data/hf/hub/models--facebook--dacvae-watermarked/snapshots/8680102d141858a21bd533543966a2eb2e569f92/weights.pth' if args.local_work else None)
    passt='openmic-passt-s-f128-10sec-p16-s10-ap.85.pt'
    # Match hear21passt's official release cache filename.
    fetch('https://github.com/kkoutini/PaSST/releases/download/v0.0.5/'+passt,root/'torch/hub/checkpoints'/passt,
          'dc229428753176e8be0373d25887116fc15b490af86f671cecf9ed76a0f287da',
          args.local_work/'mus3d-torch-cache/hub/checkpoints'/passt if args.local_work else None)
    fetch(f'https://huggingface.co/remus-aalto/MuS3D/raw/{MODEL_REV}/README.md',notices/'MuS3D-model-card.md')
    fetch('https://raw.githubusercontent.com/creativecommons/cc-legal-tools-data/main/docs/licenses/by/4.0/legalcode.txt', notices/'MuS3D-models-CC-BY-4.0.txt')
    fetch('https://raw.githubusercontent.com/kkoutini/PaSST/main/LICENSE', notices/'PaSST-APACHE.txt')
    # Wheel licence files remain in site-packages; also collect a readable
    # inventory and copies alongside the model notices for redistribution.
    subprocess.run([str(executable), '-I', '-c', '''
import importlib.metadata as m, json, pathlib, shutil, sys
target=pathlib.Path(sys.argv[1]); rows=[]
for dist in m.distributions():
    name=dist.metadata['Name']; version=dist.version
    rows.append({'name':name,'version':version,'license':dist.metadata.get('License-Expression',dist.metadata.get('License',''))})
    for f in dist.files or ():
        if any(word in f.name.lower() for word in ('license','copying','notice')):
            source=pathlib.Path(dist.locate_file(f))
            if source.is_file():
                dest=target/'Dependencies'/name/pathlib.Path(str(f))
                dest.parent.mkdir(parents=True,exist_ok=True); shutil.copyfile(source,dest)
(target/'dependencies.json').write_text(json.dumps(rows,indent=2),encoding='utf-8')
''', str(notices)], env=environment, check=True)
    (notices/'ATTRIBUTION.txt').write_text('MuS3D by V. Valtteri Kallinen, Eloi Moliner, Lauri Juvela, Vesa Valimaki (Aalto University).\nModels: CC BY 4.0, https://huggingface.co/remus-aalto/MuS3D\nSource: https://github.com/REMUS-Aalto/Mus3D\nDrumAtlas changes: offline paths, PyTorch Intel compatibility and chunked full attention.\nPaSST: https://github.com/kkoutini/PaSST\nDACVAE: https://github.com/facebookresearch/dacvae; SAM license also included for the codec adapter/model.\n',encoding='utf-8')
    shutil.copyfile(Path(__file__).resolve().parents[1]/'Tools/SynthLayersWorker.py', root/'SynthLayersWorker.py')
    manifest={'protocol':1,'python':executable.relative_to(root).as_posix(),'worker':'SynthLayersWorker.py',
              'source_root':'src','model_root':'models','torch_home':'torch','threads':4,'device':'auto',
              'source_revision':SOURCE_REV,'model_revision':MODEL_REV,'packaged':True}
    (root/'runtime.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
    print('Runtime staged:', root, flush=True)

if __name__ == '__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--cache',type=Path,required=True)
    parser.add_argument('--local-work',type=Path)
    build(parser.parse_args())
