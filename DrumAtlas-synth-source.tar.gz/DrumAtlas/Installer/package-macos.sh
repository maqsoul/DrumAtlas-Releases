#!/bin/bash
set -euo pipefail
# Package only an already built and tested native macOS build.
: "${DRUMATLAS_BUILD_DIR:?Set the tested build directory}"
: "${DRUMATLAS_VERSION:?Set version matching CMakeLists.txt}"
[[ "$(uname -s)" == Darwin ]] || exit 1
src="$(cd "$(dirname "$0")/.." && pwd)"
stage="$(mktemp -d "${TMPDIR:-/tmp}/drumatlas-package.XXXXXX")"
echo "Staging: $stage"
app="$DRUMATLAS_BUILD_DIR/DrumAtlas_artefacts/Release/Standalone/DrumAtlas.app"
vst="$DRUMATLAS_BUILD_DIR/DrumAtlas_artefacts/Release/VST3/DrumAtlas.vst3"
[[ -d "$app" && -d "$vst" ]] || { echo 'Missing app/VST3 bundles'; exit 1; }
mkdir -p "$stage/root/Applications" "$stage/root/Library/Audio/Plug-Ins/VST3"
ditto "$app" "$stage/root/Applications/DrumAtlas.app"
ditto "$vst" "$stage/root/Library/Audio/Plug-Ins/VST3/DrumAtlas.vst3"
shared="$stage/root/Library/Application Support/DrumAtlas"
mkdir -p "$shared/Source"
for entry in Source ThirdParty Tests Tools Installer LicenseServer CMakeLists.txt LICENSE THIRD_PARTY.md README.md RELEASE-SERVICES.md; do
 [[ ! -e "$src/$entry" ]] || ditto "$src/$entry" "$shared/Source/$entry"
done
if find "$shared/Source" \( -name server-secrets.json -o -name '*.pem' -o -name '*.sqlite*' -o -name '*.dpapi' \) -print -quit | grep -q .; then
 echo 'Private material found in source distribution; refusing to package'; exit 1
fi
if [[ -n "${DRUMATLAS_APP_IDENTITY:-}" ]]; then
 while IFS= read -r -d '' lib; do codesign --force --timestamp --options runtime --sign "$DRUMATLAS_APP_IDENTITY" "$lib"; done < <(find "$stage/root" -name '*.dylib' -print0)
 for bundle in "$stage/root/Applications/DrumAtlas.app" "$stage/root/Library/Audio/Plug-Ins/VST3/DrumAtlas.vst3"; do
  codesign --force --timestamp --options runtime --sign "$DRUMATLAS_APP_IDENTITY" "$bundle"
  codesign --verify --deep --strict "$bundle"
 done
else
 echo 'No Developer ID: package is for local testing, not a signed public release.'
fi
output="$DRUMATLAS_BUILD_DIR/DrumAtlas-$DRUMATLAS_VERSION-$(uname -m).pkg"
pkgbuild --root "$stage/root" --identifier audio.drumatlas.installer --version "$DRUMATLAS_VERSION" --install-location / "$stage/payload.pkg"
if [[ -n "${DRUMATLAS_INSTALLER_IDENTITY:-}" ]]; then
 productsign --sign "$DRUMATLAS_INSTALLER_IDENTITY" "$stage/payload.pkg" "$output"
else
 cp "$stage/payload.pkg" "$output"
fi
if [[ -n "${DRUMATLAS_NOTARY_PROFILE:-}" ]]; then
 [[ -n "${DRUMATLAS_APP_IDENTITY:-}" && -n "${DRUMATLAS_INSTALLER_IDENTITY:-}" ]] || { echo 'Notarization needs both Developer ID identities'; exit 1; }
 xcrun notarytool submit "$output" --keychain-profile "$DRUMATLAS_NOTARY_PROFILE" --wait
 xcrun stapler staple "$output"
fi
echo "Package: $output"
echo 'Stage retained for inspection. Include corresponding source/licences with public distribution; see THIRD_PARTY.md.'
