"""Export buildable corresponding source without local state or credentials."""
from pathlib import Path
import shutil, sys, tarfile, re
src=Path(__file__).resolve().parents[1]
dst=Path(sys.argv[1]).resolve()
dst.mkdir(parents=True,exist_ok=False)
entries=['Source','Resources','ThirdParty','Tests','Tools','Installer','CMakeLists.txt','LICENSE','JUCE-LICENSE.md','THIRD_PARTY.md','README.md','DRUM-SEPARATION-RU.md','CLEAN-VOCAL-PROVENANCE.json','SYNTH-LAYERS-PROVENANCE.json']
excluded={'.git','__pycache__','node_modules','.wrangler'}
for entry in entries:
    item=src/entry
    for f in (item.rglob('*') if item.is_dir() else [item]):
        if not f.is_file() or set(f.relative_to(src).parts)&excluded: continue
        rel=f.relative_to(src)
        if f.suffix.lower() in {'.exe','.dll','.pdb','.pyc','.sqlite','.db','.pem','.dpapi'} or 'secret' in f.name.lower():
            raise RuntimeError('Unexpected binary/private source item: '+str(rel))
        data=f.read_bytes()
        if re.search(rb'sk-proj-[A-Za-z0-9_-]{20,}', data) or any(x in data for x in (b'-----BEGIN '+b'PRIVATE KEY-----',b'-----BEGIN '+b'RSA PRIVATE KEY-----')):
            raise RuntimeError('Possible private credential in '+str(rel))
        target=dst/rel;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(f,target)
if len(sys.argv)>2:
    with tarfile.open(sys.argv[2],'w:gz') as archive: archive.add(dst,arcname='DrumAtlas')
print('Source export:',dst)
