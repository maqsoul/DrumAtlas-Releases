# Current EMBER packages

Display version: **1.0.0**. Internal build/package version: **1.0.9**.
Selected application icon: **07 / Record orbit**, approved by the owner on 2026-11-08.

## Windows

`DrumAtlas-Current.iss` installs VST3, optional Standalone, models, decoding/runtime
libraries, licences and corresponding source. Fourteen installer languages are
retained. The desktop shortcut task uses the icon embedded in DrumAtlas.exe.
The Setup executable and every adjacent `.bin` part must be kept together.
The installer never copies sample libraries, activation data or personal keys.

## macOS

`macos-current.yml` builds native arm64 and x86_64 packages on macOS runners.
It builds AU, VST3 and Standalone, runs pitch/tempo/licence and visual-meter tests,
checks runtime architecture, installs the resulting package on the disposable
runner and runs `auval` against the installed AU. Target macOS: 14 or later.
Intel ONNX Runtime 1.24.4 is built from source, because its upstream release does
not include an Intel macOS binary. Mac models are installed once under
`/Library/Application Support/DrumAtlas/Models` and shared by all three formats.

These packages are **not Apple Developer ID signed or notarized**. Ad-hoc signing
supports native loading; it is not a substitute for Developer ID or notarization.
Package generation must finish and AU validation must pass before calling a Mac
installer ready. A Windows build or a prepared workflow is not a Mac build.

## Optional runtime

The local Synth Layers Python/model runtime is not redistributed. Its dependencies
and separately licensed encoder require separate setup; personal runtime manifests
and credentials must never enter a customer package. Standard stem separation,
drum/percussion separation and quality vocal/bass/drum models are included.
Windows NVIDIA acceleration is Windows-only; macOS uses the native CPU runtime.

This workflow creates downloadable test artifacts. It does not publish a release,
change `stable.json`, or update existing customers automatically.
