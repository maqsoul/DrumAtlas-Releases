# Current EMBER packages

Display version: **1.0.0**. Internal build/package version: **1.0.9**.
Selected application icon: **07 / Record orbit**, approved by the owner on 2026-11-08.

## Windows

`DrumAtlas-Current.iss` installs VST3, optional Standalone, models, decoding/runtime
libraries, licences and corresponding source. Fourteen installer languages are
retained. The desktop shortcut task uses the icon embedded in DrumAtlas.exe.
The Setup executable and every adjacent `.bin` part must be kept together.
The installer never copies sample libraries, activation data or personal keys.

## macOS

`macos-synth.yml` builds native arm64 and x86_64 packages on macOS runners.
It builds AU, VST3 and Standalone, runs pitch/tempo/licence and visual-meter tests,
checks runtime architecture, installs the resulting package on the disposable
runner and runs `auval` against the installed AU. Target macOS: 14 or later.
Intel ONNX Runtime 1.24.4 is built from source, because its upstream release does
not include an Intel macOS binary. Mac models are installed once under
`/Library/Application Support/DrumAtlas/Models` and shared by all three formats.

These packages are **not Apple Developer ID signed or notarized**. Ad-hoc signing
supports native loading; it is not a substitute for Developer ID or notarization.
Package generation must finish and AU validation must pass before calling a Mac
installer ready. A Windows build or a prepared workflow is not a Mac build.

## Included Synth Layers runtime

Full installers include a separate, relocatable CPython/PyTorch runtime, MuS3D,
PaSST and DACVAE weights, dependencies and their licence notices. They require no
Python installation, Hugging Face sign-in or additional download after installation.
`build-synth-runtime.py` builds this distribution from pinned official archives;
it never copies a developer's Python environment or credentials.

Windows installs it once in `%PROGRAMDATA%/DrumAtlas/SynthLayers`. macOS installs
it in the shared Models/SynthLayers directory. The plugin discovers the packaged
manifest automatically, before consulting a legacy per-user manifest. Windows
selects supported NVIDIA CUDA hardware automatically and otherwise uses CPU;
macOS uses CPU. The offline check performs real inference with network access
blocked and is repeated on the installed Mac payload.

For Windows packaging, `/DSynthPayload=<verified runtime directory>` may point
Inno Setup directly at this runtime to avoid an additional large staging copy.
If omitted, SynthLayers is expected inside the regular payload directory.

This workflow creates downloadable test artifacts. It does not publish a release,
change `stable.json`, or update existing customers automatically.
