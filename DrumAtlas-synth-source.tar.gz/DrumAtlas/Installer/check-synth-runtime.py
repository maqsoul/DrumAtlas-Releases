"""Real offline inference using only the bundled interpreter, code and weights."""
import argparse
import importlib.util
import json
from pathlib import Path
import socket
import sys
import tempfile
import time

parser = argparse.ArgumentParser()
parser.add_argument('runtime', type=Path)
parser.add_argument('--device', choices=['cpu', 'cuda'], default='cpu')
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()
root = args.runtime.resolve()
spec = importlib.util.spec_from_file_location('synth_worker', root/'SynthLayersWorker.py')
worker = importlib.util.module_from_spec(spec)
spec.loader.exec_module(worker)
runtime = worker.load_runtime(root/'runtime.json')
runtime['device'] = args.device

def denied(*args, **kwargs):
    raise RuntimeError('Offline validation attempted network access')

socket.create_connection = denied
socket.socket.connect = denied
socket.socket.connect_ex = denied
started = time.monotonic()
with tempfile.TemporaryDirectory(prefix='drumatlas-synth-offline-') as cache:
    torch, device = worker.prepare_runtime(runtime, Path(cache))
    import numpy as np
    from classifiers.stem_classifier import StemClassifier
    from source_embedding_generator.separator_io import load_seg, load_separator
    from source_embedding_generator import protocol
    from utils.torch_common import set_seed
    models = Path(runtime['model_root'])
    classifier = StemClassifier.load(models/'classifiers/stem_classifier_pcatrain.pkl')
    # A deterministic chord, not user audio. Exercise every frozen encoder,
    # generated embedding, classifier and the actual query-conditioned separator.
    rate = 44100
    t = torch.arange(rate*10, dtype=torch.float32, device=device)/rate
    signal = sum(torch.sin(t*frequency*2*torch.pi) for frequency in (130.81,164.81,196.0))*.06
    mix = torch.stack([signal, signal*.9])[None]
    with torch.inference_mode():
        set_seed(0)
        seg = load_seg(models/'SEG_mixemb', device=device, use_ema=False)
        discovery = seg.inference(mix.mean(1, keepdim=True), level=protocol.LEVEL_TRACK,
                                  max_steps=1, steps=2, churn=.1, audio=False)
        embeddings = np.asarray(discovery['emb'], dtype='float32')
        if embeddings.size == 0 or not np.isfinite(embeddings).all():
            raise RuntimeError('Invalid generated embedding')
        classifier.proba(embeddings, 'track')
        query = torch.as_tensor(embeddings[:1], device=device).unsqueeze(0)
        del seg
        if device == 'cuda': torch.cuda.empty_cache()
        separator = load_separator(models/'BS-Locoformer_query', device=device, use_ema=False)
        level = torch.tensor([protocol.LEVEL_TRACK], dtype=torch.long, device=device)
        result = separator.sample(query, mix=mix, query_is_embedding=True, level=level)
        if result.shape[-2:] != mix.shape[-2:] or not torch.isfinite(result).all():
            raise RuntimeError('Invalid separated audio shape or values')
        report = {'ok': True, 'offline': True, 'device': device,
                  'python': sys.version.split()[0], 'torch': torch.__version__,
                  'frames': result.shape[-1], 'peak': float(result.abs().max()),
                  'seconds': round(time.monotonic()-started, 2)}
args.output.write_text(json.dumps(report, indent=2), encoding='utf-8')
print(json.dumps(report), flush=True)
