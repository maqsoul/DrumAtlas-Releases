# Third-party components, DrumAtlas 0.6.1

## JUCE 9.0.3
https://github.com/juce-framework/JUCE/tree/9.0.3

This package uses JUCE under the AGPLv3 open-source licensing route. JUCE source
and its licence are supplied with this release. Embedded codecs and the VST3 SDK
retain their upstream notices. DrumAtlas application source is AGPL-3.0-or-later.

## ONNX Runtime DirectML 1.24.4
https://github.com/microsoft/onnxruntime/releases/tag/v1.24.4
https://github.com/microsoft/onnxruntime

Copyright Microsoft Corporation. MIT licence. The release includes the official
Windows x64 runtime DLL, licence, and ThirdPartyNotices.txt. Build headers are
included in the corresponding DrumAtlas source. Debug symbols are not distributed.

## YAMNet
Google/TensorFlow YAMNet, Apache License 2.0.
Original implementation and training taxonomy:
https://github.com/tensorflow/models/tree/master/research/audioset/yamnet
Original model: https://www.kaggle.com/models/google/yamnet/tensorFlow2/yamnet/1

ONNX conversion by zeropointnine, model card declares Apache-2.0:
https://huggingface.co/zeropointnine/yamnet-onnx

Distributed files: yamnet.onnx, yamnet_class_map.csv. No retraining or modification
of the model weights was performed. DrumAtlas groups predicted classes, extracts
embeddings and combines these with acoustic features. Scores do not establish
identity of original samples or a calibrated percentage of perceptual similarity.

## Installer
Built with Inno Setup 6.2.2, https://github.com/jrsoftware/issrc/releases/tag/is-6_2_2.
Installer source and generated artwork are supplied in the application source.
The Inno Setup copyright/licence notice is included with release notices.

No user audio, commercial sample library or downloaded music is bundled.
Regression tests generate their own synthetic audio.

## libsndfile 1.2.2
Official Windows x64 release: https://github.com/libsndfile/libsndfile/releases/tag/1.2.2
LGPL-2.1-or-later, dynamically loaded. The DLL remains replaceable in Models.
The original source archive, official Windows distribution and licence are included.
API: https://libsndfile.github.io/libsndfile/api.html

## Harmonic/percussive separation
DrumAtlas's own median-filter HPSS implementation uses soft masks and overlap-add;
an additional transient gate preserves low-frequency drum attacks. Reference method:
https://librosa.org/doc/main/generated/librosa.decompose.hpss.html
No librosa code or dependency is bundled. HPSS is not a learned multi-instrument stem separator.
## Demucs 6-source ONNX (0.4)

Local source separation uses the MIT-licensed HT-Demucs 6-source model, ONNX export by StemSplit.
Model: https://huggingface.co/StemSplitio/htdemucs-6s-onnx
Original: https://github.com/facebookresearch/demucs
Export code: https://github.com/StemSplit/demucs-onnx
The fp16weights artifact is distributed as Models/htdemucs_6s.onnx (float32 computation).
Its SHA-256 and upstream revision are recorded in DEMUCS-PROVENANCE.json.
Full original and export MIT notices accompany the release in Licenses.
Windows Media Foundation uses operating-system components and is not redistributed.

## Detailed separation (0.6.0 personal beta)

MDX23C DrumSep ONNX from scragnog/HOT-Step-CPP-SuperSep, revision 440487b8300dcd61453cc52ec244a38150b03456. SHA256 dd94f6605e1ff42b11b6d7232117fb25ae24870613d25d8a6d083e2fd868b01d. Original weight redistribution terms are unconfirmed; architecture/export MIT notices do not grant a weight licence. Public/commercial redistribution is not cleared. See DRUM-SEPARATION-RU.md.

AudioSep ResUNet ONNX from niobures/AudioSep, revision b508693e47fcb996073cd18787debfb2c40dca65, models/ailia-models/audiosep_resunet.onnx. SHA256 030b1ff2af237e753ed5441c3a11358defaf2a706d7e037af681e4282b0ec179. Original AudioSep and ailia conversion MIT notices are included. Fixed query embeddings and original input BatchNorm coefficients are in percussion-prompts.json. BatchNorm extracted from official audo/AudioSep audiosep_base_4M_steps.ckpt, SHA256 f8cda01bfd0ebd141eef45d41db7a3ada23a56568465840d3cff04b8010ce82c; text encoder SHA256 f3cb68423900435937ff5c139f1c867ef8d1b0c05e5023c64f3446a24c08d3de. Neither checkpoint nor text encoder is distributed.

## DirectML acceleration (0.6.1)
Runtime DLLs are from the official onnxruntime-directml 1.24.4 Windows x64 CPython 3.12 wheel on PyPI, SHA256 f2ecb68b7b7b259d2ef3112ae760149f9b5a1e7c0fbb73d539da6250a648a614. Only onnxruntime.dll and DirectML.dll are redistributed, with Microsoft licence/notices. Python is not part of the installed application. Headers match ORT v1.24.4. Model weights are unchanged.
Documentation: https://onnxruntime.ai/docs/execution-providers/DirectML-ExecutionProvider.html
DirectML.dll is the unmodified Microsoft DirectML 1.15.4 redistributable, under the Microsoft Software License Terms for DirectML (Windows/Xbox use), not the repository's source-code MIT licence. The complete redistributable terms are included as DIRECTML-LICENSE.txt. Official terms: https://www.nuget.org/packages/Microsoft.AI.DirectML/1.15.4/License

## Pitch/time processing (1.0.0)
Signalsmith Stretch, MIT, https://github.com/Signalsmith-Audio/signalsmith-stretch
Revision a670068d9aeb64913331d5cc29337b19a457a7df.
Signalsmith Linear, MIT, https://github.com/Signalsmith-Audio/linear
Revision 146b26f91b48835d665fa0498d64d9617818d27a.
Unmodified headers and original MIT notices accompany the source/release.
