#pragma once
#include <juce_audio_processors/juce_audio_processors.h>
#include <algorithm>
#include <vector>
namespace atlas::hosting {
// Build during preparation. Lookup under the caller's processor callback lock:
// no RTTI, vendor string queries, allocation or linear parameter enumeration.
class PublicParameterIndex {
public:
    juce::Result prepare(const juce::Array<juce::AudioProcessorParameter*>&parameters){
        entries.clear();count=parameters.size();if(count>65536)return juce::Result::fail("Public parameter count exceeds index limit.");entries.reserve(size_t(count));
        for(int i=0;i<count;++i){auto*p=parameters[i];if(!p||!p->isAutomatable())continue;auto*hosted=dynamic_cast<juce::HostedAudioProcessorParameter*>(p);if(!hosted)continue;auto text=hosted->getParameterID();if(text.isEmpty()||text.length()>10||!text.containsOnly("0123456789"))continue;auto id=text.getLargeIntValue();if(id<0||id>0xffffffffll)continue;entries.push_back({uint32_t(id),i,p});}
        std::sort(entries.begin(),entries.end(),[](const Entry&a,const Entry&b){return a.id<b.id;});
        for(size_t i=1;i<entries.size();++i)if(entries[i-1].id==entries[i].id){entries.clear();return juce::Result::fail("Ambiguous numeric public parameter IDs.");}
        return juce::Result::ok();
    }
    juce::AudioProcessorParameter*find(uint32_t id,const juce::Array<juce::AudioProcessorParameter*>&parameters)const noexcept{
        if(parameters.size()!=count)return nullptr;
        auto it=std::lower_bound(entries.begin(),entries.end(),id,[](const Entry&entry,uint32_t value){return entry.id<value;});
        if(it==entries.end()||it->id!=id||parameters[it->index]!=it->parameter)return nullptr;
        return it->parameter;
    }
private:
    struct Entry{uint32_t id;int index;juce::AudioProcessorParameter*parameter;};std::vector<Entry>entries;int count=0;
};
}
