#pragma once
#include <juce_audio_processors/juce_audio_processors.h>
#include <set>
#include <cmath>
#include <vector>
namespace atlas::hosting {
inline juce::String parameterId(juce::AudioProcessorParameter&parameter){if(auto*hosted=dynamic_cast<juce::HostedAudioProcessorParameter*>(&parameter))return hosted->getParameterID();return {};}
inline juce::var parameterCapabilities(juce::AudioPluginInstance&plugin,const juce::PluginDescription&description){
 auto*root=new juce::DynamicObject;juce::var result(root);root->setProperty("schema",1);root->setProperty("plugin_version",description.version);root->setProperty("plugin_name",description.name);root->setProperty("vendor",description.manufacturerName);root->setProperty("uid",description.createIdentifierString());juce::Array<juce::var>rows;auto&parameters=plugin.getParameters();if(parameters.size()>8192)throw std::runtime_error("Plugin exposes more than 8192 parameters; use its native editor");std::set<juce::String>ids;
 for(int index=0;index<parameters.size();++index){auto&parameter=*parameters[index];auto id=parameterId(parameter);float value=parameter.getValue();if(!std::isfinite(value)||value<0||value>1)throw std::runtime_error("Plugin reported invalid normalized parameter value");if(id.isNotEmpty()&&!ids.insert(id).second)throw std::runtime_error("Duplicate public parameter ID");auto*row=new juce::DynamicObject;row->setProperty("id",id);row->setProperty("index",index);row->setProperty("name",parameter.getName(256));row->setProperty("label",parameter.getLabel().substring(0,64));row->setProperty("value",value);row->setProperty("default",parameter.getDefaultValue());row->setProperty("text",parameter.getText(value,256));row->setProperty("minimum",0.0);row->setProperty("maximum",1.0);row->setProperty("writable",id.isNotEmpty()&&parameter.isAutomatable());row->setProperty("discrete",parameter.isDiscrete());row->setProperty("steps",parameter.getNumSteps());rows.add(row);}
 root->setProperty("parameters",rows);if(juce::JSON::toString(result).getNumBytesAsUTF8()>2*1024*1024)throw std::runtime_error("Parameter capability map is too large");return result;
}
inline std::vector<std::pair<juce::AudioProcessorParameter*,float>> resolveParameterEdits(juce::AudioPluginInstance&plugin,const juce::var&edits){
 if(edits.isVoid())return {};auto*rows=edits.getArray();if(!rows||rows->size()>64)throw std::runtime_error("Expected at most 64 parameter edits");std::set<int>seen;std::vector<std::pair<juce::AudioProcessorParameter*,float>>validated;
 for(const auto&row:*rows){if(!row.isObject()||!(row["value"].isDouble()||row["value"].isInt()||row["value"].isInt64()))throw std::runtime_error("Parameter value must be a number");double value=double(row["value"]);if(!std::isfinite(value)||value<0||value>1)throw std::runtime_error("Parameter value outside normalized range 0..1");int index=-1;
  if(row.hasProperty("id")){if(!row["id"].isString()||row["id"].toString().isEmpty())throw std::runtime_error("Invalid parameter ID");for(int i=0;i<plugin.getParameters().size();++i)if(parameterId(*plugin.getParameters()[i])==row["id"].toString()){if(index>=0)throw std::runtime_error("Ambiguous parameter ID");index=i;}}
  else if(row["index"].isInt())index=int(row["index"]);
  if(index<0||index>=plugin.getParameters().size()||!seen.insert(index).second)throw std::runtime_error("Unknown or duplicate parameter");auto*parameter=plugin.getParameters()[index];if(!parameter->isAutomatable())throw std::runtime_error("Parameter does not expose public automation; use native editor");if(row.hasProperty("expected_name")&&row["expected_name"].toString()!=parameter->getName(256))throw std::runtime_error("Parameter name changed; refresh capabilities");validated.emplace_back(parameter,float(value));
 }
 return validated;
}
inline void applyParameterEdits(juce::AudioPluginInstance&plugin,const juce::var&edits){
 const auto validated=resolveParameterEdits(plugin,edits);
 for(const auto&edit:validated){edit.first->beginChangeGesture();edit.first->setValueNotifyingHost(edit.second);edit.first->endChangeGesture();}
}
}
