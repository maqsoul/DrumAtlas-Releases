"""Data-only IPC. No shell, eval, arbitrary device code or network listener."""
import json
import math
import os
import re
import time
from pathlib import Path

DEVICES = ("Analog", "Collision", "Drift", "Electric", "Meld", "Operator", "Tension", "Wavetable")
ID = re.compile(r"^[a-f0-9]{32}$")
TEMPLATE_PREFIX = "Live track: "


def safe_template(track):
    """A named empty MIDI instrument track; no user's clips are cloned/removed."""
    if not getattr(track, "has_midi_input", False) or not getattr(track, "has_audio_output", False):
        return False
    if getattr(track, "is_frozen", False) or getattr(track, "is_foldable", False):
        return False
    if not isinstance(track.name, str) or not 1 <= len(track.name) <= 80 or track.name.startswith("DA "):
        return False
    if track.arrangement_clips or any(slot.has_clip for slot in track.clip_slots):
        return False
    pending = list(track.devices)
    count = 0
    while pending:
        device = pending.pop()
        count += 1
        if count > 512:
            return False
        if any("drumatlas" in str(getattr(device, key, "")).lower() for key in ("name", "class_name", "class_display_name")):
            return False
        for chain in getattr(device, "chains", ()):
            pending.extend(chain.devices)
    return count > 0


def templates(song):
    names = [track.name for track in song.tracks]
    return {TEMPLATE_PREFIX + track.name: track for track in song.tracks
            if names.count(track.name) == 1 and safe_template(track)}


def atomic_json(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(".tmp")
    temp.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
    os.replace(str(temp), str(path))


def number(value, low, high):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or not low <= value <= high:
        raise ValueError("Invalid number or range")
    return value


def validate(payload, session, songs_root, now=None):
    now = time.time() * 1000 if now is None else now
    if not isinstance(payload, dict) or payload.get("schema") != 1 or payload.get("session") != session:
        raise ValueError("Wrong bridge session or schema")
    if not isinstance(payload.get("id"), str) or not ID.fullmatch(payload["id"]):
        raise ValueError("Invalid request identity")
    if abs(now - number(payload.get("created_ms"), 0, 1e15)) > 60000:
        raise ValueError("Expired request; send it again from DrumAtlas")
    command = payload.get("command")
    if command in ("play", "stop", "render"):
        if not isinstance(payload.get("song_id"), str) or not ID.fullmatch(payload["song_id"]):
            raise ValueError("Invalid transport song identity")
        return payload
    if command != "import":
        raise ValueError("Unsupported bridge command")
    if not isinstance(payload.get("song_id"), str) or not ID.fullmatch(payload["song_id"]):
        raise ValueError("Invalid song identity")
    number(payload.get("bpm"), 30, 300)
    length = number(payload.get("length"), 1, 16384)
    tracks = payload.get("tracks")
    if not isinstance(tracks, list) or not 1 <= len(tracks) <= 24:
        raise ValueError("Invalid track list")
    total = 0
    for track in tracks:
        if not isinstance(track, dict) or not isinstance(track.get("name"), str) or not 1 <= len(track["name"]) <= 80:
            raise ValueError("Invalid track name")
        if track.get("kind") == "midi":
            device = track.get("device")
            if device not in DEVICES and not (isinstance(device, str) and device.startswith(TEMPLATE_PREFIX) and 0 < len(device[len(TEMPLATE_PREFIX):]) <= 80):
                raise ValueError("Unsupported native instrument")
            notes = track.get("notes")
            if not isinstance(notes, list) or len(notes) > 100000:
                raise ValueError("Too many MIDI notes")
            total += len(notes)
            for note in notes:
                if not isinstance(note, list) or len(note) != 4:
                    raise ValueError("Invalid note")
                pitch, start, duration, velocity = note
                if type(pitch) is not int or type(velocity) is not int:
                    raise ValueError("MIDI pitch and velocity must be integers")
                number(pitch, 0, 127)
                number(velocity, 1, 127)
                number(start, 0, length)
                number(duration, .0001, length)
                if start + duration > length + .001:
                    raise ValueError("Note extends beyond arrangement")
        elif track.get("kind") == "audio":
            number(track.get("gain", 1), 0, 1)
            path = Path(track.get("file", "")).resolve()
            root = Path(songs_root).resolve()
            if root not in path.parents or path.suffix.lower() != ".wav" or not path.is_file():
                raise ValueError("Audio must be an existing DrumAtlas composition WAV")
        else:
            raise ValueError("Invalid track kind")
    if total > 200000:
        raise ValueError("Composition exceeds the bridge note budget")
    sections = payload.get("sections")
    if not isinstance(sections, list) or not 1 <= len(sections) <= 64:
        raise ValueError("Invalid sections")
    end = 0
    for section in sections:
        if not isinstance(section, dict) or not isinstance(section.get("name"), str) or not 1 <= len(section["name"]) <= 64:
            raise ValueError("Invalid section name")
        start = number(section.get("start"), 0, length)
        size = number(section.get("length"), .001, length)
        if abs(start - end) > .001:
            raise ValueError("Sections must cover the song without gaps")
        end = start + size
    if abs(end - length) > .001:
        raise ValueError("Incomplete section coverage")
    return payload


def import_song(song, payload, add_notes):
    """Create new tracks or duplicate empty templates; roll back only our new tracks."""
    if song.is_playing or song.record_mode:
        raise ValueError("Stop Live playback/recording before importing the arrangement")
    tag = "DA " + payload["song_id"][:8] + " - "
    if any(track.name.startswith(tag) for track in song.tracks):
        raise ValueError("This composition is already present in Live")
    old_tempo = song.tempo
    previous_selection = song.view.selected_track
    end = 0.0
    has_content = False
    for track in song.tracks:
        for clip in track.arrangement_clips:
            has_content = True
            end = max(end, clip.end_time)
        has_content |= any(slot.has_clip for slot in track.clip_slots)
    if has_content and abs(old_tempo - payload["bpm"]) > .01:
        raise ValueError("Live already contains music at a different tempo. Use an empty Set or match its tempo first")
    start = math.ceil(end / 4) * 4
    if start + payload["length"] > 1576800:
        raise ValueError("Live arrangement limit exceeded")
    created = []
    available_templates = templates(song)
    song.begin_undo_step()
    try:
        if not has_content:
            song.tempo = payload["bpm"]
        for spec in payload["tracks"]:
            template = spec.get("device", "").startswith(TEMPLATE_PREFIX)
            if template:
                source = available_templates.get(spec["device"])
                if source is None or source not in song.tracks or not safe_template(source):
                    raise ValueError("Keep the chosen empty MIDI instrument track in this Set: " + spec["device"])
                previous_tracks = list(song.tracks)
                song.duplicate_track(previous_tracks.index(source))
                added = [track for track in song.tracks if track not in previous_tracks]
                created.extend(added)
                if len(added) != 1:
                    raise ValueError("Live did not duplicate exactly one template track")
                track = added[0]
                track.arm = False
                track.solo = False
                track.mute = False
            elif spec["kind"] == "midi":
                song.create_midi_track(-1)
            else:
                song.create_audio_track(-1)
            if not template:
                track = song.tracks[-1]
                created.append(track)
            track.name = tag + spec["name"]
            if spec["kind"] == "midi":
                if not template:
                    track.insert_device(spec["device"])
                if not track.devices:
                    raise ValueError("Live did not load " + spec["device"])
                for section in payload["sections"]:
                    at, size = section["start"], section["length"]
                    track.create_midi_clip(start + at, size)
                    clip = next(c for c in track.arrangement_clips if abs(c.start_time - (start + at)) < .001)
                    clip.name = section["name"] + " - " + spec["name"]
                    notes = [(n[0], n[1] - at, min(n[2], at + size - n[1]), n[3])
                             for n in spec["notes"] if at <= n[1] < at + size]
                    add_notes(clip, notes)
            else:
                track.create_audio_clip(spec["file"], start)
                if not track.arrangement_clips:
                    raise ValueError("Live did not create the audio clip")
                clip = track.arrangement_clips[-1]
                clip.warping = False
                clip.gain = spec.get("gain", 1)
                clip.name = spec["name"]
        return {"tracks": len(created), "start": start, "length": payload["length"], "song_id": payload["song_id"]}
    except Exception:
        # Track identities, not guessed indices: never delete pre-existing tracks.
        for track in reversed(created):
            current = list(song.tracks)
            if track in current:
                song.delete_track(current.index(track))
        song.tempo = old_tempo
        raise
    finally:
        if previous_selection in song.tracks:
            song.view.selected_track = previous_selection
        song.end_undo_step()
