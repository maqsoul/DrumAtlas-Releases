from .surface import DrumAtlasBridge


def create_instance(c_instance):
    return DrumAtlasBridge(c_instance)
