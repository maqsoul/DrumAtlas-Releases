import json
import os
import time
import uuid
from pathlib import Path

import Live
from _Framework.ControlSurface import ControlSurface
from .protocol import DEVICES, ID, atomic_json, import_song, templates, validate
from .capture import Capture


class DrumAtlasBridge(ControlSurface):
    def __init__(self, c_instance):
        super().__init__(c_instance)
        self.root = Path(os.environ["APPDATA"]) / "DrumAtlas"
        self.session = uuid.uuid4().hex
        self.folder = self.root / "LiveBridge"
        self.inbox = self.folder / "requests" / self.session
        self.inbox.mkdir(parents=True, exist_ok=True)
        self.state_file = self.folder / "instances" / (self.session + ".json")
        self.last_publish = 0
        self.applied = {}
        self.capture = None
        self.show_message("DrumAtlas bridge connected")
        self._publish()

    def _publish(self):
        app = self.application()
        compatible = (app.get_major_version(), app.get_minor_version()) >= (12, 3)
        atomic_json(self.state_file, {"schema": 1, "session": self.session,
                    "heartbeat_ms": int(time.time() * 1000), "pid": os.getpid(),
                    "tempo": self.song().tempo, "supported": compatible,
                    "devices": list(DEVICES) + list(templates(self.song())) if compatible else [],
                    "status": "Connected" if compatible else "Live 12.3 or newer is required"})
        self.last_publish = time.monotonic()

    @staticmethod
    def _add_notes(clip, notes):
        # Remote Script Python API uses MidiNoteSpecification objects, unlike
        # the Max API's JSON dictionary. Keep calls on Live's main thread.
        for start in range(0, len(notes), 512):
            clip.add_new_notes(tuple(Live.Clip.MidiNoteSpecification(
                pitch=pitch, start_time=at, duration=duration, velocity=velocity)
                for pitch, at, duration, velocity in notes[start:start + 512]))

    def update_display(self):
        super().update_display()
        try:
            if time.monotonic() - self.last_publish > 1:
                self._publish()
            if self.capture:
                capture, request, reply, result = self.capture
                try:
                    if not request.exists():
                        raise ValueError("Rendering cancelled")
                    rendered = capture.poll()
                    if rendered is None:
                        return
                    result.update(ok=True, result=rendered)
                except Exception as error:
                    result["error"] = str(error)
                finally:
                    if result.get("ok") or result.get("error"):
                        try:
                            capture.close()
                        finally:
                            self.capture = None
                if self.capture:
                    return
                atomic_json(reply, result)
                request.unlink(missing_ok=True)
                return
            paths = sorted(self.inbox.glob("*.json"))
            if not paths:
                return
            path = paths[0]
            if not ID.fullmatch(path.stem):
                return
            reply = self.folder / "responses" / self.session / path.name
            if reply.exists():
                path.unlink()  # Completed request cannot execute twice.
                return
            result = {"schema": 1, "id": path.stem, "session": self.session, "ok": False}
            try:
                if path.stat().st_size > 32 * 1024 * 1024:
                    raise ValueError("Bridge request too large")
                data = json.loads(path.read_text(encoding="utf-8-sig"))
                validate(data, self.session, self.root / "Composer" / "songs")
                if data["id"] != path.stem:
                    raise ValueError("Request filename mismatch")
                if data["command"] == "import":
                    result["result"] = import_song(self.song(), data, self._add_notes)
                    self.applied[data["song_id"]] = result["result"]
                else:
                    entry = self.applied.get(data.get("song_id"))
                    tag = "DA " + data["song_id"][:8] + " - "
                    if not entry or not any(track.name.startswith(tag) for track in self.song().tracks):
                        raise ValueError("Send this composition to Live in the current bridge session first")
                    if self.song().record_mode:
                        raise ValueError("Disable recording before preview transport")
                    if data["command"] == "render":
                        target = self.root / "Composer" / "songs" / data["song_id"] / ("live-mix-" + data["id"] + ".wav")
                        capture = Capture(self.song(), entry, target, Live.Song.Quantization.q_no_q)
                        self.capture = (capture, path, reply, result)
                        return
                    elif data["command"] == "play":
                        self.song().current_song_time = entry["start"]
                        self.song().start_playing()
                    else:
                        self.song().stop_playing()
                        self.song().current_song_time = entry["start"]
                result["ok"] = True
            except Exception as error:
                result["error"] = str(error)
                self.log_message("DrumAtlas bridge: " + str(error))
            atomic_json(reply, result)
            path.unlink()
        except Exception as error:
            self.log_message("DrumAtlas bridge IO: " + str(error))

    def disconnect(self):
        try:
            if self.capture:
                self.capture[0].close()
                self.capture = None
            self.state_file.unlink(missing_ok=True)
        finally:
            super().disconnect()
