"""Realtime resampling of bridge-owned tracks; no UI automation or offline API claims."""
import shutil
import time
from pathlib import Path


class Capture:
    def __init__(self, song, entry, target, no_quantization):
        if song.is_playing or song.record_mode or getattr(song, "session_record", False):
            raise ValueError("Stop Live playback and recording before rendering")
        self.song, self.target = song, Path(target)
        self.track = None
        self.closed = False
        self.states = [(t, bool(t.mute), bool(t.solo)) for t in list(song.tracks) + list(song.return_tracks)]
        self.arms = [(t, bool(t.arm)) for t in song.tracks if getattr(t, "can_be_armed", False)]
        self.position, self.loop = song.current_song_time, song.loop
        self.selection = song.view.selected_track
        tag = "DA " + entry["song_id"][:8] + " - "
        owned = [t for t in song.tracks if t.name.startswith(tag)]
        if len(owned) != entry["tracks"]:
            raise ValueError("Composition tracks changed; send a fresh version to Live before rendering")
        self.deadline = time.monotonic() + (entry["length"] + 8) * 60 / song.tempo + 30
        self.started = time.monotonic()
        self.copy_started = None
        self.recording_finished = False
        self.partial = self.target.with_suffix(self.target.suffix + ".partial")
        self.end_beat = entry["start"] + entry["length"] + 4
        try:
            song.create_audio_track(-1)
            self.track = song.tracks[-1]
            self.track.name = "DrumAtlas render capture"
            inputs = self.track.available_input_routing_types
            resampling = next((r for r in inputs if str(r.display_name).lower() == "resampling"), None)
            if resampling is None:
                raise ValueError("Live Resampling input is unavailable")
            self.track.input_routing_type = resampling
            self.track.current_monitoring_state = 2  # Off: prevents feedback.
            self.track.mute = True
            self.track.arm = True
            for track, _, _ in self.states:
                track.solo = False
                # Returns remain available for the chosen tracks' send effects.
                track.mute = track not in owned and track not in song.return_tracks
            song.loop = False
            song.current_song_time = entry["start"]
            self.slot = self.track.clip_slots[0]
            self.slot.fire(record_length=entry["length"] + 4, launch_quantization=no_quantization)
        except Exception:
            self.close()
            raise

    def poll(self):
        if time.monotonic() > self.deadline:
            raise ValueError("Live recording timed out")
        if not self.recording_finished:
            if not self.slot.has_clip:
                if time.monotonic() - self.started > 10:
                    raise ValueError("Live did not start recording")
                return None
            clip = self.slot.clip
            if clip.is_recording:
                if not self.song.is_playing:
                    raise ValueError("Live playback stopped before rendering finished")
                return None
            if self.song.current_song_time < self.end_beat - .05:
                raise ValueError("Live recording ended before the complete arrangement was captured")
            self.source = Path(clip.file_path)
            self.recording_finished = True
            # Live retains an exclusive recording handle while the capture track
            # owns the clip. Remove only our temporary track before reading it.
            # Cache the path first: Live clip objects become invalid on deletion.
            self.close()
        source = self.source
        if not source.is_file() or source.stat().st_size < 64:
            raise ValueError("Live did not produce a recorded audio file")
        self.target.parent.mkdir(parents=True, exist_ok=True)
        if self.target.exists():
            raise ValueError("Capture destination already exists")
        if self.copy_started is None:
            self.copy_started = time.monotonic()
        try:
            shutil.copyfile(str(source), str(self.partial))
            self.partial.replace(self.target)
        except PermissionError:
            # Live finalises/releases its recording handle on a later message-loop
            # tick. Never block that thread waiting for the same writer to close.
            if time.monotonic() - self.copy_started < 10:
                return None
            raise
        return {"file": str(self.target), "realtime": True, "tail_beats": 4}

    def close(self):
        if self.closed:
            return
        self.closed = True
        self.song.stop_playing()
        for track, mute, solo in self.states:
            if track in self.song.tracks or track in self.song.return_tracks:
                track.mute, track.solo = mute, solo
        if self.track in self.song.tracks:
            self.song.delete_track(list(self.song.tracks).index(self.track))
        for track, arm in self.arms:
            if track in self.song.tracks:
                track.arm = arm
        self.song.loop = self.loop
        self.song.current_song_time = self.position
        if self.selection in self.song.tracks:
            self.song.view.selected_track = self.selection
        try:
            if self.partial.exists():
                self.partial.unlink()
        except OSError:
            pass  # Never prevent transport restoration for temporary-file cleanup.
