# DrumAtlasBridge for Ableton Live 12.3+ (Windows)

Copy the `DrumAtlasBridge` directory into your Ableton User Library's
`Remote Scripts` directory. Restart Live and select **DrumAtlasBridge** in a
free **Control Surface** slot under **Settings → Link, Tempo & MIDI**.
Input and Output can remain None: this bridge uses local files, not a MIDI port.
Do not replace a control surface that you use for hardware.

In DrumAtlas AI Chat, open **Allowed instruments**. The connected bridge adds
Analog, Collision, Drift, Electric, Meld, Operator, Tension and Wavetable with
the `(Live)` suffix. The Live edition/license must include the chosen device.
These are synthesizers with initial sounds; empty Sampler/Drum Rack devices
and arbitrary Max devices are intentionally not presented as playable sounds.

When the AI chooses a Live device, it creates MIDI in DrumAtlas and sends the
completed composition to Live automatically. **Send to Live** also transfers a
completed composition manually. Native tracks become MIDI tracks with section
clips; rendered sample/VST tracks become audio tracks. The original MIDI files
for those rendered tracks remain in the composition folder.

Stop Live before import. The bridge appends new tracks and places the song after
existing Arrangement content. It never replaces pre-existing tracks or clips.
If a nonempty Set has a different tempo, import stops without changing its
tempo. Use an empty Set or deliberately match the tempo first. Imports are one
undo step; failures attempt to remove only this import's new tracks and restore
the previous tempo and selection. A failed rollback in Live itself can still
require inspecting/undoing the test Set.

**Play in Live** starts the imported composition; Stop returns to its start.
The bridge does not automatically start recording or save/close the Live Set.
If the bridge/Live has restarted, send the composition in the new session first.
Duplicate imports of the same composition into a Set are rejected. Preserve
the `DA <song id> - ...` track prefixes if you rely on duplicate detection.

To use an already configured instrument or rack, create an empty MIDI track
with a unique name. Choose **Live track: name** under **Allowed plugins**.
The bridge duplicates the template, retaining its devices and preset.

Stop playback and choose **Ableton Live → Render complete mix in Live**.
The bridge records the generated tracks and their returns to a temporary
resampling track in real time. At the end it releases that track and restores
the previous transport position, loop, mutes, solos, selection and record arms.
DrumAtlas reads the recording, includes four beats of tail and exposes a
24-bit WAV for dragging into the DAW.

IPC is JSON under `%APPDATA%/DrumAtlas/LiveBridge/`: per-instance heartbeats,
session-specific request queues and responses. No network service, shell or
arbitrary Python execution is exposed. Requests expire after 60 seconds,
responses use unique IDs, and multiple active Live bridge instances are rejected
by the plugin. Audio paths must point to WAVs inside DrumAtlas's Composer/songs
folder. The bridge treats generated plans as data and validates ranges before
editing a Set. Local processes running as the same user are not a security
boundary.

Reference APIs:

- [Ableton: installing third-party remote scripts](https://help.ableton.com/hc/en-us/articles/209072009-Installing-third-party-remote-scripts)
- [Live Track API: insert_device, create_midi_clip and create_audio_clip](https://docs.cycling74.com/apiref/lom/track/)
- [Live Clip API: add_new_notes](https://docs.cycling74.com/apiref/lom/clip/)

`Tests/test_live_bridge.py` verifies validation, section note placement, duplicate
rejection, occupied-Set tempo protection, recording/playback guards and rollback
of only newly created tracks. These tests do not substitute for loading the
companion in the installed version of Live.
