// Isolated CUDA runtime: never load a second ONNX Runtime into the DAW process.
#define NOMINMAX
#define ORT_API_MANUAL_INIT
#include <onnxruntime_cxx_api.h>
#include <windows.h>
#include <filesystem>
#include <fstream>
#include <vector>
#include <thread>
#include <chrono>
#include <cmath>
namespace fs=std::filesystem;
static void publish(const fs::path&p,const void*data,size_t size){auto tmp=p;tmp+=L".tmp";{std::ofstream f(tmp,std::ios::binary);f.write(static_cast<const char*>(data),size);if(!f)throw std::runtime_error("GPU worker output write failed");}fs::rename(tmp,p);}
int wmain(int argc,wchar_t**argv){
 if(argc!=5)return 2;const fs::path folder=argv[1],runtime=argv[2],model=argv[3];
 try{
  HANDLE parent=OpenProcess(SYNCHRONIZE,FALSE,DWORD(std::wcstoul(argv[4],nullptr,10)));if(!parent)throw std::runtime_error("GPU worker parent unavailable");
  struct CloseParent{HANDLE handle;~CloseParent(){CloseHandle(handle);}}closeParent{parent};
  SetDefaultDllDirectories(LOAD_LIBRARY_SEARCH_DEFAULT_DIRS|LOAD_LIBRARY_SEARCH_USER_DIRS);
  AddDllDirectory(runtime.c_str());
  auto dll=LoadLibraryExW((runtime/L"onnxruntime.dll").c_str(),nullptr,LOAD_LIBRARY_SEARCH_DLL_LOAD_DIR|LOAD_LIBRARY_SEARCH_DEFAULT_DIRS);
  if(!dll)throw std::runtime_error("CUDA ONNX Runtime unavailable");
  auto get=reinterpret_cast<const OrtApiBase*(ORT_API_CALL*)()>(GetProcAddress(dll,"OrtGetApiBase"));if(!get)throw std::runtime_error("CUDA runtime API unavailable");
  auto api=get()->GetApi(ORT_API_VERSION);if(!api)throw std::runtime_error("CUDA runtime version incompatible");Ort::InitApi(api);
  Ort::Env env(ORT_LOGGING_LEVEL_ERROR,"DrumAtlas vocal GPU");env.DisableTelemetryEvents();
  Ort::SessionOptions options;options.SetIntraOpNumThreads(2);options.SetInterOpNumThreads(1);options.DisableMemPattern();options.SetGraphOptimizationLevel(ORT_ENABLE_ALL);
  OrtCUDAProviderOptionsV2*cuda=nullptr;Ort::ThrowOnError(api->CreateCUDAProviderOptions(&cuda));
  struct Release{const OrtApi*api;OrtCUDAProviderOptionsV2*cuda;~Release(){api->ReleaseCUDAProviderOptions(cuda);}}release{api,cuda};
  const char*keys[]{"device_id","use_tf32","gpu_mem_limit","arena_extend_strategy","cudnn_conv_algo_search","cudnn_conv_use_max_workspace"};
  const char*values[]{"0","0","7516192768","kSameAsRequested","HEURISTIC","0"};
  Ort::ThrowOnError(api->UpdateCUDAProviderOptions(cuda,keys,values,6));Ort::ThrowOnError(api->SessionOptionsAppendExecutionProvider_CUDA_V2(options,cuda));
  Ort::Session session(env,model.c_str(),options);const char*ready="ready";publish(folder/L"ready",ready,5);
  constexpr size_t frames=352800;const auto memory=Ort::MemoryInfo::CreateCpu(OrtArenaAllocator,OrtMemTypeDefault);
  // Exit if parent vanishes or no request arrives for ten minutes.
  auto last=std::chrono::steady_clock::now();
  while(!fs::exists(folder/L"quit")&&WaitForSingleObject(parent,0)==WAIT_TIMEOUT){
   auto request=folder/L"request.f32";
   if(!fs::exists(request)){if(std::chrono::steady_clock::now()-last>std::chrono::minutes(10))break;std::this_thread::sleep_for(std::chrono::milliseconds(5));continue;}
   if(fs::file_size(request)!=frames*2*sizeof(float))throw std::runtime_error("Invalid GPU request length");
   std::vector<float>x(frames*2);{std::ifstream f(request,std::ios::binary);f.read(reinterpret_cast<char*>(x.data()),x.size()*sizeof(float));if(!f)throw std::runtime_error("Cannot read GPU request");}fs::remove(request);
   const int64_t shape[]{1,2,frames};auto input=Ort::Value::CreateTensor<float>(memory,x.data(),x.size(),shape,3);
   const char*in="mix",*out="sources";auto y=session.Run(Ort::RunOptions{nullptr},&in,&input,1,&out,1);
   if(y[0].GetTensorTypeAndShapeInfo().GetShape()!=std::vector<int64_t>{1,2,2,frames})throw std::runtime_error("Invalid GPU output shape");
   const auto*data=y[0].GetTensorData<float>();for(size_t i=0;i<frames*2;++i)if(!std::isfinite(data[i]))throw std::runtime_error("Non-finite GPU audio");
   publish(folder/L"response.f32",data,frames*2*sizeof(float));last=std::chrono::steady_clock::now();
  }
  return 0;
 }catch(const std::exception&e){try{const std::string message=e.what();publish(folder/L"error",message.data(),message.size());}catch(...){}return 1;}
}
