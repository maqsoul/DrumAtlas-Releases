#pragma once
#include "../Source/HostProtocol.h"
#include "HostFormats.h"
#include "HostedEditor.h"
#include "../Source/NativeEditorPosition.h"
#include "ParameterCapabilities.h"
#include "InstrumentAudioStream.h"
#include <juce_audio_processors/juce_audio_processors.h>
#include <juce_cryptography/juce_cryptography.h>
#include <mutex>
#include <deque>
namespace atlas::hosting::service {
class Window final:public juce::DocumentWindow {
public:
    explicit Window(juce::AudioPluginInstance&plugin,bool visible,const juce::var&position={}):DocumentWindow(plugin.getName(),juce::Colour(0xff101d29),allButtons){setUsingNativeTitleBar(true);auto*editor=createHostedEditor(plugin);setContentOwned(editor,true);centreWithSize(getWidth(),getHeight());restorePosition(position);placementReady=true;setVisible(visible);}
    void closeButtonPressed()override{setVisible(false);}
    void resized()override{DocumentWindow::resized();if(placementReady)restorePosition({});}
    juce::var position()const{return nativeEditorPosition(getX(),getY());}
    void restorePosition(const juce::var&value){NativeEditorPoint desired{getX(),getY()};if(value.isObject()&&validNativeEditorPosition(value))desired={int(value["x"]),int(value["y"])};const auto&displays=juce::Desktop::getInstance().getDisplays();auto*display=displays.getDisplayForRect({desired.x,desired.y,getWidth(),getHeight()});if(!display)display=displays.getPrimaryDisplay();if(display){auto area=display->userArea;desired=visibleNativeEditorPosition(desired,getWidth(),getHeight(),area.getX(),area.getY(),area.getWidth(),area.getHeight());}setTopLeftPosition(desired.x,desired.y);}
private:
    bool placementReady=false;
};
inline int testWindowResize(const juce::File&fixture){
    try{
        atlas::hosting::HostFormats format;juce::OwnedArray<juce::PluginDescription>found;
        format.findAllTypesForFile(found,fixture.getFullPathName());if(found.isEmpty())return 1;
        juce::String error;auto plugin=format.createInstanceFromDescription(*found[0],48000,128,error);if(!plugin)return 1;
        Window window(*plugin,false);auto*editor=dynamic_cast<juce::AudioProcessorEditor*>(window.getContentComponent());
        const auto*display=juce::Desktop::getInstance().getDisplays().getPrimaryDisplay();if(!editor||!display)return 1;
        const auto area=display->userArea;
        // A vendor may grow its editor after construction (e.g. its browser opens).
        // Simulate that while the old window is near the lower-right screen edge.
        for(auto size:{juce::Point<int>(400,300),juce::Point<int>(640,480)}){
            window.setTopLeftPosition(area.getRight()-120,area.getBottom()-80);
            editor->setSize(size.x,size.y);
            if(editor->getWidth()!=size.x||editor->getHeight()!=size.y)return 1;
            if(window.getWidth()<=area.getWidth()&&window.getHeight()<=area.getHeight()&&!area.contains(window.getBounds()))return 1;
        }
        return 0;
    }catch(...){return 1;}
}
class Session final:public juce::Component,private juce::Thread {
public:
    Session(juce::NamedPipe&channel,juce::String id,juce::String secret):juce::Thread("VST control pipe"),pipe(channel),instanceId(std::move(id)),token(std::move(secret)){startThread();}
    ~Session()override{signalThreadShouldExit();ready.signal();pipe.close();stopThread(-1);unload();}
private:
    static void require(bool condition,const char*why){if(!condition)throw std::runtime_error(why);}
    void unload(){
#if JUCE_WINDOWS
stream.reset();std::memset(heldNotes,0,sizeof(heldNotes));
#endif
ccMap=juce::var();editorPosition=juce::var();for(auto&position:effectPositions)position=juce::var();window.reset();for(auto&editor:effectWindows)editor.reset();effects.clear();if(plugin&&resourcesPrepared)plugin->releaseResources();resourcesPrepared=false;plugin.reset();phase=ipc::Phase::empty;}
    juce::var capabilities(bool includeParameters=true){auto*o=new juce::DynamicObject;o->setProperty("protocol",ipc::version);o->setProperty("control_transport","bounded-local-pipe");o->setProperty("realtime_audio",false);o->setProperty("shared_memory_supported",false);o->setProperty("scope","Persistent VST control and optional Windows shared-memory audio");
#if JUCE_WINDOWS
 o->setProperty("process_id",juce::int64(GetCurrentProcessId()));o->setProperty("shared_memory_supported",true);o->setProperty("realtime_audio",stream!=nullptr);if(stream)o->setProperty("audio_diagnostics",stream->diagnostics());
#endif
o->setProperty("state",plugin!=nullptr);o->setProperty("native_gui",plugin&&plugin->hasEditor());o->setProperty("parameter_gui",plugin!=nullptr);o->setProperty("non_realtime",plugin&&plugin->isNonRealtime());o->setProperty("sample_rate",sampleRate);o->setProperty("block_size",blockSize);if(plugin){o->setProperty("routing",hostRoutingCapabilities(*plugin));if(includeParameters)o->setProperty("parameters",parameterCapabilities(*plugin,description));o->setProperty("plugin_latency_samples",plugin->getLatencySamples());int pipeline=0;
#if JUCE_WINDOWS
 if(stream)pipeline=int(audioipc::pipelineBlocks)*blockSize;
#endif
 o->setProperty("pipeline_latency_samples",pipeline);o->setProperty("latency_samples",plugin->getLatencySamples()+effects.latency()+pipeline);o->setProperty("effect_latency_samples",effects.latency());o->setProperty("active_effects",effects.activeCount());auto tail=plugin->getTailLengthSeconds();o->setProperty("tail_seconds",std::min(600.,effects.tailSeconds()+(std::isfinite(tail)&&tail>=0?tail:600.)));o->setProperty("midi_input",plugin->acceptsMidi());o->setProperty("name",description.name);o->setProperty("version",description.version);o->setProperty("uid",description.createIdentifierString());o->setProperty("class_id",classId);}return o;}
    void restore(const juce::var&state){require(state.isObject(),"Invalid instrument state");require(validNativeEditorPosition(state["editor_position"]),"Invalid native editor position");if(state.hasProperty("uid"))require(state["uid"].toString()==description.createIdentifierString(),"State belongs to another instrument");if(state.hasProperty("class_id"))require(state["class_id"].toString().equalsIgnoreCase(classId),"State class identity mismatch");if(state.hasProperty("plugin_version"))require(state["plugin_version"].toString()==description.version,"State version mismatch");auto encoded=state["state"].toString();require(encoded.length()<=24*1024*1024,"State exceeds size limit");juce::MemoryBlock bytes;require(state["state"].isString()&&(encoded.isEmpty()||bytes.fromBase64Encoding(encoded))&&bytes.getSize()<=16*1024*1024&&juce::SHA256(bytes).toHexString()==state["sha256"].toString(),"Invalid state checksum");plugin->setStateInformation(bytes.getData(),int(bytes.getSize()));require(supportedMainBuses(*plugin,false),"Restored instrument has unsupported main bus layout");editorPosition=state["editor_position"].clone();if(window)window->restorePosition(editorPosition);}
    juce::var snapshot(){juce::MemoryBlock bytes;plugin->getStateInformation(bytes);require(bytes.getSize()<=16*1024*1024,"State exceeds size limit");auto*o=new juce::DynamicObject;o->setProperty("schema",1);if(window)editorPosition=window->position();if(!editorPosition.isVoid())o->setProperty("editor_position",editorPosition.clone());if(!ccMap.isVoid())o->setProperty("cc_parameter_map",ccMap.clone());o->setProperty("path",description.fileOrIdentifier);o->setProperty("uid",description.createIdentifierString());o->setProperty("name",description.name);o->setProperty("xml",description.createXml()->toString());o->setProperty("class_id",classId);o->setProperty("plugin_version",description.version);o->setProperty("state",bytes.toBase64Encoding());o->setProperty("sha256",juce::SHA256(bytes).toHexString());return o;}
    void create(const juce::var&config,const juce::var&chain){
        require(validNativeEditorPosition(config["editor_position"]),"Invalid native editor position");if(chain.isArray())for(const auto&effect:*chain.getArray())require(validNativeEditorPosition(effect["editor_position"]),"Invalid effect editor position");require(config.isObject()&&config["path"].isString()&&juce::File::isAbsolutePath(config["path"].toString()),"Absolute plugin path required");auto path=config["path"].toString();require(juce::File(path).exists(),"Instrument is missing; saved MIDI/state remain available");juce::OwnedArray<juce::PluginDescription>found;format.findAllTypesForFile(found,path);juce::PluginDescription*selected=nullptr;auto uid=config["uid"].toString();for(auto*d:found)if(d->isInstrument&&(uid.isEmpty()||d->createIdentifierString()==uid)){require(selected==nullptr,"Module contains multiple instrument classes; choose an explicit UID");selected=d;}require(selected!=nullptr,"Instrument class was not found");auto cid=pluginClassIdentity(juce::File(path),*selected);if(config.hasProperty("class_id"))require(cid.equalsIgnoreCase(config["class_id"].toString()),"Saved class identity mismatch");juce::String error;auto loaded=format.createInstanceFromDescription(*selected,sampleRate,blockSize,error);if(!loaded)throw std::runtime_error(("Cannot instantiate instrument: "+error).toStdString());
        require(configureInstrumentOutputs(*loaded),"Cannot route instrument main output");
        description=*selected;classId=cid;plugin=std::move(loaded);try{if(config.hasProperty("state"))restore(config);require(supportedMainBuses(*plugin,false),"State changed the supported main bus layout");}catch(...){unload();throw;}std::vector<CCParameterBinding> bindings;auto valid=readCCParameterMap(config["cc_parameter_map"],bindings);require(valid.wasOk(),"Invalid MIDI CC parameter bindings");ccMap=config["cc_parameter_map"].clone();effects.load(chain,format,sampleRate,blockSize);editorPosition=config["editor_position"].clone();for(int i=0;i<chain.size()&&i<8;++i)effectPositions[size_t(i)]=chain[i]["editor_position"].clone();phase=ipc::Phase::created;
    }
    juce::var readSnapshot(){
#if JUCE_WINDOWS
 struct Pause {AudioStream*stream;bool resume;explicit Pause(AudioStream*p):stream(p),resume(p&&p->running()){if(stream)stream->pause();}~Pause(){if(resume)stream->resume();}}pause(stream.get());
#endif
 auto*o=new juce::DynamicObject;juce::var result(o);o->setProperty("instrument",snapshot());auto effectStates=effects.snapshot();for(int i=0;i<effectStates.size()&&i<8;++i){if(effectWindows[size_t(i)])effectPositions[size_t(i)]=effectWindows[size_t(i)]->position();if(!effectPositions[size_t(i)].isVoid())effectStates[i].getDynamicObject()->setProperty("editor_position",effectPositions[size_t(i)].clone());}o->setProperty("effects",effectStates);require(juce::JSON::toString(result,true).getNumBytesAsUTF8()<ipc::maxMessageBytes-4096,"Combined instrument/effect snapshot exceeds IPC size budget");return result;
 }
    juce::var perform(const ipc::Request&request){
        auto operation=request.operation;if(operation=="HELLO"||operation=="CAPS")return capabilities(operation=="CAPS");
        if(operation=="CREATE"){create(request.payload["instrument"],request.payload["effects"]);return capabilities(false);}
        if(operation=="PREPARE"){auto rate=request.payload["sample_rate"],block=request.payload["block_size"];require((rate.isDouble()||ipc::integer(rate))&&ipc::integer(block),"Audio format must be numeric");double nextRate=double(rate);int nextBlock=int(block);require((nextRate==44100||nextRate==48000||nextRate==96000)&&(nextBlock==64||nextBlock==128||nextBlock==256||nextBlock==512||nextBlock==1024),"Unsupported sample rate or block size");require(!request.payload.hasProperty("non_realtime")||request.payload["non_realtime"].isBool(),"Invalid offline processing mode");bool nonRealtime=bool(request.payload["non_realtime"]);bool suspended=phase==ipc::Phase::suspended;
#if JUCE_WINDOWS
 stream.reset();
#endif
 if(!resourcesPrepared||sampleRate!=nextRate||blockSize!=nextBlock||plugin->isNonRealtime()!=nonRealtime){if(resourcesPrepared){effects.release();plugin->releaseResources();resourcesPrepared=false;}sampleRate=nextRate;blockSize=nextBlock;plugin->setNonRealtime(nonRealtime);plugin->setRateAndBufferSizeDetails(sampleRate,blockSize);plugin->prepareToPlay(sampleRate,blockSize);resourcesPrepared=true;effects.prepare(sampleRate,blockSize,nonRealtime);}require(supportedMainBuses(*plugin,false),"Prepared instrument has unsupported main bus layout");plugin->suspendProcessing(suspended);phase=suspended?ipc::Phase::suspended:ipc::Phase::prepared;require(plugin->getLatencySamples()>=0&&plugin->getLatencySamples()+effects.latency()<=int(sampleRate*60),"Invalid instrument latency");
#if JUCE_WINDOWS
 if(request.payload.hasProperty("mapping_name")){require(request.payload["mapping_name"].isString(),"Invalid mapping name");stream=std::make_unique<AudioStream>(*plugin,request.payload["mapping_name"].toString(),sampleRate,blockSize,heldNotes,effects,ccMap);if(!suspended)stream->resume();}
#endif
 return capabilities(false);}
        if(operation=="SUSPEND"){
#if JUCE_WINDOWS
 if(stream)stream->pause();
#endif
 plugin->suspendProcessing(true);phase=ipc::Phase::suspended;return capabilities(false);}
        if(operation=="RESUME"){require(resourcesPrepared,"Prepare before resume");require(supportedMainBuses(*plugin,false),"Cannot resume instrument with unsupported main bus layout");plugin->suspendProcessing(false);phase=ipc::Phase::prepared;
#if JUCE_WINDOWS
 if(stream)stream->resume();
#endif
 return capabilities(false);}
        if(operation=="GET_STATE")return readSnapshot();
        if(operation=="SET_STATE"){require(!request.payload.hasProperty("effects"),"Restore effect chains through CREATE");require(juce::JSON::toString(request.payload["instrument"]["cc_parameter_map"])==juce::JSON::toString(ccMap),"Restore changed MIDI bindings through CREATE");restore(request.payload["instrument"]);return capabilities(false);}
        if(operation=="GUI_OPEN"||operation=="GUI_CLOSE"){
            auto*target=plugin.get();auto*editor=&window;auto*position=&editorPosition;
            if(request.payload.hasProperty("effect_index")){auto index=request.payload["effect_index"];require(ipc::integer(index)&&int(index)>=0&&int(index)<8,"Invalid effect editor index");target=effects.at(int(index));require(target!=nullptr,"Effect is absent or bypassed; restart with an active effect before opening it");editor=&effectWindows[size_t(int(index))];position=&effectPositions[size_t(int(index))];}
            if(operation=="GUI_CLOSE"){if(*editor)*position=(*editor)->position();editor->reset();return capabilities(false);}
            require(!request.payload.hasProperty("visible")||request.payload["visible"].isBool(),"Invalid GUI visibility");bool visible=!request.payload.hasProperty("visible")||bool(request.payload["visible"]);if(!*editor)*editor=std::make_unique<Window>(*target,visible,*position);else{(*editor)->restorePosition((*editor)->position());(*editor)->setVisible(visible);}return capabilities(false);
        }
        if(operation=="CLOSE"){unload();phase=ipc::Phase::closed;return juce::var(new juce::DynamicObject);}
        throw std::runtime_error("Audio/MIDI transport is not enabled in this control-only worker");
    }
    void handle(juce::var value){
        ipc::Request request;auto error=ipc::decodeRequest(value,instanceId,token,juce::Time::currentTimeMillis(),request);juce::var payload;
        if(!error){if(std::find(recent.begin(),recent.end(),request.id)!=recent.end())error={"E_DUPLICATE","Request ID was already processed"};else{recent.push_back(request.id);if(recent.size()>128)recent.pop_front();error=ipc::allowed(phase,request.operation);}}
        if(!error){try{if(request.operation=="PROCESS"||request.operation=="MIDI")error={"E_UNSUPPORTED","Audio and MIDI packets use shared memory, not the control pipe"};else payload=perform(request);}catch(const std::exception&e){error={"E_PLUGIN",juce::String::fromUTF8(e.what())};}catch(...){error={"E_PLUGIN","Instrument raised an unknown exception"};}}
        {std::lock_guard<std::mutex>lock(mutex);response=ipc::reply(value,instanceId,error,payload);closing=request.operation=="CLOSE"&&!error;}ready.signal();
    }
    void run()override{
        while(!threadShouldExit()){
            juce::var value;auto error=ipc::readFrame(pipe,value,-1);if(error)break;
            ready.reset();juce::Component::SafePointer<Session>safe(this);juce::MessageManager::callAsync([safe,value]{if(safe)safe->handle(value);});
            while(!threadShouldExit()&&!ready.wait(100)){}if(threadShouldExit())break;
            juce::var next;bool stop=false;{std::lock_guard<std::mutex>lock(mutex);next=response;stop=closing;}
            if(ipc::writeFrame(pipe,next,5000)||stop)break;
        }
        juce::MessageManager::callAsync([]{juce::MessageManager::getInstance()->stopDispatchLoop();});
    }
#if JUCE_WINDOWS
    std::unique_ptr<AudioStream>stream;bool heldNotes[16][128]{};
#endif
    LiveEffects effects;juce::var ccMap,editorPosition;std::array<juce::var,8>effectPositions;
    std::array<std::unique_ptr<Window>,8>effectWindows;
    juce::NamedPipe&pipe;juce::String instanceId,token,classId;atlas::hosting::HostFormats format;juce::PluginDescription description;std::unique_ptr<juce::AudioPluginInstance>plugin;std::unique_ptr<Window>window;ipc::Phase phase=ipc::Phase::empty;double sampleRate=44100;int blockSize=256;bool resourcesPrepared=false,closing=false;std::deque<juce::String>recent;std::mutex mutex;juce::var response;juce::WaitableEvent ready;
};
inline int run(const juce::String&pipeName,const juce::String&instance,const juce::String&token){if(!ipc::identifier(instance)||!ipc::identifier(token)||!pipeName.startsWith("DrumAtlas-control-"))return 2;juce::ScopedJuceInitialiser_GUI gui;juce::NamedPipe pipe;if(!pipe.openExisting(pipeName))return 3;Session session(pipe,instance,token);juce::MessageManager::getInstance()->runDispatchLoop();return 0;}
}
