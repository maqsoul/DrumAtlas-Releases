#pragma once
#include <juce_audio_processors/juce_audio_processors.h>
#include <array>
#include <cstdint>
#include <stdexcept>
#include <vector>

namespace atlas::hosting {
// Some processors use 128-bit SIMD loads directly on the host's channel pointers.
// A JUCE AudioBuffer and views beginning at a MIDI event need only be float-aligned.
class AlignedPluginBlock {
public:
    AlignedPluginBlock(int channels, int frames) { prepare(channels, frames); }

    void prepare(int channels, int frames) {
        if (channels < 1 || channels > 64 || frames < 1 || frames > 65536)
            throw std::runtime_error("Invalid plugin block capacity");
        maxChannels = channels;
        stride = (frames + 3) & ~3;
        storage.resize(size_t(channels) * stride + 3);
    }

    void process(juce::AudioPluginInstance& plugin, juce::AudioBuffer<float>& audio, juce::MidiBuffer& midi) {
        const int channels = audio.getNumChannels(), frames = audio.getNumSamples();
        const int nativeChannels = std::max({channels, plugin.getTotalNumInputChannels(), plugin.getTotalNumOutputChannels()});
        if (nativeChannels > maxChannels || frames > stride)
            throw std::runtime_error("Plugin block exceeds prepared capacity");
        bool aligned = (frames % 4 == 0 && channels == nativeChannels);
        for (int ch = 0; ch < channels && aligned; ++ch)
            aligned = (reinterpret_cast<std::uintptr_t>(audio.getReadPointer(ch)) % 16 == 0);
        if (aligned) { plugin.processBlock(audio, midi); return; }

        float* base = storage.data();
        base += ((16 - reinterpret_cast<std::uintptr_t>(base) % 16) % 16) / sizeof(float);
        std::array<float*, 64> planes{};
        for (int ch = 0; ch < nativeChannels; ++ch) {
            planes[ch] = base + ch * stride;
            if (ch < channels) std::copy_n(audio.getReadPointer(ch), frames, planes[ch]);
            else std::fill_n(planes[ch], frames, 0.f);
            std::fill_n(planes[ch] + frames, (4 - frames % 4) % 4, 0.f);
        }
        juce::AudioBuffer<float> view(planes.data(), nativeChannels, frames);
        plugin.processBlock(view, midi);
        for (int ch = 0; ch < channels; ++ch)
            std::copy_n(planes[ch], frames, audio.getWritePointer(ch));
    }
private:
    int stride=0, maxChannels=0;
    std::vector<float> storage;
};
}
