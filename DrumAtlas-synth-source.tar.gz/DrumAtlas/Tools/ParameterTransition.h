#pragma once
#include "ParameterCapabilities.h"
#include "../Source/MidiParameterMap.h"
namespace atlas::hosting {
// Rendered audition only. Original track/state remains untouched. Continuous
// public values move linearly with <=4 samples between updates; discrete values
// switch once at the end. Timing is in source frames, before PDC compensation.
class ParameterTransition {
public:
 ParameterTransition(juce::AudioPluginInstance& plugin,const juce::var& spec,
                     const juce::String& version,const juce::var& ccMap,double rate,double seconds):instance(plugin){
  if(spec.isVoid())return;
  auto fail=[](bool ok,const char*why){if(!ok)throw std::runtime_error(why);};
  fail(spec.isObject()&&spec["plugin_version"].isString()&&spec["plugin_version"].toString()==version,"Transition plugin version changed; prepare the edit again");
  auto numeric=[](const juce::var&v){return v.isInt()||v.isInt64()||v.isDouble();};
  fail(numeric(spec["start_seconds"])&&numeric(spec["duration_seconds"]),"Invalid transition timing");
  double start=double(spec["start_seconds"]),duration=double(spec["duration_seconds"]);
  fail(std::isfinite(start)&&std::isfinite(duration)&&start>=0&&duration>=.02&&duration<=10&&start+duration<=seconds,"Transition must fit inside the MIDI phrase (20 ms to 10 s)");
  auto* edits=spec["edits"].getArray();fail(edits&&!edits->isEmpty()&&edits->size()<=64,"Transition needs 1..64 public parameter edits");
  for(const auto&edit:*edits)fail(edit["id"].isString()&&edit["expected_name"].isString(),"Transition requires verified public ID and name");
  auto resolved=resolveParameterEdits(plugin,spec["edits"]);
  std::vector<CCParameterBinding> bindings;auto valid=readCCParameterMap(ccMap,bindings);fail(valid.wasOk(),"Invalid MIDI CC mapping");
  for(const auto&edit:resolved){for(const auto&binding:bindings)fail(binding.parameter!=parameterId(*edit.first),"Transition parameter also has a MIDI CC mapping; remove that mapping for this audition");
   float from=edit.first->getValue();fail(std::isfinite(from)&&from>=0&&from<=1,"Invalid transition starting value");
   values.push_back({edit.first,from,edit.second,edit.first->isDiscrete(),plugin.getParameters().indexOf(edit.first)});}
  first=juce::int64(std::llround(start*rate));last=first+std::max<juce::int64>(1,juce::int64(std::llround(duration*rate)));
 }
 int prepare(juce::int64 offset,int count){
  if(values.empty()||finished)return count;
  for(const auto&value:values)if(value.index<0||value.index>=instance.getParameters().size()||instance.getParameters()[value.index]!=value.parameter)throw std::runtime_error("Transition parameter layout changed; reopen Sound Designer");
  if(offset<first)return int(std::min<juce::int64>(count,first-offset));
  double fraction=std::min(1.,double(offset-first)/double(last-first));
  for(auto&value:values){if(value.discrete&&offset<last)continue;value.parameter->setValueNotifyingHost(value.discrete?value.to:float(value.from+(value.to-value.from)*fraction));}
  if(offset>=last){finished=true;return count;}
  return int(std::min<juce::int64>(std::min(count,4),last-offset));
 }
 bool active()const{return !values.empty();}
private:
 struct Value{juce::AudioProcessorParameter*parameter;float from,to;bool discrete;int index;};
 juce::AudioPluginInstance&instance;std::vector<Value>values;juce::int64 first=0,last=0;bool finished=false;
};
}
