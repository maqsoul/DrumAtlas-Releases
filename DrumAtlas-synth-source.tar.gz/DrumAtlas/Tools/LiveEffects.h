#pragma once
#include "AlignedPluginBlock.h"
#include "HostFormats.h"
#include "HostRouting.h"
#include <juce_cryptography/juce_cryptography.h>
namespace atlas::hosting::service {
class LiveEffects {
public:
    LiveEffects(){messages.ensureSize(65536);}
    ~LiveEffects(){clear();}
    void clear(){release();items.clear();original=juce::var();}
    void load(const juce::var&chain,atlas::hosting::HostFormats&format,double rate,int block){
        clear();if(chain.isVoid())return;require(chain.isArray()&&chain.size()<=8,"Invalid live effect chain");original=chain.clone();
        for(int index=0;index<chain.size();++index){const auto&config=chain[index];require(config.isObject()&&config["effect"].isBool()&&bool(config["effect"]),"Invalid live effect descriptor");require(!config.hasProperty("bypass")||config["bypass"].isBool(),"Invalid live effect bypass");if(bool(config["bypass"]))continue;
            auto path=config["path"].toString();require(juce::File::isAbsolutePath(path)&&juce::File(path).exists(),"Live effect is missing");juce::OwnedArray<juce::PluginDescription>found;format.findAllTypesForFile(found,path);juce::PluginDescription*selected=nullptr;for(auto*d:found)if(!d->isInstrument&&d->createIdentifierString()==config["uid"].toString())selected=d;require(selected!=nullptr,"Live effect class not found");
            auto cid=pluginClassIdentity(juce::File(path),*selected);if(config.hasProperty("class_id"))require(cid.equalsIgnoreCase(config["class_id"].toString()),"Live effect class identity mismatch");if(config.hasProperty("plugin_version"))require(config["plugin_version"].toString()==selected->version,"Live effect version mismatch");
            juce::String error;auto plugin=format.createInstanceFromDescription(*selected,rate,block,error);require(bool(plugin),"Cannot instantiate live effect: "+error);auto layout=plugin->getBusesLayout();for(auto&bus:layout.inputBuses)bus=juce::AudioChannelSet::disabled();for(auto&bus:layout.outputBuses)bus=juce::AudioChannelSet::disabled();require(!layout.inputBuses.isEmpty()&&!layout.outputBuses.isEmpty(),"Effect needs audio input and output");layout.inputBuses.getReference(0)=layout.outputBuses.getReference(0)=juce::AudioChannelSet::stereo();if(!plugin->setBusesLayout(layout)){layout.inputBuses.getReference(0)=layout.outputBuses.getReference(0)=juce::AudioChannelSet::mono();require(plugin->setBusesLayout(layout),"Effect needs unsupported bus layout");}
            auto encoded=config["state"].toString();juce::MemoryBlock state;require(config["state"].isString()&&encoded.length()<=24*1024*1024&&(encoded.isEmpty()||state.fromBase64Encoding(encoded))&&state.getSize()<=16*1024*1024&&juce::SHA256(state).toHexString()==config["sha256"].toString(),"Invalid live effect state checksum");if(state.getSize())plugin->setStateInformation(state.getData(),int(state.getSize()));require(layoutValid(*plugin),"Effect state changed supported layout");items.push_back({index,*selected,cid,std::move(plugin),false,0});
        }
    }
    void prepare(double rate,int block,bool nonRealtime=false){hostBlock.prepare(2,block);totalLatency=0;tail=0;for(auto&item:items){auto&p=*item.plugin;p.setNonRealtime(nonRealtime);p.setRateAndBufferSizeDetails(rate,block);item.prepared=true;p.prepareToPlay(rate,block);require(layoutValid(p),"Prepared effect has unsupported layout");item.latency=p.getLatencySamples();require(item.latency>=0&&item.latency<=int(rate*60),"Invalid live effect latency");totalLatency+=item.latency;require(totalLatency<=int(rate*60),"Live effect latency budget exceeded");auto seconds=p.getTailLengthSeconds();require(!std::isnan(seconds)&&seconds>=0,"Invalid live effect tail");tail=std::min(600.,tail+(std::isfinite(seconds)?seconds:600.));}}
    void release(){for(auto&item:items)if(item.prepared){item.plugin->releaseResources();item.prepared=false;}totalLatency=0;tail=0;}
    void setPlayHead(juce::AudioPlayHead*head){for(auto&item:items)item.plugin->setPlayHead(head);}
    void process(juce::AudioBuffer<float>&audio,const juce::MidiBuffer&midi){for(auto&item:items){auto&p=*item.plugin;const juce::ScopedLock lock(p.getCallbackLock());require(layoutValid(p),"Live effect bus layout changed; restart with supported main buses");if(p.getTotalNumInputChannels()==1){audio.addFrom(0,0,audio,1,0,audio.getNumSamples());audio.applyGain(0,0,audio.getNumSamples(),.5f);}messages.clear();messages.addEvents(midi,0,audio.getNumSamples(),0);hostBlock.process(p,audio,messages);require(p.getLatencySamples()==item.latency,"Live effect latency changed; save the sound and restart");if(p.getTotalNumOutputChannels()==1)audio.copyFrom(1,0,audio,0,0,audio.getNumSamples());}}
    juce::var snapshot(){auto result=original.clone();for(auto&item:items){juce::MemoryBlock state;item.plugin->getStateInformation(state);require(state.getSize()<=16*1024*1024,"Effect snapshot exceeds limit");auto*o=result[item.index].getDynamicObject();o->setProperty("state",state.toBase64Encoding());o->setProperty("sha256",juce::SHA256(state).toHexString());o->setProperty("plugin_version",item.description.version);o->setProperty("class_id",item.cid);o->setProperty("xml",item.description.createXml()->toString());}return result;}
    int latency()const{return totalLatency;}
    double tailSeconds()const{return tail;}
    int activeCount()const{return int(items.size());}
    juce::AudioPluginInstance* at(int index){for(auto&item:items)if(item.index==index)return item.plugin.get();return nullptr;}
private:
    static void require(bool condition,const juce::String&message){if(!condition)throw std::runtime_error(message.toStdString());}
    static bool layoutValid(juce::AudioPluginInstance&p){return supportedMainBuses(p,true);}
    struct Item{int index;juce::PluginDescription description;juce::String cid;std::unique_ptr<juce::AudioPluginInstance>plugin;bool prepared;int latency;};
    AlignedPluginBlock hostBlock{2,1};std::vector<Item>items;juce::var original;juce::MidiBuffer messages;int totalLatency=0;double tail=0;
};
}
