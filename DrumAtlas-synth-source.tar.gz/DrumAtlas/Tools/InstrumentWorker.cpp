// Standalone scanner: third-party modules never load in the DAW process.
#include <juce_audio_processors/juce_audio_processors.h>
#include <iostream>
#include <cstdlib>
#include <cmath>
#include "InstrumentOffline.h"
#include "HostFormats.h"
#include "InstrumentSession.h"
static int workerMain(int argc,char**argv){
#if JUCE_WINDOWS
    // A failed DLL/VST load must return an error to the isolated scanner, not
    // leave a system-modal "Bad Image" dialog waiting on the user's desktop.
    SetErrorMode(GetErrorMode() | SEM_FAILCRITICALERRORS | SEM_NOOPENFILEERRORBOX);
#endif
    if(argc==3&&juce::String(argv[1])=="--test-configure-resize"){juce::ScopedJuceInitialiser_GUI gui;auto fixture=juce::File(juce::String::fromUTF8(argv[2]));if(offline::testConfigureResize(fixture)!=0)return 1;return atlas::hosting::service::testWindowResize(fixture);}
    if(argc==5&&juce::String(argv[1])=="--serve")return atlas::hosting::service::run(juce::String::fromUTF8(argv[2]),juce::String::fromUTF8(argv[3]),juce::String::fromUTF8(argv[4]));
    if(argc==2&&juce::String(argv[1])=="--test-crash")std::_Exit(66);
    if(argc==2&&juce::String(argv[1])=="--test-hang"){for(;;)juce::Thread::sleep(1000);}
    if(argc==5&&(juce::String(argv[1])=="--render"||juce::String(argv[1])=="--configure"||juce::String(argv[1])=="--capture")){
        juce::ScopedJuceInitialiser_GUI gui;
        return offline::run(juce::File(juce::String::fromUTF8(argv[2])),juce::File(juce::String::fromUTF8(argv[3])),juce::String::fromUTF8(argv[4]),juce::String(argv[1])=="--configure",juce::String(argv[1])=="--capture");
    }
    if((argc!=5&&argc!=6)||(juce::String(argv[1])!="--scan"&&juce::String(argv[1])!="--probe")||(argc==6&&juce::String(argv[1])!="--probe"))return 2;
    const bool probe=juce::String(argv[1])=="--probe";
    juce::ScopedJuceInitialiser_GUI gui;
    const auto path=juce::String::fromUTF8(argv[2]),request=juce::String::fromUTF8(argv[4]);
    auto*result=new juce::DynamicObject();juce::var root(result);result->setProperty("protocol",1);result->setProperty("request_id",request);result->setProperty("operation",probe?"PROBE":"SCAN");result->setProperty("status","error");
    try {
        if(!juce::File::isAbsolutePath(path))throw std::runtime_error("Absolute plugin path required");
        atlas::hosting::HostFormats format;juce::OwnedArray<juce::PluginDescription> descriptions;format.findAllTypesForFile(descriptions,path);

#if JUCE_WINDOWS
        std::vector<atlas::hosting::FactoryClass> classes;
        if(!descriptions.isEmpty()&&descriptions[0]->pluginFormatName=="VST3")
            classes=atlas::hosting::factoryClasses(juce::File(path));
#endif
        juce::Array<juce::var> plugins;
        for(auto*d:descriptions){auto*v=new juce::DynamicObject();v->setProperty("uid",d->createIdentifierString());v->setProperty("name",d->name);v->setProperty("vendor",d->manufacturerName);v->setProperty("version",d->version);v->setProperty("category",d->category);v->setProperty("instrument",d->isInstrument);v->setProperty("inputs",d->numInputChannels);v->setProperty("outputs",d->numOutputChannels);v->setProperty("path",d->fileOrIdentifier);v->setProperty("description_xml",d->createXml()->toString());v->setProperty("compatibility","Untested");v->setProperty("editor_capability","unknown_until_probe");
#if JUCE_WINDOWS
        v->setProperty("architecture",sizeof(void*)==4?"x86":"x86_64");v->setProperty("format",d->pluginFormatName);v->setProperty("class_id",d->pluginFormatName=="VST3"?atlas::hosting::classIdentity(classes,*d):atlas::hosting::pluginClassIdentity(juce::File(path),*d));
#else
        v->setProperty("architecture","unverified");v->setProperty("class_id","");
#endif
        plugins.add(v);}
        result->setProperty("plugins",plugins);result->setProperty("status",plugins.isEmpty()?"not_found":"scanned");
        if(probe){
            juce::PluginDescription*description=nullptr;auto selectedUid=argc==6?juce::String::fromUTF8(argv[5]):juce::String();for(auto*d:descriptions)if(selectedUid.isNotEmpty()?d->createIdentifierString()==selectedUid:d->isInstrument){description=d;break;}if(!description&&selectedUid.isEmpty()&&!descriptions.isEmpty())description=descriptions[0];if(!description)throw std::runtime_error("No plugin class in this module");
            juce::String error;auto instance=format.createInstanceFromDescription(*description,44100,256,error);if(!instance)throw std::runtime_error(error.toStdString());
            instance->setRateAndBufferSizeDetails(44100,256);instance->prepareToPlay(44100,256);struct ReleasePrepared{juce::AudioPluginInstance&instance;~ReleasePrepared(){instance.releaseResources();}}releasePrepared{*instance};const int channels=std::max({2,instance->getTotalNumInputChannels(),instance->getTotalNumOutputChannels()});if(channels>64)throw std::runtime_error("Probe channel limit exceeded");
            atlas::hosting::AlignedPluginBlock hostBlock(channels,256);juce::AudioBuffer<float> audio(channels,256);float peak=0;
            for(int frame=0;frame<88200;frame+=256){audio.clear();juce::MidiBuffer midi;if(frame==0)midi.addEvent(juce::MidiMessage::noteOn(1,60,juce::uint8(90)),0);if(frame<=44100&&frame+256>44100)midi.addEvent(juce::MidiMessage::noteOff(1,60),44100-frame);hostBlock.process(*instance,audio,midi);for(int ch=0;ch<channels;++ch)for(int i=0;i<256;++i){auto sample=audio.getSample(ch,i);if(!std::isfinite(sample))throw std::runtime_error("Non-finite instrument output");peak=std::max(peak,std::abs(sample));}}
            if(instance->getLatencySamples()<0||!std::isfinite(instance->getTailLengthSeconds())||instance->getTailLengthSeconds()<0)throw std::runtime_error("Invalid reported latency or tail");
            juce::MemoryBlock state;instance->getStateInformation(state);if(state.getSize()>32*1024*1024)throw std::runtime_error("Probe state limit exceeded");instance->setStateInformation(state.getData(),int(state.getSize()));
            result->setProperty("probe_name",description->name);result->setProperty("sample_rate",44100);result->setProperty("block_size",256);result->setProperty("peak",peak);result->setProperty("state_bytes",juce::int64(state.getSize()));result->setProperty("latency_samples",instance->getLatencySamples());result->setProperty("has_editor",instance->hasEditor());result->setProperty("probe_uid",description->createIdentifierString());result->setProperty("parameter_count",instance->getParameters().size());result->setProperty("tail_seconds",instance->getTailLengthSeconds());for(auto&plugin:plugins)if(plugin["uid"].toString()==description->createIdentifierString()){auto*o=plugin.getDynamicObject();o->setProperty("editor_capability",instance->hasEditor()?"available":"parameter_editor");o->setProperty("parameter_count",instance->getParameters().size());o->setProperty("latency_samples",instance->getLatencySamples());o->setProperty("tail_seconds",instance->getTailLengthSeconds());o->setProperty("probe_status",peak>0?"audio_verified":"silent");}result->setProperty("status",peak>0?"probed":"silent");result->setProperty("scope","Standalone MIDI/audio/state only; GUI, DAW integration and realtime IPC untested");
        }
    }catch(const std::exception&e){result->setProperty("status","error");result->setProperty("error",juce::String::fromUTF8(e.what()));}
    juce::File output(juce::String::fromUTF8(argv[3]));return output.replaceWithText(juce::JSON::toString(root))?0:3;
}

#if JUCE_WINDOWS
int wmain(int argc,wchar_t**argv){
    std::vector<std::string> storage;storage.reserve(size_t(argc));
    for(int i=0;i<argc;++i)storage.push_back(juce::String(argv[i]).toStdString());
    std::vector<char*> utf8;for(auto&arg:storage)utf8.push_back(arg.data());
    return workerMain(argc,utf8.data());
}
#else
int main(int argc,char**argv){return workerMain(argc,argv);}
#endif
