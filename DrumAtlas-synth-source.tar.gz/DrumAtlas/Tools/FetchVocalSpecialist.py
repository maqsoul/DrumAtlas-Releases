"""Fetch a pinned original FP32 vocals model for local separation testing.

The conversion's model card declares MIT. Check upstream weight terms before
redistributing; this downloader does not grant rights to training data/weights.
"""
import argparse
import hashlib
from pathlib import Path
import urllib.request

REVISION = "2ef0d757d3e226d0da85fb8c71514f464fcabdd0"
NAME = "htdemucs_ft_vocals.onnx"
SHA256 = "8c5d5e2da1f27050240bb80236673307ee3b40d4b064066d9350f4d64bfd544d"
SIZE = 316446953
URL = f"https://huggingface.co/StemSplitio/htdemucs-ft-vocals-onnx/resolve/{REVISION}/{NAME}"


def verified(path):
    if not path.is_file() or path.stat().st_size != SIZE:
        return False
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest() == SHA256


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("model_dir", type=Path)
    args = parser.parse_args()
    args.model_dir.mkdir(parents=True, exist_ok=True)
    target = args.model_dir / NAME
    if verified(target):
        print("Model already verified:", target)
        return
    partial = target.with_suffix(".download")
    with urllib.request.urlopen(URL, timeout=60) as source, partial.open("wb") as output:
        while block := source.read(1024 * 1024):
            output.write(block)
    if not verified(partial):
        raise RuntimeError("Size/SHA-256 verification failed; existing model unchanged")
    partial.replace(target)
    print("Downloaded and verified:", target)


if __name__ == "__main__":
    main()
