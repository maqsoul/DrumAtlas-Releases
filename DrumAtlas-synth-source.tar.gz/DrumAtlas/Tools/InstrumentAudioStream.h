#pragma once
#include "../Source/HostSharedAudio.h"
#include "LiveEffects.h"
#include "MappedCCProcessor.h"
#include "PublicParameterIndex.h"
#include <juce_audio_processors/juce_audio_processors.h>
#if JUCE_WINDOWS
namespace atlas::hosting::service {
class AudioStream final:private juce::Thread {
public:
    AudioStream(juce::AudioPluginInstance&instance,const juce::String&name,double rate,int block,bool (&notes)[16][128],LiveEffects&chain,const juce::var&ccMap={}):juce::Thread("VST shared audio"),plugin(instance),expectedLatency(instance.getLatencySamples()),sampleRate(rate),blockSize(block),buffer(2,block),held(notes),effects(chain),mapped(instance,ccMap,block){auto result=mapping.open(name,rate,uint32_t(block));if(result.failed())throw std::runtime_error(result.getErrorMessage().toStdString());auto indexed=parameterIndex.prepare(plugin.getParameters());if(indexed.failed())throw std::runtime_error(indexed.getErrorMessage().toStdString());midi.ensureSize(65536);mappedMidi.ensureSize(65536);effectMidi.ensureSize(65536);plugin.setPlayHead(&head);effects.setPlayHead(&head);}
    ~AudioStream()override{pause();plugin.setPlayHead(nullptr);effects.setPlayHead(nullptr);}
    void resume(){if(!isThreadRunning())startThread(juce::Thread::Priority::high);}
    void pause(){signalThreadShouldExit();mapping.wake();stopThread(-1);}
    bool running()const{return isThreadRunning();}
    juce::var diagnostics(){auto*o=new juce::DynamicObject;auto*r=mapping.get();o->setProperty("underruns",juce::int64(audioipc::load(r->underruns)));o->setProperty("overruns",juce::int64(audioipc::load(r->overruns)));o->setProperty("invalid_samples",juce::int64(audioipc::load(r->invalidSamples)));o->setProperty("clipped_samples",juce::int64(audioipc::load(r->clippedSamples)));o->setProperty("midi_drops",juce::int64(audioipc::load(r->midiDrops)));o->setProperty("protocol_errors",juce::int64(audioipc::load(r->protocolErrors)));o->setProperty("heartbeat",juce::int64(audioipc::load(r->heartbeat)));o->setProperty("last_block_wall_us",juce::int64(audioipc::load(r->lastBlockMicros)));o->setProperty("peak_block_wall_us",juce::int64(audioipc::load(r->peakBlockMicros)));o->setProperty("over_budget_blocks",juce::int64(audioipc::load(r->overBudgetBlocks)));o->setProperty("timed_blocks",juce::int64(audioipc::load(r->timedBlocks)));return o;}
private:
    struct Head:juce::AudioPlayHead{PositionInfo position;juce::Optional<PositionInfo>getPosition()const override{return position;}}head;
    struct Ramp{juce::AudioProcessorParameter*parameter=nullptr;double start=0,target=0;int begin=0,end=0;};
    void position(const audioipc::Packet&packet,int offset){const auto&t=packet.transport;auto&p=head.position;p.setTimeInSamples(audioipc::advanceHostPosition(t.samplePosition,offset));p.setTimeInSeconds(t.seconds+offset/sampleRate);p.setPpqPosition(t.ppq+offset/sampleRate*t.bpm/60.);p.setBpm(t.bpm);p.setTimeSignature(juce::AudioPlayHead::TimeSignature{int(t.numerator),int(t.denominator)});p.setIsPlaying(t.playing!=0);p.setIsRecording(t.recording!=0);p.setIsLooping(t.looping!=0);p.setLoopPoints(juce::AudioPlayHead::LoopPoints{t.loopStart,t.loopEnd});}
    juce::AudioProcessorParameter*parameter(uint32_t wanted)noexcept{return parameterIndex.find(wanted,plugin.getParameters());}
    bool process(const audioipc::Packet&input,audioipc::Packet&output){
        const juce::ScopedLock callbackLock(plugin.getCallbackLock());std::array<juce::AudioProcessorParameter*,audioipc::maxAutomation>eventParameters{};
        auto*r=mapping.get();output={};output.blockId=input.blockId;output.epoch=input.epoch;output.frames=uint32_t(blockSize);output.transport=input.transport;
        if(!audioipc::valid(input,uint32_t(blockSize))||input.frames!=uint32_t(blockSize)){audioipc::increment(r->protocolErrors);return false;}
        for(uint32_t i=0;i<input.automationCount;++i){const auto&e=input.automation[i];eventParameters[i]=parameter(e.parameter);if(!eventParameters[i]||uint32_t(e.offset)+e.rampSamples>input.frames){audioipc::increment(r->protocolErrors);return false;}}
        if(!supportedMainBuses(plugin,false))throw std::runtime_error("Instrument bus layout changed; restart with a supported main output");
        if(plugin.getLatencySamples()!=expectedLatency)throw std::runtime_error("Instrument latency changed; save the sound and restart");
        juce::ScopedNoDenormals denormals;buffer.clear();std::array<bool,audioipc::maxFrames+1>boundaries{};boundaries[0]=boundaries[input.frames]=true;
        for(uint32_t i=0;i<input.automationCount;++i){const auto&e=input.automation[i];boundaries[e.offset]=true;const auto last=e.offset+(e.rampSamples>1?e.rampSamples-1:0);boundaries[last]=true;for(int at=e.offset+4;at<last;at+=4)boundaries[size_t(at)]=true;}
        // JUCE VST3 reset() toggles component activation and can reload sample libraries.
        // Use MIDI note cleanup here; never reinitialise the plugin on the audio thread.
        bool reset=!seen||input.epoch!=lastEpoch||(seen&&input.blockId!=lastBlock+1)||(wasPlaying&&(!input.transport.playing||input.transport.samplePosition!=lastPosition));
        std::array<Ramp,audioipc::maxAutomation>ramps{};int rampCount=0;
        for(uint32_t begin=0;begin<input.frames;){uint32_t end=begin+1;while(end<input.frames&&!boundaries[end])++end;
            for(int i=0;i<rampCount;++i){auto&a=ramps[size_t(i)];if(a.parameter){double fraction=a.end==a.begin?1.:juce::jlimit(0.,1.,double(int(begin)-a.begin)/(a.end-a.begin));a.parameter->setValueNotifyingHost(float(a.start+(a.target-a.start)*fraction));if(int(begin)>=a.end)a.parameter=nullptr;}}
            for(uint32_t i=0;i<input.automationCount;++i){const auto&e=input.automation[i];if(e.offset!=begin)continue;auto*p=eventParameters[i];for(auto&a:ramps)if(a.parameter==p)a.parameter=nullptr;if(e.rampSamples<=1)p->setValueNotifyingHost(e.value);else{int slot=0;while(slot<rampCount&&ramps[size_t(slot)].parameter)++slot;if(slot==rampCount)++rampCount;ramps[size_t(slot)]={p,p->getValue(),e.value,int(begin),int(begin+e.rampSamples-1)};}}
            midi.clear();mappedMidi.clear();if(reset&&begin==0)for(int channel=1;channel<=16;++channel){midi.addEvent(juce::MidiMessage::controllerEvent(channel,64,0),0);midi.addEvent(juce::MidiMessage::allSoundOff(channel),0);midi.addEvent(juce::MidiMessage::allNotesOff(channel),0);for(int note=0;note<128;++note)if(held[channel-1][note]){midi.addEvent(juce::MidiMessage::noteOff(channel,note),0);held[channel-1][note]=false;}}
            for(uint32_t i=0;i<input.midiCount;++i){const auto&e=input.midi[i];if(e.offset>=begin&&e.offset<end){midi.addEvent(juce::MidiMessage(e.data,int(e.size)),int(e.offset-begin));mappedMidi.addEvent(juce::MidiMessage(e.data,int(e.size)),int(e.offset-begin));auto type=e.data[0]&0xf0;auto channel=e.data[0]&15;if(type==0x90||type==0x80)held[channel][e.data[1]]=type==0x90&&e.data[2]>0;else if(type==0xb0&&(e.data[1]==120||e.data[1]==123))for(auto&note:held[channel])note=false;}}
            position(input,int(begin));float*channels[2]{buffer.getWritePointer(0,int(begin)),buffer.getWritePointer(1,int(begin))};juce::AudioBuffer<float>segment(channels,2,int(end-begin));{const juce::ScopedLock lock(plugin.getCallbackLock());effectMidi.clear();effectMidi.addEvents(midi,0,int(end-begin),0);mapped.process(segment,midi,[&](int offset){position(input,int(begin)+offset);},&mappedMidi);if(plugin.getLatencySamples()!=expectedLatency)throw std::runtime_error("Instrument latency changed; save the sound and restart");position(input,int(begin));if(plugin.getMainBusNumOutputChannels()==1)segment.copyFrom(1,0,segment,0,0,segment.getNumSamples());effects.process(segment,effectMidi);}begin=end;
        }
        for(int ch=0;ch<2;++ch)for(uint32_t i=0;i<input.frames;++i){float value=buffer.getSample(ch,int(i));if(!std::isfinite(value)){value=0;audioipc::increment(r->invalidSamples);}else if(std::abs(value)>1){value=juce::jlimit(-1.f,1.f,value);audioipc::increment(r->clippedSamples);}output.audio[ch][i]=value;}
        seen=true;lastEpoch=input.epoch;lastBlock=input.blockId;wasPlaying=input.transport.playing!=0;lastPosition=audioipc::advanceHostPosition(input.transport.samplePosition,int(input.frames));return true;
    }
    void run()override{
        audioipc::Packet input{},output{};auto*r=mapping.get();
        while(!threadShouldExit()){
            if(!audioipc::pop(r->input,input)){mapping.wait(100);continue;}
            if(input.epoch!=audioipc::load(r->epoch))continue;
            audioipc::store(r->processing,1);const auto blockStarted=juce::Time::getMillisecondCounterHiRes();
            try{process(input,output);}catch(...){output={};output.blockId=input.blockId;output.epoch=input.epoch;output.frames=uint32_t(blockSize);audioipc::increment(r->protocolErrors);audioipc::increment(r->pluginFailures);}
            audioipc::recordBlockTime(*r,juce::Time::getMillisecondCounterHiRes()-blockStarted);
            if(!audioipc::push(r->output,output))audioipc::increment(r->overruns);audioipc::increment(r->heartbeat);audioipc::store(r->processing,0);
        }
    }
    juce::AudioPluginInstance&plugin;const int expectedLatency;double sampleRate;int blockSize;audioipc::Mapping mapping;juce::AudioBuffer<float>buffer;juce::MidiBuffer midi,effectMidi,mappedMidi;bool (&held)[16][128];LiveEffects&effects;MappedCCProcessor mapped;PublicParameterIndex parameterIndex;bool seen=false,wasPlaying=false;uint32_t lastEpoch=0;uint64_t lastBlock=0;int64_t lastPosition=0;
};
}
#endif
