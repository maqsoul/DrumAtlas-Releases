#pragma once
#include "AlignedPluginBlock.h"
#include "HostRouting.h"
#include "SerumBass.h"
#include "SoundPresetState.h"
#include <juce_audio_processors/juce_audio_processors.h>
#include <juce_dsp/juce_dsp.h>
#include <array>
#include <vector>
#include <cmath>
#include <stdexcept>

namespace atlas::hosting::autosound {
struct Candidate {int program=-1;juce::File file;juce::String name;double prior=0;int bassRecipe=-1;};
inline int nameScore(const juce::String&name,const juce::String&role,const juce::String&genre){
    auto words=juce::StringArray::fromTokens(name.toLowerCase()," _-./[]()",{});juce::StringArray hints;
    if(role=="Bass")hints={"bass","sub","808","bs","ba"};else if(role=="Chords")hints={"pad","keys","piano","poly","chord","pd","ky"};else if(role=="Melody"||role=="Countermelody")hints={"lead","pluck","bell","keys","ld","pl"};else hints.add(role.toLowerCase());
    int score=0;for(auto&hint:hints)if(words.contains(hint))score+=4;if(name.containsIgnoreCase(genre)&&genre.isNotEmpty())score+=2;return score;
}
inline bool matchesPreset(const juce::File&file,const juce::PluginDescription&description,const juce::String&classId){
    if(file.hasFileExtension("atlaspreset")){juce::MemoryBlock state;return readSoundState(file,description,classId,state);}
    if(file.getSize()<28||file.getSize()>16*1024*1024)return false;juce::FileInputStream in(file);if(!in.openedOk())return false;
    char header[40]{};auto read=in.read(header,40);
    if(file.hasFileExtension("vstpreset"))return description.pluginFormatName=="VST3"&&read==40&&std::memcmp(header,"VST3",4)==0&&juce::String::fromUTF8(header+8,32).equalsIgnoreCase(classId);
    if(description.pluginFormatName!="VST"||read<28||std::memcmp(header,"CcnK",4)!=0)return false;
    auto id=juce::ByteOrder::bigEndianInt(header+16);return id==juce::uint32(description.uniqueId);
}
inline std::vector<Candidate> candidates(juce::AudioPluginInstance&plugin,const juce::PluginDescription&description,const juce::String&classId,const juce::var&request){
    auto role=request["auto_program_role"].toString(),genre=request["sound_genre"].toString();std::vector<Candidate>result{{-1,{},"Current sound",0}};
    for(int i=0;i<std::min(4096,plugin.getNumPrograms());++i){if(i==plugin.getCurrentProgram())continue;auto name=plugin.getProgramName(i);int score=nameScore(name,role,genre);result.push_back({i,{},name.isNotEmpty()?name:"Program "+juce::String(i+1),double(score)});}
    juce::Array<juce::File>roots;auto docs=juce::File::getSpecialLocation(juce::File::userDocumentsDirectory);roots.add(docs.getChildFile("VST3 Presets"));roots.add(docs.getChildFile("VST Presets"));
    if(role=="Bass"&&serumPreset::compatible(description,classId)&&serumPreset::initialSound(plugin)){
        result.push_back({-1,{},"Sub sine / designed",6,0});result.push_back({-1,{},"Sub shape / designed",6,1});result.push_back({-1,{},"Sub + quiet saw / designed",6,2});
    }
    if(role!="Bass"&&bool(request["export_matched_preset"])&&serumPreset::compatible(description,classId)&&serumPreset::initialSound(plugin)){
        result.push_back({-1,{},"Rounded pluck / designed",4,3});result.push_back({-1,{},"Soft pad / designed",4,4});result.push_back({-1,{},"Bright lead / designed",4,5});
    }
   #if JUCE_WINDOWS
    roots.add(juce::File::getSpecialLocation(juce::File::commonApplicationDataDirectory).getChildFile("VST3 Presets"));
   #endif
    if(auto*extra=request["preset_roots"].getArray())for(int i=0;i<std::min(16,extra->size());++i)if(juce::File::isAbsolutePath((*extra)[i].toString()))roots.addIfNotAlreadyThere(juce::File((*extra)[i].toString()));
    int inspected=0;auto deadline=juce::Time::getMillisecondCounterHiRes()+5000;
    for(auto&root:roots){if(!root.isDirectory())continue;for(auto&entry:juce::RangedDirectoryIterator(root,true,"*.vstpreset;*.fxp;*.fxb;*.atlaspreset",juce::File::findFiles)){if(++inspected>10000||juce::Time::getMillisecondCounterHiRes()>deadline)break;auto file=entry.getFile();if(matchesPreset(file,description,classId)){auto name=file.getFileNameWithoutExtension();result.push_back({-1,file,name,double(nameScore(name,role,genre))});}}if(inspected>10000||juce::Time::getMillisecondCounterHiRes()>deadline)break;}
    std::stable_sort(result.begin()+1,result.end(),[](const auto&a,const auto&b){return a.prior>b.prior;});
    // A stem search must not silently stop after the first twelve named sounds.
    // Keep the smaller budget only for the legacy automatic composer operation.
    if(!bool(request["export_matched_preset"])&&result.size()>13)result.resize(13);return result;
}
inline bool load(juce::AudioPluginInstance&plugin,const Candidate&candidate,const juce::PluginDescription& description,const juce::String& identity){
    if(candidate.bassRecipe>=0)return serumPreset::bass(plugin,candidate.bassRecipe);
    if(candidate.file==juce::File()){if(candidate.program>=0)plugin.setCurrentProgram(candidate.program);return true;}
    if(candidate.file.hasFileExtension("atlaspreset")){
        juce::MemoryBlock state;
        // Recheck checksum after discovery in case the file was changed.
        if(!readSoundState(candidate.file,description,identity,state))return false;
        plugin.setStateInformation(state.getData(),int(state.getSize()));return true;
    }
    juce::MemoryBlock bytes;if(!candidate.file.loadFileAsData(bytes))return false;
    if(candidate.file.hasFileExtension("vstpreset")){auto*client=plugin.getVST3Client();return client&&client->setPreset(bytes);}
    auto*client=plugin.getVSTClient();return client&&client->loadFromFXBFile({static_cast<const std::byte*>(bytes.getData()),bytes.getSize()});
}
struct Probe {std::array<double,12>bands{};double peak=0,tail=0;};
inline Probe probe(juce::AudioPluginInstance&plugin,double rate,int block,const juce::String&role,int targetPitch=-1){
    const int channels=std::min(2,plugin.getMainBusNumOutputChannels()),latency=plugin.getLatencySamples();
    if(!supportedMainBuses(plugin,false)||latency<0||latency>int(rate*2))throw std::runtime_error("Preset changed the supported output layout or latency");
    const int count=int(rate*.9),off=int(rate*.5),pitch=targetPitch>=0?juce::jlimit(0,120,targetPitch):(role=="Bass"?36:60);
    std::array<std::vector<float>,2>signal;for(auto&v:signal)v.resize(size_t(count));
    struct AuditionTransport final : juce::AudioPlayHead {
        PositionInfo position;
        juce::Optional<PositionInfo> getPosition() const override { return position; }
    } transport;
    auto* previousHead=plugin.getPlayHead();
    struct RestoreTransport {juce::AudioPluginInstance& instrument;juce::AudioPlayHead* previous;~RestoreTransport(){instrument.setPlayHead(previous);}} restore{plugin,previousHead};
    transport.position.setBpm(120.);transport.position.setTimeSignature(juce::AudioPlayHead::TimeSignature{4,4});transport.position.setIsPlaying(true);
    plugin.setPlayHead(&transport);
    AlignedPluginBlock hostBlock(std::max(2,plugin.getTotalNumOutputChannels()),block);juce::AudioBuffer<float>audio(2,block);plugin.reset();
    for(int at=0;at<count+latency;at+=block){audio.clear();juce::MidiBuffer midi;if(at==0){midi.addEvent(juce::MidiMessage::allSoundOff(1),0);midi.addEvent(juce::MidiMessage::noteOn(1,pitch,juce::uint8(90)),0);if(role=="Chords"){midi.addEvent(juce::MidiMessage::noteOn(1,pitch+4,juce::uint8(75)),0);midi.addEvent(juce::MidiMessage::noteOn(1,pitch+7,juce::uint8(75)),0);}}
        if(at<=off&&at+block>off){for(int key:{pitch,pitch+4,pitch+7})midi.addEvent(juce::MidiMessage::noteOff(1,key),off-at);}
        transport.position.setTimeInSamples(at);transport.position.setTimeInSeconds(at/rate);transport.position.setPpqPosition(2.*at/rate);
        hostBlock.process(plugin,audio,midi);if(plugin.getLatencySamples()!=latency)throw std::runtime_error("Preset latency changed during audition");
        for(int i=0;i<block;++i)for(int ch=0;ch<channels;++ch){float v=audio.getSample(ch,i);if(!std::isfinite(v))throw std::runtime_error("Preset produced invalid audio");int position=at+i-latency;if(position>=0&&position<count)signal[size_t(ch)][size_t(position)]=v;}}
    Probe result;double early=0,late=0;for(int ch=0;ch<channels;++ch)for(int i=0;i<count;++i){auto v=signal[size_t(ch)][size_t(i)];result.peak=std::max(result.peak,double(std::abs(v)));(i<off?early:late)+=double(v)*v;}result.tail=late/(early+1e-16);
    juce::dsp::FFT fft(11);std::array<float,4096>data{};constexpr double edges[]{20,60,100,180,300,500,800,1300,2200,3600,5600,8000,11026};double total=1e-16;
    for(int ch=0;ch<channels;++ch)for(int frame=0;frame<12;++frame){data.fill(0);int start=frame*(count-2048)/11;for(int i=0;i<2048;++i)data[size_t(i)]=signal[size_t(ch)][size_t(start+i)]*float(.5-.5*std::cos(juce::MathConstants<double>::twoPi*i/2047));fft.performFrequencyOnlyForwardTransform(data.data());for(int k=1;k<=1024;++k){double hz=k*rate/2048,e=double(data[size_t(k)])*data[size_t(k)];if(hz>11026)continue;total+=e;for(int b=0;b<12;++b)if(hz>=edges[b]&&hz<edges[b+1]){result.bands[size_t(b)]+=e;break;}}}
    for(auto&v:result.bands)v=std::sqrt(v/total);return result;
}
inline juce::String select(juce::AudioPluginInstance&plugin,const juce::PluginDescription&description,const juce::String&identity,const juce::var&request,double rate,int block,const juce::File&progress,juce::var&report){
    auto options=candidates(plugin,description,identity,request);juce::MemoryBlock initial,bestState;plugin.getStateInformation(initial);if(initial.getSize()>16*1024*1024)throw std::runtime_error("Instrument state too large for audition");bestState=initial;double best=-1e20;juce::String selected="Current sound";juce::Array<juce::var>rows;auto role=request["auto_program_role"].toString();
    if(auto*target=request["target_features"]["bands"].getArray())for(auto&v:*target)if(!std::isfinite(double(v))||double(v)<0||double(v)>1)throw std::runtime_error("Invalid audition target");
    std::vector<Probe>distinct;bool chosen=false;
    for(auto&option:options){progress.replaceWithText("Audition: "+option.name);if(&option!=&options.front())plugin.setStateInformation(initial.getData(),int(initial.getSize()));if(option.file!=juce::File()&&!matchesPreset(option.file,description,identity))continue;if(!load(plugin,option,description,identity))continue;auto measured=probe(plugin,rate,block,role,int(request.getProperty("audition_pitch",-1)));
        // Disk-backed instruments may accept a program before its samples are
        // ready. A fast offline probe alone wrongly classified these as silent.
        int retries=0;for(int delay:{250,500,1000,1500,2000}){
            if(measured.peak>=1.e-5)break;
            progress.replaceWithText("Waiting for sound: "+option.name+" / "+juce::String(++retries));
           #if JUCE_MODAL_LOOPS_PERMITTED
            if(juce::MessageManager::getInstance()->isThisTheMessageThread())juce::MessageManager::getInstance()->runDispatchLoopUntil(delay);else
           #endif
            juce::Thread::sleep(delay);
            measured=probe(plugin,rate,block,role,int(request.getProperty("audition_pitch",-1)));
        }
        double score=option.prior*(bool(request["export_matched_preset"])?0.005:0.08);
        if(auto*target=request["target_features"]["bands"].getArray();target&&target->size()==12){double distance=0;for(int i=0;i<12;++i){double delta=measured.bands[size_t(i)]-double((*target)[i]);distance+=delta*delta;}score-=distance*4;}
        else if(role=="Bass"){double low=0;for(int i=0;i<5;++i)low+=measured.bands[size_t(i)]*measured.bands[size_t(i)];score+=2*low;}
        else if(role=="Chords")score+=std::min(.4,measured.tail);else score-=std::min(.5,measured.tail);
        if(measured.peak<1e-5)score-=100;if(measured.peak>1)score-=std::min(10.,measured.peak-1);
        bool duplicate=false;for(auto&previous:distinct){double delta=0;for(int b=0;b<12;++b)delta+=std::pow(previous.bands[size_t(b)]-measured.bands[size_t(b)],2);if(delta<1e-5&&std::abs(previous.peak-measured.peak)<.01&&std::abs(previous.tail-measured.tail)<.01){duplicate=true;break;}}if(!duplicate&&measured.peak>=1e-5)distinct.push_back(measured);
        auto*row=new juce::DynamicObject;row->setProperty("name",option.name);row->setProperty("peak",measured.peak);row->setProperty("readiness_retries",retries);row->setProperty("score",score);row->setProperty("similar_to_previous",duplicate);row->setProperty("source",option.bassRecipe>=0?"designed public controls":option.file!=juce::File()?"preset file":option.program>=0?"public program":"current state");rows.add(juce::var(row));
        if(measured.peak>=1e-5&&!duplicate&&score>best){juce::MemoryBlock candidateState;plugin.getStateInformation(candidateState);if(candidateState.getSize()>16*1024*1024)continue;best=score;selected=option.name;bestState=std::move(candidateState);chosen=true;}
    }
    if(options.size()>1)plugin.setStateInformation(bestState.getData(),int(bestState.getSize()));plugin.reset();report=rows;
    return "Auditioned "+juce::String(rows.size())+" candidate(s), "+juce::String(int(distinct.size()))+" distinct audition(s); selected: "+selected+(distinct.size()<=1?". No audibly different alternative was found in the checked public programs and standard presets.":"")+(!chosen?" Warning: all checked sounds were silent.":"");
}
}
