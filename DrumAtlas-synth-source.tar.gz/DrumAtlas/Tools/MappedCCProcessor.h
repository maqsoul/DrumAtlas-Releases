#pragma once
#include "AlignedPluginBlock.h"
#include "../Source/MidiParameterMap.h"
#include "ParameterCapabilities.h"
#include <array>
namespace atlas::hosting {
// Construct outside processing after state restore. Pointer identity is checked
// under the caller's callback lock; a changed parameter layout requires restart.
class MappedCCProcessor {
public:
 MappedCCProcessor(juce::AudioPluginInstance&instance,const juce::var&value,int block):plugin(instance),hostBlock(std::max(2,instance.getTotalNumOutputChannels()),block){
  auto result=readCCParameterMap(value,bindings);if(result.failed())throw std::runtime_error(result.getErrorMessage().toStdString());
  for(size_t b=0;b<bindings.size();++b){auto&binding=bindings[b];int found=-1;for(int i=0;i<plugin.getParameters().size();++i)if(parameterId(*plugin.getParameters()[i])==binding.parameter){if(found>=0)throw std::runtime_error("Ambiguous mapped parameter ID");found=i;}
   if(found<0||!plugin.getParameters()[found]->isAutomatable()||plugin.getParameters()[found]->getName(256)!=binding.name)throw std::runtime_error("Mapped parameter is missing or changed; review MIDI CC bindings");indices[b]=found;parameters[b]=plugin.getParameters()[found];}
  segmentMidi.ensureSize(65536);
 }
 template<class Position>void process(juce::AudioBuffer<float>&audio,juce::MidiBuffer&midi,Position&&position,const juce::MidiBuffer*source=nullptr){
  if(audio.getNumChannels()<1||audio.getNumChannels()>2)throw std::runtime_error("Unsupported mapped MIDI audio layout");
  if(bindings.empty()){hostBlock.process(plugin,audio,midi);return;}
  for(size_t b=0;b<bindings.size();++b)if(indices[b]>=plugin.getParameters().size()||parameters[b]!=plugin.getParameters()[indices[b]])throw std::runtime_error("Mapped parameter layout changed; restart the instrument");
  struct Change{int offset;size_t binding;float value;};std::array<Change,256>changes{};size_t count=0;
  for(const auto&event:(source?*source:midi)){if(event.numBytes!=3||(event.data[0]&0xf0)!=0xb0||event.data[1]>127||event.data[2]>127||event.samplePosition<0||event.samplePosition>=audio.getNumSamples())continue;
   for(size_t b=0;b<bindings.size();++b)if((event.data[0]&15)+1==bindings[b].channel&&event.data[1]==bindings[b].controller){if(count==changes.size())throw std::runtime_error("MIDI CC automation block budget exceeded");changes[count++]={event.samplePosition,b,float(event.data[2])/127.f};}}
  if(count==0){hostBlock.process(plugin,audio,midi);return;}
  size_t next=0;int begin=0;
  while(begin<audio.getNumSamples()){
   while(next<count&&changes[next].offset==begin){parameters[changes[next].binding]->setValueNotifyingHost(changes[next].value);++next;}
   int end=next<count?changes[next].offset:audio.getNumSamples();position(begin);segmentMidi.clear();segmentMidi.addEvents(midi,begin,end-begin,-begin);
   float*channels[2]{audio.getWritePointer(0,begin),audio.getWritePointer(std::min(1,audio.getNumChannels()-1),begin)};juce::AudioBuffer<float>segment(channels,audio.getNumChannels(),end-begin);hostBlock.process(plugin,segment,segmentMidi);begin=end;
  }
 }
private:
 juce::AudioPluginInstance&plugin;AlignedPluginBlock hostBlock;std::vector<CCParameterBinding>bindings;std::array<int,16>indices{};std::array<juce::AudioProcessorParameter*,16>parameters{};juce::MidiBuffer segmentMidi;
};
}
