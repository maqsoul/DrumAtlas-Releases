#pragma once
#include "FactoryIdentity.h"
#include <juce_cryptography/juce_cryptography.h>

namespace atlas::hosting {
// Kept inside AtlasWorker: no third-party module is loaded by the DAW process.
class HostFormats {
public:
    void findAllTypesForFile(juce::OwnedArray<juce::PluginDescription>& found,
                             const juce::String& path) {
        const juce::File file(path);
        if (file.hasFileExtension("vst3")) vst3.findAllTypesForFile(found, path);
#if JUCE_WINDOWS
        else if (file.hasFileExtension("dll") && file.existsAsFile()) {
            juce::FileInputStream input(file);
            if (!input.openedOk() || input.readShort() != 0x5a4d)
                throw std::runtime_error("Not a Windows plugin DLL");
            input.setPosition(0x3c);
            const auto pe = juce::uint32(input.readInt());
            if (pe > file.getSize() - 24 || !input.setPosition(pe)
                || input.readInt() != 0x00004550)
                throw std::runtime_error("Invalid Windows DLL header");
            if (juce::uint16(input.readShort()) != (sizeof(void*)==4?0x14c:0x8664))
                throw std::runtime_error("Plugin architecture does not match this worker; use the matching AtlasWorker32/AtlasWorker bridge");
            vst2.findAllTypesForFile(found, path);
        }
#endif
    }
    std::unique_ptr<juce::AudioPluginInstance> createInstanceFromDescription(
            const juce::PluginDescription& description, double rate, int block,
            juce::String& error) {
        if (description.pluginFormatName == vst3.getName())
            return vst3.createInstanceFromDescription(description, rate, block, error);
#if JUCE_WINDOWS
        if (description.pluginFormatName == vst2.getName())
            return vst2.createInstanceFromDescription(description, rate, block, error);
#endif
        error = "Unsupported instrument format";
        return {};
    }
private:
    juce::VST3PluginFormat vst3;
#if JUCE_WINDOWS
    juce::VSTPluginFormat vst2;
#endif
};

inline juce::String pluginClassIdentity(const juce::File& path,
                                       const juce::PluginDescription& description) {
    if (description.pluginFormatName == "VST") {
        // VST2 has only a 32-bit vendor ID, not a VST3 class UUID. Include the
        // vendor and class name to reject accidental ID collisions on reconnect.
        auto identity = juce::String::toHexString(juce::uint32(description.uniqueId))
                      + "\n" + description.manufacturerName + "\n" + description.name;
        // Keep existing x64 IDs stable, but never reconnect an opaque x86 chunk
        // to an x64 build just because its vendor/name/32-bit plugin ID match.
        if (sizeof(void*) == 4) identity += "\nx86";
        return "vst2:" + juce::SHA256(identity.toRawUTF8(),
                                    size_t(identity.getNumBytesAsUTF8())).toHexString();
    }
    if (description.pluginFormatName != "VST3")
        throw std::runtime_error("Unsupported plugin identity format");
    return classIdentity(path, description);
}
}
