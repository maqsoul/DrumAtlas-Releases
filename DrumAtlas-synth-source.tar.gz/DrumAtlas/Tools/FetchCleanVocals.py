"""Fetch the pinned FP32 Mel-Band RoFormer used by Maximum vocal separation.

The conversion's model card declares MIT. Check upstream weight terms before
redistributing; this downloader does not grant rights to training data/weights.
"""
import argparse
import hashlib
from pathlib import Path
import urllib.request

REVISION = "60cb6b4b97e41b42f7ff16c2e386f47a8cc7e50a"
NAME = "melband_roformer_vocals.onnx"
SHA256 = "64a4f3bee48fbe7d971b23875adc924ed004c3533f49672592641dddc0f6f561"
SIZE = 953292899
URL = f"https://huggingface.co/smank/mel-band-roformer-vocals-onnx/resolve/{REVISION}/{NAME}"


def verified(path):
    if not path.is_file() or path.stat().st_size != SIZE:
        return False
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest() == SHA256


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("model_dir", type=Path)
    args = parser.parse_args()
    args.model_dir.mkdir(parents=True, exist_ok=True)
    target = args.model_dir / NAME
    if verified(target):
        print("Model already verified:", target)
        return
    partial = target.with_suffix(".download")
    with urllib.request.urlopen(URL, timeout=60) as source, partial.open("wb") as output:
        while block := source.read(1024 * 1024):
            output.write(block)
    if not verified(partial):
        raise RuntimeError("Size/SHA-256 verification failed; existing model unchanged")
    partial.replace(target)
    print("Downloaded and verified:", target)


if __name__ == "__main__":
    main()
