#pragma once
#include <juce_audio_processors/juce_audio_processors.h>

namespace atlas::hosting {
// No allocation: also used before dispatching audio to a vendor processor.
inline bool supportedMainBuses(const juce::AudioProcessor& processor, bool effect) noexcept {
    const auto* output = processor.getBus(false, 0);
    if (!effect)
        return output && output->getNumberOfChannels() > 0
            && processor.getTotalNumInputChannels() == 0
            && processor.getTotalNumOutputChannels() <= 64;
    if (!output || output->getNumberOfChannels() < 1 || output->getNumberOfChannels() > 2) return false;
    for (int i = 1; i < processor.getBusCount(false); ++i)
        if (processor.getBus(false, i)->getNumberOfChannels() != 0) return false;
    for (int i = 1; i < processor.getBusCount(true); ++i)
        if (processor.getBus(true, i)->getNumberOfChannels() != 0) return false;
    const auto* input = processor.getBus(true, 0);
    return input && input->getNumberOfChannels() == output->getNumberOfChannels();
}

// Prefer a compact bus layout. Fixed-output VST2 synths can expose several
// stereo pairs as a single immutable bus. Route its first pair to the track.
inline bool configureInstrumentOutputs(juce::AudioProcessor& processor) {
    const auto native = processor.getBusesLayout();
    if (native.outputBuses.isEmpty()) return false;
    auto compact = native;
    for (auto& bus : compact.inputBuses) bus = juce::AudioChannelSet::disabled();
    for (auto& bus : compact.outputBuses) bus = juce::AudioChannelSet::disabled();
    for (auto main : {juce::AudioChannelSet::stereo(), juce::AudioChannelSet::mono()}) {
        compact.outputBuses.getReference(0) = main;
        if (processor.setBusesLayout(compact) && supportedMainBuses(processor, false)) return true;
    }
    return (processor.getBusesLayout() == native || processor.setBusesLayout(native))
        && supportedMainBuses(processor, false);
}

// Control thread only. Describe both vendor buses and the route this host supports.
inline juce::var hostRoutingCapabilities(juce::AudioProcessor& processor) {
    auto* root = new juce::DynamicObject;
    juce::var result(root);
    root->setProperty("schema", 1);
    root->setProperty("route", "instrument-main-output-to-serial-effects");
    root->setProperty("sidechain_supported", false);
    root->setProperty("multi_output_supported", false);
    root->setProperty("main_layout_supported", supportedMainBuses(processor, false));
    root->setProperty("effect_parameter_automation", false);
    for (bool input : {true, false}) {
        juce::Array<juce::var> buses;
        for (int i = 0; i < processor.getBusCount(input); ++i) {
            const auto* bus = processor.getBus(input, i);
            auto* row = new juce::DynamicObject;
            row->setProperty("index", i);
            row->setProperty("name", bus->getName());
            row->setProperty("channels", bus->getNumberOfChannels());
            row->setProperty("active", bus->getNumberOfChannels() > 0);
            buses.add(juce::var(row));
        }
        root->setProperty(input ? "input_buses" : "output_buses", buses);
    }
    return result;
}
}
