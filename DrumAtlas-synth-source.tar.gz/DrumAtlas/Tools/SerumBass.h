#pragma once
#include <juce_audio_processors/juce_audio_processors.h>

namespace atlas::hosting::serumPreset {
inline juce::var header(const juce::MemoryBlock& bytes){
    if(bytes.getSize()<17||std::memcmp(bytes.getData(),"XferJson\0",9)!=0)return {};
    auto* data=static_cast<const char*>(bytes.getData());auto size=juce::ByteOrder::littleEndianInt64(data+9);
    if(size>65536||size>bytes.getSize()-17)return {};
    return juce::JSON::parse(juce::String::fromUTF8(data+17,int(size)));
}
inline bool compatible(const juce::PluginDescription& d,const juce::String& identity){
    return d.pluginFormatName=="VST3"&&identity.equalsIgnoreCase("56534558667350736572756D20320000")&&d.version.startsWith("2.");
}
inline bool initialSound(juce::AudioPluginInstance& plugin){
    juce::MemoryBlock actual;plugin.getStateInformation(actual);auto xml=juce::AudioProcessor::getXmlFromBinary(actual.getData(),int(actual.getSize()));
    if(xml)if(auto* controller=xml->getChildByName("IEditController")){juce::MemoryBlock chunk;if(chunk.fromBase64Encoding(controller->getAllSubText()))return header(chunk)["presetName"].toString().trim()=="- Init -";}
    return false;
}
inline bool bass(juce::AudioPluginInstance& plugin,int recipe){
    struct Setting{const char* id;const char* name;float value;};
    const Setting settings[]={{"1000000","A Enable",recipe>=2?1.f:0.f},{"1000001","A Level",recipe>=3?.65f:.18f},{"1001000","B Enable",0},{"1002000","C Enable",0},{"1003000","Noise Enable",0},{"1004000","Sub Enable",1},{"1004001","Sub Level",recipe>=3?.18f:.75f},{"1004033","Sub Shape",recipe==1||recipe==5?.2f:0.f},{"1004003","Sub Octave",.5f},{"3000000","Env 1 Attack",recipe==4?.65f:.12559432f},{"3000004","Env 1 Release",recipe==4?.65f:recipe==5?.38f:.215f}};
    std::vector<std::pair<juce::AudioProcessorParameter*,float>> edits;
    for(auto& s:settings){juce::AudioProcessorParameter* found=nullptr;for(auto* p:plugin.getParameters())if(auto* h=dynamic_cast<juce::HostedAudioProcessorParameter*>(p))if(h->getParameterID()==s.id&&p->getName(256)==s.name&&p->isAutomatable()){found=p;break;}if(!found)return false;edits.emplace_back(found,s.value);}
    for(auto& e:edits)e.first->setValueNotifyingHost(e.second);return true;
}
}
