"""Download the pinned, unmodified MIT drum specialist into a developer model folder."""
import argparse
import hashlib
from pathlib import Path
import urllib.request

REVISION = "55f929d333054c69ae0e829b15e8f8826a39d6eb"
NAME = "htdemucs_ft_drums.onnx"
SHA256 = "f76b68af36066e38885b369299b5032a861038f9b49da5aa6cf1c31cfa69cf27"
SIZE = 316446953
URL = f"https://huggingface.co/StemSplitio/htdemucs-ft-drums-onnx/resolve/{REVISION}/{NAME}"

def verified(path):
    if not path.is_file() or path.stat().st_size != SIZE:
        return False
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest() == SHA256

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("model_dir", type=Path)
    args = parser.parse_args()
    args.model_dir.mkdir(parents=True, exist_ok=True)
    target = args.model_dir / NAME
    if verified(target):
        print("Model already verified:", target)
        return
    partial = target.with_suffix(".download")
    with urllib.request.urlopen(URL, timeout=60) as source, partial.open("wb") as output:
        while block := source.read(1024 * 1024):
            output.write(block)
    if not verified(partial):
        raise RuntimeError("Model download failed size/SHA-256 verification; existing model unchanged")
    partial.replace(target)
    print("Downloaded and verified:", target)

if __name__ == "__main__":
    main()
