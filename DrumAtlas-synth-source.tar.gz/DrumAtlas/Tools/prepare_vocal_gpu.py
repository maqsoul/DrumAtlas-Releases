# Reproducible FP32 graph rewrite. Requires onnx and numpy; not needed at runtime.
import sys,pathlib
import argparse,hashlib,json
a=argparse.ArgumentParser();a.add_argument("source");a.add_argument("output");args=a.parse_args()
import onnx,numpy as np
from onnx import helper as h,numpy_helper as nh
source=pathlib.Path(args.source)
assert hashlib.file_digest(source.open('rb'),'sha256').hexdigest()=='64a4f3bee48fbe7d971b23875adc924ed004c3533f49672592641dddc0f6f561', 'Unexpected source model'
m=onnx.load(source)
nodes=list(m.graph.node);new=[];i=0;count=0
while i<len(nodes):
 n=nodes[i]
 if n.op_type=='Einsum' and n.name.endswith('/attend/Einsum'):
  mul,soft,out=nodes[i+1:i+4]
  assert (mul.op_type,soft.op_type,out.op_type)==('Mul','Softmax','Einsum')
  batch,seq=(60,801) if '.0/layers.0.0/attend/' in n.name else (801,60)
  prefix=n.name+'/fused';ins=[]
  shape3=prefix+'/shape3';shape4=prefix+'/shape4'
  m.graph.initializer.extend([nh.from_array(np.array([batch,seq,512],np.int64),shape3),nh.from_array(np.array([batch,seq,8,64],np.int64),shape4)])
  for j,x in enumerate([n.input[0],n.input[1],out.input[1]]):
   trans=prefix+'/trans'+str(j);flat=prefix+'/flat'+str(j)
   new.append(h.make_node('Transpose',[x],[trans],perm=[0,2,1,3],name=trans));new.append(h.make_node('Reshape',[trans,shape3],[flat],name=flat));ins.append(flat)
  new.append(h.make_node('MultiHeadAttention',ins,[prefix+'/mha'],domain='com.microsoft',num_heads=8,scale=0.125,name=prefix))
  new.append(h.make_node('Reshape',[prefix+'/mha',shape4],[prefix+'/reshaped'],name=prefix+'/reshape'))
  new.append(h.make_node('Transpose',[prefix+'/reshaped'],list(out.output),perm=[0,2,1,3],name=prefix+'/out'))
  count+=1;i+=4
 else:new.append(n);i+=1
assert count==12
if not any(x.domain=='com.microsoft' for x in m.opset_import):m.opset_import.append(h.make_opsetid('com.microsoft',1))
del m.graph.node[:];m.graph.node.extend(new);onnx.checker.check_model(m);target=pathlib.Path(args.output);onnx.save(m,target)
manifest={'source_sha256':hashlib.file_digest(source.open('rb'),'sha256').hexdigest(),'optimized_sha256':hashlib.file_digest(target.open('rb'),'sha256').hexdigest(),'precision':'float32','weights':'unchanged','attention_blocks':count}
target.with_name('vocal-gpu-manifest.json').write_text(json.dumps(manifest,indent=2))
print(json.dumps(manifest),flush=True)
