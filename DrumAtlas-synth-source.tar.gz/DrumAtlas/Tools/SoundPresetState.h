#pragma once
#include <juce_audio_processors/juce_audio_processors.h>
#include <juce_cryptography/juce_cryptography.h>

namespace atlas::hosting::autosound {
inline bool readSoundState(const juce::File& file,const juce::PluginDescription& description,
                           const juce::String& identity,juce::MemoryBlock& state){
    if(file.getSize()<=0||file.getSize()>24*1024*1024)return false;
    auto config=juce::JSON::parse(file);
    if(config["uid"].toString()!=description.createIdentifierString()||
       config["class_id"].toString()!=identity||config["state"].toString().isEmpty())return false;
    return state.fromBase64Encoding(config["state"].toString())&&state.getSize()>0&&
        state.getSize()<=16*1024*1024&&juce::SHA256(state).toHexString()==config["sha256"].toString();
}
}
