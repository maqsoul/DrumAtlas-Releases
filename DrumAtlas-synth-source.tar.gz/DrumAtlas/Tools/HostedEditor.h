#pragma once
#include <juce_audio_processors/juce_audio_processors.h>

namespace atlas::hosting {
// The host owns either editor. A plugin without a vendor GUI still exposes
// its standard VST parameters through JUCE's parameter editor.
inline juce::AudioProcessorEditor* createHostedEditor(juce::AudioPluginInstance& plugin) {
    if (auto* native = plugin.createEditorIfNeeded()) return native;
    return new juce::GenericAudioProcessorEditor(plugin);
}
}
