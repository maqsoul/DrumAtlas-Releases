#pragma once
#include "../Source/TempoMap.h"
#include "HostFormats.h"
#include "AutoSound.h"
#include "HostedEditor.h"
#include "../Source/NativeEditorPosition.h"
#include "ParameterCapabilities.h"
#include "MappedCCProcessor.h"
#include "ParameterTransition.h"
#include <juce_audio_formats/juce_audio_formats.h>
#include <juce_cryptography/juce_cryptography.h>

namespace offline {
inline void require(bool ok,const juce::String&why){if(!ok)throw std::runtime_error(why.toStdString());}
inline juce::String checksum(const juce::MemoryBlock&b){return juce::SHA256(b).toHexString();}
struct PlayHead:juce::AudioPlayHead {
    PositionInfo position;
    juce::Optional<PositionInfo>getPosition()const override{return position;}
};
// Some instruments complete native-browser loading on their processing thread.
// Keep that thread alive while configuring, even though this window has no audio
// device. Output is discarded; preview remains the explicit rendered audition.
class ConfigureAudioPump final:private juce::Thread {
public:
    ConfigureAudioPump(juce::AudioPluginInstance&p,double rate,int block):Thread("Instrument editor processing"),plugin(p),sampleRate(rate),blockSize(block),audio(std::max(2,std::max(p.getTotalNumInputChannels(),p.getTotalNumOutputChannels())),block),hostBlock(audio.getNumChannels(),block){midi.ensureSize(4096);require(startThread(),"Cannot start editor processing");}
    ~ConfigureAudioPump()override{stop();}
    void stop(){signalThreadShouldExit();notify();stopThread(-1);}
    int processedBlocks()const noexcept{return blocks.load();}
    bool failed()const noexcept{return error.load();}
private:
    void run()override{
        juce::ScopedNoDenormals guard;double next=juce::Time::getMillisecondCounterHiRes();
        while(!threadShouldExit()){
            try{audio.clear();midi.clear();{const juce::ScopedLock lock(plugin.getCallbackLock());if(!plugin.isSuspended())hostBlock.process(plugin,audio,midi);}++blocks;}
            catch(...){error.store(true);return;}
            next+=blockSize*1000./sampleRate;const double now=juce::Time::getMillisecondCounterHiRes();if(next<now)next=now;
            wait(std::max(1,int(std::ceil(next-now))));
        }
    }
    juce::AudioPluginInstance&plugin;double sampleRate;int blockSize;juce::AudioBuffer<float>audio;atlas::hosting::AlignedPluginBlock hostBlock;juce::MidiBuffer midi;std::atomic<int>blocks{0};std::atomic<bool>error{false};
};
class ConfigureWindow:public juce::DocumentWindow,private juce::ComponentListener {
public:
    ConfigureWindow(juce::AudioPluginInstance&p,bool&accepted,bool visible=true):DocumentWindow(p.getName()+" — save sound then close",juce::Colours::darkgrey,allButtons),accept(accepted){
        setUsingNativeTitleBar(true);auto*editor=atlas::hosting::createHostedEditor(p);
        content=std::make_unique<juce::Component>();content->addAndMakeVisible(editor);pluginEditor.reset(editor);editor->addComponentListener(this);
        content->addAndMakeVisible(save);content->addAndMakeVisible(cancel);save.setButtonText("Save sound and close");cancel.setButtonText("Cancel");
        save.setBounds(8,8,190,28);cancel.setBounds(208,8,90,28);editor->setTopLeftPosition(0,44);
        content->setSize(std::max(320,editor->getWidth()),editor->getHeight()+44);setContentNonOwned(content.get(),true);
        save.onClick=[this]{accept=true;juce::MessageManager::getInstance()->stopDispatchLoop();};
        cancel.onClick=[this]{closeButtonPressed();};centreWithSize(getWidth(),getHeight());placementReady=true;keepControlsVisible();setVisible(visible);
    }
    ~ConfigureWindow()override{pluginEditor->removeComponentListener(this);clearContentComponent();pluginEditor.reset();}
    juce::AudioProcessorEditor* editorComponent()const{return pluginEditor.get();}
    void closeButtonPressed()override{juce::MessageManager::getInstance()->stopDispatchLoop();}
    void resized()override{DocumentWindow::resized();if(placementReady)keepControlsVisible();}
private:
    void keepControlsVisible(){
        const auto& displays=juce::Desktop::getInstance().getDisplays();
        auto* display=displays.getDisplayForRect(getBounds());if(!display)display=displays.getPrimaryDisplay();
        if(display){auto area=display->userArea;auto point=atlas::hosting::visibleNativeEditorPosition({getX(),getY()},getWidth(),getHeight(),area.getX(),area.getY(),area.getWidth(),area.getHeight());setTopLeftPosition(point.x,point.y);}
    }
    void componentMovedOrResized(juce::Component&component,bool,bool resized)override{
        if(resized&&pluginEditor.get()==&component&&content){content->setSize(std::max(320,component.getWidth()),std::max(1,component.getHeight())+44);}
    }
    bool placementReady=false;bool&accept;juce::TextButton save,cancel;std::unique_ptr<juce::Component>content;std::unique_ptr<juce::AudioProcessorEditor>pluginEditor;
};

inline int testConfigureResize(const juce::File&fixture){
    try{atlas::hosting::HostFormats format;juce::OwnedArray<juce::PluginDescription>found;format.findAllTypesForFile(found,fixture.getFullPathName());require(!found.isEmpty(),"Fixture not found");juce::String error;auto plugin=format.createInstanceFromDescription(*found[0],48000,128,error);require(plugin!=nullptr,"Cannot instantiate editor fixture");plugin->setRateAndBufferSizeDetails(48000,128);plugin->prepareToPlay(48000,128);{ConfigureAudioPump pump(*plugin,48000,128);auto deadline=juce::Time::getMillisecondCounterHiRes()+2000;while(pump.processedBlocks()<3&&juce::Time::getMillisecondCounterHiRes()<deadline)juce::Thread::sleep(5);pump.stop();require(pump.processedBlocks()>=3&&!pump.failed(),"Editor must process audio while open");auto count=pump.processedBlocks();juce::Thread::sleep(20);require(count==pump.processedBlocks(),"Editor processing must stop before state capture");}plugin->releaseResources();bool accepted=false;ConfigureWindow window(*plugin,accepted,false);auto*editor=window.editorComponent();require(editor!=nullptr,"Fixture editor missing");auto*display=juce::Desktop::getInstance().getDisplays().getPrimaryDisplay();require(display!=nullptr,"Display missing");auto area=display->userArea;for(auto size:{juce::Point<int>(640,480),juce::Point<int>(420,300),juce::Point<int>(area.getWidth()+200,area.getHeight()+200)}){window.setTopLeftPosition(area.getRight()-100,area.getBottom()-80);editor->setSize(size.x,size.y);require(window.getContentComponent()->getWidth()==size.x&&window.getContentComponent()->getHeight()==size.y+44,"Host wrapper must follow native editor resize");require(area.contains(window.getPosition()),"Editor title and save controls must remain reachable");if(window.getWidth()<=area.getWidth()&&window.getHeight()<=area.getHeight())require(area.contains(window.getBounds()),"Fitting editor stays on screen");}return 0;}catch(...){return 1;}
}

inline int run(const juce::File&requestFile,const juce::File&responseFile,const juce::String&id,bool configure,bool capture=false){
    auto*out=new juce::DynamicObject;juce::var response(out);out->setProperty("request_id",id);out->setProperty("protocol",2);out->setProperty("glide_protocol",1);out->setProperty("tempo_protocol",1);out->setProperty("effects_protocol",1);out->setProperty("audio_source_protocol",1);out->setProperty("identity_protocol",1);out->setProperty("parameter_protocol",1);out->setProperty("sound_audition_protocol",1);out->setProperty("transition_protocol",1);out->setProperty("status","error");
    try{
        auto*timings=new juce::DynamicObject;out->setProperty("stage_ms",juce::var(timings));double stageStart=juce::Time::getMillisecondCounterHiRes();auto mark=[&](const char*stage){auto now=juce::Time::getMillisecondCounterHiRes();timings->setProperty(stage,now-stageStart);stageStart=now;};
        require(requestFile.getSize()>0&&requestFile.getSize()<=64*1024*1024,"Invalid render request size");
        auto request=juce::JSON::parse(requestFile);require(request.isObject()&&request["request_id"].toString()==id,"Invalid request identity");
        auto config=request["instrument"];auto path=config["path"].toString();require(juce::File::isAbsolutePath(path)&&juce::File(path).exists(),"Instrument is missing; MIDI remains available");
        double rate=double(request.getProperty("sample_rate",44100));int block=int(request.getProperty("block_size",256));
        require((rate==44100||rate==48000||rate==96000)&&(block==64||block==128||block==256||block==512||block==1024),"Invalid render format");
        atlas::hosting::HostFormats format;juce::OwnedArray<juce::PluginDescription>found;format.findAllTypesForFile(found,path);mark("scan");juce::PluginDescription*description=nullptr;
        const bool configuringEffect=bool(config["effect"]);auto uid=config["uid"].toString();
        for(auto*d:found)if(d->isInstrument!=configuringEffect&&(uid.isEmpty()||d->createIdentifierString()==uid)){description=d;break;}
        require(description!=nullptr,"Saved instrument class not found");juce::String fullIdentity;if(configure||capture||config.hasProperty("class_id"))fullIdentity=atlas::hosting::pluginClassIdentity(juce::File(path),*description);if(config.hasProperty("class_id"))require(fullIdentity.equalsIgnoreCase(config["class_id"].toString()),"Saved plugin class identity mismatch");
        mark("identity");juce::String error;auto instance=format.createInstanceFromDescription(*description,rate,block,error);require(bool(instance),"Cannot create instrument: "+error);mark("instantiate");
        if (!configuringEffect) {
            require(atlas::hosting::configureInstrumentOutputs(*instance),
                    "Cannot route main output of " + description->name);
        } else {
            auto layout = instance->getBusesLayout();
            require(!layout.inputBuses.isEmpty() && !layout.outputBuses.isEmpty(), "Effect requires audio input and output");
            for (auto& bus : layout.inputBuses) bus = juce::AudioChannelSet::disabled();
            for (auto& bus : layout.outputBuses) bus = juce::AudioChannelSet::disabled();
            bool configured = false;
            for (auto main : {juce::AudioChannelSet::stereo(), juce::AudioChannelSet::mono()}) {
                layout.inputBuses.getReference(0) = layout.outputBuses.getReference(0) = main;
                if (instance->setBusesLayout(layout)) { configured = true; break; }
            }
            require(configured, "Cannot route main effect buses of " + description->name);
        }
        auto encoded=config["state"].toString();if(encoded.isNotEmpty()){
            juce::MemoryBlock state;require(encoded.length()<=24*1024*1024&&state.fromBase64Encoding(encoded)&&state.getSize()<=16*1024*1024,"Invalid instrument state");
            require(checksum(state)==config["sha256"].toString(),"Instrument state checksum mismatch");instance->setStateInformation(state.getData(),int(state.getSize()));
        }
        mark("layout_and_state_restore");instance->setNonRealtime(!configure);instance->setRateAndBufferSizeDetails(rate,block);instance->prepareToPlay(rate,block);
        require(atlas::hosting::supportedMainBuses(*instance,configuringEffect),"Plugin state changed supported layout");
        mark("prepare");
        if(capture && request["auto_program_role"].isString()){
            require(!configuringEffect,"Sound audition requires an instrument");
            juce::var audition;
            out->setProperty("program_notice",atlas::hosting::autosound::select(*instance,*description,fullIdentity,request,rate,block,responseFile.getSiblingFile("progress"),audition));
            out->setProperty("sound_auditions",audition);
            mark("sound_audition");
        }
        if(configure||capture){
            bool accepted=capture;
            if(capture){if(request.hasProperty("expected_plugin_version"))require(request["expected_plugin_version"].toString()==description->version,"Plugin version changed; refresh capabilities");atlas::hosting::applyParameterEdits(*instance,request["parameters"]);}
            else{ConfigureAudioPump pump(*instance,rate,block);{ConfigureWindow window(*instance,accepted);juce::MessageManager::getInstance()->runDispatchLoop();pump.stop();}require(!pump.failed(),"Instrument failed while processing in its editor");}
            if(!accepted){out->setProperty("status","cancelled");}
            else{
                // VST3 controller changes may be queued until the next audio block.
                // Flush them into the processor before serialising state (e.g. Serum 2).
                if(configure||request.hasProperty("auto_program_role")||(request["parameters"].isArray()&&request["parameters"].size()>0)){juce::AudioBuffer<float>flush(std::max(2,std::max(instance->getTotalNumInputChannels(),instance->getTotalNumOutputChannels())),block);flush.clear();juce::MidiBuffer silence;atlas::hosting::AlignedPluginBlock(flush.getNumChannels(),block).process(*instance,flush,silence);}
                juce::MemoryBlock state;instance->getStateInformation(state);require(state.getSize()<=16*1024*1024,"Instrument state too large");
                if(bool(request["export_matched_preset"])){
                    bool audible=false;
                    if(auto* rows=out->getProperty("sound_auditions").getArray())for(const auto& row:*rows)audible|=double(row["peak"])>=1.e-5;
                    require(audible,"The instrument did not produce an audible preset");
                    juce::MemoryBlock preset;juce::String filename;
                    if(description->pluginFormatName=="VST3"){auto* client=instance->getVST3Client();require(client!=nullptr,"No VST3 preset interface");preset=client->getPreset();filename="Match.vstpreset";}
                    else {auto* client=instance->getVSTClient();require(client&&client->saveToFXBFile(preset,false),"Cannot export VST2 preset");filename="Match.fxp";}
                    require(preset.getSize()>0 && responseFile.getSiblingFile(filename).replaceWithData(preset.getData(),preset.getSize()),"Cannot write matched preset");
                }
                auto*c=new juce::DynamicObject;juce::var saved(c);c->setProperty("schema",1);require(atlas::hosting::validNativeEditorPosition(config["editor_position"]),"Invalid native editor position");if(config.hasProperty("editor_position"))c->setProperty("editor_position",config["editor_position"].clone());if(config.hasProperty("cc_parameter_map"))c->setProperty("cc_parameter_map",config["cc_parameter_map"].clone());if(fullIdentity.isNotEmpty())c->setProperty("class_id",fullIdentity);if(configuringEffect)c->setProperty("effect",true);c->setProperty("path",path);c->setProperty("uid",description->createIdentifierString());c->setProperty("name",description->name);c->setProperty("xml",description->createXml()->toString());c->setProperty("plugin_version",description->version);c->setProperty("state",state.toBase64Encoding());c->setProperty("sha256",checksum(state));if(configure){try{out->setProperty("capabilities",atlas::hosting::parameterCapabilities(*instance,*description));}catch(const std::exception&e){out->setProperty("capability_error",juce::String::fromUTF8(e.what()));}}else out->setProperty("capabilities",atlas::hosting::parameterCapabilities(*instance,*description));out->setProperty("instrument",saved);out->setProperty("status","configured");
            }
        }else{
            const bool audioSource=request.hasProperty("source_audio");require(audioSource==configuringEffect,"Effect rendering needs an audio source; instruments render MIDI");
            juce::File sourceFile;std::unique_ptr<juce::AudioFormatReader>sourceReader;juce::int64 sourceSize=0,sourceModified=0;
            if(audioSource){auto sourcePath=request["source_audio"].toString();require(juce::File::isAbsolutePath(sourcePath),"Invalid audio source path");sourceFile=juce::File(sourcePath);require(sourceFile.existsAsFile()&&sourceFile!=responseFile.getSiblingFile("audio.wav"),"Audio source is missing or conflicts with output");sourceSize=sourceFile.getSize();sourceModified=sourceFile.getLastModificationTime().toMilliseconds();require(juce::SHA256(sourceFile).toHexString()==request["source_sha256"].toString(),"Audio source checksum mismatch");juce::AudioFormatManager sourceFormats;sourceFormats.registerBasicFormats();sourceReader.reset(sourceFormats.createReaderFor(sourceFile));require(sourceReader&&sourceReader->numChannels==2&&sourceReader->sampleRate==rate,"Invalid audio source format");}
            std::vector<std::unique_ptr<juce::AudioPluginInstance>>effects;std::vector<int>effectLatency;juce::Array<juce::var>effectReports;
            struct ReleaseEffects{decltype(effects)&items;~ReleaseEffects(){for(auto&fx:items)fx->releaseResources();}}releaseEffects{effects};
            double effectTail=0;bool adaptiveTail=false;int addedLatency=0;
            if(request.hasProperty("effects")){auto*chain=request["effects"].getArray();require(chain&&chain->size()<=8,"Invalid effect chain");for(const auto&fx:*chain){if(bool(fx["bypass"]))continue;auto fxPath=fx["path"].toString();require(bool(fx["effect"])&&juce::File::isAbsolutePath(fxPath)&&juce::File(fxPath).exists(),"Effect is missing");juce::OwnedArray<juce::PluginDescription>descriptions;format.findAllTypesForFile(descriptions,fxPath);juce::PluginDescription*fxDescription=nullptr;for(auto*d:descriptions)if(!d->isInstrument&&d->createIdentifierString()==fx["uid"].toString()){fxDescription=d;break;}require(fxDescription!=nullptr,"Effect class not found");if(fx.hasProperty("class_id"))require(atlas::hosting::pluginClassIdentity(juce::File(fxPath),*fxDescription).equalsIgnoreCase(fx["class_id"].toString()),"Saved effect class identity mismatch");auto processor=format.createInstanceFromDescription(*fxDescription,rate,block,error);require(bool(processor),"Cannot create effect: "+error);
                auto fxLayout=processor->getBusesLayout();for(auto&bus:fxLayout.inputBuses)bus=juce::AudioChannelSet::disabled();for(auto&bus:fxLayout.outputBuses)bus=juce::AudioChannelSet::disabled();require(!fxLayout.inputBuses.isEmpty()&&!fxLayout.outputBuses.isEmpty(),"Effect requires audio input and output");fxLayout.inputBuses.getReference(0)=fxLayout.outputBuses.getReference(0)=juce::AudioChannelSet::stereo();if(!processor->setBusesLayout(fxLayout)){fxLayout.inputBuses.getReference(0)=fxLayout.outputBuses.getReference(0)=juce::AudioChannelSet::mono();require(processor->setBusesLayout(fxLayout),"Effect requires unsupported bus layout");}
                juce::MemoryBlock state;auto encodedState=fx["state"].toString();require(encodedState.length()<=24*1024*1024&&(encodedState.isEmpty()||state.fromBase64Encoding(encodedState))&&state.getSize()<=16*1024*1024&&checksum(state)==fx["sha256"].toString(),"Effect state checksum mismatch");if(state.getSize())processor->setStateInformation(state.getData(),int(state.getSize()));processor->setNonRealtime(true);processor->setRateAndBufferSizeDetails(rate,block);processor->prepareToPlay(rate,block);effects.push_back(std::move(processor));auto&loaded=*effects.back();require(loaded.getTotalNumInputChannels()>=1&&loaded.getTotalNumInputChannels()<=2&&loaded.getTotalNumInputChannels()==loaded.getTotalNumOutputChannels(),"Effect state changed supported layout");auto latency=loaded.getLatencySamples();double tail=loaded.getTailLengthSeconds();require(latency>=0&&latency<=int(rate*60)&&!std::isnan(tail)&&tail>=0,"Invalid effect latency or tail");addedLatency+=latency;if(!std::isfinite(tail)||tail>600)adaptiveTail=true;else effectTail+=tail;effectLatency.push_back(latency);auto*report=new juce::DynamicObject;report->setProperty("name",fxDescription->name);report->setProperty("uid",fxDescription->createIdentifierString());report->setProperty("latency_samples",latency);report->setProperty("tail_seconds",std::isfinite(tail)&&tail<=600?juce::var(tail):juce::var("unknown"));effectReports.add(juce::var(report));}}
            const double seconds=double(request["song_seconds"]),bpm=double(request["bpm"]);
            require(std::isfinite(seconds)&&seconds>0&&seconds<=100000&&std::isfinite(bpm)&&bpm>=20&&bpm<=300,"Invalid timeline");
            if(audioSource)require(sourceReader->lengthInSamples==int64_t(std::ceil((seconds+2)*rate)),"Audio source duration differs from timeline");
            const int numerator=int(request["numerator"]),denominator=int(request["denominator"]);require(numerator>=1&&numerator<=12&&(denominator==4||denominator==8),"Invalid meter");
            const double declaredTail=instance->getTailLengthSeconds();require(!std::isnan(declaredTail)&&declaredTail>=0,"Invalid instrument tail");adaptiveTail|=!std::isfinite(declaredTail)||declaredTail>600;const double knownTail=(audioSource?2.:0.)+effectTail+(std::isfinite(declaredTail)&&declaredTail<=600?declaredTail:0.);require(knownTail<=600,"Effect chain tail exceeds supported render budget");const double limit=double(request.getProperty("unknown_tail_seconds",0.));require(std::isfinite(limit)&&(limit==0||(limit>=2&&limit<=600)),"Invalid unknown tail limit");const bool finiteWindow=adaptiveTail&&limit>0;const double tail=adaptiveTail?(finiteWindow?std::max(limit,knownTail):600.):std::max(2.,knownTail);
            const int instrumentLatency=instance->getLatencySamples();const int latency=instrumentLatency+addedLatency;require(latency>=0&&latency<=int(rate*60),"Invalid instrument latency");
            int64_t frames=int64_t(std::ceil((seconds+tail)*rate));const int64_t processFrames=frames+latency,minimumFrames=int64_t(std::ceil((seconds+std::max(2.,knownTail))*rate));int64_t writtenFrames=0,quietFrames=0;bool tailSettled=!adaptiveTail;
            struct Event{int64_t frame;juce::MidiMessage midi;};std::vector<Event>events;
            if(auto*controls=request["controls"].getArray()){require(controls->size()<=13000000,"Too many MIDI controls");for(auto&c:*controls){auto frame=juce::int64(c["frame"]);int channel=int(c["channel"]),number=int(c["number"]),value=int(c["value"]);bool bend=c["kind"].toString()=="bend";
                require((bend||c["kind"].toString()=="cc")&&frame>=0&&frame<=int64_t(std::ceil(seconds*rate))+1&&channel>=1&&channel<=16&&number>=0&&number<=127&&value>=0&&value<=(bend?16383:127),"Invalid MIDI control");events.push_back({frame,bend?juce::MidiMessage::pitchWheel(channel,value):juce::MidiMessage::controllerEvent(channel,number,value)});}}
            auto*notes=request["notes"].getArray();require(notes&&notes->size()<=100000,"Invalid MIDI payload");
            for(auto&n:*notes){auto start=juce::int64(n["start"]),end=juce::int64(n["end"]);int channel=int(n["channel"]),pitch=int(n["pitch"]),velocity=int(n["velocity"]);
                require(start>=0&&end>start&&end<=int64_t(std::ceil(seconds*rate))+1&&pitch>=0&&pitch<=127&&velocity>=1&&velocity<=127&&channel>=1&&channel<=16,"Invalid MIDI event");
                events.push_back({start,juce::MidiMessage::noteOn(channel,pitch,juce::uint8(velocity))});events.push_back({end,juce::MidiMessage::noteOff(channel,pitch)});
            }
            std::stable_sort(events.begin(),events.end(),[](const Event&a,const Event&b){return a.frame<b.frame||(a.frame==b.frame&&a.midi.isNoteOff()&&!b.midi.isNoteOff());});
            const auto transportEnd=int64_t(std::ceil(seconds*rate));
            auto output=responseFile.getSiblingFile("audio.wav");juce::TemporaryFile temporary(output);std::unique_ptr<juce::OutputStream>stream=temporary.getFile().createOutputStream();require(bool(stream),"Cannot create render file");
            juce::WavAudioFormat wav;auto writer=wav.createWriterFor(stream,juce::AudioFormatWriterOptions{}.withSampleRate(rate).withNumChannels(2).withBitsPerSample(32).withSampleFormat(juce::AudioFormatWriterOptions::SampleFormat::floatingPoint));require(bool(writer),"Cannot create float WAV");
            atlas::music::Project clockProject;clockProject.settings.bpm=bpm;
            if(request.hasProperty("tempo_map")){auto*points=request["tempo_map"].getArray();require(points&&points->size()<=512,"Invalid tempo map");int64_t previous=0;for(const auto&t:*points){auto tick=juce::int64(t["tick"]);double pointBpm=double(t["bpm"]);require((t["tick"].isInt()||t["tick"].isInt64())&&tick>previous&&std::isfinite(pointBpm)&&pointBpm>=20&&pointBpm<=300,"Invalid tempo map point");clockProject.tempos.push_back({tick,pointBpm});previous=tick;}}
            atlas::music::TempoMap timeline(clockProject);for(const auto&s:timeline.segments)require(s.seconds<seconds,"Tempo point outside song");size_t tempoIndex=0;
            PlayHead head;struct ResetHead{juce::AudioPluginInstance&instance;decltype(effects)&chain;~ResetHead(){instance.setPlayHead(nullptr);for(auto&fx:chain)fx->setPlayHead(nullptr);}}resetHead{*instance,effects};instance->setPlayHead(&head);for(auto&fx:effects)fx->setPlayHead(&head);head.position.setBpm(bpm);head.position.setTimeSignature(juce::AudioPlayHead::TimeSignature{numerator,denominator});head.position.setIsPlaying(true);
            atlas::hosting::ParameterTransition transition(*instance,config["transition_preview"],description->version,config["cc_parameter_map"],rate,seconds);out->setProperty("transition_preview",transition.active());
            atlas::hosting::MappedCCProcessor mapped(*instance,config["cc_parameter_map"],block);atlas::hosting::AlignedPluginBlock effectBlock(2,block);juce::AudioBuffer<float>audio(2,block);size_t next=0;double peak=0;auto progress=responseFile.getSiblingFile("progress");uint32_t lastProgress=0;
            for(int64_t offset=0;offset<processFrames;){
                while(tempoIndex+1<timeline.segments.size()&&int64_t(std::llround(timeline.segments[tempoIndex+1].seconds*rate))<=offset)++tempoIndex;int count=int(std::min<int64_t>(block,processFrames-offset));if(tempoIndex+1<timeline.segments.size())count=int(std::min<int64_t>(count,int64_t(std::llround(timeline.segments[tempoIndex+1].seconds*rate))-offset));if(offset<transportEnd)count=int(std::min<int64_t>(count,transportEnd-offset));count=transition.prepare(offset,count);audio.setSize(2,count,false,false,true);audio.clear();juce::MidiBuffer midi;
                while(next<events.size()&&events[next].frame<offset+count){if(events[next].frame>=offset)midi.addEvent(events[next].midi,int(events[next].frame-offset));++next;}
                head.position.setIsPlaying(offset<transportEnd);
                if(!audioSource&&offset==transportEnd){for(int channel=1;channel<=16;++channel){midi.addEvent(juce::MidiMessage::controllerEvent(channel,64,0),0);midi.addEvent(juce::MidiMessage::allNotesOff(channel),0);}}
                double quarters=timeline.ticks(offset/rate)/atlas::music::ppq;head.position.setBpm(timeline.segments[tempoIndex].bpm);head.position.setTimeInSamples(offset);head.position.setTimeInSeconds(offset/rate);head.position.setPpqPosition(quarters);head.position.setPpqPositionOfLastBarStart(std::floor(quarters/(numerator*4./denominator))*(numerator*4./denominator));
                juce::MidiBuffer effectMidi(midi);if(audioSource){require(sourceReader->read(&audio,0,count,offset,true,true),"Cannot read source audio");for(int channel=0;channel<2;++channel)for(int frame=0;frame<count;++frame)require(std::isfinite(audio.getSample(channel,frame)),"Non-finite source audio");if(instance->getTotalNumInputChannels()==1){audio.addFrom(0,0,audio,1,0,count);audio.applyGain(0,0,count,.5f);}}mapped.process(audio,midi,[&](int delta){auto sample=offset+delta;double q=timeline.ticks(sample/rate)/atlas::music::ppq;head.position.setTimeInSamples(sample);head.position.setTimeInSeconds(sample/rate);head.position.setPpqPosition(q);head.position.setPpqPositionOfLastBarStart(std::floor(q/(numerator*4./denominator))*(numerator*4./denominator));});head.position.setTimeInSamples(offset);head.position.setTimeInSeconds(offset/rate);head.position.setPpqPosition(quarters);head.position.setPpqPositionOfLastBarStart(std::floor(quarters/(numerator*4./denominator))*(numerator*4./denominator));require(instance->getLatencySamples()==instrumentLatency,"Instrument latency changed during render; retry");
                if(instance->getMainBusNumOutputChannels()==1)audio.copyFrom(1,0,audio,0,0,count);
                for(size_t index=0;index<effects.size();++index){auto&fx=*effects[index];if(fx.getTotalNumInputChannels()==1){audio.addFrom(0,0,audio,1,0,count);audio.applyGain(0,0,count,.5f);}auto messages=effectMidi;effectBlock.process(fx,audio,messages);require(fx.getLatencySamples()==effectLatency[index],"Effect latency changed during render; retry");if(fx.getTotalNumOutputChannels()==1)audio.copyFrom(1,0,audio,0,0,count);}
                for(int ch=0;ch<2;++ch)for(int i=0;i<count;++i){float sample=audio.getSample(ch,i);require(std::isfinite(sample)&&std::abs(sample)<1000000,"Invalid instrument output");peak=std::max(peak,double(std::abs(sample)));}
                if(finiteWindow){const auto fadeFrames=int64_t(rate*.25);for(int i=0;i<count;++i){auto remaining=processFrames-1-offset-i;if(remaining<fadeFrames)for(int ch=0;ch<audio.getNumChannels();++ch)audio.setSample(ch,i,audio.getSample(ch,i)*float(remaining)/float(fadeFrames));}}
                const int skip=int(std::max<int64_t>(0,std::min<int64_t>(count,latency-offset)));if(count>skip){require(writer->writeFromAudioSampleBuffer(audio,skip,count-skip),"Instrument WAV write failed");for(int i=skip;i<count;++i){++writtenFrames;if(adaptiveTail){if(writtenFrames>=int64_t(std::ceil(seconds*rate))&&std::max(std::abs(audio.getSample(0,i)),std::abs(audio.getSample(1,i)))<1.e-5f)++quietFrames;else quietFrames=0;}}}if(adaptiveTail&&writtenFrames>=minimumFrames&&quietFrames>=int64_t(rate)){frames=writtenFrames;tailSettled=true;break;}
                auto now=juce::Time::getMillisecondCounter();if(now-lastProgress>500){require(progress.replaceWithText(juce::String(offset)),"Cannot report progress");lastProgress=now;}offset+=count;
            }
            if(audioSource)require(sourceFile.getSize()==sourceSize&&sourceFile.getLastModificationTime().toMilliseconds()==sourceModified,"Audio source changed during render");out->setProperty("tail_faded",finiteWindow&&!tailSettled);require(tailSettled||finiteWindow,"Instrument tail did not become silent within 600 seconds; release sustained notes or reduce the preset feedback before rendering");require(writer->flush(),"Cannot finish instrument WAV");writer.reset();require(temporary.overwriteTargetFileWithTemporary(),"Cannot commit instrument render");
            if(audioSource){auto*first=new juce::DynamicObject;first->setProperty("name",description->name);first->setProperty("uid",description->createIdentifierString());first->setProperty("latency_samples",instrumentLatency);first->setProperty("tail_seconds",std::isfinite(declaredTail)&&declaredTail<=600?juce::var(declaredTail):juce::var("unknown"));effectReports.insert(0,juce::var(first));}out->setProperty("source_kind",audioSource?"audio":"instrument");out->setProperty("effects",effectReports);out->setProperty("instrument_latency_samples",audioSource?0:instrumentLatency);out->setProperty("status","rendered");out->setProperty("latency_samples",latency);out->setProperty("tail_seconds",double(frames)/rate-seconds);out->setProperty("tail_policy",finiteWindow&&!tailSettled?"continuous tail, 250 ms fade":adaptiveTail?"silence-detected (-100 dBFS for 1 second, at least 2 seconds tail)":"plugin-reported");out->setProperty("frames",juce::int64(frames));out->setProperty("peak",peak);
            instance->setPlayHead(nullptr);
        }
        mark(configure?"editor_and_save":capture?"capture":"render");instance->releaseResources();
    }catch(const std::exception&e){out->setProperty("error",juce::String::fromUTF8(e.what()));}
    return responseFile.replaceWithText(juce::JSON::toString(response))?0:3;
}
}
