# Windows x86 VST2 worker

Configure this directory separately with a Windows x86 C++ toolchain and
`-DJUCE_DIR=<JUCE source>`; build target `AtlasWorker32`. Do not configure the main
DrumAtlas plugin as x86. The fixture target is `AtlasVst2Fixture32`.

Ship `AtlasWorker32.exe` beside the x64 `AtlasWorker.exe`. For development,
`DRUMATLAS_WORKER_X86` may specify an absolute bridge path. Scanner, live host,
parameter capture and offline renderer choose the worker from the DLL PE machine.
Missing bridges produce an explicit error. Worker fingerprints include both
executables, invalidating scan evidence after either changes.

The shared-memory layout is compile-time checked on both architectures. The x86
worker is large-address-aware but remains subject to 32-bit address-space limits.
Instrument and active effects in one chain must have matching bitness. Render an
instrument first to apply effects of another bitness. No universal third-party
compatibility or native DAW acceptance is implied by fixture checks.

Regression commands (absolute paths; writable TEMP/TMP):

```
python Tests/verify_vst2.py --worker <AtlasWorker32.exe> --fixture <AtlasVst2Fixture32.dll> --output <scratch>
DrumAtlasHostTests.exe <AtlasWorker.exe> <AtlasVst2Fixture32.dll> <report.json> --live
DrumAtlasHostTests.exe <AtlasWorker.exe> <AtlasVst2Fixture32.dll> <scratch> --bridge-recovery
DrumAtlasEditTests.exe --instrument-render <AtlasVst2Fixture32.dll> <scratch>
```

For the last command set `DRUMATLAS_WORKER` to the x64 worker. Run the live matrix
with `DRUMATLAS_HOST_PROBE_OFFLINE=0` and `=1`. The recovery check injects faults
only in the unshipped fixture DLL, checks audible snapshot recovery, and uses a
temporary missing-bridge override; it does not alter installed plugins.
