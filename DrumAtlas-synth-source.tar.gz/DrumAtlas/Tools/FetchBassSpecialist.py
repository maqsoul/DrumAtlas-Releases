"""Fetch a pinned original FP32 bass model for local separation testing.

The conversion's model card declares MIT. Check upstream weight terms before
redistributing; this downloader does not grant rights to training data/weights.
"""
import argparse
import hashlib
from pathlib import Path
import urllib.request

REVISION = "410457f134bf91cb3ecb74abf1a897882d26afa8"
NAME = "htdemucs_ft_bass.onnx"
SHA256 = "2a74d9283fc2336fcc58d50f87a7080aff57aea372f65cfe3f0211ea1ff16182"
SIZE = 316446953
URL = f"https://huggingface.co/StemSplitio/htdemucs-ft-bass-onnx/resolve/{REVISION}/{NAME}"


def verified(path):
    if not path.is_file() or path.stat().st_size != SIZE:
        return False
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest() == SHA256


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("model_dir", type=Path)
    args = parser.parse_args()
    args.model_dir.mkdir(parents=True, exist_ok=True)
    target = args.model_dir / NAME
    if verified(target):
        print("Model already verified:", target)
        return
    partial = target.with_suffix(".download")
    with urllib.request.urlopen(URL, timeout=60) as source, partial.open("wb") as output:
        while block := source.read(1024 * 1024):
            output.write(block)
    if not verified(partial):
        raise RuntimeError("Size/SHA-256 verification failed; existing model unchanged")
    partial.replace(target)
    print("Downloaded and verified:", target)


if __name__ == "__main__":
    main()
