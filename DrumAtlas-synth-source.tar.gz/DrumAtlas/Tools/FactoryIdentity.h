#pragma once
#include <juce_audio_processors/juce_audio_processors.h>
#if JUCE_WINDOWS
#include <juce_audio_processors_headless/format_types/VST3_SDK/pluginterfaces/base/ipluginbase.h>
#endif
namespace atlas::hosting {
struct FactoryClass {juce::String cid,name;int uid=0;};
inline std::vector<FactoryClass> factoryClasses(const juce::File&path){
 std::vector<FactoryClass> result;
#if JUCE_WINDOWS
 auto binary=path.isDirectory()?path.getChildFile("Contents/x86_64-win").getChildFile(path.getFileName()):path;
 juce::DynamicLibrary library;if(!library.open(binary.getFullPathName()))throw std::runtime_error("Cannot load VST3 factory for class identity");
 using Entry=bool(PLUGIN_API*)();auto init=reinterpret_cast<Entry>(library.getFunction("InitDll"));if(init&&!init())throw std::runtime_error("VST3 factory initialization failed");
 struct Exit{Entry callback;~Exit(){if(callback)callback();}}exit{reinterpret_cast<Entry>(library.getFunction("ExitDll"))};
 auto get=reinterpret_cast<GetFactoryProc>(library.getFunction("GetPluginFactory"));if(!get)throw std::runtime_error("VST3 factory export missing");auto*factory=get();if(!factory)throw std::runtime_error("VST3 factory unavailable");struct Release{Steinberg::IPluginFactory*p;~Release(){p->release();}}release{factory};
 const int count=factory->countClasses();if(count<0||count>65536)throw std::runtime_error("Invalid VST3 class count");
 for(int index=0;index<count;++index){Steinberg::PClassInfo info{};if(factory->getClassInfo(index,&info)!=Steinberg::kResultOk)continue;if(std::strncmp(info.category,"Audio Module Class",sizeof(info.category))!=0)continue;Steinberg::FUID id(info.cid);char text[33]{};id.toString(text);juce::uint32 hash=0;for(auto value:{id.getLong1(),id.getLong2(),id.getLong3(),id.getLong4()})hash=hash*31+value;result.push_back({juce::String::fromUTF8(text,32),juce::String::fromUTF8(info.name,int(sizeof(info.name))).trim(),int(hash)});}
#endif
 return result;
}
inline juce::String classIdentity(const std::vector<FactoryClass>&classes,const juce::PluginDescription&description){juce::String result;for(const auto&entry:classes)if(entry.uid==description.uniqueId&&entry.name==description.name){if(result.isNotEmpty())throw std::runtime_error("Ambiguous VST3 class hash; refusing to load the wrong class");result=entry.cid;}
#if JUCE_WINDOWS
if(result.isEmpty())throw std::runtime_error("Factory class identity does not match plugin metadata");
#endif
return result;}

inline juce::String classIdentity(const juce::File&path,const juce::PluginDescription&description){return classIdentity(factoryClasses(path),description);}
}
