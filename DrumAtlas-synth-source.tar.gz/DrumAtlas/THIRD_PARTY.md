# Third-party components, DrumAtlas 0.6.1

## HTDemucs FT bass specialist (local 1.0.0 stem update)

Pinned conversion: https://huggingface.co/StemSplitio/htdemucs-ft-bass-onnx
Revision: `410457f134bf91cb3ecb74abf1a897882d26afa8`.
File: `htdemucs_ft_bass.onnx`, 316446953 bytes.
SHA-256: `2a74d9283fc2336fcc58d50f87a7080aff57aea372f65cfe3f0211ea1ff16182`.
Original FP32 weights/compute; only output 1 (bass) is used.
The conversion model card declares MIT. This is provenance, not independent
clearance of upstream trained-weight/data terms for public redistribution.
The current change is a local Windows update; no new model is publicly published.

## Optional HTDemucs FT drums specialist (1.0.0 stem update)
Original model: Meta / Facebook Research Demucs, MIT, https://github.com/facebookresearch/demucs
ONNX export: https://huggingface.co/StemSplitio/htdemucs-ft-drums-onnx
Pinned revision: 55f929d333054c69ae0e829b15e8f8826a39d6eb (model card declares MIT).
File: htdemucs_ft_drums.onnx, 316446953 bytes, original FP32 weights unchanged.
SHA-256: f76b68af36066e38885b369299b5032a861038f9b49da5aa6cf1c31cfa69cf27.
Only the drums output of this specialist is used. The other three outputs are
not substitutes for the separate bass/other/vocals specialists.
The original DEMUCS-LICENSE.txt is included with the existing Demucs distribution.
Download/verification recipe: Tools/FetchDrumSpecialist.py. Runtime inference is native;
Python is only a developer download tool, not a user dependency.

## JUCE 9.0.3
https://github.com/juce-framework/JUCE/tree/9.0.3

This package uses JUCE under the AGPLv3 open-source licensing route. JUCE source
and its licence are supplied with this release. Embedded codecs and the VST3 SDK
retain their upstream notices. DrumAtlas application source is AGPL-3.0-or-later.

## ONNX Runtime DirectML 1.24.4
https://github.com/microsoft/onnxruntime/releases/tag/v1.24.4
https://github.com/microsoft/onnxruntime

Copyright Microsoft Corporation. MIT licence. The release includes the official
Windows x64 runtime DLL, licence, and ThirdPartyNotices.txt. Build headers are
included in the corresponding DrumAtlas source. Debug symbols are not distributed.

## YAMNet
Google/TensorFlow YAMNet, Apache License 2.0.
Original implementation and training taxonomy:
https://github.com/tensorflow/models/tree/master/research/audioset/yamnet
Original model: https://www.kaggle.com/models/google/yamnet/tensorFlow2/yamnet/1

ONNX conversion by zeropointnine, model card declares Apache-2.0:
https://huggingface.co/zeropointnine/yamnet-onnx

Distributed files: yamnet.onnx, yamnet_class_map.csv. No retraining or modification
of the model weights was performed. DrumAtlas groups predicted classes, extracts
embeddings and combines these with acoustic features. Scores do not establish
identity of original samples or a calibrated percentage of perceptual similarity.

## Installer
Built with Inno Setup 6.2.2, https://github.com/jrsoftware/issrc/releases/tag/is-6_2_2.
Installer source and generated artwork are supplied in the application source.
The Inno Setup copyright/licence notice is included with release notices.

No user audio, commercial sample library or downloaded music is bundled.
Regression tests generate their own synthetic audio.

## libsndfile 1.2.2
Official Windows x64 release: https://github.com/libsndfile/libsndfile/releases/tag/1.2.2
LGPL-2.1-or-later, dynamically loaded. The DLL remains replaceable in Models.
The original source archive, official Windows distribution and licence are included.
API: https://libsndfile.github.io/libsndfile/api.html

## Harmonic/percussive separation
DrumAtlas's own median-filter HPSS implementation uses soft masks and overlap-add;
an additional transient gate preserves low-frequency drum attacks. Reference method:
https://librosa.org/doc/main/generated/librosa.decompose.hpss.html
No librosa code or dependency is bundled. HPSS is not a learned multi-instrument stem separator.
## Demucs 6-source ONNX (0.4)

Local source separation uses the MIT-licensed HT-Demucs 6-source model, ONNX export by StemSplit.
Model: https://huggingface.co/StemSplitio/htdemucs-6s-onnx
Original: https://github.com/facebookresearch/demucs
Export code: https://github.com/StemSplit/demucs-onnx
The fp16weights artifact is distributed as Models/htdemucs_6s.onnx (float32 computation).
Its SHA-256 and upstream revision are recorded in DEMUCS-PROVENANCE.json.
Full original and export MIT notices accompany the release in Licenses.
Windows Media Foundation uses operating-system components and is not redistributed.

## Detailed separation (0.6.0 personal beta)

MDX23C DrumSep ONNX from scragnog/HOT-Step-CPP-SuperSep, revision 440487b8300dcd61453cc52ec244a38150b03456. SHA256 dd94f6605e1ff42b11b6d7232117fb25ae24870613d25d8a6d083e2fd868b01d. Original weight redistribution terms are unconfirmed; architecture/export MIT notices do not grant a weight licence. Public/commercial redistribution is not cleared. See DRUM-SEPARATION-RU.md.

AudioSep ResUNet ONNX from niobures/AudioSep, revision b508693e47fcb996073cd18787debfb2c40dca65, models/ailia-models/audiosep_resunet.onnx. SHA256 030b1ff2af237e753ed5441c3a11358defaf2a706d7e037af681e4282b0ec179. Original AudioSep and ailia conversion MIT notices are included. Fixed query embeddings and original input BatchNorm coefficients are in percussion-prompts.json. BatchNorm extracted from official audo/AudioSep audiosep_base_4M_steps.ckpt, SHA256 f8cda01bfd0ebd141eef45d41db7a3ada23a56568465840d3cff04b8010ce82c; text encoder SHA256 f3cb68423900435937ff5c139f1c867ef8d1b0c05e5023c64f3446a24c08d3de. Neither checkpoint nor text encoder is distributed.

## DirectML acceleration (0.6.1)
Runtime DLLs are from the official onnxruntime-directml 1.24.4 Windows x64 CPython 3.12 wheel on PyPI, SHA256 f2ecb68b7b7b259d2ef3112ae760149f9b5a1e7c0fbb73d539da6250a648a614. Only onnxruntime.dll and DirectML.dll are redistributed, with Microsoft licence/notices. The standard ONNX modes do not require Python; the optional local synth-layer worker below uses a separate Python environment. Headers match ORT v1.24.4. Model weights are unchanged.
Documentation: https://onnxruntime.ai/docs/execution-providers/DirectML-ExecutionProvider.html
DirectML.dll is the unmodified Microsoft DirectML 1.15.4 redistributable, under the Microsoft Software License Terms for DirectML (Windows/Xbox use), not the repository's source-code MIT licence. The complete redistributable terms are included as DIRECTML-LICENSE.txt. Official terms: https://www.nuget.org/packages/Microsoft.AI.DirectML/1.15.4/License

## Pitch/time processing (1.0.0)
Signalsmith Stretch, MIT, https://github.com/Signalsmith-Audio/signalsmith-stretch
Revision a670068d9aeb64913331d5cc29337b19a457a7df.
Signalsmith Linear, MIT, https://github.com/Signalsmith-Audio/linear
Revision 146b26f91b48835d665fa0498d64d9617818d27a.
Unmodified headers and original MIT notices accompany the source/release.

### Vocal specialist (local quality update)

HTDemucs FT vocal-only ONNX export: https://huggingface.co/StemSplitio/htdemucs-ft-vocals-onnx/tree/2ef0d757d3e226d0da85fb8c71514f464fcabdd0 . FP32, 316446953 bytes; SHA-256 `8c5d5e2da1f27050240bb80236673307ee3b40d4b064066d9350f4d64bfd544d`. Only output row 3 is used. The export card declares MIT; original Demucs attribution and weight provenance above still apply. No claim of artifact-free or perfect separation.

### Clean vocal / Maximum (local quality update)

Mel-Band RoFormer ONNX: https://huggingface.co/smank/mel-band-roformer-vocals-onnx/tree/60cb6b4b97e41b42f7ff16c2e386f47a8cc7e50a . Original FP32 artifact `melband_roformer_vocals.onnx`, 953292899 bytes, SHA-256 `64a4f3bee48fbe7d971b23875adc924ed004c3533f49672592641dddc0f6f561`. The export card declares MIT and credits KimberleyJensen's vocal weights, ZFTurbo/lucidrains architecture, and the Mixxx convolutional STFT conversion. Input is stereo 44100 Hz / 352800 frames. Only source 0 (vocals) is used; source 1 is residual accompaniment. DrumAtlas zero-pads each channel from 343980 to 352800 samples and crops it back before overlap-add. No weight quantization or sample clipping. This local update does not authorize public redistribution beyond the upstream terms.


### Bundled local synth-layer worker

MuS3D source: https://github.com/REMUS-Aalto/Mus3D , revision
308a785814f9bfc8563c9eb2fb1ccc9c502a0d9c. Main source MIT; the query-conditioned
BS-Locoformer component has Apache-2.0 attribution. We use SEG_mixemb and
BS-Locoformer_query, not the SAM Audio DiT separator. Model card:
https://huggingface.co/remus-aalto/MuS3D/tree/ea60328e89e0cefaa8e3a2fcc6dfebdc286f897e
declares CC-BY-4.0. Model hashes and local adaptation are recorded in
SYNTH-LAYERS-PROVENANCE.json. Windows attention uses PyTorch's math SDPA backend,
split along independent batch rows; model weights and attention sequences are
unchanged. The patch is supplied in Tools/MuS3D-Windows-Attention.patch.

The standalone runtime also uses upstream PaSST/OpenMIC and the separately
licensed facebook/dacvae-watermarked encoder. Original MIT, Apache-2.0,
CC BY 4.0 and SAM notices accompany the runtime in SynthLayers/Licenses.
Frozen encoders retain upstream BF16 on supported CUDA devices and FP32 on CPU;
the separator uses FP32. The installer includes an isolated CPython interpreter,
PyTorch and supporting packages with their wheel licence files. The builder
records exact installed versions and pinned model/source revisions. No personal
Python environment, Hugging Face credentials or user audio is redistributed.
See Installer/build-synth-runtime.py for reproducible assembly and
Installer/check-synth-runtime.py for offline inference validation.


## Optional Windows NVIDIA stem acceleration

The isolated `AtlasStemGpu` helper uses ONNX Runtime GPU 1.24.4 (MIT) and NVIDIA
CUDA 12 runtime/cuBLAS/cuFFT/cuRAND/NVRTC/nvJitLink and cuDNN 9 components under
their supplied NVIDIA SDK/EULA terms. Original notices accompany the local
bundle in `Tools/StemGPU/Licenses`. No Python interpreter is needed at runtime.
The bundle uses already-downloaded official package DLLs. The Mel-Band RoFormer
weights above remain unchanged: `Tools/prepare_vocal_gpu.py` reproducibly rewrites
FP32 attention operations and records source/derived SHA-256 values. See
`docs/MAXIMUM-ACCELERATION.md` for scope, fallbacks and measured validation.

## Interface fonts
Ubuntu Sans is the selected interface and wordmark typeface, including Kazakh Cyrillic. The original variable font and Ubuntu Font Licence 1.0 are bundled as Resources/Fonts/UbuntuSans.ttf and UbuntuSans-LICENCE.txt. Source: https://github.com/google/fonts/tree/main/ufl/ubuntusans . The following former theme fonts remain available as bundled resources for compatibility.
Manrope and Space Grotesk are embedded from the Google Fonts repository. Original font files and SIL Open Font License texts are in Resources/Fonts.
Sources: https://github.com/google/fonts/tree/main/ofl/manrope and https://github.com/google/fonts/tree/main/ofl/spacegrotesk .

Noto Sans is embedded for the complete Kazakh alphabet (Latin and Cyrillic use the same face in Kazakh UI). Source: https://github.com/google/fonts/tree/main/ofl/notosans . Copyright 2022 The Noto Project Authors. Licensed under SIL Open Font License 1.1; original font and license are included in Resources/Fonts/NotoSans.ttf and NotoSans-OFL.txt.


## AI composer instrument host
The isolated VST2 host uses the GPL-3.0 FST headers. Original license, upstream commit
and integration notices are included under ThirdParty/fst. VST3 hosting uses JUCE's
bundled VST3 interfaces. No third-party instrument binaries or sample libraries
are redistributed. The local chat runtime and GGUF weights remain external,
user-selected files; this change does not redistribute them.
