"""Windows regression: progress readers must not abort a synth separation job."""
import ctypes
from ctypes import wintypes
import importlib.util
import json
import os
from pathlib import Path
import tempfile
import threading
import time
import unittest

worker_path = Path(os.environ.get('SYNTH_WORKER_UNDER_TEST',
                                str(Path(__file__).resolve().parents[1] / 'Tools/SynthLayersWorker.py')))
spec = importlib.util.spec_from_file_location('synth_worker', worker_path)
worker = importlib.util.module_from_spec(spec)
spec.loader.exec_module(worker)


@unittest.skipUnless(os.name == 'nt', 'Requires actual Windows file sharing')
class ProgressTests(unittest.TestCase):
    def setUp(self):
        self.folder = tempfile.TemporaryDirectory()
        self.addCleanup(self.folder.cleanup)
        self.path = Path(self.folder.name) / 'progress.json'
        worker.save_json(self.path, {'fraction': 0})
        self.kernel = ctypes.WinDLL('kernel32', use_last_error=True)
        self.kernel.CreateFileW.argtypes = [wintypes.LPCWSTR, wintypes.DWORD, wintypes.DWORD,
                                           ctypes.c_void_p, wintypes.DWORD, wintypes.DWORD, wintypes.HANDLE]
        self.kernel.CreateFileW.restype = wintypes.HANDLE
        self.kernel.CloseHandle.argtypes = [wintypes.HANDLE]
        self.kernel.CloseHandle.restype = wintypes.BOOL

    def lock_reader(self):
        # Match a reader permitting read/write, but not rename/delete.
        handle = self.kernel.CreateFileW(str(self.path), 0x80000000, 3, None, 3, 0x80, None)
        if handle == ctypes.c_void_p(-1).value:
            raise ctypes.WinError(ctypes.get_last_error())
        return handle

    def test_original_replace_reproduces_failure(self):
        handle = self.lock_reader()
        try:
            temp = self.path.with_suffix('.tmp')
            temp.write_text('{}')
            with self.assertRaises(PermissionError):
                temp.replace(self.path)
        finally:
            self.kernel.CloseHandle(handle)

    def test_transient_reader_retries_successfully(self):
        handle = self.lock_reader()
        release = threading.Timer(0.06, self.kernel.CloseHandle, (handle,))
        release.start()
        try:
            self.assertTrue(worker.save_json(self.path, {'fraction': 0.5}, required=False))
        finally:
            release.join()
        self.assertEqual(json.loads(self.path.read_text())['fraction'], 0.5)

    def test_busy_progress_preserves_previous_json_then_recovers(self):
        handle = self.lock_reader()
        started = time.monotonic()
        try:
            self.assertFalse(worker.save_json(self.path, {'fraction': 0.5}, required=False))
            self.assertEqual(json.loads(self.path.read_text()), {'fraction': 0})
            self.assertFalse(self.path.with_suffix('.json.tmp').exists())
        finally:
            self.kernel.CloseHandle(handle)
        self.assertLess(time.monotonic() - started, 1.0)
        self.assertTrue(worker.save_json(self.path, {'fraction': 1}, required=False))
        self.assertEqual(json.loads(self.path.read_text()), {'fraction': 1})

    def test_required_result_cannot_silently_disappear(self):
        handle = self.lock_reader()
        try:
            with self.assertRaises(PermissionError):
                worker.save_json(self.path, {'ok': True})
        finally:
            self.kernel.CloseHandle(handle)

    def test_missing_directory_optional_vs_required(self):
        absent = self.path.parent / 'absent' / 'progress.json'
        self.assertFalse(worker.save_json(absent, {}, required=False))
        with self.assertRaises(FileNotFoundError):
            worker.save_json(absent, {})

    def test_atomic_utf8_and_final_result(self):
        worker.save_json(self.path, {'phase': 'Готово', 'fraction': 1}, required=False)
        result = self.path.parent / 'result.json'
        self.assertTrue(worker.save_json(result, {'ok': True, 'frames': 441000}))
        self.assertEqual(json.loads(self.path.read_text(encoding='utf-8'))['phase'], 'Готово')
        self.assertTrue(json.loads(result.read_text())['ok'])


class DiscoveryTests(unittest.TestCase):
    def test_full_track_includes_late_synth_section(self):
        anchors=worker.candidate_anchors([(i*441000, 10 if i==2 else 1) for i in range(18)], 180*44100, 441000)
        self.assertEqual(anchors[0],2*441000)
        self.assertTrue(any(at>=140*44100 for at in anchors))
        self.assertLessEqual(len(anchors),7)

    def test_short_track_and_silence(self):
        self.assertEqual(worker.candidate_anchors([],1000,441000),[0])
        self.assertEqual(worker.candidate_anchors([(0,0)],1000,441000),[0])

    def test_do_not_rename_guitar_or_noise_as_synth(self):
        class Classifier:
            thresholds=[.4,.4,.4]
            def proba(self,embeddings,level):
                return [[.95,.1,.15],[.1,.3,.2]],['guitar','synth_lead','synth_pad']
        self.assertEqual(worker.synth_candidates(None,Classifier()),[])

    def test_confident_synth_evidence(self):
        class Classifier:
            thresholds=[.4,.6,.4]
            def proba(self,embeddings,level):
                return [[.1,.9,.1],[.1,.1,.8]],['guitar','synth_lead','synth_pad']
        result=worker.synth_candidates(None,Classifier())
        self.assertEqual([(r[1],r[2]) for r in result],[('Synth Part',0),('Synth Pad',1)])


if __name__ == '__main__':
    unittest.main(verbosity=2)
