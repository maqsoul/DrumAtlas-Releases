#include "../Source/Neural.h"
#include "../Source/Engine.h"
#include <iostream>
#include <random>
#include <stdexcept>

static void require(bool v, const char* message) { if (!v) throw std::runtime_error(message); }
static std::vector<float> tone(double hz, double seconds, bool decay = true) {
    std::vector<float> v(size_t(atlas::analysisRate * seconds));
    for (size_t i = 0; i < v.size(); ++i) { const double t = i / atlas::analysisRate;
        v[i] = float(std::sin(juce::MathConstants<double>::twoPi * hz * t) * (decay ? std::exp(-t * 12) : 1)); }
    return v;
}
int main(int argc,char**argv) {
    try {
        using namespace atlas;
        if(argc>1){juce::AudioFormatManager basic,extended;basic.registerBasicFormats();registerFormats(extended);int failures=0;for(int a=1;a<argc;++a){juce::File target(juce::String::fromUTF8(argv[a]));juce::Array<juce::File>files;if(target.isDirectory())files=target.findChildFiles(juce::File::findFiles,false,"*.mp3;*.wav");else files.add(target);for(auto&file:files){std::unique_ptr<juce::AudioFormatReader>original(basic.createReaderFor(file));auto decoded=decode(extended,file);std::cout<<file.getFileName()<<" | previous="<<(original?"OK":"FAIL")<<" | extended="<<(decoded.error.isEmpty()?"OK":decoded.error.toRawUTF8())<<" | duration="<<decoded.duration<<"\n";if(decoded.error.isNotEmpty())++failures;else{auto tail=decode(extended,file,std::max(0.,decoded.duration-1),1);if(tail.error.isNotEmpty()){++failures;std::cout<<"TAIL FAIL: "<<tail.error<<"\\n";}}}}return failures?1:0;}
        require(nameLabel("no kick").category=="Other","No kick is not positive metadata");
        require(nameLabel("without_kick_snare").category!="Kick","Without kick excludes kick");
        require(nameLabel("kickless_loop").category=="Other","Kickless is not kick");
        require(nameLabel("Perc Shaker").category=="Shaker","Specific percussion name overrides generic tag");
        require(nameLabel("Conga_02").category=="Conga"&&nameLabel("Bongo_01").category=="Bongo","Separate hand percussion categories");
        require(nameLabel("Ride Cymbal").category=="Ride"&&nameLabel("Crash").category=="Crash","Ride and crash categories");
        require(nameLabel("without bongo").category!="Bongo","Negative percussion label");
        require(nameLabel("FX_Riser_01").category=="FX","FX category");
        require(nameLabel("kick_snare_loop").category=="Other","Mixed loop is not a kick one-shot");
        require(pathLabel(juce::File("C:/library/Kicks/processed/001.wav"),{"C:/library"}).category=="Kick","Nested category folders");
        require(pathLabel(juce::File("C:/library/Kicks/no kick loop.wav"),{"C:/library"}).category!="Kick","Negative filename blocks inherited folder category");
        require(pathLabel(juce::File("C:/library/Kicks/percussion.wav"),{"C:/library"}).category=="Percussion","Explicit filename wins over folder");
        require(pathLabel(juce::File("C:/library/Kicks/Snares/001.wav"),{"C:/library"}).category=="Snare","Nearest folder wins");
        require(pathLabel(juce::File("C:/library/Kicks and Snares/001.wav"),{"C:/library"}).category=="Other","Pack with mixed instruments is ambiguous");
        require(pathLabel(juce::File("C:/library/Kicks/without kick/kick01.wav"),{"C:/library"}).category!="Kick","Negative folder blocks kick");
        require(pathLabel(juce::File("C:/library/Kicks/Snares and Kicks/001.wav"),{"C:/library"}).category=="Other","Mixed inner folder must not inherit single outer category");
        const auto kick = tone(65, 0.5);
        const auto f = describe(kick);
        require(classify({}, f, 0.5, {}).category == "Kick", "Low decaying tone should be kick candidate");
        auto quieter = kick; for (auto& v : quieter) v *= 0.04f;
        require(distance(f, describe(quieter)) < 0.001f, "Search should be level invariant");
        auto padded = kick; padded.insert(padded.begin(), 4000, 0); padded.insert(padded.end(), 4000, 0);
        require(distance(f, describe(padded)) < 0.001f, "Silence padding should not change timbre");
        std::vector<float> noise(11025); std::mt19937 rng(123);
        for (size_t i = 0; i < noise.size(); ++i) noise[i] = std::uniform_real_distribution<float>(-1, 1)(rng) * std::exp(-float(i) / 2200);
        require(distance(f, describe(tone(75, 0.5))) < distance(f, describe(noise)), "Nearby low tone should rank above noise");
        require(classify("Pack_Kick_01", describe(noise), 0.5, {}).category == "Kick", "Filename category detection");
        require(classify("Vocal_Kick_back_01", f, .5, {}).category == "Vocal", "Vocal filename must not be stolen by the word kick");
        Sample sample;sample.name="Kick voice.wav";sample.category="Vocal";sample.kind="One-shot";sample.genres.add("House");
        require(!matchesFilters(sample,"Kick",{}, {},{}), "Strict category excludes vocals even if filename says Kick");
        require(matchesFilters(sample,"Vocal","One-shot","House","voice"), "Combined exact category/type/genre and text filters");
        require(!matchesFilters(sample,"Vocal","Loop",{},{}), "Strict type filtering");
        require(!matchesFilters(sample,{}, {},"Techno",{}), "Strict genre filtering");
        for(auto cat:{"Kick","Snare","Clap","Open Hat","Closed Hat","Tom","Rim","Cymbal","Ride","Crash","Percussion","Shaker","Conga","Bongo","Tambourine","Cowbell","Claves","Guiro","Woodblock"}){sample.category=cat;require(matchesFilters(sample,"Drums","One-shot","House","voice"),"Drums includes kit and hand percussion while retaining other filters");require(!matchesFilters(sample,"Drums","Loop",{},{}),"Drums still respects sample type");}
        for(auto cat:{"Vocal","Bass","Keys","Guitar","Synth","Strings","Brass","Instrument","FX","Other"}){sample.category=cat;require(!matchesFilters(sample,"Drums",{},{},{}),"Drums excludes melodic, vocal, FX and unknown categories");}
        require(genreTags("Pack_Hip-Hop_Kick.wav").contains("Hip-Hop"), "Genre metadata tokenisation");
        Neural neural; require(neural.available(), neural.error().toRawUTF8());
        auto neuralKick=neural.analyse(kick);require(neuralKick.valid&&neuralKick.embedding.size()==1024,"Real YAMNet inference and embedding");
        auto embedded=f;embedded.embedding=neuralKick.embedding;
        require(fromJson(juce::JSON::parse(juce::JSON::toString(toJson(embedded)))).embedding==embedded.embedding,"Quantised embedding cache roundtrip");
        require(classify("foo_OPEN_HAT_23", f, 0.5, {}).category == "Open Hat", "Open hat parsing");
        require(classify("Piano_Loop_120BPM", f, 4, {}).kind == "Loop", "Loop parsing");
        require(classify("Piano_Loop_120BPM", f, 4, {}).category == "Keys", "Instrument parsing");
        require(classify("808_C_Sub", f, 2, {}).category == "Bass", "808 parsing");
        require(classify({}, describe(std::vector<float>(22050)), 1, {}).category == "Other", "Silence must not be assigned a drum");
        std::vector<float> rhythm(44100, 0);
        for (int onset : {0, 11025, 22050, 33075}) for (int j = 0; j < 2205; ++j) rhythm[size_t(onset + j)] += kick[size_t(j)];
        auto attacks = onsets(rhythm);
        require(attacks.size() == 4, "Detect four isolated attacks");
        require(classify({}, describe(rhythm), 2, attacks).kind == "Loop?", "Regular multiple hits should suggest loop");
        auto mix=tone(440,2,false);for(size_t i=0;i<mix.size();++i)mix[i]=mix[i]*.4f+rhythm[i];auto stems=separate(mix);
        auto correlation=[](const std::vector<float>&x,const std::vector<float>&y){double xy=0,xx=0,yy=0;for(size_t i=0;i<x.size();++i){xy+=x[i]*y[i];xx+=x[i]*x[i];yy+=y[i]*y[i];}return xy/std::sqrt(xx*yy+1e-20);};
        require(correlation(stems.percussive,rhythm)>correlation(mix,rhythm),"HPSS improves drum-to-harmonic separation on controlled mixture");
        require(distance(describe(rhythm),describe(stems.percussive))<distance(describe(rhythm),describe(mix)),"Separated drums rank closer to clean drum reference");
        require(distance(f, fromJson(juce::JSON::parse(juce::JSON::toString(toJson(f))))) < 0.00001f, "Cache roundtrip");
        {Features shortHat;shortHat.duration=.08f;Features openHat;openHat.duration=.4f;NeuralResult snare;snare.instruments={{"Snare",.8f},{"Rim",.1f}};
         require(detailedHitCategory("Hi Hat",shortHat,{})=="Closed Hat"&&detailedHitCategory("Hi Hat",openHat,{})=="Open Hat","Hat event duration distinguishes estimates independently of filter");
         require(detailedHitCategory("Snare",shortHat,snare)=="Snare","Snare does not become rim without evidence");snare.instruments={{"Snare",.1f},{"Rim",.7f}};
         require(detailedHitCategory("Snare",shortHat,snare)=="Rim","Rim requires independent classifier evidence");}
        juce::AudioFormatManager fm; fm.registerBasicFormats();
        require(decode(fm, juce::File::getCurrentWorkingDirectory().getChildFile("missing-file.wav")).error.isNotEmpty(), "Missing audio error");
        std::cout << "PASS: classification, silence, gain invariance, timbre ranking, onset detection, loop inference, cache roundtrip, missing file\n";
        return 0;
    } catch (const std::exception& e) { std::cerr << "FAIL: " << e.what() << '\n'; return 1; }
}
