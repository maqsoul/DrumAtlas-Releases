#include "../Source/Engine.h"
#include <iostream>
#include <stdexcept>

int main(int argc,char**argv){try{
 if(argc!=2)return 2;
 if(juce::SystemStats::getEnvironmentVariable("DRUMATLAS_CACHE_DIR",{}).isEmpty()||juce::SystemStats::getEnvironmentVariable("DRUMATLAS_SYNTH_RUNTIME",{}).isEmpty())throw std::runtime_error("Isolated cache and runtime required");
 auto check=[](bool ok,const char*why){if(!ok)throw std::runtime_error(why);};
 atlas::Engine engine;const juce::File reference(juce::String::fromUTF8(argv[1]));
 auto run=[&]{const auto start=juce::Time::getMillisecondCounterHiRes();engine.analyseReference(reference,30,10,"Synth",true,false,2,true);
   while(engine.snapshot().busy){check(juce::Time::getMillisecondCounterHiRes()-start<900000,"Synth job timed out");juce::Thread::sleep(100);}
   auto result=engine.snapshot();if(result.status!="referenceReady")throw std::runtime_error(result.detail.toStdString());
   std::cout<<"Synth job completed in "<<(juce::Time::getMillisecondCounterHiRes()-start)/1000<<" seconds"<<std::endl;return result;};
 auto first=run();check(!first.stems.empty()&&first.stems.size()<=2,"Discovered synth layers returned");
 juce::AudioFormatManager formats;atlas::registerFormats(formats);
 for(const auto&stem:first.stems){
   check(stem.name=="Synth Part"||stem.name=="Synth Pad","Canonical synth labels");
   std::unique_ptr<juce::AudioFormatReader>reader(formats.createReaderFor(juce::File(stem.path)));
   check(reader&&reader->sampleRate==44100&&reader->numChannels==2&&reader->lengthInSamples==441000&&reader->usesFloatingPointData,"Exact stereo FLOAT output duration");
   juce::AudioBuffer<float>audio(2,441000);check(reader->read(&audio,0,441000,0,true,true),"Read layer");double power=0;
   for(int c=0;c<2;++c)for(int i=0;i<441000;++i){auto x=audio.getSample(c,i);check(std::isfinite(x),"Finite layer");power+=x*x;}
   check(power>1e-6,"Layer is audible");std::cout<<stem.name<<" -> "<<stem.path<<std::endl;
 }
 for(const auto&match:first.matches)check(match.category=="Synth","Synth results never mix drum or vocal categories");
 auto repeated=run();check(repeated.stems.size()==first.stems.size(),"Repeated stem count");
 for(size_t i=0;i<first.stems.size();++i)check(first.stems[i].path==repeated.stems[i].path,"Repeat reuses unchanged output");
 std::cout<<"Synth layers native integration passed"<<std::endl;return 0;
}catch(const std::exception&e){std::cerr<<e.what()<<std::endl;return 1;}}
