#include "../Source/Engine.h"
#include <juce_cryptography/juce_cryptography.h>
#include <iostream>
#include <stdexcept>

int main(int argc,char**argv){try{
 if(argc<2)return 2;
 const auto root=juce::SystemStats::getEnvironmentVariable("DRUMATLAS_CACHE_DIR",{});
 if(root.isEmpty())throw std::runtime_error("Isolated test cache required");
 juce::File dir(root);dir.createDirectory();
 auto check=[](bool ok,const char*why){if(!ok)throw std::runtime_error(why);};
 juce::File reference(juce::String::fromUTF8(argv[1]));
 if(argc>2){
  juce::File fixture(juce::String::fromUTF8(argv[2]));juce::MemoryBlock bytes;
  check(fixture.getChildFile("input.f32").loadFileAsData(bytes)&&bytes.getSize()==size_t(atlas::StemSeparator::frames)*2*sizeof(float),"Read parity input");
  std::vector<float>input(bytes.getSize()/sizeof(float));std::memcpy(input.data(),bytes.getData(),bytes.getSize());
  atlas::StemSeparator fine(true);check(fine.available(),"Fine-tuned model available");auto output=fine.process(input);
  check(output.size()==6&&output[0].size()==input.size(),"Fine-tuned drum output shape");
  for(int i=1;i<6;++i)check(output[i].empty(),"Discard non-specialist by-products");
  juce::MemoryBlock expectedBytes;check(fixture.getChildFile("expected.f32").loadFileAsData(expectedBytes)&&expectedBytes.getSize()==bytes.getSize(),"Read parity output");
  std::vector<float>expected(input.size());std::memcpy(expected.data(),expectedBytes.getData(),expectedBytes.getSize());
  double peak=0,error=0,power=0;for(size_t i=0;i<expected.size();++i){double diff=double(output[0][i])-expected[i];peak=std::max(peak,std::abs(diff));error+=diff*diff;power+=double(expected[i])*expected[i];}
  double snr=10*std::log10(power/std::max(1e-30,error));std::cout<<"FT parity peak error="<<peak<<" SNR="<<snr<<" dB"<<std::endl;
  check(peak<.001&&snr>75,"Native FT output matches Python reference");
 }
 atlas::Engine engine;
 auto run=[&](double start,double length,const juce::String&category,int quality){
  auto before=juce::Time::getMillisecondCounterHiRes();
  engine.analyseReference(reference,start,length,category,true,true,quality);
  while(engine.snapshot().busy){check(juce::Time::getMillisecondCounterHiRes()-before<240000,"Stem processing timed out");juce::Thread::sleep(20);}
  auto result=engine.snapshot();if(result.status!="referenceReady")throw std::runtime_error(result.detail.toStdString());
  std::cout<<"RUN start="<<start<<" length="<<length<<" quality="<<quality<<" seconds="<<result.elapsed<<" stems="<<result.stems.size()<<std::endl;
  return result;
 };
 auto first=run(0,15,{},0);check(first.stems.size()==22,"Complete stem set including melody alternative");
 auto repeat=run(0,15,{},0);check(repeat.stems.size()==first.stems.size(),"Cached stem count");
 for(size_t i=0;i<first.stems.size();++i)check(first.stems[i].path==repeat.stems[i].path,"Repeat reuses exact completed files");
 // An edited WAV with unchanged size and mtime must not be reused.
 juce::File altered(first.stems.back().path);auto time=altered.getLastModificationTime();juce::MemoryBlock bytes;check(altered.loadFileAsData(bytes)&&bytes.getSize()>128,"Read cached WAV");
 static_cast<unsigned char*>(bytes.getData())[bytes.getSize()-10]^=1;
 check(altered.replaceWithData(bytes.getData(),bytes.getSize()),"Modify cache fixture");altered.setLastModificationTime(time);
 auto repaired=run(0,15,{},0);check(repaired.stems.back().path!=altered.getFullPathName(),"Changed output invalidates cache");
 // Selection, category and quality must all produce independent results.
 auto selected=run(1,3,"Kick",0);check(selected.stems.size()==2,"Targeted drums only");
 auto thorough=run(1,3,"Kick",1);auto maximum=run(1,3,"Kick",2);
 auto fineAll=run(1,3,{},1);check(fineAll.stems.size()==22,"Fine-tuned specialists with all other stems retained");
 check(juce::SHA256(juce::File(fineAll.stems.front().path))==juce::SHA256(juce::File(thorough.stems.front().path)),"All-stem mode uses the same specialist drum output");
 check(selected.stems.front().path!=thorough.stems.front().path&&thorough.stems.front().path!=maximum.stems.front().path,"Quality modes do not share incompatible cached audio");
 juce::AudioFormatManager formats;atlas::registerFormats(formats);
 auto readStem=[&](const atlas::Snapshot&set,const juce::String&name){juce::File file;for(const auto&s:set.stems)if(s.name==name)file=juce::File(s.path);std::unique_ptr<juce::AudioFormatReader>reader(formats.createReaderFor(file));check(reader!=nullptr,"Stem exists");juce::AudioBuffer<float>audio(2,int(reader->lengthInSamples));check(reader->read(&audio,0,audio.getNumSamples(),0,true,true),"Read stem");return audio;};
 auto melody=readStem(fineAll,"Melody"),other=readStem(fineAll,"Other"),keys=readStem(fineAll,"Keys");
 for(int c=0;c<2;++c)for(int i=0;i<melody.getNumSamples();++i)check(std::abs(melody.getSample(c,i)-other.getSample(c,i)-keys.getSample(c,i))<1e-5f,"Melody is the aligned Other + Piano alternative, without added voice/drums/bass");
 auto bass=run(1,3,"Bass",1);check(bass.stems.size()==1,"Bass-only avoids unused models");
 check(juce::SHA256(juce::File(bass.stems[0].path))==juce::SHA256(juce::File(fineAll.stems[1].path)),"Parallel and selected bass preserve identical samples");
 auto vocal=run(1,3,"Vocal",1);check(vocal.stems.size()==1,"Vocal-only avoids unused models");check(juce::SHA256(juce::File(vocal.stems[0].path))==juce::SHA256(juce::File(fineAll.stems[3].path)),"All and targeted vocal use the same specialist");
 auto melodic=run(1,3,"Melody",1);check(melodic.stems.size()==1&&melodic.stems[0].name=="Melody","Selected melody is available independently");
 for(const auto&hit:melodic.hits)check(hit.category=="Keys"||hit.category=="Synth","Melody search includes only keys and synth candidates");
 if(argc>3){
  juce::File fixture(juce::String::fromUTF8(argv[3]));juce::MemoryBlock in,expected;
  check(fixture.getChildFile("input.f32").loadFileAsData(in)&&fixture.getChildFile("expected.f32").loadFileAsData(expected)&&in.getSize()==expected.getSize(),"Read bass parity fixture");
  std::vector<float>x(in.getSize()/sizeof(float)),y(x.size());std::memcpy(x.data(),in.getData(),in.getSize());std::memcpy(y.data(),expected.getData(),expected.getSize());
  atlas::StemSeparator specialist(atlas::StemSeparator::FineBass,4);check(specialist.available(),"Bass specialist available");auto result=specialist.process(x);double power=0,error=0;
  for(int i=0;i<6;++i)if(i!=1)check(result[i].empty(),"Discard bass specialist by-products");
  check(result[1].size()==y.size(),"Bass output shape");for(size_t i=0;i<y.size();++i){double d=double(result[1][i])-y[i];error+=d*d;power+=double(y[i])*y[i];}
  double snr=10*std::log10(power/std::max(1e-30,error));std::cout<<"Bass parity SNR="<<snr<<" dB"<<std::endl;check(snr>75,"Native bass matches pinned model reference");
 }
 if(argc>4){juce::File fixture(juce::String::fromUTF8(argv[4]));juce::MemoryBlock in,expected;check(fixture.getChildFile("input.f32").loadFileAsData(in)&&fixture.getChildFile("expected.f32").loadFileAsData(expected)&&in.getSize()==expected.getSize(),"Read vocal parity fixture");std::vector<float>x(in.getSize()/4),y(x.size());std::memcpy(x.data(),in.getData(),in.getSize());std::memcpy(y.data(),expected.getData(),expected.getSize());atlas::StemSeparator specialist(atlas::StemSeparator::FineVocals,4);check(specialist.available(),"Vocal specialist available");auto result=specialist.process(x);double error=0,power=0;for(int i=0;i<6;++i)if(i!=3)check(result[i].empty(),"Vocal by-products discarded");check(result[3].size()==y.size(),"Vocal shape");for(size_t i=0;i<y.size();++i){double d=double(result[3][i])-y[i];error+=d*d;power+=double(y[i])*y[i];}double snr=10*std::log10(power/std::max(1e-30,error));std::cout<<"Vocal parity SNR="<<snr<<" dB"<<std::endl;check(snr>75,"Native vocal matches original FP32 model");}
 for(const auto&set:{selected,thorough,maximum})for(const auto&stem:set.stems){
  std::unique_ptr<juce::AudioFormatReader>reader(formats.createReaderFor(juce::File(stem.path)));
  check(reader&&reader->lengthInSamples==132300&&reader->numChannels==2&&reader->usesFloatingPointData&&reader->bitsPerSample==32,"All qualities preserve selected duration and stereo");
  juce::AudioBuffer<float>audio(2,132300);check(reader->read(&audio,0,132300,0,true,true),"Decode output WAV");
  for(int c=0;c<2;++c)for(int i=0;i<132300;++i)check(std::isfinite(audio.getSample(c,i)),"Finite output");
 }
 // Prepared input is shared across queries but output must match single-query inference.
 atlas::DetailSeparator percussion(atlas::DetailSeparator::Percussion);check(percussion.available(),"AudioSep available");
 std::vector<float>input(81600);for(size_t i=0;i<input.size();++i)input[i]=.1f*std::sin(float(i)*.37f);
 auto grouped=percussion.percussionMany(input,{"Shaker","Conga"});
 for(int k=0;k<2;++k){auto single=percussion.percussion(input,k==0?"Shaker":"Conga");check(single==grouped[k],"Grouped queries preserve exact samples");}
 int calls=0;check(percussion.percussionMany(input,{"Shaker","Conga"},[&]{return ++calls>1;}).empty(),"Cancelled batch does not publish partial output");
 {
  std::vector<float>x(atlas::StemSeparator::frames*2);for(size_t i=0;i<x.size();++i)x[i]=.03f*std::sin(float(i)*.071f);
  std::vector<float>expected;{atlas::StemSeparator original(atlas::StemSeparator::FineBass,4);check(original.available(),"Cached bass available");expected=original.process(x)[1];}
  auto prepared=dir.getChildFile("prepared-models").findChildFiles(juce::File::findFiles,false,"htdemucs_ft_bass-*.ort");check(prepared.size()==1,"One prepared bass graph for this runtime/thread count");
  {juce::FileOutputStream stream(prepared[0]);check(stream.openedOk()&&stream.setPosition(16)&&stream.writeByte(char(0x7f)),"Corrupt only isolated optimized graph");stream.flush();}
  atlas::StemSeparator repaired(atlas::StemSeparator::FineBass,4);check(repaired.available(),"Corrupt prepared graph rebuilds from original model");check(repaired.process(x)[1]==expected,"Rebuilt model produces identical output");
 }
 std::cout<<"PASS: exact cache reuse, modified output invalidation, quality isolation, selected duration, shared spectra parity, cancellation\n";
 return 0;
}catch(const std::exception&e){std::cerr<<"FAIL: "<<e.what()<<std::endl;return 1;}}
