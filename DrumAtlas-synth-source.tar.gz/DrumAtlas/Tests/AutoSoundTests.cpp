#include "../Tools/AutoSound.h"
#include <iostream>

namespace {
void check(bool value,const char*message){if(!value)throw std::runtime_error(message);}
class Synth final:public juce::AudioPluginInstance {
public:
    explicit Synth(int channels=2)
        : AudioPluginInstance(BusesProperties().withOutput("Out",
              channels==2 ? juce::AudioChannelSet::stereo() : juce::AudioChannelSet::discreteChannels(channels),true)),
          fixedChannels(channels) {}
    bool isBusesLayoutSupported(const BusesLayout& layout)const override{
        return layout.getMainOutputChannelSet().size()==fixedChannels;
    }
    const int fixedChannels;
    const juce::String getName()const override{return "Audition fixture";}
    void fillInPluginDescription(juce::PluginDescription&d)const override{d.name=getName();d.pluginFormatName="Fixture";d.isInstrument=true;}
    void prepareToPlay(double rate,int)override{sampleRate=rate;reset();}
    void releaseResources()override{}
    void reset()override{phase=0;gate=false;}
    void processBlock(juce::AudioBuffer<float>&buffer,juce::MidiBuffer&midi)override{
        for(int ch=0;ch<buffer.getNumChannels();++ch)check(reinterpret_cast<std::uintptr_t>(buffer.getReadPointer(ch))%16==0,"Plugin received misaligned channel");
        check(buffer.getNumChannels()>=fixedChannels,"Missing native output buffers");
        for(int ch=2;ch<fixedChannels;++ch){check(buffer.getMagnitude(ch,0,buffer.getNumSamples())==0,"Auxiliary scratch was not cleared");juce::FloatVectorOperations::fill(buffer.getWritePointer(ch),1.f,buffer.getNumSamples());}
        auto event=midi.begin();for(int i=0;i<buffer.getNumSamples();++i){while(event!=midi.end()&&(*event).samplePosition<=i){auto message=(*event).getMessage();if(message.isNoteOn())gate=true;else if(message.isNoteOff()||message.isAllSoundOff())gate=false;++event;}
            float value=gate&&program?float(.2*std::sin(phase)):0;phase+=juce::MathConstants<double>::twoPi*(program==1?80:2000)/sampleRate;
            buffer.setSample(0,i,value);buffer.setSample(1,i,antiphase?-value:value);
        }
    }
    double getTailLengthSeconds()const override{return 0;}
    bool acceptsMidi()const override{return true;}bool producesMidi()const override{return false;}
    juce::AudioProcessorEditor*createEditor()override{return nullptr;}bool hasEditor()const override{return false;}
    int getNumPrograms()override{return programs;}int getCurrentProgram()override{return program;}
    void setCurrentProgram(int value)override{program=value;}
    const juce::String getProgramName(int i)override{return i==0?"Bass silence":i==1?"Unlabelled 01":"Bright lead";}
    void changeProgramName(int,const juce::String&)override{}
    void getStateInformation(juce::MemoryBlock&data)override{data.replaceAll(&program,sizeof(program));}
    void setStateInformation(const void*data,int count)override{if(count==sizeof(program))std::memcpy(&program,data,sizeof(program));}
    int program=0,programs=3;bool antiphase=true,gate=false;double phase=0,sampleRate=44100;
};
}
int main(int argc,char**argv){try{
    juce::ScopedJuceInitialiser_GUI gui;check(argc==2,"Scratch path required");auto root=juce::File(juce::String::fromUTF8(argv[1]));check(root.createDirectory().wasOk(),"Scratch directory");
    Synth synth;synth.prepareToPlay(44100,256);juce::PluginDescription description;synth.fillInPluginDescription(description);
    {alignas(16) float left[12]{},right[12]{};left[0]=right[8]=1.f;float*planes[]={left+1,right+1};juce::AudioBuffer<float>odd(planes,2,7);juce::MidiBuffer midi;
     midi.addEvent(juce::MidiMessage::noteOn(1,60,juce::uint8(90)),2);synth.program=1;atlas::hosting::AlignedPluginBlock workspace(2,256);workspace.process(synth,odd,midi);
     check(left[0]==1.f&&right[8]==1.f&&left[1]==0.f&&left[2]==0.f&&left[4]!=0.f,"Odd block preserves event offset, audio and surrounding samples");synth.program=0;}
    Synth multi(18);
    check(atlas::hosting::configureInstrumentOutputs(multi)&&multi.getTotalNumOutputChannels()==18,"Keep fixed native outputs");
    multi.prepareToPlay(44100,256);multi.program=1;
    const auto multiResult=atlas::hosting::autosound::probe(multi,44100,256,"Chords");
    check(multiResult.peak>.19&&multiResult.peak<.21,"Audition must return the first stereo pair without auxiliary bleed");
    auto*o=new juce::DynamicObject;juce::var request(o);o->setProperty("auto_program_role","Bass");juce::var report;
    auto notice=atlas::hosting::autosound::select(synth,description,{},request,44100,256,root.getChildFile("progress"),report);
    check(report.size()==3,"All three public sounds must be auditioned, including unnamed options");check(synth.program==1,"Bass audition must choose audible low-frequency sound over silent named Bass and bright lead");
    auto stereo=atlas::hosting::autosound::probe(synth,44100,256,"Bass");synth.antiphase=false;auto mono=atlas::hosting::autosound::probe(synth,44100,256,"Bass");check(stereo.peak>.19,"Opposite phase channels must not cancel in analysis");for(int i=0;i<12;++i)check(std::abs(stereo.bands[i]-mono.bands[i])<1e-6,"Stereo phase invariant spectrum");
    synth.program=2;auto lead=atlas::hosting::autosound::probe(synth,44100,256,"Bass");juce::Array<juce::var>bands;for(auto v:lead.bands)bands.add(v);auto*t=new juce::DynamicObject;t->setProperty("bands",bands);o->setProperty("target_features",juce::var(t));synth.program=0;
    atlas::hosting::autosound::select(synth,description,{},request,44100,256,root.getChildFile("progress"),report);check(synth.program==2,"Measured target must select bright sound for a bright reference");
    char bytes[40]{};std::memcpy(bytes,"VST3",4);const juce::String identity="0123456789ABCDEF0123456789ABCDEF";std::memcpy(bytes+8,identity.toRawUTF8(),32);auto file=root.getChildFile("matching.vstpreset");check(file.replaceWithData(bytes,sizeof(bytes)),"Write header fixture");description.pluginFormatName="VST3";
    check(atlas::hosting::autosound::matchesPreset(file,description,identity),"Matching VST3 class header");check(!atlas::hosting::autosound::matchesPreset(file,description,"00000000000000000000000000000000"),"Reject foreign plugin preset");check(file.replaceWithText("VST3"),"Write truncated fixture");check(!atlas::hosting::autosound::matchesPreset(file,description,identity),"Reject truncated preset");
    synth.fillInPluginDescription(description);synth.programs=40;
    o->setProperty("export_matched_preset",true);
    check(atlas::hosting::autosound::candidates(synth,description,identity,request).size()==40,"Find Sound must not truncate the instrument to 13 programs");
    synth.programs=1;synth.program=1;juce::MemoryBlock state;synth.getStateInformation(state);
    // JUCE wrappers may fill their description differently from the scanner.
    // Preset identity must use the scanned module description in both stages.
    description.fileOrIdentifier="scanned-wrapper-module";
    auto* config=new juce::DynamicObject;juce::var saved(config);config->setProperty("uid",description.createIdentifierString());config->setProperty("class_id",identity);
    config->setProperty("state",state.toBase64Encoding());config->setProperty("sha256",juce::SHA256(state).toHexString());
    auto captured=root.getChildFile("Saved bass.atlaspreset");check(captured.replaceWithText(juce::JSON::toString(saved)),"Save captured sound fixture");
    check(atlas::hosting::autosound::matchesPreset(captured,description,identity),"Accept captured sound with matching plugin identity");
    check(!atlas::hosting::autosound::matchesPreset(captured,description,"wrong"),"Reject captured sound for another plugin class");
    o->setProperty("preset_roots",juce::Array<juce::var>{root.getFullPathName()});o->removeProperty("target_features");synth.program=0;
    atlas::hosting::autosound::select(synth,description,identity,request,44100,256,root.getChildFile("progress"),report);
    check(synth.program==1&&report.size()==2,"Empty initial instrument must find and restore saved audible sound");
    config->setProperty("sha256","wrong");check(captured.replaceWithText(juce::JSON::toString(saved)),"Corrupt state fixture");
    check(!atlas::hosting::autosound::matchesPreset(captured,description,identity),"Reject corrupted captured sound");
    std::cout<<"PASS: audible selection, unlabelled programs, stereo phase, reference ranking and preset identity\n";return 0;
}catch(const std::exception&e){std::cerr<<e.what()<<'\n';return 1;}}
