#include "../Source/Engine.h"
#include "../Source/DrumSpectralCleanup.h"
#include "../Source/StemResampler.h"
#include "../Source/StemOutput.h"
#include <iostream>
#include <stdexcept>
int main(int argc,char**argv){try{
 if(argc<2)return 2;auto dir=juce::File(juce::String::fromUTF8(argv[1]));dir.createDirectory();
 {
  std::vector<float>power(6*15,0.f);std::fill_n(power.begin(),15,1.f);
  atlas::DrumSpectralCleanup solo(power,3,5);
  for(int i=0;i<15;++i)if(std::abs(solo.gain[i]-1)>1e-6f)throw std::runtime_error("Cleanup changed isolated source");
  std::fill_n(power.begin()+15,15,.0001f);atlas::DrumSpectralCleanup bleed(power,3,5);
  if(bleed.gain[15]>.101f||bleed.gain[0]<.999f)throw std::runtime_error("Cleanup did not suppress low-confidence leakage");
  std::fill(power.begin(),power.end(),0.f);atlas::DrumSpectralCleanup silent(power,3,5);
  for(float v:silent.gain)if(!std::isfinite(v))throw std::runtime_error("Silence cleanup");
  power[0]=std::numeric_limits<float>::quiet_NaN();bool rejected=false;try{atlas::DrumSpectralCleanup bad(power,3,5);}catch(...){rejected=true;}if(!rejected)throw std::runtime_error("Invalid cleanup power accepted");
 }
 auto save=[&](const juce::String&name,const std::vector<float>&data){if(!dir.getChildFile(name).replaceWithData(data.data(),data.size()*sizeof(float)))throw std::runtime_error("Cannot write test result");for(float v:data)if(!std::isfinite(v))throw std::runtime_error("Non-finite model result");};
 if(argc>3&&juce::String(argv[3])=="--render-kit"){
  juce::AudioFormatManager fm;atlas::registerFormats(fm);std::unique_ptr<juce::AudioFormatReader>reader(fm.createReaderFor(juce::File(juce::String::fromUTF8(argv[2]))));if(!reader)throw std::runtime_error("Cannot read kit render source");
  const double duration=reader->lengthInSamples/reader->sampleRate;
  atlas::StemResampler resampler(*reader,44100,0,duration);constexpr int n=130560,overlap=n*7/8,step=n-overlap;
  const auto total=atlas::stemFrameCount(duration,44100);atlas::DetailSeparator model(atlas::DetailSeparator::Drums);if(!model.available())throw std::runtime_error(model.error().toStdString());
  const juce::StringArray names{"Kick","Snare","Tom","Hi Hat","Ride","Crash"};
  std::vector<std::unique_ptr<juce::AudioFormatWriter>>writers;for(auto name:names)writers.push_back(atlas::createStemWriter(dir.getChildFile(name+".wav"),44100,2));
  std::vector<std::vector<float>>sums(6,std::vector<float>(2*n));std::vector<float>weights(n),window(n,1.f);
  for(int i=0;i<overlap;++i){window[i]=std::min(window[i],float(i+1)/overlap);window[n-1-i]=std::min(window[n-1-i],float(i+1)/overlap);}
  auto started=juce::Time::getMillisecondCounterHiRes();
  for(juce::int64 at=0;at<total;at+=step){
   int count=int(std::min<juce::int64>(n,total-at)),write=int(std::min<juce::int64>(step,total-at));auto result=model.drums(resampler.read(at,count,n,2),{0,1,2,3,4,5},true);
   for(int i=0;i<count;++i)weights[i]+=window[i];
   for(int s=0;s<6;++s){
    for(int c=0;c<2;++c)for(int i=0;i<count;++i)sums[s][c*n+i]+=result[s][c*n+i]*window[i];
    juce::AudioBuffer<float>audio(2,write);for(int c=0;c<2;++c)for(int i=0;i<write;++i)audio.setSample(c,i,sums[s][c*n+i]/std::max(1e-8f,weights[i]));
    if(!writers[s]->writeFromAudioSampleBuffer(audio,0,write))throw std::runtime_error("Kit render write failed");
    for(int c=0;c<2;++c){auto first=sums[s].begin()+c*n;std::move(first+step,first+n,first);std::fill(first+overlap,first+n,0.f);}
   }
   std::move(weights.begin()+step,weights.end(),weights.begin());std::fill(weights.begin()+overlap,weights.end(),0.f);
   if((at/step)%40==0)std::cout<<"Kit render "<<double(at)/44100<<" / "<<duration<<" seconds"<<std::endl;
  }
  std::cout<<"PASS kit render frames="<<total<<" wall_seconds="<<(juce::Time::getMillisecondCounterHiRes()-started)/1000<<std::endl;return 0;
 }
 auto fixture=[&](int n,int channels,int rate){std::vector<float>v(size_t(n)*channels);for(int c=0;c<channels;++c)for(int i=0;i<n;++i){double t=double(i)/rate,u=std::fmod(t,.5);v[size_t(c)*n+i]=float((.5*std::sin(t*6.283185307*65)*std::exp(-u*20)+.07*std::sin(t*6.283185307*(4150+200*c))*std::exp(-u*45)));}
  if(argc>2){juce::AudioFormatManager fm;atlas::registerFormats(fm);std::unique_ptr<juce::AudioFormatReader>r(fm.createReaderFor(atlas::ioFile(juce::File(juce::String::fromUTF8(argv[2])))));if(!r)throw std::runtime_error("Cannot decode test audio");int count=int(std::min<juce::int64>(r->lengthInSamples,juce::int64(std::ceil(double(n)*r->sampleRate/rate))+2));juce::AudioBuffer<float>raw(2,count);if(!r->read(&raw,0,count,0,true,true))throw std::runtime_error("Cannot read test audio");for(int c=0;c<channels;++c)for(int i=0;i<n;++i){double p=i*r->sampleRate/rate;int a=int(p),b=a+1;v[size_t(c)*n+i]=a+1<count?float(raw.getSample(c,a)+(raw.getSample(c,b)-raw.getSample(c,a))*(p-a)):0;}}
  return v;};
 {atlas::DetailSeparator mdx(atlas::DetailSeparator::Drums);if(!mdx.available())throw std::runtime_error(mdx.error().toStdString());std::cout<<"MDX backend: "<<mdx.backend()<<"\n";auto input=fixture(130560,2,44100);save("mdx-input.f32",input);auto result=mdx.drums(input);if(result.size()!=6)throw std::runtime_error("Six MDX stems required");for(size_t i=0;i<result.size();++i){if(result[i].size()!=261120)throw std::runtime_error("MDX output length");save("mdx-"+juce::String(int(i))+".f32",result[i]);}}
 if(argc>3&&juce::String(argv[3])=="--clean"){
  atlas::DetailSeparator model(atlas::DetailSeparator::Drums);auto input=fixture(130560,2,44100);auto start=juce::Time::getMillisecondCounterHiRes();auto clean=model.drums(input,{0,1,2,3,4,5},true);std::cout<<"Clean drums seconds: "<<(juce::Time::getMillisecondCounterHiRes()-start)/1000<<"\n";
  for(int k=0;k<6;++k)save("clean-"+juce::String(k)+".f32",clean[k]);
  auto selected=model.drums(input,{0,3},true);if(selected[0]!=clean[0]||selected[3]!=clean[3]||!selected[1].empty())throw std::runtime_error("Selected cleanup differs from full-kit cleanup");
  return 0;
 }
 {atlas::DetailSeparator model(atlas::DetailSeparator::Percussion);if(!model.available())throw std::runtime_error(model.error().toStdString());std::cout<<"AudioSep backend: "<<model.backend()<<"\n";auto input=fixture(81600,1,32000);save("perc-input.f32",input);for(auto name:juce::StringArray{"Shaker","Conga","Bongo"}){auto result=model.percussion(input,name);if(result.size()!=input.size())throw std::runtime_error("AudioSep output length");save(name+".f32",result);}}
 std::cout<<"PASS: native MDX23C six stems and AudioSep Shaker/Conga/Bongo, finite outputs and exact lengths\n";return 0;
 }catch(const std::exception&e){std::cerr<<"FAIL: "<<e.what()<<"\n";return 1;}}
