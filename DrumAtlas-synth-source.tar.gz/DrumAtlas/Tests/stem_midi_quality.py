"""Known-note audio -> native transcription -> MIDI metrics (no listening oracle).

Run using the local test Python (numpy/soundfile) with --exe and --models.
Synthetic accuracy is regression evidence, not an accuracy claim for mixed music.
"""
import argparse
import json
import math
import os
from pathlib import Path
import struct
import subprocess
import numpy as np
import soundfile as sf


def read_midi(path):
    data=path.read_bytes(); division=struct.unpack_from('>H',data,12)[0]
    pos=22; end=pos+struct.unpack_from('>I',data,18)[0]; tick=0; status=0; tempo=500000
    active={}; result=[]
    def variable():
        nonlocal pos
        v=0
        while True:
            b=data[pos];pos+=1;v=(v<<7)|(b&127)
            if b<128:return v
    while pos<end:
        tick+=variable();b=data[pos]
        if b>=128:status=b;pos+=1
        if status==255:
            kind=data[pos];pos+=1;length=variable()
            if kind==81:tempo=int.from_bytes(data[pos:pos+length],'big')
            pos+=length;continue
        if status in (240,247):pos+=variable();continue
        kind=status&240;ch=status&15;note=data[pos];pos+=1
        velocity=data[pos] if kind not in (192,208) else 0
        if kind not in (192,208):pos+=1
        seconds=tick*tempo/(division*1e6)
        if kind==144 and velocity:active[ch,note]=(seconds,velocity)
        elif kind==128 or kind==144:
            item=active.pop((ch,note),None)
            if item:result.append(dict(pitch=note,start=item[0],end=seconds,velocity=item[1],channel=ch+1))
    return sorted(result,key=lambda x:(x['start'],x['pitch']))


def fixtures(folder):
    rng=np.random.default_rng(3517); cases=[]
    def save(name,role,rate,audio,events):
        path=folder/(name+'.wav');sf.write(path,audio,rate,subtype='FLOAT')
        cases.append(dict(name=name,role=role,path=str(path),expected=events))
    for rate in (44100,48000):
        t=np.arange(int(4.2*rate))/rate;x=np.zeros_like(t);events=[]
        for at,amp in zip((0,.4,.9,1.55,2.6,3.4),(1,.25,.64,.09,1,.36)):
            u=t-at;mask=(u>=0)&(u<.32);u=np.maximum(0,u)
            phase=2*np.pi*(45*u+35*.025*(1-np.exp(-u/.025)))
            x+=mask*.65*amp*np.exp(-u*22)*np.sin(phase)
            events.append(dict(pitch=36,start=at,end=at+.08,amplitude=amp))
        save('kick_'+str(rate),'Kick',rate,x,events)
    rate=44100;t=np.arange(rate*5)/rate
    for name,role,keys,harmonics in (
        ('bass_harmonics','Bass',[28,35,33,40,28,28,45],(.08,.55,.30,.12)),
        ('bass_sub','Bass',[24,31,36,29,24,24,40],(1.,.05,.02)),
        ('bass_low','Bass',[16,19,24,28,21,16,28],(1.,.35,.22)),
        ('melody','Melody',[69,72,74,67,69,64,76],(1.,.22,.08))):
        x=np.zeros_like(t);events=[]
        for j,key in enumerate(keys):
            at=.2+j*.65;stop=at+.43;u=t-at;mask=(u>=0)&(t<stop)
            env=np.minimum(np.clip(u/.012,0,1),np.clip((stop-t)/.025,0,1))
            frequency=440*2**((key-69)/12)
            for h,weight in enumerate(harmonics,1):x+=mask*env*.27*weight*np.sin(2*np.pi*h*frequency*u)
            events.append(dict(pitch=key,start=at,end=stop))
        save(name,role,rate,x,events)
        if name=='melody':save('melody_antiphase',role,rate,np.stack([x,-x],axis=1),events)
    x=np.zeros_like(t);events=[]
    for at,keys in ((.25,[60,64,67]),(1.8,[57,60,64]),(3.25,[53,57,60])):
        stop=at+1.1;u=t-at;env=np.minimum(np.clip(u/.02,0,1),np.clip((stop-t)/.06,0,1))
        for key in keys:
            f=440*2**((key-69)/12);x+=env*.16*(np.sin(2*np.pi*f*u)+.15*np.sin(4*np.pi*f*u))
            events.append(dict(pitch=key,start=at,end=stop))
    save('chord_changes','Keys',rate,x,events)
    save('silence','Bass',rate,np.zeros(rate*3),[])
    save('noise_only','Bass',rate,rng.normal(0,.003,rate*3),[])
    save('noise_melody','Melody',rate,rng.normal(0,.003,rate*3),[])
    x=np.zeros_like(t);events=[]
    for j,key in enumerate((45,50,57,45,50)):
        at=.2+j*.8;u=np.maximum(0,t-at);f=440*2**((key-69)/12)
        x+=(t>=at)*.6*np.exp(-u*15)*np.sin(2*np.pi*f*u)
        events.append(dict(pitch=key,start=at,end=at+.08))
    save('tuned_toms','Tom',rate,x,events)
    x=np.zeros_like(t);events=[]
    for j in range(7):
        at=.2+j*.55;u=np.maximum(0,t-at);f=440*2**((33-69)/12)
        x+=(t>=at)*.3*np.exp(-u*7)*(np.sin(2*np.pi*f*u)+.4*np.sin(4*np.pi*f*u))
        events.append(dict(pitch=33,start=at,end=at+.55))
    save('repeated_bass','Bass',rate,x,events)
    x=np.zeros_like(t);events=[]
    for j,key in enumerate((69,72,74,76,74,72,69,67)):
        at=.2+j*.15;stop=at+.09;u=t-at;env=np.minimum(np.clip(u/.004,0,1),np.clip((stop-t)/.008,0,1))
        f=440*2**((key-69)/12);x+=env*.3*(np.sin(2*np.pi*f*u)+.25*np.sin(4*np.pi*f*u))
        events.append(dict(pitch=key,start=at,end=stop))
    save('fast_melody','Melody',rate,x,events)
    for name,role,key,spacing,decay in (('hat_roll','Closed Hat',42,.0625,200),('snare_ghosts','Snare',38,.32,70)):
        x=np.zeros_like(t);events=[]
        for j in range(12):
            at=.2+j*spacing;u=np.maximum(0,t-at);amp=1. if j%2==0 else .25
            noise=rng.normal(0,.3,len(t));noise[1:]-=noise[:-1].copy()
            x+=(t>=at)*amp*np.exp(-u*decay)*noise
            events.append(dict(pitch=key,start=at,end=at+.08))
        save(name,role,rate,x,events)
    # Separate stems, simultaneous known attacks, including the late track.
    t=np.arange(rate*50)/rate
    for role in ('Kick','Bass'):
        x=np.zeros_like(t);events=[]
        for beat,key in zip((4,8,16,32,64),(25,30,32,33,28)):
            at=beat*60/84;u=np.maximum(0,t-at);stop=at+.4
            if role=='Kick':
                x+=(t>=at)*.6*np.exp(-u*25)*np.sin(2*np.pi*(50*u+25*.02*(1-np.exp(-u/.02))))
            else:
                env=np.minimum(np.clip(u/.004,0,1),np.clip((stop-t)/.015,0,1))
                f=440*2**((key-69)/12);x+=env*.3*(np.sin(2*np.pi*f*u)+.3*np.sin(4*np.pi*f*u))
            events.append(dict(pitch=36 if role=='Kick' else key,start=at,end=stop,amplitude=1.))
        save('sync_84_'+role.lower(),role,rate,x,events)
        cases[-1]['bpm']=84
    (folder/'fixtures.json').write_text(json.dumps(cases,indent=2),encoding='utf8')
    return cases


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--exe',type=Path,required=True)
    parser.add_argument('--models',type=Path,required=True);parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--fixtures',type=Path);parser.add_argument('--report-only',action='store_true')
    args=parser.parse_args();args.output.mkdir(parents=True,exist_ok=True)
    cases=json.loads(args.fixtures.read_text(encoding='utf8')) if args.fixtures else fixtures(args.output)
    env=dict(os.environ,DRUMATLAS_MODEL_DIR=str(args.models.resolve()),DRUMATLAS_CACHE_DIR=str(args.output.resolve()/'cache.json'))
    results=[];failures=0
    for case in cases:
        dest=args.output/(case['name']+'.mid')
        command=[str(args.exe.resolve()),str(args.output.resolve()),'--stem',case['path'],case['role'],dest.name]
        if 'bpm' in case:command.append(str(case['bpm']))
        run=subprocess.run(command,env=env,capture_output=True,text=True,errors='replace',timeout=240)
        actual=read_midi(dest) if run.returncode==0 else []
        unmatched=list(range(len(actual)));matches=[]
        for expected in case['expected']:
            possible=[i for i in unmatched if actual[i]['pitch']==expected['pitch'] and abs(actual[i]['start']-expected['start'])<.09]
            if possible:
                i=min(possible,key=lambda k:abs(actual[k]['start']-expected['start']));unmatched.remove(i)
                matches.append((expected,actual[i]))
        metrics=dict(name=case['name'],expected=len(case['expected']),actual=len(actual),matched=len(matches),extra=len(unmatched),
                     max_onset_error=max((abs(a['start']-b['start']) for a,b in matches),default=0),notes=actual)
        success=len(matches)==len(case['expected']) and not unmatched and (run.returncode==0 or not case['expected'])
        if not case['expected'] and run.returncode!=0 and 'No confident notes or hits' not in run.stderr:success=False
        if case['role']=='Kick' and len(matches)==len(case['expected']):
            errors=[abs(b['velocity']-min(127,round(120*math.sqrt(a['amplitude'])))) for a,b in matches]
            metrics['max_velocity_error']=max(errors);success=success and max(errors)<=8 and metrics['max_onset_error']<.025
        if case['name'].startswith('sync_84_'):
            success=success and metrics['max_onset_error']<.012
        metrics['passed']=success;metrics['diagnostic']=run.stdout+run.stderr
        if not success:failures+=1
        print(json.dumps({k:v for k,v in metrics.items() if k not in ('notes','diagnostic')}),flush=True);results.append(metrics)
    synced={row['name']:row['notes'] for row in results if row['name'].startswith('sync_84_')}
    if len(synced)==2:
        pairs=list(zip(synced['sync_84_kick'],synced['sync_84_bass']))
        error=max((abs(a['start']-b['start']) for a,b in pairs),default=999)
        if error>=.012:failures+=1
        print('Cross-stem attack difference:',error,flush=True)
    (args.output/'report.json').write_text(json.dumps(results,indent=2),encoding='utf8')
    return 0 if args.report_only or not failures else 1


if __name__=='__main__':raise SystemExit(main())
