#include "../Source/PreviewVisualMeter.h"
#include <iostream>
#include <limits>
#include <stdexcept>

static void check(bool ok,const char*message){if(!ok)throw std::runtime_error(message);}
static atlas::PreviewVisualLevels tone(float hz,float gain,bool inverted=false,double rate=48000){
    atlas::PreviewVisualMeter meter;meter.begin(rate,1);
    for(int i=0;i<int(rate);++i){float x=gain*float(std::sin(6.283185307179586*hz*i/rate));meter.push(x,inverted?-x:x);}
    meter.publish();return meter.read();
}
int main(){try{
    const auto bass=tone(70,.2f),high=tone(8000,.2f),quiet=tone(70,.02f),opposite=tone(70,.2f,true);
    check(bass.bass>high.bass*8,"Bass and hi-hat must produce different band responses");
    check(high.treble>bass.treble*8,"High frequencies must excite fine motion");
    check(bass.level>quiet.level*9,"Preview gain must change motion strength");
    check(std::abs(opposite.level-bass.level)<1e-6f,"Out-of-phase stereo must not cancel visual energy");
    atlas::PreviewVisualMeter meter;meter.begin(48000,1);meter.push(1,1);meter.publish();check(meter.read().peak>.99f,"Short drum attacks must survive for the UI");
    for(int i=0;i<96000;++i)meter.push(0,0);meter.publish();check(meter.read().level<.0001f&&meter.read().peak<.0001f,"Silence must settle");
    for(int i=0;i<4800;++i)meter.push(.5f,.5f);meter.begin(48000,2);meter.push(0,0);meter.publish();check(meter.read().level==0,"New file must reset filter memory");
    meter.push(std::numeric_limits<float>::quiet_NaN(),std::numeric_limits<float>::infinity());meter.publish();check(std::isfinite(meter.read().level),"Invalid values must not poison motion");
    check(std::abs(tone(70,.2f,false,44100).level-bass.level)<.02f,"Sample rate invariance");
    std::cout<<"PASS: frequency bands, gain, stereo, transients, silence, file switch, finite values, sample rate\n";return 0;
}catch(const std::exception&e){std::cerr<<e.what()<<'\n';return 1;}}
