// Unshipped test DLL. Uses the independent GPLv3 JUCE 5.3.2 interface, not
// the FST headers used by AtlasWorker, to catch MIDI/time/state ABI mistakes.
#include <cstdint>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <cstdlib>
#include <thread>
#include <chrono>
#define JUCE_MSVC 1
#ifdef _WIN64
#define JUCE_64BIT 1
#else
#define JUCE_64BIT 0
#endif
namespace juce { using int16 = int16_t; using int32 = int32_t; using uint32 = uint32_t; using pointer_sized_int = intptr_t; }
namespace reference {
#include "../ThirdParty/fst/juce_VSTInterface-reference.h"
}
using namespace reference;
struct Synth {
    VstEffectInterface effect{};
    VstHostCallback host;
    float gain = .25f;
    double phase = 0, rate = 44100;
    bool gate = false;
    int on = -1, off = -1;
    Synth(VstHostCallback callback) : host(callback) {
        effect.interfaceIdentifier = juceVstInterfaceIdentifier;
        effect.numPrograms = 1; effect.numParameters = 1;
        effect.numOutputChannels = 2;
        effect.flags = 16 | 32 | 256; // replacing, chunks, synth
        effect.plugInIdentifier = 0x41543246; effect.plugInVersion = 1000;
        effect.effectPointer = this;
        effect.setParameterValueFunction = [](auto* e, int, float v) { self(e).gain = std::clamp(v, 0.f, 1.f); };
        effect.getParameterValueFunction = [](auto* e, int) { return self(e).gain; };
        effect.dispatchFunction = dispatch;
        effect.processAudioFunction = effect.processAudioInplaceFunction = process;
    }
    static Synth& self(VstEffectInterface* e) { return *static_cast<Synth*>(e->effectPointer); }
    static intptr_t __cdecl dispatch(VstEffectInterface* e, int op, int, intptr_t value, void* ptr, float opt) {
        auto& s = self(e);
        auto text = [ptr](const char* value) { if(ptr) std::strcpy(static_cast<char*>(ptr), value); return intptr_t(1); };
        switch(op) {
            case plugInOpcodeClose: delete &s; return 0;
            case plugInOpcodeSetSampleRate: s.rate = opt; return 0;
            case plugInOpcodeResumeSuspend: if (!value) s.gate = false; return 0;
            case plugInOpcodeGetPlugInCategory: return 2;
            case plugInOpcodeGetVstInterfaceVersion: return 2400;
            case plugInOpcodeGetManufacturerVersion: return 1000;
            case plugInOpcodeGetPlugInName: return text("Atlas VST2 Fixture");
            case plugInOpcodeGetManufacturerName: return text("DrumAtlas QA");
            case plugInOpcodeGetManufacturerProductName: return text("Atlas VST2 Fixture");
            case plugInOpcodeGetParameterName: return text("Gain");
            case plugInOpcodeGetCurrentProgramName: return text("Sine");
            case plugInOpcodeIsParameterAutomatable: return 1;
            case plugInOpcodeCanPlugInDo: return ptr && (!std::strcmp(static_cast<char*>(ptr), "receiveVstMidiEvent") || !std::strcmp(static_cast<char*>(ptr), "receiveVstEvents"));
            case plugInOpcodeGetData: *static_cast<void**>(ptr) = &s.gain; return sizeof(s.gain);
            case plugInOpcodeSetData: if (value == sizeof(s.gain) && ptr) std::memcpy(&s.gain, ptr, sizeof(s.gain)); return 0;
            case plugInOpcodePreAudioProcessingEvents: {
                auto* events = static_cast<VstEventBlock*>(ptr);
                for (int i=0; i<events->numberOfEvents; ++i) {
                    auto* midi = reinterpret_cast<VstMidiEvent*>(events->events[i]);
                    if(midi->type != vstMidiEventType) continue;
                    const int status = midi->midiData[0] & 0xf0;
                    if(status == 0x90 && midi->midiData[2]) s.on = midi->sampleOffset;
                    else if(status == 0x80 || status == 0x90) s.off = midi->sampleOffset;
                }
                return 1;
            }
            default: return 0;
        }
    }
    static void __cdecl process(VstEffectInterface* e, float**, float** out, int frames) {
        // Test DLL only: exercise the real worker audio-thread watchdog.
        if (const auto* failure = std::getenv("DRUMATLAS_HOST_TEST_FAILURE")) {
            if (std::strcmp(failure, "audio-crash") == 0) std::_Exit(78);
            if (std::strcmp(failure, "audio-hang") == 0)
                for (;;) std::this_thread::sleep_for(std::chrono::seconds(1));
        }
        auto& s = self(e);
        auto* time = reinterpret_cast<VstTimingInformation*>(s.host(e, hostOpcodeGetTimingInfo, 0, 0, nullptr, 0));
        if(time && ((time->flags & vstTimingInfoFlagTempoValid) != 0)
            && (!std::isfinite(time->tempoBPM) || time->tempoBPM <= 0 || time->sampleRate != s.rate))
            std::abort();
        for(int i=0; i<frames; ++i) {
            if(i == s.on) s.gate = true;
            if(i == s.off) s.gate = false;
            const float value = s.gate ? s.gain * float(std::sin(s.phase)) : 0.f;
            s.phase += 6.283185307179586 * 440 / s.rate;
            out[0][i] = out[1][i] = value;
        }
        s.on = s.off = -1;
    }
};
extern "C" __declspec(dllexport) VstEffectInterface* VSTPluginMain(VstHostCallback callback) {
    if(!callback || !callback(nullptr, hostOpcodeVstVersion, 0, 0, nullptr, 0)) return nullptr;
    return &(new Synth(callback))->effect;
}
