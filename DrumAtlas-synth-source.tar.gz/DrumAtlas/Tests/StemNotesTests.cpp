#include "../Source/StemSounds.h"
#include "../Source/StemMidiClock.h"
#include <iostream>
using namespace atlas;
static void check(bool condition,const juce::String& message){if(!condition)throw std::runtime_error(message.toStdString());}
static juce::File fixture(const juce::File& scratch,bool drums){
    auto file=scratch.getChildFile(drums?"hits.wav":"chord.wav");
    constexpr int rate=44100;
    juce::AudioBuffer<float> audio(1,rate*4);
    for(int i=0;i<audio.getNumSamples();++i){
        double t=double(i)/rate,v=0;
        if(drums){for(double hit:{0.25,1.,1.5,3.})if(t>=hit&&t<hit+.09)v+=.6*std::exp(-(t-hit)*48)*std::sin(2*3.14159265*70*(t-hit));}
        else if(t>.35&&t<3.3){double envelope=std::min({1.,(t-.35)*30,(3.3-t)*30});
            for(int key:{60,64,67}){double phase=2*3.14159265*440*std::pow(2.,(key-69)/12.)*t;v+=envelope*.11*(std::sin(phase)+.18*std::sin(2*phase));}}
        audio.setSample(0,i,float(v));
    }
    std::unique_ptr<juce::OutputStream> stream=file.createOutputStream();auto writer=juce::WavAudioFormat().createWriterFor(stream,juce::AudioFormatWriterOptions{}.withSampleRate(rate).withNumChannels(1).withBitsPerSample(24));
    check(writer&&writer->writeFromAudioSampleBuffer(audio,0,audio.getNumSamples()),"Cannot write fixture");return file;
}
int main(int argc,char** argv){
    try{
        check(argc>=2,"Expected scratch path");juce::File scratch(juce::String::fromUTF8(argv[1]));
        check(scratch.createDirectory().wasOk(),"Cannot create scratch");
        if((argc==6||argc==7) && juce::String(argv[2])=="--stem"){
            stemnotes::Part part;auto result=stemnotes::analyse(juce::File(juce::String::fromUTF8(argv[3])),juce::String::fromUTF8(argv[4]),part);
            check(result.wasOk(),result.getErrorMessage());result=stemnotes::writeMidi(part,argc==7?juce::String(argv[6]).getDoubleValue():120,scratch.getChildFile(juce::String::fromUTF8(argv[5])));
            check(result.wasOk(),result.getErrorMessage());std::cout<<part.role<<" / "<<part.notes.size()<<" notes\n";return 0;
        }
        if(argc==7 && juce::String(argv[2])=="--match"){
            stemnotes::Part part;auto result=stemnotes::analyse(juce::File(juce::String::fromUTF8(argv[3])),juce::String::fromUTF8(argv[4]),part,{},true);
            check(result.wasOk(),result.getErrorMessage());
            auto catalogue=juce::JSON::parse(juce::File(juce::String::fromUTF8(argv[5])));auto* choices=catalogue.getArray();check(choices!=nullptr,"Missing catalogue");
            for(auto& config:*choices)if(config["name"].toString()==juce::String::fromUTF8(argv[6])){
                stemsounds::Match match;auto r=stemsounds::findVst(config.clone(),part,match,{});
                check(r.wasOk()&&match.preset.existsAsFile()&&match.preview.existsAsFile(),r.getErrorMessage()+" preset or preview failed");
                std::cout<<part.family<<" / "<<part.role<<" / "<<part.notes.size()<<" notes\n"<<match.description<<"\n"<<match.preview.getFullPathName()<<"\n";return 0;
            }
            throw std::runtime_error("Instrument absent");
        }
        for(bool drums:{false,true}){
            auto file=fixture(scratch,drums);stemnotes::Part part;
            auto result=stemnotes::analyse(file,drums?"Kick":"Synth Pad",part);
            check(result.wasOk(),result.getErrorMessage());
            if(drums){check(part.notes.size()==4,"Expected four drum hits");for(auto& n:part.notes)check(n.pitch==36,"Kick GM pitch");}
            else{check(part.role=="Chords","Polyphonic role");for(int pitch:{60,64,67})check(std::any_of(part.notes.begin(),part.notes.end(),[&](auto& n){return n.pitch==pitch&&n.start<.55&&n.end>3.;}),"Missing sustained chord tone "+juce::String(pitch));}
            auto dest=file.withFileExtension(".mid");check(stemnotes::writeMidi(part,132,dest).wasOk(),"MIDI export");
            juce::MidiFile midi;juce::FileInputStream in(dest);check(midi.readFrom(in)&&midi.getNumTracks()==1,"MIDI readback");midi.convertTimestampTicksToSeconds();
            check(std::abs(midi.getLastTimestamp()-4.)<.002,"Trailing silence retained in MIDI clip");
            std::vector<double> times;for(auto* event:*midi.getTrack(0))if(event->message.isNoteOn()){check(event->message.getChannel()==(drums?10:1),"MIDI channel");times.push_back(event->message.getTimeStamp());}
            check(times.size()==part.notes.size()&&std::abs(times.back()-part.notes.back().start)<.002,"MIDI timing");
            if(!drums && argc>2){
                auto pluginList=juce::JSON::parse(juce::File(juce::String::fromUTF8(argv[2])));
                auto* plugins=pluginList.getArray();check(plugins!=nullptr,"Instrument catalogue missing");bool tested=false;
                for(auto& config:*plugins)if(config["name"].toString()==(argc>3?juce::String::fromUTF8(argv[3]):juce::String("Serum 2"))){
                    stemsounds::Match match;auto r=stemsounds::findVst(config.clone(),part,match,{});check(r.wasOk(),r.getErrorMessage());
                    check(match.preset.existsAsFile()&&match.preview.existsAsFile(),"Missing preset or audio");std::cout<<match.description<<"\n"<<match.preset.getFullPathName()<<"\n";tested=true;break;
                }
                check(tested,"Instrument absent");stemsounds::Match match;auto r=stemsounds::findNative(stemsounds::liveLibrary(),"Operator",part.timbre,match,{});
                check(r.wasOk()&&match.preset.existsAsFile(),r.getErrorMessage());std::cout<<match.description<<"\n";
            }
        }
        // The same audio instant must map to the same DAW beat, even when a
        // per-stem detector reports half/double tempo or a knob has been edited.
        for(double estimate:{42.,84.,126.,168.,0.})for(double ratio:{50.,100.,150.}){
            double bpm=stemnotes::exportTempo(84,estimate,ratio);
            stemnotes::Part part;part.role="grid";part.duration=180;
            for(double beat:{0.,16.,80.,240.})part.notes.push_back({36,100,beat*60/84,(beat+.25)*60/84});
            check(stemnotes::writeMidi(part,bpm,scratch.getChildFile("grid.mid")).wasOk(),"Grid export");
            juce::MidiFile grid;juce::FileInputStream in(scratch.getChildFile("grid.mid"));check(grid.readFrom(in),"Grid MIDI readback");
            int index=0;const double beats[]{0,16,80,240};
            for(auto* event:*grid.getTrack(0))if(event->message.isNoteOn())check(event->message.getTimeStamp()==beats[index++]*960,"Shared 84 BPM clock: no cumulative drift");
            check(index==4&&std::abs(grid.getLastTimestamp()-252*960)<1,"Full clip length in shared clock");
        }
        check(stemnotes::exportTempo(0,0,100)==0,"No silent 120 BPM fallback when reference tempo is unknown");
        {
            auto reference=scratch.getChildFile("clock-reference.wav"),store=scratch.getChildFile("clocks.json");
            check(reference.replaceWithText("original reference"),"Clock fixture");
            check(stemnotes::saveClock(store,reference,84).wasOk(),"Save reference clock");
            for(double host:{120.,84.,0.,126.}){
                double chosen=stemnotes::savedClock(store,reference);
                if(chosen==0)chosen=stemnotes::exportTempo(host,126,150);
                check(chosen==84,"Saved reference clock survives host change and preview stretch");
            }
            check(stemnotes::saveClock(store,reference,0).failed()&&stemnotes::savedClock(store,reference)==84,"Invalid BPM cannot overwrite shared clock");
            check(reference.appendText(" replacement"),"Change reference");
            check(stemnotes::savedClock(store,reference)==0,"Changed reference must not inherit stale clock");
        }
        std::cout<<"PASS: chord, hits, timestamps and MIDI readback\n";return 0;
    }catch(const std::exception& e){std::cerr<<e.what()<<"\n";return 1;}
}
