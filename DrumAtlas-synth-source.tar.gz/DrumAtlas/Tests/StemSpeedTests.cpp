#include "../Source/Engine.h"
#include <juce_cryptography/juce_cryptography.h>
#include <iostream>
#include <stdexcept>
#include <cstdlib>
#if JUCE_WINDOWS
#define NOMINMAX
#include <windows.h>
#endif
int main(int argc,char**argv){try{
 if(argc!=3&&argc!=4)return 2;
 auto require=[](bool ok,const char*message){if(!ok)throw std::runtime_error(message);};
 require(juce::SystemStats::getEnvironmentVariable("DRUMATLAS_CACHE_DIR",{}).isNotEmpty(),"Isolated cache required");
 const juce::File reference(juce::String::fromUTF8(argv[1]));const double duration=juce::String(argv[2]).getDoubleValue();
 require(reference.existsAsFile()&&duration>0,"Valid reference/duration required");
 auto variable=[](const char*key,const char*value){
#if JUCE_WINDOWS
 _putenv_s(key,value);SetEnvironmentVariableA(key,value);
#else
 setenv(key,value,1);
#endif
 };
 variable("DRUMATLAS_STEM_CACHE","0");atlas::Engine engine;
 if(argc==4&&juce::String(argv[3])=="--cancel"){
  variable("DRUMATLAS_VOCAL_GPU","1");engine.analyseReference(reference,30,duration,"Vocal",true,false,2);
  auto root=juce::File(juce::SystemStats::getEnvironmentVariable("DRUMATLAS_CACHE_DIR",{})).getChildFile("gpu-jobs");
  const auto start=juce::Time::getMillisecondCounterHiRes();bool ready=false;
  while(engine.snapshot().busy&&juce::Time::getMillisecondCounterHiRes()-start<45000){if(!root.findChildFiles(juce::File::findFiles,true,"ready").isEmpty()){ready=true;break;}juce::Thread::sleep(20);}
  require(ready,"GPU worker must start for cancellation test");juce::Thread::sleep(1000);engine.cancel();
  auto before=juce::Time::getMillisecondCounterHiRes();engine.analyseReference(reference,0,1,"Kick",false,false,0);
  while(engine.snapshot().busy){require(juce::Time::getMillisecondCounterHiRes()-before<20000,"Cancelled GPU must release the queue promptly");juce::Thread::sleep(20);}
  require(engine.snapshot().status=="referenceReady","Next job succeeds after GPU cancellation");require(root.findChildFiles(juce::File::findFiles,true,"ready").isEmpty(),"GPU job resources removed");
  std::cout<<"PASS GPU cancellation and following job in "<<(juce::Time::getMillisecondCounterHiRes()-before)/1000<<" seconds"<<std::endl;return 0;
 }
 auto run=[&](bool accelerated){variable("DRUMATLAS_VOCAL_GPU",accelerated?"1":"0");variable("DRUMATLAS_STEM_PIPELINE",accelerated?"1":"0");
  const auto start=juce::Time::getMillisecondCounterHiRes();double last=start;
  engine.analyseReference(reference,30,duration,{},true,true,2);
  while(engine.snapshot().busy){const auto now=juce::Time::getMillisecondCounterHiRes();require(now-start<1800000,"Separation timeout");if(now-last>30000){auto s=engine.snapshot();std::cout<<(accelerated?"GPU":"Baseline")<<" elapsed="<<(now-start)/1000<<" status="<<s.status<<" processed="<<s.processed<<"/"<<s.total<<std::endl;last=now;}juce::Thread::sleep(20);}
  auto result=engine.snapshot();if(result.status!="referenceReady")throw std::runtime_error(result.detail.toStdString());
  std::cout<<(accelerated?"GPU":"Baseline")<<" completed seconds="<<result.elapsed<<" stems="<<result.stems.size()<<std::endl;return result;
 };
 atlas::Snapshot baseline;
 const auto sourceHash=juce::SHA256(reference).toHexString();
 if(argc==4){auto report=juce::JSON::parse(juce::File(juce::String::fromUTF8(argv[3])));require(report.getProperty("source_sha256",{}).toString()==sourceHash&&double(report.getProperty("duration",0))==duration&&double(report.getProperty("start",0))==30,"Baseline reference identity");baseline.elapsed=double(report.getProperty("seconds",0));auto stems=report.getProperty("stems",{});require(stems.isArray(),"Baseline stem list");for(auto&s:*stems.getArray()){auto path=s.getProperty("path",{}).toString();require(juce::SHA256(juce::File(path)).toHexString()==s.getProperty("sha256",{}).toString(),"Baseline WAV integrity");baseline.stems.push_back({s.getProperty("name",{}).toString(),path});}std::cout<<"Reusing verified baseline seconds="<<baseline.elapsed<<std::endl;}
 else baseline=run(false);
 const auto saveReport=[&](const atlas::Snapshot&s,const char*name){auto*object=new juce::DynamicObject();object->setProperty("source_sha256",sourceHash);object->setProperty("duration",duration);object->setProperty("start",30);object->setProperty("seconds",s.elapsed);juce::Array<juce::var>stems;for(auto&stem:s.stems){auto*v=new juce::DynamicObject();v->setProperty("name",stem.name);v->setProperty("path",stem.path);v->setProperty("sha256",juce::SHA256(juce::File(stem.path)).toHexString());stems.add(juce::var(v));}object->setProperty("stems",stems);require(juce::File(juce::SystemStats::getEnvironmentVariable("DRUMATLAS_CACHE_DIR",{})).getChildFile(name).replaceWithText(juce::JSON::toString(juce::var(object))),"Write comparison report");};
 saveReport(baseline,"baseline.json");const auto fast=run(true);saveReport(fast,"accelerated.json");require(baseline.stems.size()==22&&fast.stems.size()==22,"All 22 stems retained");
 juce::AudioFormatManager formats;atlas::registerFormats(formats);
 for(size_t k=0;k<baseline.stems.size();++k){const auto&a=baseline.stems[k];const auto&b=fast.stems[k];require(a.name==b.name,"Stem ordering retained");
  const bool identical=juce::SHA256(juce::File(a.path))==juce::SHA256(juce::File(b.path));
  if(a.name!="Vocal"){require(identical,"Non-vocal stem must remain bit-identical");continue;}
  std::unique_ptr<juce::AudioFormatReader>ra(formats.createReaderFor(juce::File(a.path))),rb(formats.createReaderFor(juce::File(b.path)));
  require(ra&&rb&&ra->lengthInSamples==rb->lengthInSamples&&ra->sampleRate==rb->sampleRate&&ra->numChannels==rb->numChannels,"Identical vocal dimensions");
  double power=0,error=0,peak=0;for(juce::int64 pos=0;pos<ra->lengthInSamples;pos+=8192){int n=int(std::min<juce::int64>(8192,ra->lengthInSamples-pos));juce::AudioBuffer<float>x(2,n),y(2,n);require(ra->read(&x,0,n,pos,true,true)&&rb->read(&y,0,n,pos,true,true),"Read both vocals");for(int c=0;c<2;++c)for(int i=0;i<n;++i){double v=x.getSample(c,i),d=y.getSample(c,i)-v;require(std::isfinite(d),"Finite output");power+=v*v;error+=d*d;peak=std::max(peak,std::abs(d));}}
  const auto snr=10*std::log10(power/std::max(1e-30,error));std::cout<<"Vocal comparison SNR="<<snr<<" dB peak_error="<<peak<<std::endl;require(snr>100&&peak<.0001,"Full overlap-add GPU vocal must preserve FP32 quality");
 }
 std::cout<<"PASS all stems, exact duration, FP32 parity; total speedup="<<baseline.elapsed/fast.elapsed<<std::endl;return 0;
}catch(const std::exception&e){std::cerr<<"FAIL: "<<e.what()<<std::endl;return 1;}}
