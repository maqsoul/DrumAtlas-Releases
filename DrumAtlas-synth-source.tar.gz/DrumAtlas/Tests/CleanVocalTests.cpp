#include "../Source/Engine.h"
#include <juce_cryptography/juce_cryptography.h>
#include <iostream>
#include <stdexcept>

int main(int argc,char**argv){try{
 if(argc!=3&&argc!=4)return 2;
 auto check=[](bool value,const char*message){if(!value)throw std::runtime_error(message);};
 check(juce::SystemStats::getEnvironmentVariable("DRUMATLAS_CACHE_DIR",{}).isNotEmpty(),"Isolated cache required");
 juce::File fixture(juce::String::fromUTF8(argv[2]));juce::MemoryBlock in,expected;
 check(fixture.getChildFile("input.f32").loadFileAsData(in)&&fixture.getChildFile("expected.f32").loadFileAsData(expected),"Read independent model oracle");
 check(in.getSize()==size_t(atlas::StemSeparator::frames)*2*sizeof(float)&&expected.getSize()==in.getSize(),"Planar stereo fixture shape");
 std::vector<float>x(in.getSize()/4),y(x.size());std::memcpy(x.data(),in.getData(),in.getSize());std::memcpy(y.data(),expected.getData(),expected.getSize());
 {
  atlas::StemSeparator separator(atlas::StemSeparator::CleanVocals,8);
  if(!separator.available())throw std::runtime_error(separator.error().toStdString());
  auto outputs=separator.process(x);check(outputs.size()==6&&outputs[3].size()==y.size(),"Vocal output shape");
  for(size_t k=0;k<outputs.size();++k)if(k!=3)check(outputs[k].empty(),"Do not publish residual as another isolated source");
  double error=0,power=0;
  for(size_t i=0;i<y.size();++i){check(std::isfinite(outputs[3][i]),"Finite model output");double d=double(outputs[3][i])-y[i];error+=d*d;power+=double(y[i])*y[i];}
  const auto snr=10*std::log10(power/std::max(error,1e-30));std::cout<<"Native / original model SNR: "<<snr<<" dB"<<std::endl;
  check(snr>75,"Native channel padding and source selection match original model");
  bool rejected=false;try{separator.process({0.f});}catch(const std::exception&){rejected=true;}check(rejected,"Reject wrong input shape");
 }
 if(argc==4&&juce::String(argv[3])=="--oracle"){std::cout<<"PASS clean vocal model oracle"<<std::endl;return 0;}
 atlas::Engine engine;juce::File reference(juce::String::fromUTF8(argv[1]));
 if(argc==4&&juce::String(argv[3])=="--full"){
  const auto start=juce::Time::getMillisecondCounterHiRes();int last=-1;
  engine.analyseReference(reference,0,-1,"Vocal",true,false,2);
  while(engine.snapshot().busy){
   check(juce::Time::getMillisecondCounterHiRes()-start<3600000,"Full-track analysis timeout");
   auto s=engine.snapshot();if(s.processed/10!=last){last=s.processed/10;std::cout<<"Processed "<<s.processed<<" seconds"<<std::endl;}juce::Thread::sleep(200);
  }
  auto s=engine.snapshot();if(s.status!="referenceReady")throw std::runtime_error(s.detail.toStdString());
  check(s.stems.size()==1,"Full-track single vocal");
  juce::AudioFormatManager formats;atlas::registerFormats(formats);
  std::unique_ptr<juce::AudioFormatReader>original(formats.createReaderFor(reference)),output(formats.createReaderFor(juce::File(s.stems[0].path)));
  check(original&&output&&output->numChannels==2&&output->usesFloatingPointData,"Full-track float stereo WAV");
  check(std::abs(output->lengthInSamples-std::llround(original->lengthInSamples*44100.0/original->sampleRate))<=1,"Full-track exact duration");
  double energy=0;
  for(juce::int64 pos=0;pos<output->lengthInSamples;pos+=8192){
   const auto count=int(std::min<juce::int64>(8192,output->lengthInSamples-pos));juce::AudioBuffer<float>block(2,count);
   check(output->read(&block,0,count,pos,true,true),"Read full-track block");
   for(int c=0;c<2;++c)for(int i=0;i<count;++i){auto v=block.getSample(c,i);check(std::isfinite(v),"Finite full-track samples");energy+=double(v)*v;}
  }
  check(energy>1e-6,"Non-silent full-track vocal");
  std::cout<<"PASS full reference: "<<s.stems[0].path<<" frames="<<output->lengthInSamples<<" elapsed="<<s.elapsed<<" seconds"<<std::endl;return 0;
 }
 auto run=[&](const juce::String&category,int quality){
  const auto start=juce::Time::getMillisecondCounterHiRes();engine.analyseReference(reference,30,3,category,true,false,quality);
  while(engine.snapshot().busy){check(juce::Time::getMillisecondCounterHiRes()-start<240000,"Analysis timeout");juce::Thread::sleep(20);}
  auto result=engine.snapshot();if(result.status!="referenceReady")throw std::runtime_error(result.detail.toStdString());
  std::cout<<"quality="<<quality<<" category="<<category<<" elapsed="<<result.elapsed<<std::endl;return result;
 };
 auto selected=run("Vocal",2);check(selected.stems.size()==1&&selected.stems[0].name=="Vocal","Maximum selected vocal only");
 auto cached=run("Vocal",2);check(cached.stems[0].path==selected.stems[0].path,"Exact repeat uses finished cache");
 auto all=run({},2);check(all.stems.size()==7,"All broad stems plus melody alternative");
 check(juce::SHA256(juce::File(all.stems[3].path))==juce::SHA256(juce::File(selected.stems[0].path)),"Selected and all-stem modes use identical clean vocal");
 auto thorough=run("Vocal",1);check(thorough.stems[0].path!=selected.stems[0].path,"Quality cache isolation");
 check(juce::SHA256(juce::File(thorough.stems[0].path))!=juce::SHA256(juce::File(selected.stems[0].path)),"Maximum really uses a different vocal model");
 juce::AudioFormatManager formats;atlas::registerFormats(formats);
 for(const auto&set:{selected,all,thorough})for(const auto&stem:set.stems){
  std::unique_ptr<juce::AudioFormatReader>r(formats.createReaderFor(juce::File(stem.path)));
  check(r&&r->lengthInSamples==132300&&r->numChannels==2&&r->usesFloatingPointData,"Exact stereo float duration");
  juce::AudioBuffer<float>audio(2,132300);check(r->read(&audio,0,132300,0,true,true),"Read output");
  for(int c=0;c<2;++c)for(int i=0;i<132300;++i)check(std::isfinite(audio.getSample(c,i)),"Finite WAV output");
 }
 std::cout<<"PASS clean vocal parity, mode routing, cache, stereo duration"<<std::endl;return 0;
}catch(const std::exception&e){std::cerr<<"FAIL: "<<e.what()<<std::endl;return 1;}}
