#include <juce_audio_utils/juce_audio_utils.h>
#include "../Source/TempoDetector.h"
#include <iostream>
#include <stdexcept>
int main(int argc,char**argv){
 juce::ScopedJuceInitialiser_GUI init;
 if(argc>1){juce::AudioFormatManager fm;atlas::registerFormats(fm);for(int i=1;i<argc;++i){auto f=juce::File(juce::String::fromUTF8(argv[i]));auto d=atlas::decode(fm,f,0,24);auto t=atlas::estimateTempo(d.mono);if(d.error.isNotEmpty()){std::cerr<<d.error<<"\n";return 2;}if(d.duration>35){auto mid=atlas::decode(fm,f,std::max(0.,d.duration*.45-12.),24);auto mt=atlas::estimateTempo(mid.mono);atlas::tempo_detail::DrumEventSource ev;ev.end=mid.mono.size()/atlas::analysisRate;for(int h:atlas::onsets(mid.mono)){double pk=0;for(size_t k=h;k<std::min(mid.mono.size(),size_t(h)+1100);++k)pk=std::max(pk,double(std::abs(mid.mono[k])));ev.events.push_back({h/atlas::analysisRate,1,pk});}atlas::tempo_detail::ReferenceTempo pt;if(atlas::tempo_detail::estimateReferenceTempo(ev,0,ev.end,0,pt).wasOk()){std::cout<<"Mid alternatives: ";for(auto c:pt.alternatives)std::cout<<c.bpm<<"="<<c.relativeSupport<<" ";std::cout<<"\n";}std::cout<<"Intro "<<t.bpm<<", middle "<<mt.bpm<<" / "<<mt.confidence<<"; ";if((mt.periodic&&!t.periodic)||(mt.periodic==t.periodic&&mt.confidence>t.confidence))t=mt;}std::cout<<f.getFileName()<<": "<<t.bpm<<" / support "<<t.confidence<<"\n";}return 0;}
 auto check=[](bool ok,const char*s){if(!ok)throw std::runtime_error(s);};
 try{
  for(double bpm:{69.,76.,88.,100.,120.,133.,179.}){
   std::vector<float>a(size_t(atlas::analysisRate*18));
   const double beat=60./bpm;
   for(double t=.2;t<17.9;t+=beat){size_t at=size_t(t*atlas::analysisRate);for(int k=0;k<1800&&at+size_t(k)<a.size();++k)a[at+size_t(k)]+=float(std::sin(k*.17)*std::exp(-k/240.));}
   auto out=atlas::estimateTempo(a);std::cout<<bpm<<" -> "<<out.bpm<<" / "<<out.confidence<<"\n";
   check(std::abs(out.bpm-bpm)<1.,"Regular rhythmic pulse tempo is incorrect");
  }
  std::vector<float> silence(size_t(atlas::analysisRate*8));check(atlas::estimateTempo(silence).bpm==0,"Silence has no tempo");
  std::vector<float> one(size_t(atlas::analysisRate),0.f);for(size_t i=0;i<one.size();++i)one[i]=float(std::sin(i*.02)*std::exp(-double(i)/1000));check(atlas::estimateTempo(one).bpm==0,"A one-shot has no inferred musical BPM");
  std::cout<<"PASS: pulse tempos, silence and one-shot rejection\n";return 0;
 }catch(const std::exception&e){std::cerr<<"FAIL: "<<e.what()<<"\n";return 1;}
}
