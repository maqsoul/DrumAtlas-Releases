#include "../Source/Composer.h"
#include "../Source/ScanDigestIndex.h"
#include "../Source/OpenAIPlanner.h"
#include "../Source/ReferenceBrief.h"
#include "../Source/MusicRender.h"
#include "../Source/Formats.h"
#include "../Source/InstrumentScanner.h"
#include "../Source/InstrumentRender.h"
#include "../Source/ReferenceMusic.h"
#include "../Source/ComposerNoteEditor.h"
#include "../Source/ComposerGroove.h"
#include "../Source/MixBalance.h"
#include <juce_events/juce_events.h>
#include <iostream>

using namespace atlas;
static void check(bool ok,const juce::String&message){if(!ok)throw std::runtime_error(message.toStdString());}
static juce::var plan(){return juce::JSON::parse(R"json({"genre":"Trap","mood":"Dark","bpm":120,"tonic":9,"scale":"minor","energy":0.6,"density":0.5,"complexity":0.5,"darkness":0.6,"groove":0.5,"melodic_density":0.5,"roles":["Kick","Snare","Closed Hat"],"sections":[{"name":"Verse","bars":8},{"name":"Chorus","bars":8}],"instruments":[]})json");}
static void wave(const juce::File&file,double seconds,double rate=44100){
    auto stream=std::unique_ptr<juce::OutputStream>(file.createOutputStream());juce::WavAudioFormat format;auto writer=format.createWriterFor(stream,juce::AudioFormatWriterOptions{}.withSampleRate(rate).withNumChannels(2).withBitsPerSample(24));check(bool(writer),"Create fixture");juce::AudioBuffer<float>b(2,4096);auto frames=juce::int64(seconds*rate);
    for(juce::int64 start=0;start<frames;start+=4096){int n=int(std::min<juce::int64>(4096,frames-start));for(int i=0;i<n;++i){double time=(start+i)/rate,within=std::fmod(time,.5);float sample=float(std::sin(time*juce::MathConstants<double>::twoPi*65.406)*std::exp(-within*30)*(time<seconds/2?.3:.7));for(int ch=0;ch<2;++ch)b.setSample(ch,i,sample);}check(writer->writeFromAudioSampleBuffer(b,0,n),"Write fixture");}
}
static void grooveChecks(const juce::File& folder){
    auto bad=plan();auto* o=bad.getDynamicObject();o->setProperty("genre","UK Garage");o->setProperty("requested_style","UK Garage");
    o->setProperty("roles",juce::StringArray{"Kick","Snare","Closed Hat","Bass","Chords"});
    o->setProperty("style_pattern",juce::JSON::parse(R"({"kick":[0.88,0.14,0.32,0.12,0.08,0.18,0.12,0.58,0.76,0.16,0.24,0.1,0.52,0.22,0.64,0.18],"snare":[0.03,0.02,0.04,0.08,0.05,0.1,0.12,0.92,0.05,0.03,0.04,0.08,0.06,0.1,0.14,0.9],"hat":[0.68,0.34,0.58,0.26,0.64,0.3,0.72,0.28,0.66,0.32,0.56,0.24,0.74,0.36,0.62,0.3],"swing":0.24})"));
    composer::Request r;r.genre.clear();r.prompt="UK Garage";
    for(int trial=0;trial<12;++trial){music::Project p;juce::StringArray notices;auto result=composer::planProject(r,{},bad,p,notices);check(result.wasOk(),result.getErrorMessage());check(music::validate(p).wasOk(),"Groove grammar outputs valid MIDI");
        const auto bar=music::barTicks(p.settings);int verse=0,chorus=0;
        for(auto& t:p.tracks){if(t.role=="Snare")for(int b=0;b<16;++b){int anchors=0;for(auto& n:t.notes)if(n.tick/bar==b){check(n.tick%bar==bar/4||n.tick%bar==3*bar/4,"Bad plan backbeat cannot stay at steps 7/15");check(n.microtiming==0&&n.probability==1,"Backbeat cannot drift or randomly disappear");++anchors;}check(anchors==2,"Two primary backbeats in every active bar");}
            if(t.role=="Bass")for(auto& n:t.notes){(n.tick<8*bar?verse:chorus)++;check(n.duration<=3*bar/16,"Bass leaves breathing room");}
        }check(verse<chorus,"Verse bass sparser than chorus");
        auto saved=music::encode(p);music::Project reopened;check(music::decode(saved,reopened).wasOk()&&juce::JSON::toString(saved)==juce::JSON::toString(music::encode(reopened)),"New arrangement survives save/reopen");
        auto old=p;old.settings.genre="House";auto before=juce::JSON::toString(music::encode(old));composer::groove::arrange(old,bad["style_pattern"],notices);check(before==juce::JSON::toString(music::encode(old)),"Do not apply UKG rules to other genres");
    }
    composer::Analysis a;a.duration=92*240./120;a.bpm=120;r.reference=folder.getChildFile("reference.wav");
    o->setProperty("sections",juce::JSON::parse(R"([{"name":"Intro","bars":8},{"name":"Verse","bars":16},{"name":"Build","bars":8},{"name":"Chorus","bars":16},{"name":"Verse","bars":16},{"name":"Chorus","bars":16},{"name":"Breakdown","bars":8},{"name":"Chorus","bars":16},{"name":"Outro","bars":8}])"));
    music::Project p;juce::StringArray notices;check(composer::planProject(r,a,bad,p,notices).wasOk()&&p.settings.bars==92,"Full reference length retained");for(auto& s:*p.sections.getArray())check(int(s["bars"])%4==0,"Long arrangement preserves four-bar phrases");
    composer::referenceMusic::Evidence e;e.attacks={{0,.9,0},{.375,.9,0},{.875,.9,1},{1.875,.9,1}};auto guide=composer::referenceMusic::build(e,120,4,{.5,.5,.5,.5});auto before=music::encode(p)["tracks"].clone();check(composer::referenceMusic::apply(p,guide,notices,false).wasOk(),"Apply uncertain guide without overwriting drums");check(juce::JSON::toString(before)==juce::JSON::toString(music::encode(p)["tracks"]),"Full mix transients cannot replace MIDI");
    auto source=folder.getChildFile("balance-input.wav");wave(source,.5);music::Settings settings;settings.bars=2;settings.activeRoles={"Kick","Snare"};auto mix=music::generate(settings);for(auto& t:mix.tracks)t.soundPath=source.getFullPathName();
    music::StemExportOptions options;options.perTrack=true;options.balanceRoles=true;auto destination=folder.getChildFile("balanced-"+juce::Uuid().toString());auto balanced=music::renderStems(mix,destination,options);check(balanced.wasOk(),"Render balanced sample stems: "+balanced.getErrorMessage());
    auto manifest=juce::JSON::parse(destination.getChildFile("manifest.json"));check(manifest["track_balance"].size()==2,"Measured track gains saved in export");
    juce::WavAudioFormat wav;auto read=[&](const juce::String& name){std::unique_ptr<juce::AudioFormatReader> reader(wav.createReaderFor(destination.getChildFile(name).createInputStream().release(),true));check(bool(reader),"Reopen stem");juce::AudioBuffer<float> a(2,int(reader->lengthInSamples));check(reader->read(&a,0,a.getNumSamples(),0,true,true),"Read stem");return a;};
    auto full=read("Mix.wav"),kick=read("001-Kick.wav"),snare=read("002-Snare.wav");for(int ch=0;ch<2;++ch)for(int i=0;i<full.getNumSamples();++i)check(std::abs(full.getSample(ch,i)-kick.getSample(ch,i)-snare.getSample(ch,i))<4.e-7,"Balanced stems sum to mix");
    check(atlas::music::balance::gain("Bass",{.9,.5})<atlas::music::balance::gain("Kick",{.9,.5}),"Sustained bass cannot overpower kick at equal source level");
}
static void sequencerChecks(const juce::File&folder){
    music::Settings settings;settings.bars=4;auto song=std::make_shared<composer::Song>();song->project=music::generate(settings);song->folder=folder;composer::NoteGrid grid;auto&track=song->project.tracks.front();grid.load(song,track.id);check(grid.notes.size()>=2,"Group edit fixture");auto original=grid.notes;grid.selectedIds={original[0].id,original[1].id};grid.selected=original[0].id;grid.velocity(43);check(grid.notes[0].velocity==43&&grid.notes[1].velocity==43,"Group velocity changes both notes");check(grid.undo()&&grid.notes[0].velocity==original[0].velocity&&grid.notes[1].velocity==original[1].velocity,"Group undo is one operation");grid.redo();grid.copySelected();auto count=grid.notes.size();grid.pasteAt(2*music::barTicks(settings));check(grid.notes.size()==count+2,"Paste copies selected group");check(grid.undo()&&grid.notes.size()==count,"Paste undo removes entire group");grid.redo();
    auto draft=grid.draft();composer::Service service;service.setMidiDraft(draft);composer::Service restored;check(restored.restore(service.serialise()).wasOk(),"Save MIDI draft in DAW state");composer::NoteGrid reopened;reopened.load(song,track.id);check(reopened.restoreDraft(restored.snapshot().midiDraft),"Restore unapplied note edits");music::Project a,b;check(composer::applyMidiChanges(song->project,grid.pending(),a).wasOk()&&composer::applyMidiChanges(song->project,reopened.pending(),b).wasOk(),"Draft remains applicable");check(juce::JSON::toString(music::encode(a))==juce::JSON::toString(music::encode(b)),"Reopened draft has identical notes");auto stale=draft.clone();stale.getDynamicObject()->setProperty("project","different");check(!reopened.restoreDraft(stale),"Reject draft from another project");
    grid.selectAll();grid.removeSelected();check(grid.notes.empty(),"Delete selection");check(grid.undo()&&grid.notes.size()==count+2,"Restore deleted group");grid.revert();check(!grid.dirty()&&grid.notes.size()==original.size(),"Revert grouped edits");
    auto source=folder.getChildFile("region-source.wav");wave(source,2);juce::AudioFormatManager fm;registerFormats(fm);std::unique_ptr<juce::AudioFormatReader>reader(fm.createReaderFor(source));juce::AudioBuffer<float>before(2,88200);check(reader&&reader->read(&before,0,88200,0,true,true),"Read audio edit fixture");auto sourceHash=juce::SHA256(source);
    for(auto action:{"mute","reverse","copy","gain"}){auto target=folder.getChildFile("region-"+juce::String(action)+".wav");target.deleteFile();composer::AudioRegionEdit edit;edit.action=action;edit.first=.5;edit.end=1;edit.destination=1.25;edit.gainDb=-6;auto result=composer::editAudioRegion(source,target,edit);check(result.wasOk(),result.getErrorMessage());std::unique_ptr<juce::AudioFormatReader>out(fm.createReaderFor(target));juce::AudioBuffer<float>after(2,88200);check(out&&out->lengthInSamples==88200&&out->read(&after,0,88200,0,true,true),"Audio edit keeps duration");for(int i=0;i<88200;++i){float expected=before.getSample(0,i);if(edit.action=="copy"){if(i>=55125&&i<77175)expected=before.getSample(0,22050+i-55125);}else if(i>=22050&&i<44100){if(edit.action=="mute")expected=0;else if(edit.action=="reverse")expected=before.getSample(0,44099-(i-22050));else expected*=float(std::pow(10.,-6./20.));}check(std::abs(expected-after.getSample(0,i))<.0000003f,"Audio operation changes only intended region");}check(sourceHash==juce::SHA256(source),"Original audio remains untouched");}
    auto arranged=folder.getChildFile("arranged-loop.wav");wave(arranged,8);auto composition=song->project;composition.settings.bpm=120;for(auto&t:composition.tracks)t.soundPath=source.getFullPathName();auto*saved=new juce::DynamicObject;saved->setProperty("schema",1);saved->setProperty("project",music::encode(composition));saved->setProperty("folder",folder.getFullPathName());saved->setProperty("mix",arranged.getFullPathName());saved->setProperty("loop_audio",arranged.getFullPathName());check(service.restore(juce::JSON::toString(juce::var(saved))).wasOk(),"Restore audio edit session");auto originalSong=service.snapshot().song;composer::AudioRegionEdit edit;edit.action="mute";edit.first=.5;edit.end=1;check(service.changeAudio(composition.id,edit),"Start audio-region render");auto until=juce::Time::getMillisecondCounterHiRes()+60000;while(service.snapshot().busy&&juce::Time::getMillisecondCounterHiRes()<until)juce::Thread::sleep(20);auto state=service.snapshot();check(!state.busy&&state.error.isEmpty()&&state.song->project.id!=composition.id,"Audio edit produces a new render: "+state.error);check(state.song->mix.existsAsFile()&&state.song->loopAudio.existsAsFile(),"Edited audio and full mix available");auto editedSong=state.song;check(service.undo()&&service.snapshot().song==originalSong&&service.redo()&&service.snapshot().song==editedSong,"Audio edit Undo/Redo restores rendered versions");
}
int main(int argc,char**argv){juce::ScopedJuceInitialiser_GUI gui;try{
    check(argc>=2,"Scratch directory required");juce::File folder(juce::String::fromUTF8(argv[1]));check(folder.createDirectory().wasOk(),"Create scratch");
    if(argc==4&&juce::String(argv[2])=="--replay-compose"){
        juce::File original(juce::String::fromUTF8(argv[3]));auto metadata=juce::JSON::parse(original.getChildFile("composition.json"));auto captured=metadata["plan"].clone();check(captured.isObject(),"Saved planner response missing");
        music::Project before;check(music::load(original.getChildFile("song.drumatlas"),before).wasOk(),"Read original generated project");
        composer::Request r;r.genre.clear();r.prompt=metadata["prompt"].toString();r.reference=juce::File(metadata["reference_path"].toString());
        if(auto* assignments=captured["instruments"].getArray())for(auto& row:*assignments){int index=int(row["index"]);check(index>=0&&index<16,"Saved instrument index");while(r.instruments.size()<=index)r.instruments.add(juce::var());for(auto& track:before.tracks)if(track.role==row["role"].toString())r.instruments.set(index,track.instrument.clone());}
        auto library=juce::JSON::parse(folder.getChildFile("library.json"));check(library.isArray(),"Replay library missing");auto samples=std::make_shared<std::vector<Sample>>();
        for(auto& row:*library.getArray()){Sample s;s.path=row["path"].toString();s.name=juce::File(s.path).getFileName();s.category=row["category"].toString();s.kind=row["kind"].toString();s.duration=double(row["duration"]);s.features=fromJson(row["features"]);samples->push_back(s);}r.samples=samples;
        composer::Service service([captured](const juce::var&,juce::String& response){response=juce::JSON::toString(captured);return juce::Result::ok();});
        check(service.generate(r),"Start production Create beat path with replayed planner response");auto deadline=juce::Time::getMillisecondCounterHiRes()+1800000;juce::String previous;
        while(service.snapshot().busy&&juce::Time::getMillisecondCounterHiRes()<deadline){auto status=service.snapshot().status;if(status!=previous){std::cout<<status<<std::endl;previous=status;}juce::Thread::sleep(100);}
        auto state=service.snapshot();check(!state.busy&&state.error.isEmpty(),state.busy?"Replay timeout":state.error);check(state.song&&state.song->mix.existsAsFile(),"Production mix missing");
        check(folder.getChildFile("replay-session.json").replaceWithText(service.serialise()),"Save replay state");check(folder.getChildFile("result.txt").replaceWithText(state.song->folder.getFullPathName()),"Save replay location");
        std::cout<<"PRODUCTION_OUTPUT="<<state.song->mix.getFullPathName()<<std::endl;return 0;
    }
    if(argc==3&&juce::String(argv[2])=="--sample-fit"){
        auto catalog=juce::JSON::parse(folder.getChildFile("library.json"));
        check(catalog.isArray(),"Sample-fit catalog missing");
        std::vector<Sample> samples;std::vector<Hit> targets;
        auto refs=juce::JSON::parse(folder.getChildFile("targets.json"));
        for(auto& role:music::generationRoles())if(refs[juce::Identifier(role)].isObject()){
            Hit hit;hit.category=role;hit.features=fromJson(refs[juce::Identifier(role)]["features"]);hit.confidence=1;targets.push_back(hit);
        }
        for(auto& row:*catalog.getArray()){
            Sample sample;sample.path=row["path"].toString();sample.category=row["category"].toString();
            sample.kind=row["kind"].toString();sample.duration=double(row["duration"]);sample.features=fromJson(row["features"]);samples.push_back(sample);
        }
        music::Settings settings;settings.bars=16;settings.bpm=140;settings.activeRoles={"Kick","Snare","Closed Hat","Open Hat","Percussion"};
        auto project=music::generate(settings);juce::StringArray notices;
        check(composer::selectSamples(project,samples,false,notices,targets,true).wasOk(),"Select library tracks");
        check(music::save(project,folder.getChildFile("selected.drumatlas")).wasOk(),"Save selected sounds");std::cout<<notices.joinIntoString("\n")<<std::endl;return 0;
    }
    if(argc==4&&juce::String(argv[2])=="--audio-beat"){
        composer::Request request;
        request.audioBeat=true;
        request.prompt=juce::String::fromUTF8("Инструментальный UK garage. Оставь паузы в куплете и добавь синтовый хук в припеве.");
        request.reference=juce::File(juce::String::fromUTF8(argv[3]));
        composer::Service service;
        check(service.generate(request),"Queue local audio generation without an API key or catalog");
        auto deadline=juce::Time::getMillisecondCounterHiRes()+900000;
        while(service.snapshot().busy && juce::Time::getMillisecondCounterHiRes()<deadline)juce::Thread::sleep(100);
        auto state=service.snapshot();
        check(!state.busy&&state.error.isEmpty(),state.busy?"Timed out":state.error);
        check(state.song&&state.song->audioBeat&&state.song->mix.existsAsFile(),"Generated audio missing");
        composer::Service restored;
        check(restored.restore(service.serialise()).wasOk()&&restored.snapshot().song->audioBeat&&restored.snapshot().song->mix==state.song->mix,"Restore stereo song");
        std::cout<<"AUDIO_OUTPUT="<<state.song->mix.getFullPathName()<<std::endl;
        return 0;
    }
    if(argc==4&&juce::String(argv[2])=="--scan-library"){
        auto paths=juce::JSON::parse(juce::File(juce::String::fromUTF8(argv[3])));check(paths.isArray(),"Plugin paths required");
        juce::Array<juce::File>roots;for(auto& path:*paths.getArray())roots.add(juce::File(path.toString()));
        composer::Service service;
        for(int pass=0;pass<2;++pass){
            auto start=juce::Time::getMillisecondCounterHiRes();check(service.scan(roots),"Start library scan");
            while(service.snapshot().busy&&juce::Time::getMillisecondCounterHiRes()-start<600000)juce::Thread::sleep(5);
            auto state=service.snapshot();check(!state.busy&&state.error.isEmpty(),state.error);
            juce::StringArray ids;for(auto&v:state.instruments)ids.add("I "+v["uid"].toString());for(auto&v:state.effects)ids.add("E "+v["uid"].toString());ids.sort(false);
            check(!ids.isEmpty()&&folder.getChildFile("classes-"+juce::String(pass)+".txt").replaceWithText(ids.joinIntoString("\n")),"Write class inventory");
            std::cout<<"pass "<<pass<<" ms "<<juce::Time::getMillisecondCounterHiRes()-start<<" instruments "<<state.instruments.size()<<" effects "<<state.effects.size()<<"\n"<<std::flush;
        }return 0;
    }
    if(argc==3&&juce::String(argv[2])=="--live-render"){
        music::Settings settings;settings.bars=2;settings.bpm=120;auto project=music::generate(settings);
        project.sections=juce::JSON::parse(R"([{"name":"Verse","start":0,"bars":2}])");
        project.tracks.erase(std::remove_if(project.tracks.begin(),project.tracks.end(),[](const auto&t){return t.role!="Bass"&&t.role!="Melody";}),project.tracks.end());
        check(project.tracks.size()==2,"Native capture fixture has two tracks");for(auto&t:project.tracks){t.liveDevice=t.role=="Bass"?"Operator":"Wavetable";t.instrument=juce::var();for(auto&n:t.notes)n.velocity=40;}
        auto assets=composer::dataDirectory().getChildFile("Composer/songs/"+project.id);check(assets.createDirectory().wasOk(),"Create native test assets");
        auto*saved=new juce::DynamicObject;saved->setProperty("schema",1);saved->setProperty("project",music::encode(project));saved->setProperty("folder",assets.getFullPathName());
        composer::Service service;check(service.restore(juce::JSON::toString(juce::var(saved))).wasOk(),"Load native capture fixture");
        for(auto action:{"import","render"}){check(service.liveCommand(action),"Start Live operation");auto until=juce::Time::getMillisecondCounterHiRes()+90000;while(service.snapshot().busy&&juce::Time::getMillisecondCounterHiRes()<until)juce::Thread::sleep(25);auto state=service.snapshot();check(!state.busy&&state.error.isEmpty(),"Live operation: "+state.error);}
        auto result=service.snapshot().song;check(result&&result->nativeMix&&result->mix.existsAsFile(),"Complete native WAV available for DAW drag");
        juce::AudioFormatManager fm;registerFormats(fm);std::unique_ptr<juce::AudioFormatReader>reader(fm.createReaderFor(result->mix));check(reader&&reader->bitsPerSample==24&&reader->lengthInSamples/reader->sampleRate>=5.9,"Native export is complete 24-bit WAV");
        composer::Service reopened;check(reopened.restore(service.serialise()).wasOk()&&reopened.snapshot().song->nativeMix&&reopened.snapshot().song->mix==result->mix,"Native mix survives save/reopen");
        check(service.undo()&&!service.snapshot().song->nativeMix&&service.redo()&&service.snapshot().song->nativeMix,"Native render Undo/Redo preserves files");
        std::cout<<"PASS native Live capture: "<<result->mix.getFullPathName()<<'\n';return 0;
    }
    if(argc==2){
        grooveChecks(folder);
        sequencerChecks(folder);
        const auto cache=folder.getChildFile("scan-mutation-"+juce::Uuid().toString());
        check(cache.createDirectory().wasOk(),"Create isolated scan cache");
        auto module=cache.getChildFile("test-binary.dll");check(module.replaceWithData("first",5),"Create test image");
        auto path=module.getFullPathName();auto modified=module.getLastModificationTime();
        hosting::ScanDigestIndex initial(cache);auto first=initial.digest(module,path,{});initial.save();
        check(first==juce::SHA256(module).toHexString(),"Fast hash stays compatible with existing scan records");
        // Modify the same file in place and restore mtime to exercise NTFS change time.
        {juce::FileOutputStream out(module);check(out.openedOk()&&out.setPosition(0)&&out.write("other",5),"Modify same-size image");out.flush();}
        check(module.setLastModificationTime(modified)&&module.getSize()==5,"Restore file timestamp");
        hosting::ScanDigestIndex reopened(cache);auto updated=reopened.digest(module,path,{});
        check(updated!=first&&updated==juce::SHA256(module).toHexString(),"Reopened digest cache detects replacement with same size and mtime");
    }
    if(argc==4&&juce::String(argv[2])=="--analyse"){
        composer::Analysis measured;auto start=juce::Time::getMillisecondCounterHiRes();auto result=composer::analyseWholeFile(juce::File(juce::String::fromUTF8(argv[3])),measured);check(result.wasOk(),result.getErrorMessage());check(measured.frames==measured.analysedFrames,"Incomplete real-reference analysis");check(folder.getChildFile("reference-analysis.json").replaceWithText(juce::JSON::toString(measured.json())),"Write analysis report");
        std::cout<<"Analysed "<<measured.duration<<" s in "<<(juce::Time::getMillisecondCounterHiRes()-start)/1000<<" s; BPM="<<measured.bpm<<"; guide bars="<<measured.musicalGuide["bars"].size()<<'\n';return 0;
    }
    auto reference=folder.getChildFile("whole-reference.wav");wave(reference,41.25);composer::Analysis a;check(composer::analyseWholeFile(reference,a).wasOk(),"Analyse whole reference");check(a.frames==1819125&&a.analysedFrames==a.frames,"Must read the last frame, not just a prefix");check(a.energy.size()==42&&a.energy[30]>a.energy[3]*1.8,"Tail energy must be present in full reference context");
    {composer::Analysis restored;check(composer::Analysis::restore(a.json(),restored).wasOk(),"Restore full reference analysis");check(a.bpm==restored.bpm&&a.tonic==restored.tonic&&a.energy==restored.energy&&juce::JSON::toString(a.musicalGuide)==juce::JSON::toString(restored.musicalGuide),"Reference guide and tempo evidence survive save/reopen");auto invalid=a.json();invalid.getDynamicObject()->setProperty("bpm",999);check(composer::Analysis::restore(invalid,restored).failed(),"Reject corrupt reference tempo");}
    composer::Analysis cancelled;check(composer::analyseWholeFile(reference,cancelled,[]{return true;}).failed(),"Cancellation must not commit partial analysis");
    composer::Request request;request.prompt="Make a complete trap beat";request.genre="Trap";music::Project project;juce::StringArray notices;auto result=composer::planProject(request,{},plan(),project,notices);check(result.wasOk(),result.getErrorMessage());check(project.settings.bars==16&&project.sections.size()==2,"Full arrangement markers");
    {
        auto planned=plan();auto* obj=planned.getDynamicObject();obj->setProperty("roles",juce::StringArray{"Kick","Melody"});
        obj->setProperty("requested_style","2-step garage");juce::Array<juce::var>beats;for(int i=0;i<16;++i)beats.add(i%4==0?.9:.1);
        auto* style=new juce::DynamicObject;for(auto k:{"kick","snare","hat"})style->setProperty(k,beats);style->setProperty("swing",.2);obj->setProperty("style_pattern",juce::var(style));
        obj->setProperty("hook",juce::JSON::parse(R"([{"step":1,"length":3,"degree":2,"velocity":91},{"step":17,"length":4,"degree":6,"velocity":100}])"));
        planned["sections"][0].getDynamicObject()->setProperty("active_roles",juce::StringArray{"Kick"});
        planned["sections"][1].getDynamicObject()->setProperty("active_roles",juce::StringArray{"Kick","Melody"});
        juce::String decoded;auto* msg=new juce::DynamicObject;msg->setProperty("content",juce::JSON::toString(planned,true));
        auto* choice=new juce::DynamicObject;choice->setProperty("message",juce::var(msg));choice->setProperty("finish_reason","stop");
        auto* reply=new juce::DynamicObject;reply->setProperty("choices",juce::Array<juce::var>{juce::var(choice)});
        check(composer::openai::readResponse(200,juce::JSON::toString(juce::var(reply)),decoded).wasOk(),"Read OpenAI completion");
        auto free=request;free.genre.clear();free.reference=reference;composer::Analysis measured;measured.duration=12;measured.bpm=120;
        music::Project rendered;auto made=composer::planProject(free,measured,juce::JSON::parse(decoded),rendered,notices);check(made.wasOk(),made.getErrorMessage());
        check(rendered.settings.genre=="2-step garage"&&rendered.settings.bars==6&&rendered.sections.size()==2&&int(rendered.sections[1]["bars"])==3,"Prompt style and proportionate reference sections");
        auto melody=std::find_if(rendered.tracks.begin(),rendered.tracks.end(),[](const auto&t){return t.role=="Melody";});check(melody!=rendered.tracks.end()&&!melody->notes.empty(),"Hook was rendered");
        check(melody->notes.front().tick==3*music::barTicks(rendered.settings)+music::barTicks(rendered.settings)/16,"Section entrance and hook rhythm");
        check(composer::openai::readResponse(401,"{}",decoded).failed()&&composer::openai::readResponse(429,"{}",decoded).failed(),"Failed API calls cannot create plans");
        check(composer::openai::readResponse(429,R"({"error":{"type":"insufficient_quota","code":"project_spend_limit_exceeded"}})",decoded).getErrorMessage().contains("project spending limit"),"Specific quota code takes precedence");
        check(composer::openai::readResponse(429,R"({"error":{"code":"rate_limit_exceeded","type":"tokens"}})",decoded,"12").getErrorMessage().contains("12 s"),"Temporary token limit uses the server retry delay");
        check(composer::openai::readResponse(429,R"({"error":{"code":"credit_balance_exhausted"}})",decoded).getErrorMessage().contains("credits exhausted"),"Exhausted credits are not a transient rate limit");
        check(composer::openai::readResponse(429,"not JSON",decoded).getErrorMessage().contains("without a recognised limit code"),"Unknown 429 does not invent a billing diagnosis");
        auto echoed=planned.clone();
        free.prompt=juce::String::fromUTF8("Сделай инструментальный UK garage по этому референсу. Сохрани ощущение грува и переход от куплета к припеву. В куплете оставь больше пауз, а в припеве добавь новый запоминающийся синтовый хук. Для баса используй Serum 2");
        echoed.getDynamicObject()->setProperty("genre","UK Garage");
        echoed.getDynamicObject()->setProperty("requested_style",free.prompt);
        check(free.prompt.length()>128&&composer::planProject(free,measured,echoed,rendered,notices).wasOk(),"A prompt echoed as the style label must not abort the beat");
        check(rendered.settings.genre=="UK Garage"&&rendered.sections.size()==2,"Keep the valid genre and arrangement after recovering a long style label");
        auto profiles=rendered.styleSnapshot["registry"]["genres"];auto profile=profiles[profiles.size()-1];
        check(profile["id"].toString()=="UK Garage"&&double(profile["swing"])==.2,"Retain the model's rhythm after label recovery");
        namespace guide=composer::referenceMusic;guide::Evidence evidence;
        std::array<double,12>am{},f{};am[9]=1;am[0]=.9;am[4]=.8;f[5]=1;f[9]=.9;f[0]=.8;
        evidence.tonal={{.5,am},{1.5,am},{2.5,f},{3.5,f}};evidence.attacks={{0.,.8,0},{1.,.6,0},{2.5,.8,0},{3.5,.6,0}};
        auto musical=guide::build(evidence,120,6,{.5,.5,.8,.8,.2,.2});check(musical["bars"].size()==3,"Reference guide covers every bar");check(musical["bars"][0]["chord"].toString()=="Am"&&musical["bars"][1]["chord"].toString()=="F","Harmonic changes retained in timeline");check(musical["bars"][2]["chord"].toString().isEmpty(),"No invented chord for missing evidence");
        std::array<double,12>single{};single[9]=1;check(guide::chord(single).name.isEmpty(),"Single bass note is not a confident chord");check(guide::build(evidence,0,6,{} )["bars"].isVoid(),"Unknown tempo must not fabricate a beat grid");
        auto guided=project;auto original=guided.tracks.front().notes;check(guide::apply(guided,musical,notices).wasOk(),"Apply reference rhythm");std::vector<int64_t>ticks;for(auto&n:guided.tracks.front().notes)if(n.tick<2*music::barTicks(guided.settings))ticks.push_back(n.tick);check(ticks==std::vector<int64_t>{0,1920,4800,6720},"Different drum patterns must remain different between bars");
        auto locked=project;locked.tracks.front().midiLocked=true;check(guide::apply(locked,musical,notices).wasOk(),"Guide respects locked tracks");check(locked.tracks.front().notes.size()==original.size(),"Locked MIDI count unchanged");for(size_t n=0;n<original.size();++n)check(locked.tracks.front().notes[n].tick==original[n].tick,"Locked note positions unchanged");
        guided=project;guided.tracks.front().role="Bass";for(auto&n:guided.tracks.front().notes){n.pitch=36;n.channel=1;}check(guide::apply(guided,musical,notices).wasOk(),"Apply harmonic bass guidance");for(auto&n:guided.tracks.front().notes){if(n.tick<3840)check(n.pitch%12==9,"First bar bass follows A");else if(n.tick<7680)check(n.pitch%12==5,"Second bar bass follows F");else check(n.pitch==36,"Uncertain bars retain generated pitch");}
    }
    {
        auto customRequest=request;customRequest.genre="UK Garage / future soul";auto customPlan=plan();music::Project customProject;
        check(composer::planProject(customRequest,{},customPlan,customProject,notices).failed(),"Custom genre must not silently fall back without its rhythm");
        auto*patterns=new juce::DynamicObject;juce::Array<juce::var>kick,snare,hat;for(int step=0;step<16;++step){kick.add(step==0||step==7?1.:0.);snare.add(step==4||step==12?1.:0.);hat.add(step%2?.6:.9);}patterns->setProperty("kick",kick);patterns->setProperty("snare",snare);patterns->setProperty("hat",hat);patterns->setProperty("swing",.24);customPlan.getDynamicObject()->setProperty("style_pattern",juce::var(patterns));customPlan.getDynamicObject()->setProperty("progression","Am F C G");
        check(composer::planProject(customRequest,{},customPlan,customProject,notices).wasOk(),"Generate custom subgenre profile");check(customProject.settings.genre==customRequest.genre,"Keep actual custom genre name");auto registry=customProject.styleSnapshot["registry"]["genres"];auto saved=registry[registry.size()-1];check(saved["id"].toString()==customRequest.genre&&double(saved["kick"][7])==1&&double(saved["swing"])==.24,"Persist exact custom rhythm in project");music::Project restored;check(music::decode(music::encode(customProject),restored).wasOk()&&restored.settings.genre==customRequest.genre,"Custom profile survives project round trip");
        customPlan["style_pattern"]["kick"].getArray()->set(0,1.1);check(composer::planProject(customRequest,{},customPlan,customProject,notices).failed(),"Reject invalid style probabilities");
    }
    auto invalid=plan();invalid.getDynamicObject()->setProperty("genre","invented");check(composer::planProject(request,{},invalid,project,notices).failed(),"Reject unknown style");invalid=plan();auto*row=new juce::DynamicObject;row->setProperty("role","Kick");row->setProperty("index",0);invalid.getDynamicObject()->setProperty("instruments",juce::Array<juce::var>{juce::var(row)});check(composer::planProject(request,{},invalid,project,notices).failed(),"Reject non-allowed plugin IDs");
    auto samples=std::make_shared<std::vector<Sample>>();for(auto name:{"Kick","Snare","Closed Hat"}){auto file=folder.getChildFile(juce::String(name)+".wav");wave(file,.15);Sample s;s.path=file.getFullPathName();s.name=file.getFileName();s.category=name;s.kind="One-shot";s.duration=.15;samples->push_back(s);}
    request.samples=samples;check(composer::planProject(request,{},plan(),project,notices).wasOk(),"Rebuild valid plan");check(composer::selectSamples(project,*samples,false,notices).wasOk(),"Assign library sounds");for(auto&t:project.tracks)check(t.soundPath.isNotEmpty(),"No hidden built-in synthesis fallback");
    {
        auto mislabelled=(*samples)[2];auto hat=folder.getChildFile("OberHat_Open_(Wet).wav");wave(hat,.3);
        mislabelled.path=hat.getFullPathName();mislabelled.duration=1.33;mislabelled.genres.add("Trap");
        auto catalog=*samples;catalog.push_back(mislabelled);auto copied=project;
        check(composer::selectSamples(copied,catalog,false,notices).wasOk(),"Select from legacy hat catalog");
        for(const auto& t:copied.tracks)if(t.role=="Closed Hat")check(t.soundPath==(*samples)[2].path,"An open hat cannot fill the closed hat lane");
    }
    {
        music::Settings settings;settings.bpm=120;settings.bars=4;settings.activeRoles={"Percussion"};
        auto base=music::generate(settings);
        auto& track=base.tracks.front();track.notes.clear();
        for(int bar:{0,1,3}){music::Note n;n.tick=music::barTicks(settings)*bar;n.duration=120;n.channel=10;n.id=juce::String(bar);track.notes.push_back(n);}
        Sample loop;auto file=folder.getChildFile("unrelated-pack-shaker.wav");wave(file,2.);
        loop.category="Shaker";loop.kind="Loop";loop.duration=2;loop.path=file.getFullPathName();loop.features.peak=.6;loop.features.centroid=4800;
        auto project=base;
        check(composer::selectSamples(project,{loop},false,notices,{},true).wasOk(),"Accept compatible loop without a genre label");
        const auto& clips=project.tracks.front().notes;
        check(clips.size()==3&&clips[2].tick==3*music::barTicks(settings)&&clips[0].duration==music::barTicks(settings),"Launch once per active bar and preserve breaks");
        // A near-tempo loop must be stretched to the exact grid, not rejected
        // or allowed to drift against the MIDI phrase.
        settings.bpm=121;auto near=base;near.settings.bpm=121;auto aligned=folder.getChildFile("aligned-loop-test");
        auto alignedResult=composer::selectSamples(near,{loop},false,notices,{},true,aligned);check(alignedResult.wasOk(),alignedResult.getErrorMessage());
        check(near.tracks[0].soundPath!=loop.path,"Near-tempo loop is a derived audio file");
        juce::AudioFormatManager formats;registerFormats(formats);std::unique_ptr<juce::AudioFormatReader> stretched(formats.createReaderFor(juce::File(near.tracks[0].soundPath)));check(stretched&&std::abs(stretched->lengthInSamples/stretched->sampleRate-240./121)<.002,"Loop duration matches MIDI bar after stretch");
        loop.duration=1.8;project=base;
        check(composer::selectSamples(project,{loop},false,notices,{},true).failed(),"Off-tempo loop cannot stand in for a one-shot");
    }
    auto gentlePlan=plan();gentlePlan["sections"][0].getDynamicObject()->setProperty("name","Intro");gentlePlan["sections"][1].getDynamicObject()->setProperty("name","Outro");
    music::Project gentle;check(composer::planProject(request,{},gentlePlan,gentle,notices).wasOk(),"Gentle sections plan");check(composer::selectSamples(gentle,*samples,false,notices).wasOk(),"Gentle sections sounds");
    for(auto&section:*gentle.sections.getArray()){auto start=int(section["start"])*music::barTicks(gentle.settings),end=start+int(section["bars"])*music::barTicks(gentle.settings);bool notes=false;for(auto&t:gentle.tracks)for(auto&n:t.notes)notes|=n.tick>=start&&n.tick<end;check(notes,"Intro/outro must retain available sounds");}
    auto bassFile=folder.getChildFile("808_C.wav");wave(bassFile,.5);Sample bass;bass.path=bassFile.getFullPathName();bass.name=bassFile.getFileName();bass.category="Bass";bass.kind="One-shot";bass.duration=.5;auto pitched=project;pitched.tracks[0].role="Bass";pitched.tracks.erase(pitched.tracks.begin()+1,pitched.tracks.end());check(composer::selectSamples(pitched,{bass},false,notices).wasOk(),"Detect root of bass sample");check(pitched.tracks[0].sampleRoot==36,"C bass at 65 Hz must use MIDI C2, not C4");
    auto longPlan=plan();longPlan["sections"][0].getDynamicObject()->setProperty("bars",64);longPlan["sections"][1].getDynamicObject()->setProperty("bars",8);check(composer::planProject(request,{},longPlan,project,notices).wasOk(),"Long song plan");check(composer::selectSamples(project,*samples,false,notices).wasOk(),"Long song samples");auto rendered=folder.getChildFile("long-song.wav");result=music::renderWav(project,rendered);check(result.wasOk(),result.getErrorMessage());juce::AudioFormatManager fm;registerFormats(fm);std::unique_ptr<juce::AudioFormatReader>reader(fm.createReaderFor(rendered));check(reader&&reader->lengthInSamples/reader->sampleRate>144,"Export must exceed 120 seconds");
    {composer::Service original;original.setDraft(juce::JSON::parse(R"({"prompt":"Keep this request","genre":"House","instruments":["test-uid"]})"));composer::Service reopened;check(reopened.restore(original.serialise()).wasOk(),"Save an unfinished chat before a song exists");check(reopened.snapshot().draft["prompt"].toString()=="Keep this request","Draft prompt restored");}
    {auto nativePlan=plan();nativePlan.getDynamicObject()->setProperty("roles",juce::Array<juce::var>{"Bass"});auto*assignment=new juce::DynamicObject;assignment->setProperty("role","Bass");assignment->setProperty("index",0);nativePlan.getDynamicObject()->setProperty("instruments",juce::Array<juce::var>{juce::var(assignment)});auto nativeRequest=request;nativeRequest.instruments.add(juce::JSON::parse(R"({"name":"Operator","format":"Live","uid":"live:Operator"})"));music::Project nativeProject;check(composer::planProject(nativeRequest,{},nativePlan,nativeProject,notices).wasOk(),"Plan native Live instrument");check(composer::selectSamples(nativeProject,{},false,notices).wasOk(),"Native role must survive without a sample");music::Project decoded;check(music::decode(music::encode(nativeProject),decoded).wasOk()&&decoded.tracks[0].liveDevice=="Operator","Native assignment persists with schema 21");check(music::renderWav(decoded,folder.getChildFile("must-not-substitute.wav")).failed(),"Native role must not use a silent or substitute local synth");auto payload=live::arrangement(decoded,folder,{});check(payload["tracks"].size()==1&&payload["tracks"][0]["device"].toString()=="Operator"&&payload["tracks"][0]["notes"].size()>0,"Live payload has the chosen instrument and generated notes");check(live::connection(folder.getChildFile("disconnected")).error.isNotEmpty(),"Disconnected Live is explicit");auto manifestFolder=folder.getChildFile("live-manifest");manifestFolder.getChildFile("tracks").createDirectory();manifestFolder.getChildFile("tracks/manifest.json").replaceWithText(R"({"outputs":[{"file":"Mix.wav","track_ids":["track-Kick"]},{"file":"001-Kick.wav","track_ids":["track-Kick"]}]})");auto single=live::arrangement(decoded,manifestFolder,{});check(single["tracks"].size()==2&&single["tracks"][1]["file"].toString().endsWith("001-Kick.wav"),"Single rendered track must not import both its stem and the Mix duplicate");}
    {
        auto base=gentle;auto beforeJson=juce::JSON::toString(music::encode(base));
        auto editPlan=[&](const juce::String&action,const juce::String&id,double amount,int first,int end){auto*op=new juce::DynamicObject;op->setProperty("action",action);op->setProperty("track",id);op->setProperty("amount",amount);op->setProperty("first_bar",first);op->setProperty("end_bar",end);auto*root=new juce::DynamicObject;root->setProperty("operations",juce::Array<juce::var>{juce::var(op)});return juce::var(root);};
        auto id=base.tracks.front().id;music::Project edited;
        auto planEdit=editPlan("velocity",id,.5,0,4);check(composer::applyEdits(base,planEdit,edited).wasOk(),"Edit selected velocity range");
        for(size_t t=0;t<base.tracks.size();++t)for(size_t n=0;n<base.tracks[t].notes.size();++n){auto&a=base.tracks[t].notes[n];auto&b=edited.tracks[t].notes[n];check(b.velocity==(t==0&&a.tick<4*music::barTicks(base.settings)?std::max(1,int(std::lround(a.velocity*.5))):a.velocity),"Only targeted notes change velocity");check(a.id==b.id&&a.pitch==b.pitch&&a.tick==b.tick&&a.duration==b.duration,"Velocity edit preserves note identity/timing");}
        check(juce::JSON::toString(music::encode(base))==beforeJson,"Source snapshot remains immutable");
        check(composer::applyEdits(base,editPlan("regenerate",id,0,0,4),edited).wasOk(),"Regenerate selected part");auto original=music::encode(base),changed=music::encode(edited);for(int i=1;i<original["tracks"].size();++i)check(juce::JSON::toString(original["tracks"][i])==juce::JSON::toString(changed["tracks"][i]),"Variation preserves every unrelated track byte-for-byte");
        check(edited.tracks[0].soundPath==base.tracks[0].soundPath&&edited.settings.seed==base.settings.seed,"Variation preserves sound and global probability seed");
        check(composer::applyEdits(base,editPlan("remove",id,0,0,base.settings.bars),edited).wasOk()&&edited.tracks.size()+1==base.tracks.size(),"Remove one requested track");
        auto unchanged=juce::JSON::toString(music::encode(edited));auto invalid=editPlan("remove",id,0,0,base.settings.bars);invalid["operations"].getArray()->add(editPlan("transpose","missing",12,0,4)["operations"][0]);check(composer::applyEdits(base,invalid,edited).failed()&&juce::JSON::toString(music::encode(edited))==unchanged,"Invalid batch is atomic, never half applied");
        check(composer::applyEdits(base,editPlan("tempo","",140,0,base.settings.bars),edited,true).failed(),"Loop tempo edits must not silently misalign audio");
        auto locked=base;locked.tracks[0].midiLocked=true;check(composer::applyEdits(locked,planEdit,edited).failed(),"Locked track remains protected");
        check(composer::applyEdits(base,editPlan("transpose",id,12,0,4),edited).failed(),"Cannot transpose drums as pitched MIDI");
        auto pitchedBase=base;pitchedBase.tracks[0].role="Melody";check(composer::applyEdits(pitchedBase,editPlan("transpose",id,12,0,4),edited).wasOk(),"Transpose a pitched part");
        check(composer::applyEdits(base,editPlan("tempo","",140,0,base.settings.bars),edited).wasOk()&&edited.settings.bpm==140,"Whole-song tempo edit");
        auto rename=editPlan("rename_section","",0,0,8);rename["operations"][0].getDynamicObject()->setProperty("section_name","Verse");
        check(composer::applyEdits(base,rename,edited).wasOk()&&edited.sections[0]["name"].toString()=="Verse","Rename exact section");
        check(juce::JSON::toString(music::encode(base))==beforeJson,"Renaming must not mutate shared section objects");
        auto duplicate=editPlan("duplicate_section","",16,0,8);
        check(composer::applyEdits(base,duplicate,edited).wasOk()&&edited.settings.bars==24&&edited.sections.size()==3,"Duplicate section at end");
        for(size_t t=0;t<base.tracks.size();++t){for(auto&n:base.tracks[t].notes){auto it=std::find_if(edited.tracks[t].notes.begin(),edited.tracks[t].notes.end(),[&](auto&v){return v.id==n.id;});check(it!=edited.tracks[t].notes.end()&&it->tick==n.tick&&it->pitch==n.pitch&&it->duration==n.duration,"Section copy preserves original notes");}for(auto&n:edited.tracks[t].notes)if(n.tick>=16*music::barTicks(base.settings)){bool originalId=false;for(auto&old:base.tracks[t].notes)originalId|=old.id==n.id;check(!originalId,"Copied notes need fresh IDs");}}
        check(composer::applyEdits(base,duplicate,edited,true).failed(),"Do not splice an unedited source loop");
        check(composer::applyEdits(base,editPlan("delete_section","",0,8,16),edited).wasOk()&&edited.settings.bars==8&&edited.sections.size()==1,"Delete section and shorten song");
        check(composer::applyEdits(base,editPlan("delete_section","",0,1,8),edited).failed(),"Reject partial-section structural edits");
        auto replacement=base.tracks.front();replacement.soundPath=bass.path;replacement.sampleRoot=36;std::map<juce::String,music::Track>assets{{"0",replacement}};
        check(composer::applyEdits(base,editPlan("replace_sound",id,0,0,16),edited,false,assets).wasOk(),"Replace a prepared sound");
        check(juce::JSON::toString(music::encode(base)["tracks"][0]["notes"])==juce::JSON::toString(music::encode(edited)["tracks"][0]["notes"])&&edited.tracks[0].soundPath==bass.path,"Sound replacement preserves exact MIDI");
        check(composer::applyEdits(locked,editPlan("replace_sound",id,0,0,16),edited,false,assets).wasOk(),"MIDI lock permits sound-only replacement");
        auto soundLocked=base;soundLocked.tracks[0].soundLocked=true;check(composer::applyEdits(soundLocked,editPlan("replace_sound",id,0,0,16),edited,false,assets).failed(),"Sound lock protects replacement");
        auto add=editPlan("add_track","",0,8,16);add["operations"][0].getDynamicObject()->setProperty("role","Kick");replacement.id="additional-kick";for(auto&n:replacement.notes)n.id="additional-"+n.id;assets["0"]=replacement;
        check(composer::applyEdits(base,add,edited,false,assets).wasOk()&&edited.tracks.size()==base.tracks.size()+1,"Add prepared track without replacing existing role");for(auto&n:edited.tracks.back().notes)check(n.tick>=8*music::barTicks(base.settings),"New track respects requested section");
        check(composer::applyEdits(base,add,edited).failed(),"Model cannot add an unprepared sound");
        auto*fx=new juce::DynamicObject;fx->setProperty("schema",1);fx->setProperty("effect",true);fx->setProperty("path",folder.getChildFile("test-effect.vst3").getFullPathName());fx->setProperty("uid","fixture");fx->setProperty("name","Test effect");fx->setProperty("xml","");fx->setProperty("state","");fx->setProperty("sha256",juce::String::repeatedString("0",64));assets["0"].effects=juce::Array<juce::var>{juce::var(fx)};
        check(composer::applyEdits(base,editPlan("add_effect",id,0,0,16),edited,false,assets).wasOk()&&edited.tracks[0].effects.size()==1,"Append prepared effect state");auto withEffect=edited;
        check(composer::applyEdits(withEffect,editPlan("remove_effect",id,0,0,16),edited).wasOk()&&edited.tracks[0].effects.size()==0,"Remove selected effect slot");check(withEffect.tracks[0].effects.size()==1,"Effect edit leaves source chain intact");
    }
    {
        auto base=project;check(!base.tracks.empty()&&!base.tracks[0].notes.empty(),"Manual fixture has notes");auto id=base.tracks[0].id;auto old=base.tracks[0].notes.front();auto moved=old;moved.tick+=20;moved.microtiming=0;moved.duration=120;moved.velocity=50;
        auto added=moved;added.id="manual-new-note";added.tick=600;added.pitch=40;
        std::vector<composer::MidiChange> changes{{composer::MidiChange::Replace,id,moved},{composer::MidiChange::Insert,id,added}};music::Project result;
        check(composer::applyMidiChanges(base,changes,result).wasOk(),"Apply a batch of note edits");check(result.tracks[0].notes.size()==base.tracks[0].notes.size()+1,"Inserted MIDI note");
        auto a=music::encode(base),b=music::encode(result);for(int i=1;i<a["tracks"].size();++i)check(juce::JSON::toString(a["tracks"][i])==juce::JSON::toString(b["tracks"][i]),"Manual edits preserve other tracks and sounds");
        auto saved=juce::JSON::toString(music::encode(result));auto bad=changes;bad.back().note.pitch=128;check(composer::applyMidiChanges(base,bad,result).failed()&&juce::JSON::toString(music::encode(result))==saved,"Invalid final MIDI batch is atomic");
        check(composer::applyMidiChanges(base,{{composer::MidiChange::Insert,id,old}},result).failed(),"Duplicate note IDs rejected");
        check(composer::applyMidiChanges(base,{{composer::MidiChange::Replace,id,added}},result).failed(),"Missing replacement cannot resurrect a note");
        check(composer::applyMidiChanges(base,{{composer::MidiChange::Remove,id,old}},result).wasOk()&&result.tracks[0].notes.size()+1==base.tracks[0].notes.size(),"Remove one note");
        auto locked=base;locked.tracks[0].midiLocked=true;check(composer::applyMidiChanges(locked,changes,result).failed(),"Manual edits respect MIDI lock");
    }
    auto realCatalog=juce::SystemStats::getEnvironmentVariable("DRUMATLAS_TEST_CATALOG",{});if(realCatalog.isNotEmpty()){auto data=juce::JSON::parse(juce::File(realCatalog));check(data.isArray(),"Real test catalog must be an array");auto real=std::make_shared<std::vector<Sample>>();for(auto&v:*data.getArray()){Sample sample;sample.path=v["path"].toString();sample.name=juce::File(sample.path).getFileName();sample.category=v["category"].toString();sample.kind=v["kind"].toString();sample.duration=double(v["duration"]);sample.error=v["error"].toString();sample.features=fromJson(v["features"]);if(auto*genres=v["genres"].getArray())for(auto&g:*genres)sample.genres.add(g.toString());real->push_back(std::move(sample));}request.samples=real;}
    if(argc>=3){composer::Service service;request.model=juce::String::fromUTF8(argv[2]);request.prompt="Create a short 8-bar trap arrangement with a 4-bar verse and 4-bar chorus. Use only Kick, Snare and Closed Hat from my library. No melodic tracks. 120 BPM.";if(argc>=4){juce::File input(juce::String::fromUTF8(argv[3]));if(input.hasFileExtension("vst3;dll")){auto scan=hosting::scan(music::instruments::workerFile(),input,folder.getChildFile("scan"));check(scan.error.isEmpty(),scan.error);if(auto*items=scan.plugins.getArray())for(auto&item:*items)if(bool(item["instrument"]))request.instruments.add(item);check(!request.instruments.isEmpty(),"Instrument discovery");request.prompt=juce::String::fromUTF8("Создай короткий бит: куплет 4 такта и припев 4 такта, 120 BPM. Используй Kick и Snare из библиотеки, а выбранный VST для Bass и Melody. Без остальных дорожек.");}else if(juce::String(argv[3])=="native"){auto rows=live::instruments(composer::dataDirectory());for(auto&row:rows)if(row["name"].toString()=="Operator"||row["name"].toString()=="Wavetable")request.instruments.add(row);check(request.instruments.size()==2,"Connect Live bridge with Operator and Wavetable");request.prompt="Create an 8-bar beat at 120 BPM: a 4-bar verse and 4-bar chorus. Kick and Snare from the sample library; Bass using Operator, Melody using Wavetable. No other tracks.";}else if(juce::String(argv[3])=="loop"){auto loop=folder.getChildFile("loop-48000.wav");wave(loop,8,48000);request.loop=loop;}else{request.reference=input;request.prompt="Create a complete beat following the full reference duration and tempo. Use Kick, Snare and Closed Hat only.";}}auto freeText=juce::SystemStats::getEnvironmentVariable("DRUMATLAS_TEST_FREE_TEXT",{});if(freeText.isNotEmpty()){request.genre.clear();request.prompt=freeText;}auto customGenre=juce::SystemStats::getEnvironmentVariable("DRUMATLAS_TEST_GENRE",{});if(customGenre.isNotEmpty()){request.genre=customGenre;request.prompt+=" Use the custom style "+customGenre+" with its own groove.";}auto reuse=juce::SystemStats::getEnvironmentVariable("DRUMATLAS_EDIT_BASE",{});if(reuse.isEmpty()){check(service.generate(request),"Start real local AI");}else{juce::File base(reuse);auto*saved=new juce::DynamicObject;saved->setProperty("schema",1);saved->setProperty("project",juce::JSON::parse(base.getChildFile("song.drumatlas")));saved->setProperty("folder",base.getFullPathName());saved->setProperty("mix",base.getChildFile("tracks/Mix.wav").getFullPathName());check(service.restore(juce::JSON::toString(juce::var(saved))).wasOk(),"Restore existing VST song before editing");}auto deadline=juce::Time::getMillisecondCounterHiRes()+240000;while(service.snapshot().busy&&juce::Time::getMillisecondCounterHiRes()<deadline)juce::Thread::sleep(100);auto state=service.snapshot();check(!state.busy,"Local model timeout");check(state.error.isEmpty(),state.error);check(state.song&&state.song->mix.existsAsFile(),"Local AI must create audible mix");if(customGenre.isNotEmpty())check(state.song->project.settings.genre==customGenre,"Real AI custom style was saved");if(live::native(state.song->project)){int native=0;for(auto&t:state.song->project.tracks)native+=t.liveDevice.isNotEmpty()?1:0;check(native==2,"AI assigned both native instrument roles");check(state.song->project.tracks.size()==4,"AI must create exactly the four requested tracks");std::cout<<state.song->messages.joinIntoString("\n")<<"\n";check(state.song->messages.joinIntoString(" ").contains("Created "),"Native song must be acknowledged by actual Live");}else if(!request.instruments.isEmpty()){int used=0;for(auto&t:state.song->project.tracks)if(!t.instrument.isVoid())++used;check(used>=2,"Chosen VST must render bass and melody");auto manifest=juce::JSON::parse(state.song->folder.getChildFile("tracks/manifest.json"));check(manifest["instruments"].size()>=2,"VST render reports");for(auto&entry:*manifest["instruments"].getArray())check(double(entry["peak"])>1e-6,"Requested VST track must sound");}if(request.loop!=juce::File()){check(state.song->loopAudio.existsAsFile(),"Loop audio track");std::unique_ptr<juce::AudioFormatReader>loopReader(fm.createReaderFor(state.song->loopAudio));check(loopReader&&loopReader->sampleRate==44100&&loopReader->lengthInSamples>8*44100,"48 kHz loop expands into a full aligned track");}if(request.reference!=juce::File())check(state.song->reference.analysedFrames==state.song->reference.frames,"AI uses whole reference");if(juce::SystemStats::getEnvironmentVariable("DRUMATLAS_TEST_EDITS",{})=="1"){
        auto original=state.song;auto edit=request;bool hasHat=false;for(auto&t:original->project.tracks)hasHat|=t.role=="Closed Hat";edit.editExisting=true;edit.prompt=juce::String::fromUTF8("Убери только дорожку Closed Hat целиком. Kick, Snare, луп и все остальные партии оставь без изменений.");
        if(!hasHat)edit.prompt=juce::String::fromUTF8("Убери только дорожку Kick целиком. Snare и все остальные партии оставь без изменений.");check(service.generate(edit),"Start conversational edit");auto waitEdit=[&]{auto limit=juce::Time::getMillisecondCounterHiRes()+240000;while(service.snapshot().busy&&juce::Time::getMillisecondCounterHiRes()<limit)juce::Thread::sleep(100);auto s=service.snapshot();check(!s.busy&&s.error.isEmpty(),"Edit failed: "+s.error);return s;};
        state=waitEdit();check(state.song&&state.song->project.id!=original->project.id,"Edit creates a distinct export version");
        check(state.song->project.tracks.size()+1==original->project.tracks.size(),"Chat removed exactly one requested track");
        auto oldTracks=music::encode(original->project)["tracks"],newTracks=music::encode(state.song->project)["tracks"];
        for(auto&t:*newTracks.getArray()){bool found=false;for(auto&old:*oldTracks.getArray())if(old["id"]==t["id"]){found=true;check(juce::JSON::toString(old)==juce::JSON::toString(t),"Chat preserves every untouched track");}check(found,"No invented track during editing");}
        if(original->loopAudio.existsAsFile())check(juce::SHA256(original->loopAudio)==juce::SHA256(state.song->loopAudio),"Editing must preserve loop audio exactly, without cumulative attenuation");
        auto revised=state.song;check(service.undo()&&service.snapshot().song==original,"Undo restores original project and rendered audio");check(service.redo()&&service.snapshot().song==revised,"Redo restores edited project and rendered audio");
        edit.prompt=juce::String::fromUTF8("Сделай velocity малого барабана Snare в два раза тише только в припеве. Остальное оставь как есть.");check(service.generate(edit),"Start section-scoped conversational edit");state=waitEdit();auto p=music::encode(revised->project),q=music::encode(state.song->project);int affected=0;for(int i=0;i<p["tracks"].size();++i){if(p["tracks"][i]["role"].toString()!="Snare")check(juce::JSON::toString(p["tracks"][i])==juce::JSON::toString(q["tracks"][i]),"Section edit preserves other tracks");else{for(int n=0;n<p["tracks"][i]["notes"].size();++n){auto a=p["tracks"][i]["notes"][n],b=q["tracks"][i]["notes"][n];bool chorus=juce::int64(a["tick"])>=4*music::barTicks(revised->project.settings);check(int(b["velocity"])==(chorus?std::max(1,int(std::lround(int(a["velocity"])*.5))):int(a["velocity"])),"Only chorus Snare velocity halved");affected+=chorus?1:0;}}}check(affected>0,"Section test has affected notes");
        for(auto&t:state.song->project.tracks)if(!t.instrument.isVoid()){auto manifest=juce::JSON::parse(state.song->folder.getChildFile("tracks/manifest.json"));check(manifest["instruments"].size()>=2,"Edited VST parts were rendered from captured states");for(auto&entry:*manifest["instruments"].getArray())check(double(entry["peak"])>1e-6,"Edited VST track remains audible");break;}
        check(service.snapshot().canUndo&&!service.snapshot().canRedo,"History buttons reflect completed edit");std::cout<<"Conversational edits and Undo/Redo passed\n";
        }
        if(juce::SystemStats::getEnvironmentVariable("DRUMATLAS_TEST_EXPANDED_EDITS",{})=="1"){
            auto edit=request;edit.editExisting=true;
            auto run=[&](const juce::String&prompt){edit.prompt=prompt;check(service.generate(edit),"Start expanded chat edit");auto limit=juce::Time::getMillisecondCounterHiRes()+240000;while(service.snapshot().busy&&juce::Time::getMillisecondCounterHiRes()<limit)juce::Thread::sleep(100);state=service.snapshot();check(!state.busy&&state.error.isEmpty(),"Expanded edit failed: "+state.error);std::cout<<"Edited: "<<prompt<<std::endl;};
            auto before=state.song;run("Add one NEW Closed Hat track from my sample library throughout the whole song. Keep all existing tracks exactly unchanged.");check(state.song->project.tracks.size()==before->project.tracks.size()+1,"AI adds exactly one track");auto old=music::encode(before->project)["tracks"],now=music::encode(state.song->project)["tracks"];for(int i=0;i<old.size();++i)check(juce::JSON::toString(old[i])==juce::JSON::toString(now[i]),"AI add preserves previous tracks");
            auto kick=std::find_if(state.song->project.tracks.begin(),state.song->project.tracks.end(),[](auto&t){return t.role=="Kick";});check(kick!=state.song->project.tracks.end(),"Kick fixture");auto kickId=kick->id,kickPath=kick->soundPath;auto priorNotes=music::encode(state.song->project)["tracks"][0]["notes"].clone();
            run("Replace only the Kick sound with a different Kick sample from my library throughout the whole song. Keep the MIDI notes unchanged.");auto changed=std::find_if(state.song->project.tracks.begin(),state.song->project.tracks.end(),[&](auto&t){return t.id==kickId;});check(changed!=state.song->project.tracks.end()&&changed->soundPath!=kickPath,"AI selects a different sound");check(juce::JSON::toString(priorNotes)==juce::JSON::toString(music::encode(state.song->project)["tracks"][0]["notes"]),"AI replacement retains notes");
            auto bars=state.song->project.settings.bars;run("Rename only the first section to Opening. Do not change its length or any music.");check(state.song->project.sections[0]["name"].toString()=="Opening"&&state.song->project.settings.bars==bars,"AI renames a section");
            auto sectionBars=int(state.song->project.sections[0]["bars"]);run("Duplicate the entire first section and append the copy at the END of the song. Do not change anything else.");check(state.song->project.settings.bars==bars+sectionBars,"AI extends arrangement by selected section");check(state.song->mix.existsAsFile(),"Edited arrangement is rendered");std::cout<<"Expanded conversational edits passed"<<std::endl;
        }
        if(juce::SystemStats::getEnvironmentVariable("DRUMATLAS_TEST_MIDI",{})=="1"){
        auto original=state.song;auto track=std::find_if(original->project.tracks.begin(),original->project.tracks.end(),[](const auto&t){return t.role=="Snare";});check(track!=original->project.tracks.end()&&!track->notes.empty(),"Manual test has Snare notes");auto n=track->notes.front();n.velocity=44;n.duration=120;n.microtiming=0;n.tick+=20;auto added=n;added.id="manual-service-added";added.tick=600;added.velocity=90;
        check(service.changeMidi(original->project.id,{{composer::MidiChange::Replace,track->id,n},{composer::MidiChange::Insert,track->id,added}}),"Queue manual MIDI batch without a model");auto deadline=juce::Time::getMillisecondCounterHiRes()+120000;while(service.snapshot().busy&&juce::Time::getMillisecondCounterHiRes()<deadline)juce::Thread::sleep(100);state=service.snapshot();check(!state.busy&&state.error.isEmpty(),state.error);check(state.song->project.id!=original->project.id&&state.song->mix.existsAsFile(),"Manual edit creates a rendered version");
        auto before=music::encode(original->project),after=music::encode(state.song->project);for(int i=0;i<before["tracks"].size();++i)if(before["tracks"][i]["id"].toString()!=track->id)check(juce::JSON::toString(before["tracks"][i])==juce::JSON::toString(after["tracks"][i]),"Manual render retains all other MIDI and VST states");
        auto manifest=juce::JSON::parse(state.song->folder.getChildFile("tracks/manifest.json"));if(auto*entries=manifest["instruments"].getArray())for(auto&entry:*entries)check(double(entry["peak"])>1e-6,"Manual-edited VST render remains audible");
        auto edited=state.song;check(service.undo()&&service.snapshot().song==original,"Undo full manual batch");check(service.redo()&&service.snapshot().song==edited,"Redo full manual batch");
        check(service.changeMidi(original->project.id,{{composer::MidiChange::Remove,track->id,n}}),"Queue stale edit guard");while(service.snapshot().busy&&juce::Time::getMillisecondCounterHiRes()<deadline)juce::Thread::sleep(50);check(service.snapshot().song==edited&&service.snapshot().error.isNotEmpty(),"Stale editor cannot overwrite a newer version");state.song=edited;std::cout<<"Manual MIDI render and history checks passed\n";
        }
        auto serialized=service.serialise();composer::Service restored;check(restored.restore(serialized).wasOk(),"Restore composer session");check(restored.snapshot().song->project.id==state.song->project.id,"Restored composition identity");std::cout<<"AI_OUTPUT="<<state.song->mix.getFullPathName()<<"\n";}
    std::cout<<"Composer checks passed\n";return 0;
}catch(const std::exception&e){std::cerr<<e.what()<<"\n";return 1;}}
