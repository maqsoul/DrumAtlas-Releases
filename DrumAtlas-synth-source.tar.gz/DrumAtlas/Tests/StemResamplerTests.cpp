#include "../Source/StemResampler.h"
#include "../Source/StemOutput.h"
#include "../Source/ContentHash.h"
#include <iostream>

struct SignalReader : juce::AudioFormatReader {
 std::vector<float> left,right;juce::int64 low=0,high=0;
 SignalReader(double rate,int size):AudioFormatReader(nullptr,"signal"),left(size),right(size){sampleRate=rate;lengthInSamples=size;numChannels=2;usesFloatingPointData=true;bitsPerSample=32;high=size;}
 bool readSamples(int*const*dest,int channels,int offset,juce::int64 start,int count)override{
  if(start<low||start+count>high)throw std::runtime_error("Read outside selection");
  for(int c=0;c<channels;++c)if(dest[c])std::copy_n((c?right:left).data()+start,count,reinterpret_cast<float*>(dest[c])+offset);return true;
 }
 void tone(double hz){for(size_t i=0;i<left.size();++i)left[i]=right[i]=float(.5*std::sin(juce::MathConstants<double>::twoPi*hz*i/sampleRate));}
};
void check(bool ok,const char*why){if(!ok)throw std::runtime_error(why);}
double rms(const std::vector<float>&x,int skip=500){double sum=0;for(int i=skip;i<int(x.size())-skip;++i)sum+=double(x[i])*x[i];return std::sqrt(sum/(x.size()-2*skip));}
int main(){try{
 for(auto frames:{1LL,5679983LL,441001LL,109999999LL})for(double rate:{32000.,44100.,48000.})check(atlas::stemFrameCount(double(frames)/rate,rate)==frames,"Integer frame duration round-trip");
 check(atlas::stemFrameCount(1000.25/44100.,44100.)==1001,"Fractional frame duration rounds up");
 check(atlas::stemFrameCount(0,44100)==0,"Zero duration stays empty");
 juce::TemporaryFile hashFile(".bin");check(hashFile.getFile().replaceWithData("abc",3),"Write SHA fixture");
 check(atlas::contentSHA256(hashFile.getFile())=="ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad","SHA-256 known vector");
 std::vector<unsigned char>hashData(2*1024*1024+17);for(size_t i=0;i<hashData.size();++i)hashData[i]=static_cast<unsigned char>((i*131+i/17)&255);
 check(hashFile.getFile().replaceWithData(hashData.data(),hashData.size()),"Write streamed SHA fixture");check(atlas::contentSHA256(hashFile.getFile())==juce::SHA256(hashFile.getFile()).toHexString(),"System SHA matches JUCE over multiple read blocks");
 {juce::FileOutputStream empty(hashFile.getFile());check(empty.openedOk()&&empty.setPosition(0)&&empty.truncate().wasOk(),"Write empty SHA fixture");}
 check(atlas::contentSHA256(hashFile.getFile())=="e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855","Empty file SHA");
 hashFile.getFile().deleteFile();bool missingRejected=false;try{atlas::contentSHA256(hashFile.getFile());}catch(const std::exception&){missingRejected=true;}check(missingRejected,"Missing file cannot produce a valid hash");
 for(double rate:{44100.,48000.,96000.}){
  SignalReader source(rate,int(rate));source.tone(1000);
  atlas::StemResampler converter(source,32000,0,1);auto pass=converter.read(0,32000,32000,1);
  double gain=20*std::log10(rms(pass)/(.5/std::sqrt(2.)));check(std::abs(gain)<.01,"Passband level");
  auto part=converter.read(7351,5217,5217,1);for(int i=0;i<5217;++i)check(part[i]==pass[7351+i],"Chunk alignment");
  source.tone(19000);auto stop=converter.read(0,32000,32000,1);double rejection=20*std::log10(rms(stop)/(.5/std::sqrt(2.)));
  check(rejection< -80,"Anti-alias rejection");std::cout<<rate<<" -> 32000: gain "<<gain<<" dB, alias "<<rejection<<" dB\n";
 }
 SignalReader source(44100,44100);source.tone(1234);source.right=source.left;for(auto&v:source.right)v=-v;
 atlas::StemResampler direct(source,44100,0,1);auto stereo=direct.read(0,44100,44110,2);
 for(int i=0;i<44100;++i){check(stereo[i]==source.left[i],"Same-rate exact L");check(stereo[44110+i]==source.right[i],"Same-rate exact R");}
 for(int i=44100;i<44110;++i)check(stereo[i]==0&&stereo[44110+i]==0,"Tail padding");
 auto mono=direct.read(0,1000,1000,1);check(rms(mono,10)==0,"Mono downmix");
 atlas::StemResampler nearInteger(source,44100,(441.-1e-8)/44100.,1);auto near=nearInteger.read(0,1000,1000,2);
 check(std::abs(near[500]-source.left[941])<.001f,"Near-integer origin does not slip one sample");
 // Fractional selection origin and sample-rate conversion cannot reset phase at chunk edges.
 source.low=442;source.high=22052;atlas::StemResampler selected(source,48000,441.2/44100.,22051.8/44100.);
 auto full=selected.read(0,23522,23522,2);auto part=selected.read(1234,9000,9000,2);
 for(int c=0;c<2;++c)for(int i=0;i<9000;++i)check(full[c*23522+1234+i]==part[c*9000+i],"Fractional origin alignment");
 juce::TemporaryFile temp(".wav");auto writer=atlas::createStemWriter(temp.getFile(),44100,2);
 juce::AudioBuffer<float> peaks(2,4);for(int c=0;c<2;++c){peaks.setSample(c,0,1.14f);peaks.setSample(c,1,-1.3f);peaks.setSample(c,2,.12345678f);peaks.setSample(c,3,0);}
 check(writer->writeFromAudioSampleBuffer(peaks,0,4),"Write float peaks");writer.reset();juce::WavAudioFormat wav;std::unique_ptr<juce::AudioFormatReader> read(wav.createReaderFor(temp.getFile().createInputStream().release(),true));
 check(read&&read->usesFloatingPointData&&read->bitsPerSample==32,"WAV is float32");juce::AudioBuffer<float> restored(2,4);check(read->read(&restored,0,4,0,true,true),"Read float peaks");
 for(int c=0;c<2;++c)for(int i=0;i<4;++i)check(restored.getSample(c,i)==peaks.getSample(c,i),"WAV preserves peaks above 0 dBFS exactly");
 std::cout<<"PASS: alias suppression, passband, exact same-rate stereo, bounded selection, chunk alignment, tail padding, unclipped float WAV\n";return 0;
 }catch(const std::exception&e){std::cerr<<"FAIL: "<<e.what()<<'\n';return 1;}}
