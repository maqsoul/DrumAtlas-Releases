import copy
import importlib.util
import tempfile
import unittest
from unittest.mock import patch
from pathlib import Path
from types import SimpleNamespace

source = Path(__file__).resolve().parents[1] / "Tools/Ableton/DrumAtlasBridge/protocol.py"
spec = importlib.util.spec_from_file_location("bridge_protocol", source)
bridge = importlib.util.module_from_spec(spec)
spec.loader.exec_module(bridge)
capture_spec = importlib.util.spec_from_file_location("bridge_capture", source.with_name("capture.py"))
capture = importlib.util.module_from_spec(capture_spec)
capture_spec.loader.exec_module(capture)


class Track:
    def __init__(self):
        self.name = "Existing track"
        self.arrangement_clips = []
        self.clip_slots = []
        self.devices = []

    def insert_device(self, name):
        self.devices.append(name)

    def create_midi_clip(self, start, length):
        self.arrangement_clips.append(SimpleNamespace(start_time=start, end_time=start + length))

    def create_audio_clip(self, path, start):
        self.arrangement_clips.append(SimpleNamespace(start_time=start, end_time=start + 8))


class Song:
    def __init__(self):
        self.tracks = [Track()]
        self.tempo = 100
        self.is_playing = self.record_mode = False
        self.view = SimpleNamespace(selected_track=self.tracks[0])
        self.undo = 0

    def create_midi_track(self, index):
        self.tracks.append(Track())

    create_audio_track = create_midi_track

    def delete_track(self, index):
        del self.tracks[index]

    def duplicate_track(self, index):
        self.tracks.insert(index + 1, copy.deepcopy(self.tracks[index]))

    def begin_undo_step(self):
        self.undo += 1

    def end_undo_step(self):
        self.undo -= 1


class BridgeTests(unittest.TestCase):
    def setUp(self):
        self.folder = tempfile.TemporaryDirectory()
        self.root = Path(self.folder.name)
        self.wav = self.root / "song.wav"
        self.wav.write_bytes(b"test")
        self.payload = dict(schema=1, session="test", id="1" * 32, song_id="2" * 32,
                            created_ms=1000, command="import", bpm=120, length=8,
                            sections=[dict(name="Verse", start=0, length=4), dict(name="Chorus", start=4, length=4)],
                            tracks=[dict(name="Bass", kind="midi", device="Operator", notes=[[48, 3, 2, 100], [50, 4, 1, 90]]),
                                    dict(name="Drums", kind="audio", file=str(self.wav))])

    def tearDown(self):
        self.folder.cleanup()

    def validate(self, payload):
        return bridge.validate(payload, "test", self.root, now=1000)

    def test_invalid_data_rejected_before_mutation(self):
        self.validate(self.payload)
        for field, value in (("bpm", float("nan")), ("session", "old"), ("command", "exec"), ("created_ms", -1)):
            data = copy.deepcopy(self.payload)
            data[field] = value
            with self.assertRaises(ValueError):
                self.validate(data)
        data = copy.deepcopy(self.payload)
        data["tracks"][1]["file"] = str(self.root.parent / "outside.wav")
        with self.assertRaises(ValueError):
            self.validate(data)
        data = copy.deepcopy(self.payload)
        data["tracks"][0]["notes"][0][2] = 100
        with self.assertRaises(ValueError):
            self.validate(data)

    def test_import_preserves_existing_track_and_splits_notes(self):
        song = Song()
        original = song.tracks[0]
        added = []
        result = bridge.import_song(song, self.validate(self.payload), lambda clip, notes: added.append(notes))
        self.assertIs(song.tracks[0], original)
        self.assertIs(song.view.selected_track, original)
        self.assertEqual(song.tempo, 120)
        self.assertEqual(result["tracks"], 2)
        self.assertEqual(added, [[(48, 3, 1, 100)], [(50, 0, 1, 90)]])
        self.assertEqual(song.undo, 0)
        with self.assertRaises(ValueError):
            bridge.import_song(song, self.payload, lambda *_: None)
        self.assertEqual(len(song.tracks), 3)

    def test_rollback_only_new_tracks(self):
        song = Song()
        original = song.tracks[0]

        def fail(*_):
            raise RuntimeError("Simulated unsupported note API")

        with self.assertRaises(RuntimeError):
            bridge.import_song(song, self.validate(self.payload), fail)
        self.assertEqual(song.tracks, [original])
        self.assertEqual(song.tempo, 100)
        self.assertEqual(song.undo, 0)

    def test_existing_music_tempo_never_changed(self):
        song = Song()
        song.tracks[0].arrangement_clips.append(SimpleNamespace(end_time=5))
        with self.assertRaises(ValueError):
            bridge.import_song(song, self.validate(self.payload), lambda *_: None)
        self.assertEqual(song.tempo, 100)
        self.assertEqual(len(song.tracks), 1)
        song.tempo = 120
        result = bridge.import_song(song, self.payload, lambda *_: None)
        self.assertEqual(result["start"], 8)

    def test_playback_or_recording_prevents_import(self):
        for field in ("is_playing", "record_mode"):
            song = Song()
            setattr(song, field, True)
            with self.assertRaises(ValueError):
                bridge.import_song(song, self.validate(self.payload), lambda *_: None)
            self.assertEqual(len(song.tracks), 1)

    def test_template_instrument_preserves_original(self):
        song = Song()
        template = song.tracks[0]
        template.has_midi_input = template.has_audio_output = True
        template.devices = [SimpleNamespace(name="Sampler", preset="My piano")]
        template.name = "Piano template"
        template.arm = True
        self.payload["tracks"][0]["device"] = "Live track: Piano template"
        result = bridge.import_song(song, self.validate(self.payload), lambda *_: None)
        self.assertEqual(result["tracks"], 2)
        self.assertEqual(template.arrangement_clips, [])
        self.assertTrue(template.arm)
        clone = song.tracks[1]
        self.assertEqual(clone.devices[0].preset, "My piano")
        self.assertFalse(clone.arm)
        self.assertEqual(len(clone.arrangement_clips), 2)

    def test_template_rejects_clips_duplicate_names_and_recursive_host(self):
        song = Song()
        template = song.tracks[0]
        template.has_midi_input = template.has_audio_output = True
        template.devices = [SimpleNamespace(name="Sampler")]
        self.assertEqual(len(bridge.templates(song)), 1)
        template.arrangement_clips = [SimpleNamespace(end_time=2)]
        self.assertEqual(bridge.templates(song), {})
        template.arrangement_clips = []
        template.devices = [SimpleNamespace(name="Rack", chains=[SimpleNamespace(devices=[SimpleNamespace(name="DrumAtlas")])])]
        self.assertEqual(bridge.templates(song), {})
        template.devices = [SimpleNamespace(name="Sampler")]
        song.tracks.append(copy.deepcopy(template))
        self.assertEqual(bridge.templates(song), {})

    def test_capture_restores_transport_mutes_solos_arms(self):
        song = Song()
        song.return_tracks = []
        song.current_song_time, song.loop = 27, True
        owned = song.tracks[0]
        owned.name = "DA " + "2" * 8 + " - Bass"
        owned.mute, owned.solo, owned.arm, owned.can_be_armed = False, True, True, True
        song.stop_playing = lambda: setattr(song, "is_playing", False)
        slot = SimpleNamespace(has_clip=False, stop=lambda: None)
        def fire(**kwargs):
            slot.has_clip = True
            slot.clip = SimpleNamespace(is_recording=True, file_path=str(self.wav))
            song.is_playing = True
        slot.fire = fire
        def create(_):
            track = Track()
            track.available_input_routing_types = [SimpleNamespace(display_name="Resampling")]
            track.clip_slots = [slot]
            song.tracks.append(track)
        song.create_audio_track = create
        # Mock fixture needs an audio-sized file; actual decoding is checked in C++.
        self.wav.write_bytes(b"a" * 128)
        entry = dict(song_id="2" * 32, tracks=1, start=0, length=8)
        render = capture.Capture(song, entry, self.root / "captured.wav", 0)
        self.assertIsNone(render.poll())
        slot.clip.is_recording = False
        song.current_song_time = 12
        with patch.object(capture.shutil, "copyfile", side_effect=PermissionError("Writer still open")):
            self.assertIsNone(render.poll())
        self.assertFalse(render.target.exists())
        self.assertEqual(song.tracks, [owned])  # Release the recording owner before copying.
        self.assertEqual(song.current_song_time, 27)
        self.assertTrue(Path(render.poll()["file"]).exists())
        self.assertFalse(render.partial.exists())
        render.close()
        render.close()
        self.assertEqual(song.tracks, [owned])
        self.assertEqual((owned.mute, owned.solo, owned.arm), (False, True, True))
        self.assertEqual((song.current_song_time, song.loop, song.is_playing), (27, True, False))
        render = capture.Capture(song, entry, self.root / "cancelled.wav", 0)
        slot.clip.is_recording = False
        song.current_song_time = 1
        with self.assertRaises(ValueError):
            render.poll()
        render.close()
        self.assertFalse((self.root / "cancelled.wav").exists())


if __name__ == "__main__":
    unittest.main()
