#pragma once
#define FST2VST 1
#include "fst.h"
// DrumAtlas ABI guards (Windows x64). Based on the separately retained
// GPLv3 JUCE 5.3.2 VSTInterface layouts; fail the build on incompatible packing.
#if defined(__cplusplus) && defined(_WIN64)
static_assert(sizeof(AEffect) == 192, "VST2 effect ABI");
static_assert(sizeof(VstTimeInfo) == 88, "VST2 timing ABI");
static_assert(sizeof(VstMidiEvent) == 32, "VST2 MIDI ABI");
static_assert(sizeof(VstMidiSysexEvent) == 48, "VST2 SysEx ABI");
static_assert(sizeof(VstPinProperties) == 128, "VST2 pin ABI");
static_assert(sizeof(VstSpeakerProperties) == 112, "VST2 speaker ABI");
static_assert(offsetof(AEffect, uniqueID) == 112, "VST2 ID offset");
static_assert(offsetof(VstMidiEvent, midiData) == 24, "VST2 MIDI offset");
static_assert(offsetof(VstTimeInfo, flags) == 84, "VST2 timing flags offset");
#endif
#if defined(__cplusplus) && defined(_WIN32) && !defined(_WIN64)
static_assert(sizeof(AEffect) == 144, "VST2 x86 effect ABI");
static_assert(sizeof(VstTimeInfo) == 88, "VST2 x86 timing ABI");
static_assert(sizeof(VstMidiEvent) == 32, "VST2 x86 MIDI ABI");
static_assert(sizeof(VstMidiSysexEvent) == 32, "VST2 x86 SysEx ABI");
static_assert(offsetof(AEffect, uniqueID) == 72, "VST2 x86 ID offset");
static_assert(offsetof(VstMidiEvent, midiData) == 24, "VST2 x86 MIDI offset");
static_assert(offsetof(VstTimeInfo, flags) == 84, "VST2 x86 timing flags offset");
#endif
