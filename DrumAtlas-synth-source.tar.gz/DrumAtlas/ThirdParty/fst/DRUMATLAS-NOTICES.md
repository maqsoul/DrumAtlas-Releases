# FST integration notices

FST upstream: https://git.iem.at/zmoelnig/FST
Revision: 074f8ab91b2a8b1347efc3858ee5c5721b32c572
Copyright 2019 IOhannes m zmoelnig, IEM. GPL-3.0-or-later; see LICENSE.
Downloaded 2026-10-25. aeffect.h/aeffectx.h/fst.h are in pluginterfaces/vst2.x.
These are open-source compatibility headers, not the Steinberg VST2 SDK.

Local changes (2026-10-25): AEffect struct tag for JUCE forward declarations;
fixed-size MIDI-key buffer; MIDI, SysEx, time, pins, event and effect layouts;
fixed-width flags, reserved fields and ABI size/offset checks; completion of
host/effect opcodes and flags used by JUCE. Unsupported FST entries retain
upstream placeholders; this is not a claim of complete legacy VST2 coverage.

Layout/opcode cross-reference: juce_VSTInterface-reference.h, unmodified from
https://github.com/juce-framework/JUCE/blob/5.3.2/modules/juce_audio_processors/format_types/juce_VSTInterface.h
Copyright 2017 ROLI Ltd. Used under its GPLv3 alternative (notice in file).
It is also used by the independent, unshipped AtlasVst2Fixture test DLL.
GPLv3 text is included in LICENSE. DrumAtlas is distributed under AGPLv3;
retain both notices and corresponding source when packaging this component.

Only AtlasWorker includes FST. No VST2 module is loaded by the DAW process.
VST2 hosting is enabled on Windows x64; no 32-bit bridge is supplied.
