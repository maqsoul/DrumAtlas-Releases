#define NOMINMAX
#include <juce_audio_utils/juce_audio_utils.h>
#include <iostream>
#if JUCE_WINDOWS
#include <windows.h>
#endif
#include "../Source/Engine.h"
#include "../Source/SpliceBrowser.h"
int runAtlasSmoke(const juce::File&);
int runAtlasLayout(const juce::File&);
int main(int argc, char** argv) {
    juce::ScopedJuceInitialiser_GUI init;
    if(argc==3&&juce::String(argv[1])=="--layout"){
      if(juce::SystemStats::getEnvironmentVariable("DRUMATLAS_CACHE_DIR",{}).isEmpty())return 2;
      try{return runAtlasLayout(juce::File(juce::String::fromUTF8(argv[2])));}catch(const std::exception&e){std::cerr<<e.what()<<"\n";return 1;}
    }
 #if JUCE_WINDOWS
    if(argc==2&&juce::String(argv[1])=="--browser"){
      atlas::SpliceBrowser browser;if(!browser.available()){std::cerr<<"WebView2 Runtime missing\n";return 1;}
      browser.setBounds(-1800,-1200,1000,720);browser.addToDesktop(juce::ComponentPeer::windowIsTemporary);browser.setVisible(true);browser.open("https://splice.com/sounds");
      const auto until=juce::Time::getMillisecondCounterHiRes()+45000;while(browser.loadedUrl().isEmpty()&&browser.loadError().isEmpty()&&juce::Time::getMillisecondCounterHiRes()<until){MSG message{};while(PeekMessageW(&message,nullptr,0,0,PM_REMOVE)){TranslateMessage(&message);DispatchMessageW(&message);}juce::Thread::sleep(5);}
      const bool ok=browser.loadedUrl().startsWith("https://splice.com/");
      auto output=juce::SystemStats::getEnvironmentVariable("DRUMATLAS_BROWSER_PREVIEW",{});
      if(output.isNotEmpty()){juce::FileOutputStream stream{juce::File(output)};juce::PNGImageFormat().writeImageToStream(browser.createComponentSnapshot({0,0,browser.getWidth(),89}),stream);}
      std::cout<<(ok?"PASS: embedded WebView2 loaded the official Splice website":"FAIL: embedded website did not finish loading")<<"\n";browser.setVisible(false);browser.removeFromDesktop();return ok?0:1;
    }
 #endif
    if (argc != 2&&argc!=4) { std::cerr << "Usage: DrumAtlasSmoke <scratch-directory> OR <sample-folder> <reference> <report>\n"; return 2; }
    const auto testCache=juce::SystemStats::getEnvironmentVariable("DRUMATLAS_CACHE_DIR",{});
    if(testCache.isEmpty()){std::cerr<<"Set DRUMATLAS_CACHE_DIR to a test directory\n";return 2;}
    const auto isolated=juce::File(testCache).getChildFile("run-"+juce::String(juce::Time::currentTimeMillis()));
 #if JUCE_WINDOWS
    _wputenv_s(L"DRUMATLAS_CACHE_DIR",isolated.getFullPathName().toWideCharPointer());
 #else
    setenv("DRUMATLAS_CACHE_DIR",isolated.getFullPathName().toRawUTF8(),1);
 #endif
    const auto testLicense=juce::SystemStats::getEnvironmentVariable("DRUMATLAS_TEST_LICENSE",{});
    if(testLicense.isNotEmpty()){isolated.createDirectory();juce::File(testLicense).copyFileTo(isolated.getChildFile("license.key"));}
    if(argc==4){atlas::Engine engine;auto wait=[&]{auto end=juce::Time::getMillisecondCounter()+180000;while(engine.snapshot().busy&&juce::Time::getMillisecondCounter()<end)juce::Thread::sleep(25);return !engine.snapshot().busy;};engine.setRoots({juce::String::fromUTF8(argv[1])});if(!wait())return 3;auto library=engine.snapshot();std::cout<<"REAL LIBRARY: "<<library.samples->size()<<" files, "<<library.issues<<" read errors\n";engine.analyseReference(juce::File(juce::String::fromUTF8(argv[2])),0,juce::SystemStats::getEnvironmentVariable("DRUMATLAS_TEST_SECONDS","-1").getDoubleValue(),juce::SystemStats::getEnvironmentVariable("DRUMATLAS_TEST_CATEGORY",{}),juce::SystemStats::getEnvironmentVariable("DRUMATLAS_TEST_STEMS",{})=="1",juce::SystemStats::getEnvironmentVariable("DRUMATLAS_TEST_DETAIL",{})=="1");if(!wait())return 3;auto reference=engine.snapshot();juce::String report="Status: "+reference.status+"\nProcessed seconds: "+juce::String(reference.processed)+"\nLibrary: "+juce::String(int(library.samples->size()))+"\nRead errors: "+juce::String(library.issues)+"\n";report+="Detail: "+reference.detail+"\n";for(auto&s:reference.stems)report+="STEM "+s.name+" | "+s.path+"\n";for(auto&h:reference.hits)report+=h.category+" at "+juce::String(h.time,2)+" s\n";for(auto&m:reference.matches)report+=m.category+" | "+juce::File(m.path).getFileName()+" | distance="+juce::String(m.distance,4)+"\n";juce::File(juce::String::fromUTF8(argv[3])).replaceWithText(report);std::cout<<report;return reference.status=="referenceReady"&&library.issues==0?0:1;}
    try { return runAtlasSmoke(juce::File(juce::String::fromUTF8(argv[1]))); }
    catch (const std::exception& e) { std::cerr << "FAIL: " << e.what() << '\n'; return 1; }
}
