#include "../Source/Splice.h"
#include "../Source/SplicePreview.h"
#include <iostream>
namespace atlas {void testSpliceCredentials(const juce::File&);juce::File storeSpliceAudio(const juce::File&,const SpliceSound&,const juce::MemoryBlock&);}
static void require(bool b,const char*message){if(!b)throw std::runtime_error(message);}
static juce::var textReply(const juce::String& text){auto*block=new juce::DynamicObject;block->setProperty("type","text");block->setProperty("text",text);juce::Array<juce::var>blocks;blocks.add(juce::var(block));auto*result=new juce::DynamicObject;result->setProperty("content",blocks);return juce::var(result);}
static atlas::SpliceState wait(atlas::SpliceService& service){const auto deadline=juce::Time::getMillisecondCounterHiRes()+90000;for(;;){auto s=service.snapshot();if(!s.busy)return s;if(juce::Time::getMillisecondCounterHiRes()>deadline)throw std::runtime_error("Service timed out");juce::Thread::sleep(30);}}
int main(int argc,char**argv){
 try{
  if(argc<2)throw std::runtime_error("Pass a scratch directory");
  const juce::File scratch(juce::String::fromUTF8(argv[1]));
  atlas::testSpliceCredentials(scratch);
  std::cout<<"PASS: native Windows DPAPI encryption, decryption, corrupt file rejection and PKCE S256\n";
  const juce::String id="de201617-7d4b-4378-8aae-eeee2b0e809a";
  auto entry=[&](const juce::String&name,const juce::String&tags,const juce::String&uuid,const juce::String&url){return "### 1. "+name+"\nDuration: 0.2s | Type: oneshot\n**Tags:** "+tags+"\n**Link:** "+url+"\n**Asset UUID:** "+uuid+"\n";};
  const juce::String url="https://splice.com/sounds/sample/test";
  auto sounds=atlas::SpliceService::parseSearch(textReply(entry("Kick.wav","drums, kicks",id,url)+entry("Snare.wav","drums, snares",id,url)+entry("without_kick.wav","kicks",id,url)+entry("kick_snare_loop.wav","kicks",id,url)+entry("Kick.wav","kicks","bad",url)+entry("Kick.wav","kicks",id,"https://example.com/sounds/test")));
  require(sounds.size()==4&&sounds[0].category=="Kick"&&sounds[1].category=="Snare"&&sounds[2].category=="Other"&&sounds[3].category=="Other","Search parsing/category validation failed");
  atlas::SpliceSound sound;sound.id=id;sound.category="Kick";sound.name="../../test kick.wav";
  juce::MemoryBlock wav;
  {std::unique_ptr<juce::OutputStream> stream=std::make_unique<juce::MemoryOutputStream>(wav,false);juce::WavAudioFormat format;auto writer=format.createWriterFor(stream,juce::AudioFormatWriterOptions().withSampleRate(44100).withNumChannels(1).withBitsPerSample(16));require(bool(writer),"WAV writer");juce::AudioBuffer<float>audio(1,4410);for(int i=0;i<audio.getNumSamples();++i)audio.setSample(0,i,float(.3*std::sin(i*.08)));require(writer->writeFromAudioSampleBuffer(audio,0,audio.getNumSamples()),"WAV fixture");}
  auto folder=scratch.getChildFile("downloads-"+juce::Uuid().toString());auto first=atlas::storeSpliceAudio(folder,sound,wav);auto second=atlas::storeSpliceAudio(folder,sound,wav);
  require(first!=second&&first.existsAsFile()&&second.isAChildOf(folder.getChildFile("Kick")),"Download collision/path containment failed");
  juce::MemoryBlock bad("<html>not audio</html>",22);bool rejected=false;try{atlas::storeSpliceAudio(folder,sound,bad);}catch(...){rejected=true;}require(rejected,"Invalid audio was accepted");
  require(folder.findChildFiles(juce::File::findFiles,true,"*.part").isEmpty(),"Partial download left behind");
  std::cout<<"PASS: category exclusions, invalid IDs/links, audio validation, no overwrite and partial-file cleanup\n";
  if(argc>2&&juce::String(argv[2])=="--live"){
   atlas::SpliceService service;juce::Thread::sleep(150);atlas::Hit hit;hit.category="Kick";hit.confidence=1;hit.features.centroid=100;hit.features.tail=.05f;service.search({hit},"Kick");auto result=wait(service);
   require(result.status=="spliceResults",("Live search failed: "+result.detail).toRawUTF8());require(!result.sounds.empty(),"Live search returned no Kick candidates");for(auto&s:result.sounds)require(s.category=="Kick"&&!s.ranked,"Live results must be Kick metadata candidates");
   std::cout<<"PASS: authenticated native read-only Splice search: "<<result.sounds.size()<<" Kick candidates; no credits spent\n";
   scratch.getChildFile("preview-page.txt").replaceWithText(result.sounds[0].pageUrl);auto previewId=result.sounds[0].id;service.preview(previewId);auto preview=wait(service);require(preview.status=="splicePreviewReady",("Native preview failed: "+preview.detail).toRawUTF8());require(preview.previewId==previewId&&preview.previewSequence>0&&juce::File(preview.previewReady).existsAsFile(),"Preview result identity/file missing");
   juce::AudioFormatManager fm;atlas::registerFormats(fm);std::unique_ptr<juce::AudioFormatReader>reader(fm.createReaderFor(juce::File(preview.previewReady)));require(reader&&reader->lengthInSamples>0,"Public preview MP3 decode failed");juce::AudioBuffer<float>buffer(2,int(std::min<juce::int64>(reader->lengthInSamples,44100)));require(reader->read(&buffer,0,buffer.getNumSamples(),0,true,true)&&buffer.getMagnitude(0,buffer.getNumSamples())>.001f,"Public preview is silent");reader.reset();require(preview.downloadedPaths.isEmpty(),"Preview must not register a licensed download");
   service.preview(previewId);auto replay=wait(service);require(replay.previewSequence>preview.previewSequence&&replay.previewReady==preview.previewReady,"Cached preview replay failed");std::cout<<"PASS: public sample preview decodes to audible PCM, replay uses cache; no purchase or library import\n";
   service.more();auto more=wait(service);require(more.status=="spliceResults"||more.status=="spliceNoMore","More candidates failed");
   if(more.status=="spliceResults"){for(auto&s:more.sounds)for(auto&old:result.sounds)require(s.id!=old.id,"Repeated candidate in more results");service.previous();auto previous=wait(service);require(previous.sounds.size()==result.sounds.size()&&previous.sounds[0].id==result.sounds[0].id,"Previous results not restored");std::cout<<"PASS: new candidates without duplicates and previous page restore\n";}else std::cout<<"PASS: no new candidates reported honestly\n";
   service.clearResults();auto cleared=wait(service);require(cleared.sounds.empty(),"Reference results were not cleared");
   const auto start=juce::Time::getMillisecondCounterHiRes();
   {atlas::SpliceService cancelled;juce::Thread::sleep(100);cancelled.search({hit},"Kick");juce::Thread::sleep(100);}
   require(juce::Time::getMillisecondCounterHiRes()-start<3000,"Closing during network I/O was too slow");
   std::cout<<"PASS: clear stale reference results and close during active network request\n";
  }
  return 0;
 }catch(const std::exception&e){std::cerr<<e.what()<<"\n";return 1;}
}
