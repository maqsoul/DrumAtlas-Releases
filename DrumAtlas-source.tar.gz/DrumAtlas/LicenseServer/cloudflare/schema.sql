CREATE TABLE IF NOT EXISTS licenses (
  serial_hash TEXT PRIMARY KEY,
  id TEXT NOT NULL UNIQUE,
  created TEXT NOT NULL,
  machine TEXT,
  receipt TEXT,
  activated TEXT
);
