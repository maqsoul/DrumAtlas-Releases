#pragma once
#include "Engine.h"
namespace atlas {
struct SpliceSound {
 juce::String id,name,category,tags,kind,pageUrl,previewUrl,previewPath,localPath;
 double duration=0,bpm=0;juce::String key;float distance=0;bool ranked=false,owned=false;
};
struct SpliceState {
 bool connected=false,busy=false,hasPrevious=false,hasMore=false;int revision=0;juce::String status="spliceDisconnected",detail,folder,loginUrl;
 std::vector<SpliceSound> sounds;juce::StringArray downloadedPaths;juce::String previewReady,downloadReady,previewId;int previewSequence=0;
};
// All network, OAuth, decoding and matching run on a dedicated worker, never the audio thread.
class SpliceService:private juce::Thread {
public:
 SpliceService();~SpliceService()override;
 SpliceState snapshot();void connect();void disconnect();void setFolder(const juce::File&);
 void search(const std::vector<Hit>&,const juce::String& category={});
 void clearResults();void more();void previous();
 void preview(const juce::String& id);void download(const juce::String& id);
 static juce::String queryFor(const Hit&);
 static std::vector<SpliceSound> parseSearch(const juce::var&);
private:
 struct Impl;std::unique_ptr<Impl>impl;void run()override;
};
}
