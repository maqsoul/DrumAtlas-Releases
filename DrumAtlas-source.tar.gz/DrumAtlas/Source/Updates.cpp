#include "Updates.h"
#include "License.h"
#include <regex>
#if JUCE_WINDOWS
#define NOMINMAX
#include <windows.h>
#include <shellapi.h>
#else
#include <unistd.h>
#endif
namespace atlas {
bool allowedUpdateRedirect(const juce::String&from,const juce::String&to){
 if(!from.startsWith("https://")||!to.startsWith("https://")||to.containsAnyOf("@\r\n\\")||to.containsChar('#'))return false;
 auto a=juce::URL(from),b=juce::URL(to);if(b.getDomain().isEmpty()||(b.getPort()!=0&&b.getPort()!=443))return false;
 auto source=a.getDomain().toLowerCase(),target=b.getDomain().toLowerCase();
 return source==target||(source=="github.com"&&(target=="release-assets.githubusercontent.com"||target=="objects.githubusercontent.com"));
}
static bool newer(const juce::String&a,const juce::String&b){
 static const std::regex version("^(0|[1-9][0-9]{0,5})\\.(0|[1-9][0-9]{0,5})\\.(0|[1-9][0-9]{0,5})$");if(!std::regex_match(a.toStdString(),version)||!std::regex_match(b.toStdString(),version))return false;
 auto x=juce::StringArray::fromTokens(a,".",{}),y=juce::StringArray::fromTokens(b,".",{});for(int i=0;i<3;++i)if(x[i].getIntValue()!=y[i].getIntValue())return x[i].getIntValue()>y[i].getIntValue();return false;
}
bool parseUpdate(const juce::String&envelope,const juce::String&platform,const juce::String&current,UpdateRelease&out){
 if(envelope.length()>131072)return false;auto e=juce::JSON::parse(envelope);juce::String payload;if(!verifyServerMessage(e.getProperty("payload",{}).toString(),e.getProperty("signature",{}).toString(),payload))return false;
 auto v=juce::JSON::parse(payload);auto version=v.getProperty("version",{}).toString();if(v.getProperty("purpose",{}).toString()!="DrumAtlas-update-v1"||!newer(version,current))return false;
 auto f=v.getProperty("platforms",{}).getProperty(platform,{});auto url=f.getProperty("url",{}).toString(),sha=f.getProperty("sha256",{}).toString();auto size=static_cast<juce::int64>(f.getProperty("bytes",0));
 auto parsed=juce::URL(url);if(!url.startsWith("https://")||parsed.getDomain().isEmpty()||url.containsChar('@')||url.containsAnyOf("\r\n")||sha.length()!=64||sha.containsOnly("0123456789abcdef")==false||size<=0||size>8LL*1024*1024*1024)return false;
 out={version,url,sha,size};return true;
}
Updates::Updates():Thread("DrumAtlas updates"){
#if JUCE_WINDOWS
 instanceMutex=CreateMutexW(nullptr,FALSE,L"Local\\DrumAtlas.Active");
#endif
 startThread();}
bool verifyUpdateFile(const juce::File&file,const UpdateRelease&release){
 if(!file.existsAsFile()||file.getSize()!=release.bytes)return false;juce::FileInputStream input(file);return input.openedOk()&&juce::SHA256(input).toHexString()==release.sha256;
}
Updates::~Updates(){signalThreadShouldExit();{std::lock_guard<std::mutex>g(networkMutex);if(active)active->cancel();}notify();stopThread(-1);
#if JUCE_WINDOWS
 if(installerProcess)CloseHandle(installerProcess);if(instanceMutex)CloseHandle(instanceMutex);
#endif
}
Updates::State Updates::snapshot(){std::lock_guard<std::mutex>g(mutex);return state;}
void Updates::check(){std::lock_guard<std::mutex>g(mutex);if(state.phase==Checking||state.phase==Downloading||state.phase==Queued||state.phase==Ready)return;action=1;notify();}
void Updates::download(){std::lock_guard<std::mutex>g(mutex);if(state.phase!=Available)return;action=2;notify();}
void Updates::install(){std::lock_guard<std::mutex>g(mutex);if(state.phase!=Ready)return;state.phase=Downloading;action=3;notify();}
void Updates::launchInstaller(){
 auto current=snapshot();bool ok=verifyUpdateFile(current.installer,release);
 if(ok){
#if JUCE_WINDOWS
  // The verified installer owns the wait; it survives the DAW and never closes it.
  auto args=juce::String("/VERYSILENT /SUPPRESSMSGBOXES /NORESTART /NOCLOSEAPPLICATIONS /DRUMATLASWAITPID=")+juce::String((int)GetCurrentProcessId());
  auto path=current.installer.getFullPathName();SHELLEXECUTEINFOW info{};info.cbSize=sizeof(info);info.fMask=SEE_MASK_NOCLOSEPROCESS|SEE_MASK_NOASYNC;info.lpVerb=L"runas";info.lpFile=path.toWideCharPointer();info.lpParameters=args.toWideCharPointer();info.nShow=SW_HIDE;
  ok=ShellExecuteExW(&info)!=FALSE;if(ok)installerProcess=info.hProcess;
#elif JUCE_MAC
  auto quote=[](juce::String s){return "'"+s.replace("'","'\\''")+"'";};
  auto file=quote(current.installer.getFullPathName());
  // Execute a fixed, quoted command, not a user-writable privileged script.
  auto command=juce::String("n=0; while kill -0 ")+juce::String((int)getpid())+" 2>/dev/null; do n=$((n+1)); [ $n -lt 17280 ] || exit 75; sleep 5; done; "
    "while /usr/sbin/lsof -t /Applications/DrumAtlas.app/Contents/MacOS/DrumAtlas /Library/Audio/Plug-Ins/VST3/DrumAtlas.vst3/Contents/MacOS/DrumAtlas /Library/Audio/Plug-Ins/Components/DrumAtlas.component/Contents/MacOS/DrumAtlas >/dev/null 2>&1; do n=$((n+1)); [ $n -lt 17280 ] || exit 75; sleep 5; done; "
    "actual=$(/usr/bin/shasum -a 256 "+file+" | /usr/bin/cut -d ' ' -f 1); [ \"$actual\" = "+quote(release.sha256)+" ] || exit 74; /usr/sbin/installer -pkg "+file+" -target /";
  auto apple="try\nwith timeout of 86400 seconds\n do shell script \""+command.replace("\\","\\\\").replace("\"","\\\"")+"\" with administrator privileges\nend timeout\ndisplay dialog \"DrumAtlas update is complete. You can open your DAW again.\" buttons {\"OK\"} default button \"OK\" with title \"DrumAtlas\"\non error errorText number errorNumber\n if errorNumber is not -128 then display dialog errorText buttons {\"OK\"} default button \"OK\" with title \"DrumAtlas update failed\"\n error number errorNumber\nend try";
  ok=macInstaller.start(juce::StringArray{"/usr/bin/osascript","-e",apple},0);
#else
  ok=false;
#endif
 }
 std::lock_guard<std::mutex>g(mutex);state.phase=ok?Queued:Ready;state.message=ok?"Update prepared. Continue working; installation starts after you close the DAW and DrumAtlas. Do not reopen them until installation finishes.":"Update was not scheduled. Retry and allow the system permission prompt. The verified package is retained.";
}
bool Updates::fetch(const juce::String&url,juce::MemoryBlock&body,juce::int64 limit,const juce::File&destination){
 std::unique_ptr<juce::WebInputStream> connection;auto next=url;
 struct Guard{Updates&u;~Guard(){std::lock_guard<std::mutex>g(u.networkMutex);u.active=nullptr;}}guard{*this};
 for(int redirects=0;;++redirects){
  {std::lock_guard<std::mutex>g(networkMutex);active=nullptr;if(threadShouldExit())return false;connection=std::make_unique<juce::WebInputStream>(juce::URL(next),false);connection->withConnectionTimeout(15000).withNumRedirectsToFollow(0);active=connection.get();}
  if(!connection->connect(nullptr))return false;auto status=connection->getStatusCode();
  if(status==200)break;
  if(destination==juce::File()||redirects>=3||(status!=301&&status!=302&&status!=303&&status!=307&&status!=308))return false;
  auto headers=connection->getResponseHeaders();headers.setIgnoresCase(true);auto target=headers["Location"];
  if(!allowedUpdateRedirect(url,target))return false;next=target;
 }
 auto&stream=*connection;if(stream.getTotalLength()>limit)return false;
 std::unique_ptr<juce::FileOutputStream>file;if(destination!=juce::File()){file=destination.createOutputStream();if(!file||file->failedToOpen())return false;file->setPosition(0);file->truncate();}
 juce::MemoryOutputStream memory(body,false);char chunk[65536];juce::int64 count=0;
 while(!stream.isExhausted()&&!threadShouldExit()){int n=stream.read(chunk,sizeof(chunk));if(n<=0)break;count+=n;if(count>limit)return false;if(file){if(!file->write(chunk,size_t(n)))return false;}else memory.write(chunk,size_t(n));}
 if(file){file->flush();if(file->getStatus().failed())return false;}return !threadShouldExit()&&!stream.isError();
}
void Updates::run(){
 const juce::String endpoint=DRUMATLAS_UPDATE_URL;
#if JUCE_WINDOWS
 const juce::String platform="windows-x64";
#elif JUCE_ARM
 const juce::String platform="mac-arm64";
#else
 const juce::String platform="mac-x64";
#endif
 auto folder=licenseFile().getParentDirectory().getChildFile("updates");auto stamp=folder.getChildFile("last-check");
 while(!threadShouldExit()){
  int job=0;{std::lock_guard<std::mutex>g(mutex);job=action;action=0;}
  if(!job){
   if(snapshot().phase==Queued){bool exited=false;
#if JUCE_WINDOWS
    exited=installerProcess&&WaitForSingleObject(installerProcess,0)==WAIT_OBJECT_0;
    if(exited){CloseHandle(installerProcess);installerProcess=nullptr;}
#elif JUCE_MAC
    exited=!macInstaller.isRunning();
#endif
    if(exited){std::lock_guard<std::mutex>g(mutex);state.phase=Ready;state.message="Update stopped before this DAW closed. Retry to schedule installation.";}
   }
   wait(snapshot().phase==Queued?1000:60000);if(juce::Time::currentTimeMillis()-stamp.loadFileAsString().getLargeIntValue()>24LL*60*60*1000){std::lock_guard<std::mutex>g(mutex);if(state.phase==Idle)action=1;}continue;}
  if(job==3){launchInstaller();continue;}
  if(!endpoint.startsWith("https://")){std::lock_guard<std::mutex>g(mutex);state={Unconfigured,{},"Update server is not configured in this build",{}};continue;}
  {std::lock_guard<std::mutex>g(mutex);state.phase=job==1?Checking:Downloading;state.message={};}
  juce::MemoryBlock body;
  if(job==1){
   bool ok=fetch(endpoint,body,131072);UpdateRelease next;bool found=ok&&parseUpdate(body.toString(),platform,JucePlugin_VersionString,next);
   if(ok){folder.createDirectory();stamp.replaceWithText(juce::String(juce::Time::currentTimeMillis()));}
   std::lock_guard<std::mutex>g(mutex);if(found){release=next;state={Available,next.version,{}, {}};}else state={ok?Idle:Failed,{},ok?"No newer verified release":"Could not check for updates",{}};
  }else{
   folder.createDirectory();
#if JUCE_WINDOWS
   auto suffix=".exe";
#else
   auto suffix=".pkg";
#endif
   auto file=folder.getChildFile("DrumAtlas-"+release.version+"-"+juce::Uuid().toString()+suffix);auto partial=file.withFileExtension(".part");
   bool ok=fetch(release.url,body,release.bytes,partial)&&partial.getSize()==release.bytes;
   if(ok)ok=verifyUpdateFile(partial,release);
   if(ok)ok=partial.moveFileTo(file);if(!ok)partial.deleteFile();
   {std::lock_guard<std::mutex>g(mutex);state={ok?Ready:Failed,release.version,ok?"Preparing installation":"Update download or signature/hash verification failed",ok?file:juce::File()};}
   if(ok)launchInstaller();
  }
 }
}
}
