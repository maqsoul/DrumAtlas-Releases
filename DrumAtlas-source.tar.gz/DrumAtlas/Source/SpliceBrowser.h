#pragma once
#include <juce_gui_extra/juce_gui_extra.h>
namespace atlas {
class SpliceBrowser final : public juce::Component {
 struct ChromeLook : juce::LookAndFeel_V4 {
  void drawButtonBackground(juce::Graphics&g,juce::Button&b,const juce::Colour&,bool hover,bool down)override {
   g.setColour(juce::Colour(down?0xffd3e3fd:hover?0xffe4e7ec:0xfff8fafd));g.fillRoundedRectangle(b.getLocalBounds().toFloat(),16.f);
  }
 } look;
 struct Icon : juce::Button {
  int kind;
  Icon(const char*name,int k):Button(name),kind(k){setTooltip(name);}
  void paintButton(juce::Graphics&g,bool hover,bool down)override {
   if(hover||down){g.setColour(juce::Colour(down?0xffd3e3fd:0xffe4e7ec));g.fillEllipse(getLocalBounds().toFloat().reduced(2));}
   g.setColour(juce::Colour(0xff444746));juce::Path p;float x=getWidth()/2.f,y=getHeight()/2.f;
   if(kind<2){float d=kind==0?-1.f:1.f;p.startNewSubPath(x-d*7,y);p.lineTo(x+d*7,y);p.lineTo(x+d*1,y-6);p.startNewSubPath(x+d*7,y);p.lineTo(x+d*1,y+6);}
   else if(kind==2){
    // The arrowhead meets the circular stroke at its tangent, without a detached corner.
    const float end=juce::MathConstants<float>::twoPi+juce::MathConstants<float>::pi/4.f;
    const float tipX=x+4.95f,tipY=y-4.95f;
    p.addCentredArc(x,y,7.f,7.f,0.f,1.65f,end,true);
    p.startNewSubPath(tipX-5.f,tipY);p.lineTo(tipX,tipY);p.lineTo(tipX,tipY-5.f);
   }
   else {p.startNewSubPath(x-5,y-5);p.lineTo(x+5,y+5);p.startNewSubPath(x+5,y-5);p.lineTo(x-5,y+5);}
   g.strokePath(p,juce::PathStrokeType(1.7f,juce::PathStrokeType::curved,juce::PathStrokeType::rounded));
  }
 } back{"Back",0},forward{"Forward",1},reload{"Reload",2},close{"Close",3};
 struct Browser : juce::WebBrowserComponent {
  juce::String loadedUrl,loadError;std::function<void(const juce::String&)> changed;std::function<void()> failed;
  explicit Browser(const Options&o):WebBrowserComponent(o){}
  void pageFinishedLoading(const juce::String&url)override{loadedUrl=url;loadError.clear();if(changed)changed(url);}
  bool pageLoadHadNetworkError(const juce::String&error)override{loadError=error;if(failed)failed();return false;}
  void newWindowAttemptingToLoad(const juce::String&url)override{if(url.startsWithIgnoreCase("https://"))goToURL(url);}
  bool pageAboutToLoad(const juce::String&url)override{bool ok=url.startsWithIgnoreCase("https://")||url=="about:blank";if(ok&&changed)changed(url);return ok;}
 };
 std::unique_ptr<Browser> browser;
 juce::TextButton account{"Account"};juce::Label title,error;juce::TextEditor address;
public:
 std::function<void()> onClose,onAccount;
 bool available()const{return browser!=nullptr;}
 juce::String loadedUrl()const{return browser?browser->loadedUrl:juce::String();}
 juce::String loadError()const{return browser?browser->loadError:juce::String("Browser runtime unavailable");}
 SpliceBrowser(){
  setLookAndFeel(&look);
  for(auto*c:std::initializer_list<juce::Component*>{&back,&forward,&reload,&account,&close,&title,&error,&address})addAndMakeVisible(c);
  title.setText("Splice",juce::dontSendNotification);title.setColour(juce::Label::textColourId,juce::Colour(0xff202124));
  account.setColour(juce::TextButton::textColourOffId,juce::Colour(0xff174ea6));
  address.setColour(juce::TextEditor::backgroundColourId,juce::Colour(0xffe9eef6));address.setColour(juce::TextEditor::textColourId,juce::Colour(0xff202124));
  address.setColour(juce::TextEditor::outlineColourId,juce::Colours::transparentBlack);address.setColour(juce::TextEditor::focusedOutlineColourId,juce::Colour(0xff1a73e8));
  address.setColour(juce::CaretComponent::caretColourId,juce::Colour(0xff202124));address.setColour(juce::TextEditor::highlightColourId,juce::Colour(0xffc2dbff));address.setColour(juce::TextEditor::highlightedTextColourId,juce::Colour(0xff202124));
  address.setIndents(12,8);address.setFont(juce::Font(juce::FontOptions(14.f)));address.setSelectAllWhenFocused(true);address.setTitle("Address");address.setTooltip("HTTPS address");
  address.onReturnKey=[this]{auto url=address.getText().trim();if(!url.contains("://"))url="https://"+url;if(url.startsWithIgnoreCase("https://"))open(url);};
  address.onEscapeKey=[this]{if(browser)address.setText(browser->loadedUrl,false);giveAwayKeyboardFocus();};
  error.setColour(juce::Label::textColourId,juce::Colour(0xffb3261e));error.setJustificationType(juce::Justification::centred);error.setVisible(false);
  auto override=juce::SystemStats::getEnvironmentVariable("DRUMATLAS_CACHE_DIR",{});auto profile=(override.isNotEmpty()?juce::File(override):juce::File::getSpecialLocation(juce::File::userApplicationDataDirectory).getChildFile("DrumAtlas")).getChildFile("WebView2");
 #if JUCE_WINDOWS
  auto options=juce::WebBrowserComponent::Options{}.withBackend(juce::WebBrowserComponent::Options::Backend::webview2).withWinWebView2Options(juce::WebBrowserComponent::Options::WinWebView2{}.withUserDataFolder(profile));
 #else
  auto options=juce::WebBrowserComponent::Options{};
 #endif
  if(juce::WebBrowserComponent::areOptionsSupported(options)){
   browser=std::make_unique<Browser>(options);addAndMakeVisible(*browser);
   browser->changed=[this](const juce::String&url){address.setText(url,false);error.setVisible(false);resized();};
   browser->failed=[this]{error.setText("Unable to load page. Check your connection and reload.",juce::dontSendNotification);error.setVisible(true);resized();};
  }else{error.setText("Browser runtime unavailable. Install Microsoft Edge WebView2 Runtime on Windows.",juce::dontSendNotification);error.setVisible(true);}
  account.onClick=[this]{if(onAccount)onAccount();};back.onClick=[this]{if(browser)browser->goBack();};forward.onClick=[this]{if(browser)browser->goForward();};reload.onClick=[this]{if(browser)browser->refresh();};close.onClick=[this]{if(onClose)onClose();};
  for(auto*b:{&back,&forward,&reload})b->setEnabled(browser!=nullptr);
 }
 ~SpliceBrowser()override{browser.reset();setLookAndFeel(nullptr);}
 void open(const juce::String&url){if(browser&&url.startsWithIgnoreCase("https://"))browser->goToURL(url);}
 void localise(const juce::String&closeText,const juce::String&accountText){close.setTooltip(closeText);account.setButtonText(accountText);resized();}
 void paint(juce::Graphics&g)override{
  g.fillAll(juce::Colours::white);g.setColour(juce::Colour(0xffdee5ef));g.fillRect(0,0,getWidth(),40);
  g.setColour(juce::Colour(0xfff8fafd));g.fillRoundedRectangle(8.f,6.f,float(juce::jmin(240,getWidth()-56)),42.f,12.f);g.fillRect(0,40,getWidth(),48);
  g.setColour(juce::Colour(0xffdadce0));g.drawHorizontalLine(88,0,float(getWidth()));
 }
 void resized()override{
  title.setBounds(22,8,juce::jmax(0,juce::jmin(200,getWidth()-70)),28);close.setBounds(getWidth()-38,4,32,32);
  auto row=getLocalBounds().withY(46).withHeight(34).reduced(8,0);
  back.setBounds(row.removeFromLeft(34));forward.setBounds(row.removeFromLeft(34));reload.setBounds(row.removeFromLeft(34));row.removeFromLeft(8);
  int aw=juce::jlimit(90,180,24+int(account.getButtonText().length()*8));account.setBounds(row.removeFromRight(juce::jmin(aw,juce::jmax(0,row.getWidth()/3))));row.removeFromRight(8);address.setBounds(row);
  auto body=getLocalBounds().withTrimmedTop(89);if(error.isVisible())error.setBounds(browser?body.removeFromBottom(36):body.reduced(20));if(browser)browser->setBounds(body);
 }
};
}
