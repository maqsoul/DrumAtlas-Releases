#include "Platform.h"
#include <juce_cryptography/juce_cryptography.h>
#include <Security/Security.h>
#include <IOKit/IOKitLib.h>
namespace atlas {
template<class T>struct CFValue {T value=nullptr;explicit CFValue(T v=nullptr):value(v){}~CFValue(){if(value)CFRelease(value);}operator T()const{return value;}CFValue(const CFValue&)=delete;};
juce::String macMachineCode(){
 auto entry=IOServiceGetMatchingService(kIOMainPortDefault,IOServiceMatching("IOPlatformExpertDevice"));if(!entry)return {};
 CFValue<CFTypeRef> value(IORegistryEntryCreateCFProperty(entry,CFSTR("IOPlatformUUID"),kCFAllocatorDefault,0));IOObjectRelease(entry);
 if(!value.value||CFGetTypeID(value.value)!=CFStringGetTypeID())return {};char uuid[256]{};if(!CFStringGetCString(static_cast<CFStringRef>(value.value),uuid,sizeof(uuid),kCFStringEncodingUTF8))return {};
 auto identity=juce::String("DrumAtlas-PC-v1|macOS|")+juce::String::fromUTF8(uuid);return "DA-PC-"+juce::SHA256(identity.toRawUTF8(),identity.getNumBytesAsUTF8()).toHexString();
}
bool macVerifySignature(const unsigned char*blob,size_t size,const juce::MemoryBlock&digest,const juce::MemoryBlock&signature){
 if(size!=72||signature.getSize()!=64)return false;unsigned char point[65]{4};std::copy(blob+8,blob+72,point+1);
 CFValue<CFDataRef> data(CFDataCreate(nullptr,point,65));const void*keys[]={kSecAttrKeyType,kSecAttrKeyClass};const void*values[]={kSecAttrKeyTypeECSECPrimeRandom,kSecAttrKeyClassPublic};
 CFValue<CFDictionaryRef> attributes(CFDictionaryCreate(nullptr,keys,values,2,&kCFTypeDictionaryKeyCallBacks,&kCFTypeDictionaryValueCallBacks));CFValue<SecKeyRef>key(SecKeyCreateWithData(data,attributes,nullptr));if(!key.value)return false;
 // CNG/IEEE-P1363 uses fixed-width r||s. Security.framework expects DER integers.
 juce::MemoryOutputStream integers;auto*sig=static_cast<const unsigned char*>(signature.getData());
 for(int part=0;part<2;++part){auto*p=sig+32*part;int length=32;while(length>1&&*p==0){++p;--length;}const bool pad=(*p&128)!=0;integers.writeByte(2);integers.writeByte(char(length+(pad?1:0)));if(pad)integers.writeByte(0);integers.write(p,size_t(length));}
 juce::MemoryOutputStream der;der.writeByte(0x30);der.writeByte(char(integers.getDataSize()));der.write(integers.getData(),integers.getDataSize());
 CFValue<CFDataRef>hash(CFDataCreate(nullptr,static_cast<const UInt8*>(digest.getData()),CFIndex(digest.getSize()))),encoded(CFDataCreate(nullptr,static_cast<const UInt8*>(der.getData()),CFIndex(der.getDataSize())));
 return SecKeyVerifySignature(key,kSecKeyAlgorithmECDSASignatureDigestX962SHA256,hash,encoded,nullptr);
}
void macSecureRandom(juce::MemoryBlock&bytes){if(SecRandomCopyBytes(kSecRandomDefault,bytes.getSize(),bytes.getData())!=errSecSuccess)throw std::runtime_error("Secure random unavailable");}
static CFMutableDictionaryRef credentialQuery(const juce::File&file){
 auto account=juce::SHA256(file.getFullPathName().toRawUTF8(),file.getFullPathName().getNumBytesAsUTF8()).toHexString();
 auto dict=CFDictionaryCreateMutable(nullptr,0,&kCFTypeDictionaryKeyCallBacks,&kCFTypeDictionaryValueCallBacks);CFDictionarySetValue(dict,kSecClass,kSecClassGenericPassword);CFDictionarySetValue(dict,kSecAttrService,CFSTR("audio.drumatlas.browser.splice"));
 CFValue<CFStringRef>name(CFStringCreateWithCString(nullptr,account.toRawUTF8(),kCFStringEncodingUTF8));CFDictionarySetValue(dict,kSecAttrAccount,name);return dict;
}
void macSaveProtected(const juce::File&file,const juce::String&text){
 CFValue<CFMutableDictionaryRef>query(credentialQuery(file));CFValue<CFDataRef>data(CFDataCreate(nullptr,reinterpret_cast<const UInt8*>(text.toRawUTF8()),CFIndex(text.getNumBytesAsUTF8())));
 const void*keys[]={kSecValueData};const void*values[]={data.value};CFValue<CFDictionaryRef>update(CFDictionaryCreate(nullptr,keys,values,1,&kCFTypeDictionaryKeyCallBacks,&kCFTypeDictionaryValueCallBacks));auto status=SecItemUpdate(query,update);
 if(status==errSecItemNotFound){CFDictionarySetValue(query,kSecValueData,data);CFDictionarySetValue(query,kSecAttrAccessible,kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly);status=SecItemAdd(query,nullptr);}
 if(status!=errSecSuccess)throw std::runtime_error("Cannot save Splice login in Keychain");file.getParentDirectory().createDirectory();if(!file.replaceWithText("Keychain"))throw std::runtime_error("Cannot save Keychain reference");
}
juce::String macLoadProtected(const juce::File&file){
 if(file.loadFileAsString()!="Keychain")return {};CFValue<CFMutableDictionaryRef>query(credentialQuery(file));CFDictionarySetValue(query,kSecReturnData,kCFBooleanTrue);CFTypeRef raw=nullptr;auto status=SecItemCopyMatching(query,&raw);CFValue<CFTypeRef>result(raw);
 if(status!=errSecSuccess||!raw||CFGetTypeID(raw)!=CFDataGetTypeID())return {};auto data=static_cast<CFDataRef>(raw);if(CFDataGetLength(data)>1024*1024)return {};return juce::String::fromUTF8(reinterpret_cast<const char*>(CFDataGetBytePtr(data)),int(CFDataGetLength(data)));
}
void macDeleteProtected(const juce::File&file){CFValue<CFMutableDictionaryRef>query(credentialQuery(file));SecItemDelete(query);file.deleteFile();}
}
