// Windows HTTPS transport, local OAuth callback and per-user encrypted token storage.
#define NOMINMAX
#include "Splice.h"
#include "SplicePreview.h"
#include "Platform.h"
#include <juce_cryptography/juce_cryptography.h>
#if JUCE_WINDOWS
#include <windows.h>
#include <winhttp.h>
#include <wincrypt.h>
#include <bcrypt.h>
#else
#include <unistd.h>
#include <cerrno>
#endif
#include <deque>
#include <set>
#include <regex>
namespace atlas {
namespace {
using String=juce::String;
const String spliceOrigin="https://mcp.splice.com",spliceEndpoint=spliceOrigin+"/mcp";
juce::var object(std::initializer_list<std::pair<juce::Identifier,juce::var>> entries){auto*o=new juce::DynamicObject;for(auto&e:entries)o->setProperty(e.first,e.second);return juce::var(o);}
String field(const juce::var&v,const char*k){return v.getProperty(k,{}).toString();}
#if JUCE_WINDOWS
struct InternetHandle{HINTERNET h=nullptr;explicit InternetHandle(HINTERNET v):h(v){}~InternetHandle(){if(h)WinHttpCloseHandle(h);}operator HINTERNET()const{return h;}};
// Async WinHTTP keeps cancellation on the worker; UI shutdown only sets a flag.
struct RequestControl {std::atomic<bool> stopping{false};std::function<bool()>cancelled;bool isCancelled(){return stopping||(cancelled&&cancelled());}void interrupt(){}void stop(){stopping=true;}};
thread_local RequestControl* requestControl=nullptr;
struct RequestHandle {
 HINTERNET h;juce::WaitableEvent completed,closed;std::atomic<DWORD>status{0},bytes{0};bool callbackInstalled=false;
 explicit RequestHandle(HINTERNET value):h(value){
  if(!h)throw std::runtime_error("HTTPS request unavailable");
  DWORD_PTR context=reinterpret_cast<DWORD_PTR>(this);
  if(!WinHttpSetOption(h,WINHTTP_OPTION_CONTEXT_VALUE,&context,sizeof(context)))throw std::runtime_error("HTTPS context unavailable");
  callbackInstalled=WinHttpSetStatusCallback(h,callback,WINHTTP_CALLBACK_FLAG_ALL_COMPLETIONS|WINHTTP_CALLBACK_FLAG_HANDLES,0)!=WINHTTP_INVALID_STATUS_CALLBACK;
  if(!callbackInstalled)throw std::runtime_error("HTTPS callbacks unavailable");
 }
 ~RequestHandle(){if(h){WinHttpCloseHandle(h);if(callbackInstalled)closed.wait(-1);}}
 operator HINTERNET()const{return h;}
 static void CALLBACK callback(HINTERNET,DWORD_PTR context,DWORD code,LPVOID,DWORD count){
  auto*self=reinterpret_cast<RequestHandle*>(context);if(!self)return;
  if(code==WINHTTP_CALLBACK_STATUS_HANDLE_CLOSING){self->closed.signal();return;}
  if(code==WINHTTP_CALLBACK_STATUS_SENDREQUEST_COMPLETE||code==WINHTTP_CALLBACK_STATUS_HEADERS_AVAILABLE||code==WINHTTP_CALLBACK_STATUS_READ_COMPLETE||code==WINHTTP_CALLBACK_STATUS_REQUEST_ERROR){self->bytes=count;self->status=code;self->completed.signal();}
 }
 void wait(DWORD expected){const auto deadline=juce::Time::getMillisecondCounterHiRes()+60000;
  for(;;){if(requestControl&&requestControl->isCancelled())throw std::runtime_error("Request cancelled");
   if(completed.wait(50)){if(status!=expected)throw std::runtime_error("Network request failed or timed out");return;}
   if(juce::Time::getMillisecondCounterHiRes()>deadline)throw std::runtime_error("Network request timed out");
  }
 }
};
struct HttpReply{int status=0;juce::MemoryBlock bytes;String session,location;String text()const{return String::fromUTF8(static_cast<const char*>(bytes.getData()),int(bytes.getSize()));}};
HttpReply https(const String&url,const String&method,const String&body={},const String&headers={},size_t limit=8*1024*1024){
 if(requestControl&&requestControl->isCancelled())throw std::runtime_error("Request cancelled");
 if(!url.startsWith("https://"))throw std::runtime_error("HTTPS required");URL_COMPONENTS uc{};uc.dwStructSize=sizeof(uc);uc.dwHostNameLength=uc.dwUrlPathLength=uc.dwExtraInfoLength=DWORD(-1);auto wide=url.toWideCharPointer();if(!WinHttpCrackUrl(wide,0,0,&uc))throw std::runtime_error("Invalid HTTPS URL");
 String host(uc.lpszHostName,int(uc.dwHostNameLength)),path(uc.lpszUrlPath,int(uc.dwUrlPathLength));if(uc.dwExtraInfoLength)path+=String(uc.lpszExtraInfo,int(uc.dwExtraInfoLength));if(path.isEmpty())path="/";
 InternetHandle session(WinHttpOpen(L"DrumAtlas/1.0.0",WINHTTP_ACCESS_TYPE_AUTOMATIC_PROXY,WINHTTP_NO_PROXY_NAME,WINHTTP_NO_PROXY_BYPASS,WINHTTP_FLAG_ASYNC));if(!session.h)throw std::runtime_error("HTTPS unavailable");WinHttpSetTimeouts(session,5000,10000,20000,30000);
 std::array<char,65536>buffer{};
 InternetHandle connection(WinHttpConnect(session,host.toWideCharPointer(),uc.nPort,0));RequestHandle request(WinHttpOpenRequest(connection,method.toWideCharPointer(),path.toWideCharPointer(),nullptr,WINHTTP_NO_REFERER,WINHTTP_DEFAULT_ACCEPT_TYPES,WINHTTP_FLAG_SECURE));if(!request.h)throw std::runtime_error("HTTPS request unavailable");DWORD disabled=WINHTTP_DISABLE_REDIRECTS;WinHttpSetOption(request,WINHTTP_OPTION_DISABLE_FEATURE,&disabled,sizeof(disabled));
 if(!WinHttpSendRequest(request,headers.toWideCharPointer(),DWORD(-1),body.isEmpty()?WINHTTP_NO_REQUEST_DATA:const_cast<char*>(body.toRawUTF8()),DWORD(body.getNumBytesAsUTF8()),DWORD(body.getNumBytesAsUTF8()),reinterpret_cast<DWORD_PTR>(&request))&&GetLastError()!=ERROR_IO_PENDING)throw std::runtime_error("Network send failed");
 request.wait(WINHTTP_CALLBACK_STATUS_SENDREQUEST_COMPLETE);
 if(!WinHttpReceiveResponse(request,nullptr)&&GetLastError()!=ERROR_IO_PENDING)throw std::runtime_error("Network response failed");request.wait(WINHTTP_CALLBACK_STATUS_HEADERS_AVAILABLE);
 HttpReply reply;DWORD status=0,size=sizeof(status);WinHttpQueryHeaders(request,WINHTTP_QUERY_STATUS_CODE|WINHTTP_QUERY_FLAG_NUMBER,WINHTTP_HEADER_NAME_BY_INDEX,&status,&size,WINHTTP_NO_HEADER_INDEX);reply.status=int(status);
 wchar_t sid[1024]{};size=sizeof(sid);if(WinHttpQueryHeaders(request,WINHTTP_QUERY_CUSTOM,L"Mcp-Session-Id",sid,&size,WINHTTP_NO_HEADER_INDEX))reply.session=String(sid);
 wchar_t location[8192]{};size=sizeof(location);if(WinHttpQueryHeaders(request,WINHTTP_QUERY_LOCATION,WINHTTP_HEADER_NAME_BY_INDEX,location,&size,WINHTTP_NO_HEADER_INDEX))reply.location=String(location);
 for(;;){if(!WinHttpReadData(request,buffer.data(),DWORD(buffer.size()),nullptr)&&GetLastError()!=ERROR_IO_PENDING)throw std::runtime_error("Network read failed");request.wait(WINHTTP_CALLBACK_STATUS_READ_COMPLETE);const auto count=request.bytes.load();if(!count)break;if(reply.bytes.getSize()+count>limit)throw std::runtime_error("Response too large");reply.bytes.append(buffer.data(),count);}
 return reply;
}
String form(std::initializer_list<std::pair<String,String>> entries){String out;for(auto&e:entries){if(out.isNotEmpty())out+="&";out+=juce::URL::addEscapeChars(e.first,true)+"="+juce::URL::addEscapeChars(e.second,true);}return out;}
#else
struct RequestControl {
 std::atomic<bool>stopping{false};std::function<bool()>cancelled;std::mutex lock;juce::WebInputStream*active=nullptr;
 bool isCancelled(){return stopping||(cancelled&&cancelled());}
 void interrupt(){std::lock_guard<std::mutex>g(lock);if(active)active->cancel();}
 void stop(){stopping=true;interrupt();}
};
thread_local RequestControl*requestControl=nullptr;
String form(std::initializer_list<std::pair<String,String>> entries){String out;for(auto&e:entries){if(out.isNotEmpty())out+="&";out+=juce::URL::addEscapeChars(e.first,true)+"="+juce::URL::addEscapeChars(e.second,true);}return out;}
struct HttpReply{int status=0;juce::MemoryBlock bytes;String session,location;String text()const{return String::fromUTF8(static_cast<const char*>(bytes.getData()),int(bytes.getSize()));}};
HttpReply https(const String&url,const String&method,const String&body={},const String&headers={},size_t limit=8*1024*1024){
 if(!url.startsWith("https://"))throw std::runtime_error("HTTPS required");juce::WebInputStream stream(juce::URL(url).withPOSTData(body),false);stream.withCustomRequestCommand(method).withExtraHeaders(headers).withConnectionTimeout(20000).withNumRedirectsToFollow(0);
 struct Active{RequestControl*c;Active(RequestControl*control,juce::WebInputStream&s):c(control){if(c){std::lock_guard<std::mutex>g(c->lock);c->active=&s;}}~Active(){if(c){std::lock_guard<std::mutex>g(c->lock);c->active=nullptr;}}}active(requestControl,stream);
 if(requestControl&&requestControl->isCancelled())throw std::runtime_error("Request cancelled");if(!stream.connect(nullptr))throw std::runtime_error("Network request failed");HttpReply reply;reply.status=stream.getStatusCode();auto responseHeaders=stream.getResponseHeaders();
 for(auto&key:responseHeaders.getAllKeys()){if(key.equalsIgnoreCase("Mcp-Session-Id"))reply.session=responseHeaders[key];if(key.equalsIgnoreCase("Location"))reply.location=responseHeaders[key];}
 std::array<char,65536>bytes{};while(!stream.isExhausted()){if(requestControl&&requestControl->isCancelled())throw std::runtime_error("Request cancelled");int n=stream.read(bytes.data(),int(bytes.size()));if(n<=0){if(stream.isError())throw std::runtime_error("Network read failed");break;}if(reply.bytes.getSize()+size_t(n)>limit)throw std::runtime_error("Response too large");reply.bytes.append(bytes.data(),size_t(n));}return reply;
}
#endif
#if JUCE_WINDOWS
String randomUrl(size_t size){juce::MemoryBlock bytes(size);if(BCryptGenRandom(nullptr,static_cast<PUCHAR>(bytes.getData()),ULONG(size),BCRYPT_USE_SYSTEM_PREFERRED_RNG)<0)throw std::runtime_error("Secure random unavailable");return juce::Base64::toBase64(bytes.getData(),bytes.getSize()).replaceCharacter('+','-').replaceCharacter('/','_').removeCharacters("=");}
String challenge(const String&text){BCRYPT_ALG_HANDLE alg=nullptr;BCRYPT_HASH_HANDLE hash=nullptr;std::array<unsigned char,32>digest{};if(BCryptOpenAlgorithmProvider(&alg,BCRYPT_SHA256_ALGORITHM,nullptr,0)<0)throw std::runtime_error("SHA256 unavailable");auto ok=BCryptCreateHash(alg,&hash,nullptr,0,nullptr,0,0)>=0&&BCryptHashData(hash,reinterpret_cast<PUCHAR>(const_cast<char*>(text.toRawUTF8())),ULONG(text.getNumBytesAsUTF8()),0)>=0&&BCryptFinishHash(hash,digest.data(),ULONG(digest.size()),0)>=0;if(hash)BCryptDestroyHash(hash);BCryptCloseAlgorithmProvider(alg,0);if(!ok)throw std::runtime_error("SHA256 failed");return juce::Base64::toBase64(digest.data(),digest.size()).replaceCharacter('+','-').replaceCharacter('/','_').removeCharacters("=");}
void saveProtected(const juce::File&file,const juce::var&value){auto text=juce::JSON::toString(value);DATA_BLOB in{DWORD(text.getNumBytesAsUTF8()),reinterpret_cast<BYTE*>(const_cast<char*>(text.toRawUTF8()))},out{};if(!CryptProtectData(&in,L"DrumAtlas Splice",nullptr,nullptr,nullptr,CRYPTPROTECT_UI_FORBIDDEN,&out))throw std::runtime_error("Cannot encrypt Splice login");juce::MemoryBlock bytes(out.pbData,out.cbData);LocalFree(out.pbData);file.getParentDirectory().createDirectory();if(!file.replaceWithData(bytes.getData(),bytes.getSize()))throw std::runtime_error("Cannot save Splice login");}
juce::var loadProtected(const juce::File&file){juce::MemoryBlock bytes;if(!file.loadFileAsData(bytes)||bytes.getSize()>1024*1024)return {};DATA_BLOB in{DWORD(bytes.getSize()),static_cast<BYTE*>(bytes.getData())},out{};if(!CryptUnprotectData(&in,nullptr,nullptr,nullptr,nullptr,CRYPTPROTECT_UI_FORBIDDEN,&out))return {};auto text=String::fromUTF8(reinterpret_cast<char*>(out.pbData),int(out.cbData));LocalFree(out.pbData);return juce::JSON::parse(text);}
#else
String randomUrl(size_t size){juce::MemoryBlock bytes(size);macSecureRandom(bytes);return juce::Base64::toBase64(bytes.getData(),bytes.getSize()).replaceCharacter('+','-').replaceCharacter('/','_').removeCharacters("=");}
String challenge(const String&text){auto bytes=juce::SHA256(text.toRawUTF8(),text.getNumBytesAsUTF8()).getRawData();return juce::Base64::toBase64(bytes.getData(),bytes.getSize()).replaceCharacter('+','-').replaceCharacter('/','_').removeCharacters("=");}
void saveProtected(const juce::File&file,const juce::var&value){macSaveProtected(file,juce::JSON::toString(value));}
juce::var loadProtected(const juce::File&file){return juce::JSON::parse(macLoadProtected(file));}
#endif
void deleteProtected(const juce::File&file){
#if JUCE_WINDOWS
 file.deleteFile();
#else
 macDeleteProtected(file);
#endif
}
juce::var mcpReply(const String&text,int id){auto direct=juce::JSON::parse(text);if(direct.isObject())return direct;for(auto line:juce::StringArray::fromLines(text))if(line.startsWith("data:")){auto value=juce::JSON::parse(line.substring(5).trim());if(int(value.getProperty("id",0))==id)return value;}throw std::runtime_error("Invalid Splice response");}
}
#if DRUMATLAS_ENABLE_SMOKE_TESTS
// Uses synthetic data only. Tests the same native DPAPI path used by OAuth.
void testSpliceCredentials(const juce::File& directory){
 const auto file=directory.getChildFile("credential-test-"+juce::Uuid().toString()+".dpapi");
 struct Cleanup{juce::File file;~Cleanup(){deleteProtected(file);}} cleanup{file};
 const String synthetic="synthetic-token-"+juce::Uuid().toString();
 saveProtected(file,object({{"access_token",synthetic},{"refresh_token","synthetic-refresh"}}));
 auto restored=loadProtected(file);
 if(field(restored,"access_token")!=synthetic||field(restored,"refresh_token")!="synthetic-refresh")throw std::runtime_error("DPAPI round trip failed");
 juce::MemoryBlock encrypted;file.loadFileAsData(encrypted);
 const std::string bytes(static_cast<const char*>(encrypted.getData()),encrypted.getSize());
 if(bytes.find(synthetic.toStdString())!=std::string::npos)throw std::runtime_error("Credential was saved in plaintext");
 file.replaceWithText("corrupt credential fixture");
 if(loadProtected(file).isObject())throw std::runtime_error("Corrupt credential accepted");
 if(challenge("dBjftJeZ4CVP-mB92K27uhbUJU1p1r_wW1gFWFOEjXk")!="E9Melhoa2OwvFrEMTJguCHaoeK1t8URWbuGJSstw-cM")throw std::runtime_error("PKCE S256 test vector failed");
}
#endif
juce::String splicePreviewUrl(const juce::String& pageUrl,const juce::String& html){
 std::smatch match;auto page=pageUrl.toStdString();if(!std::regex_match(page,match,std::regex("https://splice\\.com/sounds/sample/([a-f0-9]{64})/[^?#]*")))throw std::runtime_error("Unsupported Splice sample page");
 const auto hash=match[1].str();auto text=html.replace("\\\"","\"").replace("\\/","/").replace("\\u0026","&").replace("&amp;","&").toStdString();
 std::regex pattern("https://spliceproduction\\.s3\\.us-west-1\\.amazonaws\\.com/audio_samples/"+hash+"-scrambled/"+hash+"\\.mp3\\?[^\"\\\\\\s<>]+");
 if(!std::regex_search(text,match,pattern))throw std::runtime_error("Splice preview is unavailable for this sound");return juce::String(match[0].str());
}
juce::MemoryBlock decodeSplicePreview(const juce::MemoryBlock& bytes){
 const auto*data=static_cast<const unsigned char*>(bytes.getData());if(bytes.getSize()<28||data[0]!='s'||data[1]!='p')throw std::runtime_error("Unsupported Splice preview format");
 uint64_t span=0;for(int i=9;i>=2;--i){if(span>uint64_t(bytes.getSize()))throw std::runtime_error("Invalid Splice preview header");span=span*256+data[i];}
 const auto size=bytes.getSize()-28;if(span==0||span>size)throw std::runtime_error("Invalid Splice preview length");juce::MemoryBlock output(data+28,size);auto*audio=static_cast<unsigned char*>(output.getData());
 for(size_t part=0;part<2;++part){const size_t start=part*2*size_t(span);if(start>=size)continue;const size_t count=std::min(size_t(span),size-start);for(size_t i=0;i<count;++i)audio[start+i]^=data[10+i%18];}return output;
}
struct SpliceService::Impl {
 struct Job{int kind=0;String id,category;std::vector<Hit> hits;};
 Job lastSearch;int searchRound=0,page=0;std::vector<std::vector<SpliceSound>>pages;
 SpliceService&owner;RequestControl requests;std::mutex mutex,queueMutex;SpliceState state;std::deque<Job>jobs;juce::File root,authFile,settingsFile,previewDirectory;juce::var auth,tools,downloads;std::map<String,std::vector<Features>> targets;String session;int rpcId=0;std::atomic<int>generation{0};
 explicit Impl(SpliceService&o):owner(o){auto override=juce::SystemStats::getEnvironmentVariable("DRUMATLAS_CACHE_DIR",{});root=(override.isNotEmpty()?juce::File(override):juce::File::getSpecialLocation(juce::File::userApplicationDataDirectory).getChildFile("DrumAtlas")).getChildFile("splice");previewDirectory=root.getChildFile("previews").getChildFile(juce::Uuid().toString());authFile=root.getChildFile("auth.dpapi");downloads=juce::JSON::parse(root.getChildFile("downloads.json"));if(!downloads.isObject())downloads=object({});for(auto&entry:downloads.getDynamicObject()->getProperties()){auto path=entry.value.toString();if(ioFile(juce::File(path)).existsAsFile())state.downloadedPaths.addIfNotAlreadyThere(path);}settingsFile=root.getChildFile("settings.json");auto saved=juce::JSON::parse(settingsFile);state.folder=field(saved,"folder");if(state.folder.isEmpty())state.folder=juce::File::getSpecialLocation(juce::File::userDocumentsDirectory).getChildFile("DrumAtlas Samples").getChildFile("Splice").getFullPathName();if(field(saved,"folder").isEmpty()&&juce::File("F:/").isDirectory())state.folder="F:/DrumAtlas Samples/Splice";}
 bool cancelled(int g)const{return owner.threadShouldExit()||generation.load()!=g;}
 void status(const String&key,bool busy,const String&detail={}){std::lock_guard<std::mutex>g(mutex);state.status=key;state.busy=busy;state.detail=detail;++state.revision;}
 void push(Job job){++generation;requests.interrupt();{std::lock_guard<std::mutex>g(queueMutex);jobs.clear();jobs.push_back(std::move(job));}status("spliceWorking",true);owner.notify();}
 void saveAuth(){saveProtected(authFile,auth);}
 void token(){if(!auth.isObject()||field(auth,"access_token").isEmpty())throw std::runtime_error("Sign in to Splice first");if(double(auth.getProperty("expires_at",0))>juce::Time::currentTimeMillis()/1000.+90)return;
  const auto refresh=field(auth,"refresh_token");if(refresh.isEmpty())throw std::runtime_error("Splice session expired. Sign in again.");auto reply=https(spliceOrigin+"/oauth/token","POST",form({{"grant_type","refresh_token"},{"refresh_token",refresh},{"client_id",field(auth,"client_id")}}),"Content-Type: application/x-www-form-urlencoded\r\n");if(reply.status!=200){std::lock_guard<std::mutex>lock(mutex);state.connected=false;throw std::runtime_error("Splice session expired. Sign in again.");}auto updated=juce::JSON::parse(reply.text());if(field(updated,"access_token").isEmpty())throw std::runtime_error("Invalid Splice token response");updated.getDynamicObject()->setProperty("client_id",field(auth,"client_id"));if(field(updated,"refresh_token").isEmpty())updated.getDynamicObject()->setProperty("refresh_token",refresh);updated.getDynamicObject()->setProperty("expires_at",juce::Time::currentTimeMillis()/1000.+double(updated.getProperty("expires_in",3600)));auth=updated;saveAuth();
 }
 juce::var rpc(const String&method,const juce::var&params){token();int id=++rpcId;String headers="Content-Type: application/json\r\nAccept: application/json, text/event-stream\r\nAuthorization: Bearer "+field(auth,"access_token")+"\r\nMCP-Protocol-Version: 2025-03-26\r\n";if(session.isNotEmpty())headers+="Mcp-Session-Id: "+session+"\r\n";auto reply=https(spliceEndpoint,"POST",juce::JSON::toString(object({{"jsonrpc","2.0"},{"id",id},{"method",method},{"params",params}}),true),headers);if(reply.status==401){std::lock_guard<std::mutex>lock(mutex);state.connected=false;session.clear();throw std::runtime_error("Splice session expired. Sign in again.");}if(reply.status<200||reply.status>=300)throw std::runtime_error(("Splice HTTP "+String(reply.status)).toStdString());if(reply.session.isNotEmpty())session=reply.session;auto result=mcpReply(reply.text(),id);if(result.hasProperty("error"))throw std::runtime_error(("Splice: "+field(result["error"],"message").substring(0,300)).toStdString());return result["result"];}
 void initialise(){session.clear();rpc("initialize",object({{"protocolVersion","2025-03-26"},{"capabilities",object({})},{"clientInfo",object({{"name","DrumAtlas"},{"version","1.0.0"}})}}));String headers="Content-Type: application/json\r\nAccept: application/json, text/event-stream\r\nAuthorization: Bearer "+field(auth,"access_token")+"\r\nMCP-Protocol-Version: 2025-03-26\r\n";if(session.isNotEmpty())headers+="Mcp-Session-Id: "+session+"\r\n";auto ready=https(spliceEndpoint,"POST",juce::JSON::toString(object({{"jsonrpc","2.0"},{"method","notifications/initialized"}}),true),headers);if(ready.status<200||ready.status>=300)throw std::runtime_error("Splice initialisation failed");tools=rpc("tools/list",object({}));}
 void login(int g){juce::StreamingSocket listener;if(!listener.createListener(0,"127.0.0.1"))throw std::runtime_error("Cannot start local sign-in callback");const auto redirect="http://127.0.0.1:"+String(listener.getBoundPort())+"/callback";juce::Array<juce::var>redirects;redirects.add(redirect);juce::Array<juce::var>grants;grants.add("authorization_code");grants.add("refresh_token");juce::Array<juce::var>responses;responses.add("code");auto registration=https(spliceOrigin+"/oauth/register","POST",juce::JSON::toString(object({{"client_name","DrumAtlas"},{"redirect_uris",redirects},{"grant_types",grants},{"response_types",responses},{"token_endpoint_auth_method","none"}}),true),"Content-Type: application/json\r\n");if(registration.status!=201)throw std::runtime_error("Splice client registration failed");auto client=juce::JSON::parse(registration.text());const auto id=field(client,"client_id"),verifier=randomUrl(48),nonce=randomUrl(24);if(id.isEmpty())throw std::runtime_error("Invalid Splice client registration");auto url=spliceOrigin+"/oauth/authorize?"+form({{"client_id",id},{"redirect_uri",redirect},{"response_type","code"},{"scope","openid profile email offline_access"},{"state",nonce},{"code_challenge",challenge(verifier)},{"code_challenge_method","S256"},{"resource",spliceEndpoint}});
  {std::lock_guard<std::mutex>lock(mutex);state.loginUrl=url;state.status="spliceLoginWaiting";++state.revision;}
  const double until=juce::Time::getMillisecondCounterHiRes()+300000;
  while(!cancelled(g)&&juce::Time::getMillisecondCounterHiRes()<until){if(listener.waitUntilReady(true,200)<=0)continue;std::unique_ptr<juce::StreamingSocket>socket(listener.waitForNextConnection());if(!socket)continue;if(!socket->isLocal())continue;String request;const double deadline=juce::Time::getMillisecondCounterHiRes()+3000;while(!cancelled(g)&&!request.contains("\r\n\r\n")&&request.length()<8192&&juce::Time::getMillisecondCounterHiRes()<deadline){if(socket->waitUntilReady(true,100)<=0)continue;char bytes[1024]{};int n=socket->read(bytes,1023,false);if(n<=0)break;request+=String::fromUTF8(bytes,n);}auto first=request.upToFirstOccurrenceOf("\r\n",false,false);auto parts=juce::StringArray::fromTokens(first," ",{});if(parts.size()<2||parts[0]!="GET"||!parts[1].startsWith("/callback?")){const char*notFound="HTTP/1.1 404 Not Found\r\nConnection: close\r\nContent-Length: 0\r\n\r\n";socket->write(notFound,int(strlen(notFound)));continue;}juce::URL callback("http://127.0.0.1"+parts[1]);auto names=callback.getParameterNames(),values=callback.getParameterValues();auto parameter=[&](const String&name){int index=names.indexOf(name);return index>=0?values[index]:String();};if(parameter("state")!=nonce)continue;
   if(parameter("error").isNotEmpty()||parameter("code").isEmpty())throw std::runtime_error("Splice sign-in was cancelled");auto reply=https(spliceOrigin+"/oauth/token","POST",form({{"grant_type","authorization_code"},{"code",parameter("code")},{"client_id",id},{"redirect_uri",redirect},{"code_verifier",verifier}}),"Content-Type: application/x-www-form-urlencoded\r\n");if(reply.status!=200)throw std::runtime_error("Splice token exchange failed");auth=juce::JSON::parse(reply.text());if(!auth.isObject()||field(auth,"access_token").isEmpty())throw std::runtime_error("Invalid Splice sign-in response");auth.getDynamicObject()->setProperty("client_id",id);auth.getDynamicObject()->setProperty("expires_at",juce::Time::currentTimeMillis()/1000.+double(auth.getProperty("expires_in",3600)));saveAuth();const String page="<html><meta charset='utf-8'><h2>DrumAtlas connected to Splice</h2><p>You can close this tab and return to DrumAtlas.</p></html>";auto response="HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\nConnection: close\r\nContent-Length: "+String(page.getNumBytesAsUTF8())+"\r\n\r\n"+page;socket->write(response.toRawUTF8(),int(response.getNumBytesAsUTF8()));initialise();{std::lock_guard<std::mutex>lock(mutex);state.connected=true;state.loginUrl.clear();}status("spliceConnected",false);return;
  }
  status("spliceLoginCancelled",false);{std::lock_guard<std::mutex>lock(mutex);state.loginUrl.clear();}
 }
 juce::var call(const String&name,const juce::var&args){auto reply=rpc("tools/call",object({{"name",name},{"arguments",args}}));if(bool(reply.getProperty("isError",false)))throw std::runtime_error("Splice could not complete this request");if(reply.hasProperty("structuredContent"))return reply["structuredContent"];auto content=reply.getProperty("content",{});if(auto*items=content.getArray())for(auto&item:*items)if(field(item,"type")=="text"){auto parsed=juce::JSON::parse(field(item,"text"));if(!parsed.isVoid())return parsed;}return reply;}
 void saveDownloads(){root.createDirectory();if(!root.getChildFile("downloads.json").replaceWithText(juce::JSON::toString(downloads)))throw std::runtime_error("Cannot save Splice download index");}
 void rank(SpliceSound& sound){auto target=targets.find(sound.category);if(target==targets.end()||sound.localPath.isEmpty())return;juce::AudioFormatManager fm;registerFormats(fm);auto decoded=decode(fm,juce::File(sound.localPath),0,5);if(decoded.error.isNotEmpty())return;auto features=describe(decoded.mono);Neural model;auto result=model.analyse(decoded.mono);if(result.valid)features.embedding=result.embedding;std::vector<float>scores;for(auto&query:target->second)scores.push_back(referenceDistance(query,features,sound.category));std::sort(scores.begin(),scores.end());if(scores.empty())return;size_t n=std::min(size_t(3),scores.size());sound.distance=0;for(size_t i=0;i<n;++i)sound.distance+=scores[i]/float(n);sound.ranked=true;}
 ~Impl(){previewDirectory.deleteRecursively();}
 void searchSounds(const Job&,int,bool append=false);
 void showPage(int next){page=next;std::lock_guard<std::mutex>g(mutex);state.sounds=pages[size_t(page)];for(auto&sound:state.sounds)if(sound.localPath.isNotEmpty()&&!ioFile(juce::File(sound.localPath)).existsAsFile()){sound.localPath.clear();sound.owned=false;sound.ranked=false;}state.previewReady.clear();state.downloadReady.clear();state.hasPrevious=page>0;state.hasMore=true;state.busy=false;state.status="spliceResults";++state.revision;}void previewSound(const String&,int);void downloadSound(const String&,int);
};
SpliceService::SpliceService():juce::Thread("DrumAtlas Splice"),impl(std::make_unique<Impl>(*this)){startThread();}
SpliceService::~SpliceService(){signalThreadShouldExit();++impl->generation;impl->requests.stop();notify();stopThread(-1);}
SpliceState SpliceService::snapshot(){std::lock_guard<std::mutex>g(impl->mutex);return impl->state;}
void SpliceService::connect(){impl->push({0});}
void SpliceService::disconnect(){impl->push({1});}
void SpliceService::setFolder(const juce::File&file){impl->push({2,file.getFullPathName()});}
void SpliceService::search(const std::vector<Hit>&hits,const String&category){Impl::Job job;job.kind=3;job.hits=hits;job.category=category;impl->push(std::move(job));}
void SpliceService::preview(const String&id){impl->push({4,id});}
void SpliceService::download(const String&id){impl->push({5,id});}
void SpliceService::more(){impl->push({7});}
void SpliceService::previous(){impl->push({8});}
void SpliceService::clearResults(){impl->push({6});}
String SpliceService::queryFor(const Hit&hit){auto category=hit.category=="Keys"?String("piano"):hit.category.toLowerCase();String query=category;auto&f=hit.features;if(isDrum(hit.category)){query+=(f.tail<.12f?" short tight":" sustained");if(f.centroid>3500)query+=" bright";else if(f.centroid<900)query+=" deep dark";if(f.flatness>.35f)query+=" noisy";query+=" one shot";}else{query+=f.centroid>3000?" bright":" warm";query+=f.duration>1.5?" loop":" one shot";}return query;}
void SpliceService::run(){
 requestControl=&impl->requests;
 try{impl->auth=loadProtected(impl->authFile);std::lock_guard<std::mutex>g(impl->mutex);impl->state.connected=!field(impl->auth,"access_token").isEmpty();impl->state.status=impl->state.connected?"spliceConnected":"spliceDisconnected";++impl->state.revision;}catch(...){}
 while(!threadShouldExit()){Impl::Job job;bool found=false;{std::lock_guard<std::mutex>g(impl->queueMutex);if(!impl->jobs.empty()){job=std::move(impl->jobs.front());impl->jobs.pop_front();found=true;}}if(!found){wait(200);continue;}int generation=impl->generation.load();impl->requests.cancelled=[this,generation]{return impl->cancelled(generation);};try{if(job.kind==0)impl->login(generation);else if(job.kind==1){impl->auth=juce::var();impl->session.clear();deleteProtected(impl->authFile);impl->pages.clear();impl->targets.clear();impl->lastSearch={};impl->page=0;{std::lock_guard<std::mutex>g(impl->mutex);impl->state.connected=false;impl->state.loginUrl.clear();impl->state.sounds.clear();impl->state.hasPrevious=false;impl->state.hasMore=false;impl->state.previewReady.clear();impl->state.downloadReady.clear();}impl->status("spliceDisconnected",false);}else if(job.kind==2){auto file=juce::File(job.id);if(!ioFile(file).isDirectory()&&ioFile(file).createDirectory().failed())throw std::runtime_error("Cannot create Splice sample folder");impl->root.createDirectory();if(!impl->settingsFile.replaceWithText(juce::JSON::toString(object({{"folder",file.getFullPathName()}}))))throw std::runtime_error("Cannot save Splice folder");{std::lock_guard<std::mutex>g(impl->mutex);impl->state.folder=file.getFullPathName();}impl->status("spliceFolderSaved",false);}else if(job.kind==3)impl->searchSounds(job,generation);else if(job.kind==4)impl->previewSound(job.id,generation);else if(job.kind==5)impl->downloadSound(job.id,generation);else if(job.kind==7){if(impl->page+1<int(impl->pages.size()))impl->showPage(impl->page+1);else impl->searchSounds(impl->lastSearch,generation,true);}else if(job.kind==8){if(impl->page>0)impl->showPage(impl->page-1);else impl->status("spliceResults",false);}else if(job.kind==6){impl->pages.clear();impl->lastSearch={};impl->page=0;std::lock_guard<std::mutex>g(impl->mutex);impl->state.sounds.clear();impl->state.hasPrevious=false;impl->state.hasMore=false;impl->state.previewReady.clear();impl->state.downloadReady.clear();impl->state.status=impl->state.connected?"spliceConnected":"spliceDisconnected";impl->state.busy=false;++impl->state.revision;}}catch(const std::exception&e){if(impl->cancelled(generation))continue;impl->status("spliceError",false,String::fromUTF8(e.what()).substring(0,300));}}
}

namespace {
String responseText(const juce::var&result){String text;auto content=result.getProperty("content",{});if(auto*items=content.getArray())for(auto&item:*items)if(field(item,"type")=="text")text+=field(item,"text")+"\n";return text;}
bool assetId(const String&s){if(s.length()!=36)return false;for(int i=0;i<36;++i){if(i==8||i==13||i==18||i==23){if(s[i]!='-')return false;}else if(juce::CharacterFunctions::getHexDigitValue(s[i])<0)return false;}return true;}
String categoryFor(const String&name,const String&tags){auto label=nameLabel(name);if(label.category!="Other")return label.category;if(label.method=="Ambiguous tag")return "Other";auto fallback=nameLabel(tags.replaceCharacter(',',' ')).category;return excludedCategories(name).contains(fallback)?String("Other"):fallback;}
bool soundPage(const String&url){return url.startsWith("https://splice.com/sounds/")||url.startsWith("https://www.splice.com/sounds/");}
bool assetUrl(const String&url){if(!url.startsWith("https://"))return false;auto host=juce::URL(url).getDomain().toLowerCase();return host.endsWith(".splice.com")||host.endsWith(".splicecloud.com")||host.endsWith(".amazonaws.com")||host.endsWith(".cloudfront.net");}
String downloadUrl(const juce::var&response){for(auto key:{"download_url","presigned_url","url"}){auto value=field(response,key);if(assetUrl(value))return value;}auto text=responseText(response).toStdString();const std::regex urls(R"(https://[^\s<>"\]\)]+)");for(std::sregex_iterator it(text.begin(),text.end(),urls),end;it!=end;++it){auto value=String((*it)[0].str()).replace("&amp;","&");if(assetUrl(value))return value;}return {};}
}
juce::File storeSpliceAudio(const juce::File& folder,const SpliceSound& sound,const juce::MemoryBlock& bytes){
 if(!assetId(sound.id)||!categories().contains(sound.category))throw std::runtime_error("Invalid sample metadata");
 const auto target=folder.getChildFile(sound.category);if(ioFile(target).createDirectory().failed())throw std::runtime_error("Cannot create download folder");
 auto name=juce::File::createLegalFileName(sound.name).substring(0,160);if(name.isEmpty())name="sample.wav";
 const auto temporary=target.getChildFile(juce::Uuid().toString()+".part");
 struct Cleanup{juce::File file;~Cleanup(){ioFile(file).deleteFile();}}cleanup{temporary};
 if(!ioFile(temporary).replaceWithData(bytes.getData(),bytes.getSize()))throw std::runtime_error("Cannot save downloaded sample");
 juce::AudioFormatManager fm;registerFormats(fm);std::unique_ptr<juce::AudioFormatReader>reader(fm.createReaderFor(ioFile(temporary)));
 if(!reader||reader->lengthInSamples<=0||reader->numChannels==0)throw std::runtime_error("Downloaded file is not supported audio");reader.reset();
 // MoveFileEx without REPLACE_EXISTING never overwrites a user's existing file.
 for(int attempt=0;attempt<10;++attempt){auto destination=target.getNonexistentChildFile(sound.id+"_"+name,{},false);
#if JUCE_WINDOWS
  if(MoveFileExW(ioFile(temporary).getFullPathName().toWideCharPointer(),ioFile(destination).getFullPathName().toWideCharPointer(),MOVEFILE_WRITE_THROUGH))return destination;
  if(GetLastError()!=ERROR_ALREADY_EXISTS&&GetLastError()!=ERROR_FILE_EXISTS)break;
#else
  if(::link(temporary.getFullPathName().toRawUTF8(),destination.getFullPathName().toRawUTF8())==0)return destination;
  if(errno!=EEXIST)break;
#endif
 }
 throw std::runtime_error("Cannot move downloaded sample to its folder");
}
std::vector<SpliceSound> SpliceService::parseSearch(const juce::var&response){
 std::vector<SpliceSound>out;auto text=responseText(response);SpliceSound current;auto finish=[&]{if(assetId(current.id)&&current.name.isNotEmpty()&&soundPage(current.pageUrl)){current.category=categoryFor(current.name,current.tags);out.push_back(current);}current={};};
 for(auto line:juce::StringArray::fromLines(text)){line=line.trim();if(line.startsWith("### ")){finish();auto title=line.substring(4);int at=title.indexOf(". ");current.name=at>=0?title.substring(at+2):title;}
  else if(line.startsWith("**Asset UUID:**"))current.id=line.fromFirstOccurrenceOf("**Asset UUID:**",false,false).trim();
  else if(line.startsWith("**Link:**"))current.pageUrl=line.fromFirstOccurrenceOf("**Link:**",false,false).trim();
  else if(line.startsWith("**Tags:**"))current.tags=line.fromFirstOccurrenceOf("**Tags:**",false,false).trim();
  else if(line.startsWith("Duration:")){current.duration=line.substring(9).getDoubleValue();current.kind=line.contains("oneshot")?"One-shot":"Loop";}
 }
 finish();return out;
}
void SpliceService::Impl::searchSounds(const Job&job,int generation,bool append){
 if(!append){lastSearch=job;searchRound=0;pages.clear();page=0;}else ++searchRound;
 if(job.hits.empty())throw std::runtime_error("Analyse a reference track first");if(session.isEmpty())initialise();std::map<String,Hit>chosen;for(auto&hit:job.hits)if(job.category.isEmpty()||job.category==hit.category){auto i=chosen.find(hit.category);if(i==chosen.end()||hit.confidence>i->second.confidence)chosen[hit.category]=hit;}if(chosen.empty())throw std::runtime_error("No reference hits for this instrument. Analyse this category first.");
 targets.clear();std::vector<SpliceSound>sounds;std::set<String>seen;if(append)for(auto&past:pages)for(auto&sound:past)seen.insert(sound.id);int processed=0;
 for(auto&entry:chosen){if(cancelled(generation))return;status("spliceSearching",true,String(++processed)+" / "+String(int(chosen.size()))+" · "+entry.first);for(const auto&hit:job.hits)if(hit.category==entry.first)targets[entry.first].push_back(hit.features);auto query=SpliceService::queryFor(entry.second);if(searchRound>0){const char*variants[]={" dry clean isolated"," punchy studio recording"," natural detailed"," electronic textured"," warm rounded"};query+=variants[(searchRound-1)%5];}auto args=object({{"query",query}});if(isDrum(entry.first))args.getDynamicObject()->setProperty("type","oneshot");auto response=call("describe_a_sound",args);auto found=SpliceService::parseSearch(response);
  for(auto&sound:found){if(sound.category!=entry.first)continue;if(!seen.insert(sound.id).second)continue;auto path=field(downloads,sound.id.toRawUTF8());if(path.isNotEmpty()&&ioFile(juce::File(path)).existsAsFile()){sound.localPath=path;sound.owned=true;rank(sound);}sounds.push_back(std::move(sound));}
 }
 if(cancelled(generation))return;
 // The official MCP returns metadata only. Never label text-search results as acoustic matches.
 {std::lock_guard<std::mutex>lock(mutex);std::stable_sort(sounds.begin(),sounds.end(),[](const auto&a,const auto&b){if(a.category!=b.category)return a.category<b.category;if(a.ranked!=b.ranked)return a.ranked;return a.ranked&&a.distance<b.distance;});if(append&&sounds.empty()){state.hasMore=false;state.busy=false;state.status="spliceNoMore";++state.revision;return;}pages.push_back(sounds);page=int(pages.size())-1;state.sounds=std::move(sounds);state.hasPrevious=page>0;state.hasMore=!state.sounds.empty();state.previewReady.clear();state.downloadReady.clear();}status("spliceResults",false);
}
void SpliceService::Impl::previewSound(const String&id,int generation){
 SpliceSound selected;{std::lock_guard<std::mutex>lock(mutex);for(auto&s:state.sounds)if(s.id==id){selected=s;break;}}
 if(selected.id.isEmpty())throw std::runtime_error("Select a Splice sound");
 auto path=selected.localPath;
 if(path.isEmpty()||!ioFile(juce::File(path)).existsAsFile()){
  auto file=previewDirectory.getChildFile(selected.id+".mp3");
  if(!file.existsAsFile()){
   auto pageUrl=selected.pageUrl;HttpReply page;for(int hop=0;hop<4;++hop){page=https(pageUrl,"GET",{}, {},4*1024*1024);if(page.status!=301&&page.status!=302&&page.status!=307&&page.status!=308)break;auto next=page.location;if(next.startsWith("/"))next="https://splice.com"+next;auto base=selected.pageUrl.upToLastOccurrenceOf("/",true,false);if(!next.startsWith(base))throw std::runtime_error("Unexpected Splice preview redirect");pageUrl=next;}if(page.status!=200)throw std::runtime_error(("Splice preview page HTTP "+String(page.status)).toStdString());if(cancelled(generation))return;
   auto url=splicePreviewUrl(selected.pageUrl,page.text());auto response=https(url,"GET",{}, {},32*1024*1024);if(response.status!=200)throw std::runtime_error("Splice preview could not be loaded");if(cancelled(generation))return;
   auto audio=decodeSplicePreview(response.bytes);previewDirectory.createDirectory();juce::TemporaryFile temporary(file);if(!temporary.getFile().replaceWithData(audio.getData(),audio.getSize()))throw std::runtime_error("Cannot cache Splice preview");
   juce::AudioFormatManager fm;registerFormats(fm);std::unique_ptr<juce::AudioFormatReader>reader(fm.createReaderFor(temporary.getFile()));if(!reader||reader->lengthInSamples<=0)throw std::runtime_error("Cannot decode Splice preview");reader.reset();if(!temporary.overwriteTargetFileWithTemporary())throw std::runtime_error("Cannot finish Splice preview");
  }
  path=file.getFullPathName();
 }
 if(cancelled(generation))return;{std::lock_guard<std::mutex>lock(mutex);state.previewReady=path;state.previewId=id;++state.previewSequence;}status("splicePreviewReady",false);
}
void SpliceService::Impl::downloadSound(const String&id,int generation){
 SpliceSound selected;String folder;{std::lock_guard<std::mutex>lock(mutex);folder=state.folder;for(auto&s:state.sounds)if(s.id==id){selected=s;break;}}
 if(!assetId(selected.id))throw std::runtime_error("Select a Splice sound");if(session.isEmpty())initialise();status("spliceDownloading",true);
 auto oldPath=field(downloads,id.toRawUTF8());if(oldPath.isNotEmpty()&&ioFile(juce::File(oldPath)).existsAsFile()){std::lock_guard<std::mutex>lock(mutex);state.downloadReady=oldPath;state.previewReady=oldPath;state.busy=false;state.status="spliceDownloaded";++state.revision;return;}
 // This call can spend a credit. It is reached only by the explicit download confirmation in the editor.
 auto response=call("download_asset",object({{"asset_uuid",id}}));auto url=downloadUrl(response);if(url.isEmpty())throw std::runtime_error("Splice did not return a supported download URL. Check your Splice library before retrying.");auto audio=https(url,"GET",{}, {},256*1024*1024);if(audio.status!=200||audio.bytes.getSize()<16)throw std::runtime_error("Download failed. The sample may already be licensed; retrying the same sample is free.");
 const auto destination=storeSpliceAudio(juce::File(folder),selected,audio.bytes);downloads.getDynamicObject()->setProperty(juce::Identifier(id),destination.getFullPathName());saveDownloads();
 selected.localPath=destination.getFullPathName();rank(selected);const auto distance=selected.distance;const bool ranked=selected.ranked;
 {std::lock_guard<std::mutex>lock(mutex);for(auto&s:state.sounds)if(s.id==id){s.localPath=destination.getFullPathName();s.owned=true;s.ranked=ranked;s.distance=distance;}for(auto&past:pages)for(auto&s:past)if(s.id==id){s.localPath=destination.getFullPathName();s.owned=true;s.ranked=ranked;s.distance=distance;}state.downloadedPaths.addIfNotAlreadyThere(destination.getFullPathName());state.downloadReady=destination.getFullPathName();state.previewReady=state.downloadReady;}status("spliceDownloaded",false);
}
}
