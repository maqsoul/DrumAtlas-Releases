#pragma once
#include "Splice.h"
namespace atlas {
// Public, lossy audition data only; never call the paid asset endpoint here.
juce::String splicePreviewUrl(const juce::String& pageUrl,const juce::String& html);
juce::MemoryBlock decodeSplicePreview(const juce::MemoryBlock& bytes);
}
