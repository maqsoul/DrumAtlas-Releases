# Activation, updates and macOS — deployment status

## AU release — 12 October 2026

Published https://github.com/maqsoul/DrumAtlas-Releases/releases/tag/v1.0.5
with AU v2, VST3 and Standalone for Apple Silicon, plus Windows x64 1.0.5.
Mac run 38202986650 passed native build, pitch/tempo/license, Apple auval and
installer structure validation. The AU bundle needed an explicit final ad-hoc
signature before registration; the published bundle has been sealed and verified.
This does not provide Apple Developer ID or notarization. Logic Pro GUI testing
is still outstanding. See Installer/LOGIC-PRO-RU.md for usage and limitations.

Public Mac package: 16,105,720 bytes;
SHA256 2f3a4ee7ced4dbcc108a090dd5bfbdb3d76c5cf10dfe8c1dd36d0d61471fdfa2.
Public Windows installer passed innoextract integrity verification. The local
signed feed passed four native parsing cases (older Mac and Windows accepted,
current Mac and unsupported Intel rejected). Publishing tags no longer triggers
duplicate Mac builds: the workflow watches source changes on main only.
Production stable.json now advertises 1.0.5 for both supported platforms. The
native Windows updater downloaded the public installer, verified the feed
signature, size and SHA256, and matched the exact local 1.0.5 release binary.

These are update packages over an existing full installation; AI model weights
are preserved, not redistributed. Intel Mac remains unsupported by this channel.

## Latest verified status — 11 October 2026

Production stable.json now advertises 1.0.4 for windows-x64 and mac-arm64.
Release: https://github.com/maqsoul/DrumAtlas-Releases/releases/tag/v1.0.4
Apple Silicon update: DrumAtlas-1.0.4-arm64-Update.pkg (10,943,857 bytes).
GitHub Actions run 38157438220 built the native application/VST3, passed the
pitch/tempo/license tests and checked package structure. Downloaded public package
matches its CI SHA-256. Native updater parsing tests on Windows verified that Mac
1.0.2 accepts the signed 1.0.4 offer, 1.0.4 does not offer itself, and Intel does not
accept an ARM package. The Windows native HTTPS/CDN download probe also passed.

The macOS 1.0.2 personal installer already contains the production feed endpoint:
restart DrumAtlas to trigger a check, or use its check-updates control. Users click
to download, close the DAW and run the verified installer. No silent installation.
Apple Developer ID signing/notarization and real Mac DAW installation remain
unverified; do not bypass Gatekeeper. Full initial installation is still needed:
the update package preserves existing shared AI models and includes no weights.

Public .github/workflows/macos-update.yml builds Apple Silicon automatically when
DrumAtlas-source.tar.gz is updated. It creates a draft release without overwriting
existing assets. After checks, publish the installers, then sign and publish the
combined Windows/Mac feed with LicenseServer/publish-update.mjs. Signing keys stay
outside GitHub. Publishing a new source version alone does not announce an update;
the signed feed is the release gate. Intel is not yet supported by this channel.

## Latest verified status — 10 October 2026, 18:12 UTC

This section supersedes the earlier rollout notes below. Windows 1.0.2 is public:
https://github.com/maqsoul/DrumAtlas-Releases/releases/tag/v1.0.2
Signed production feed:
https://raw.githubusercontent.com/maqsoul/DrumAtlas-Releases/main/stable.json
All eight Windows CTest checks passed. The native end-to-end download probe also
passed: public HTTPS feed, production signature, GitHub CDN redirect, exact size
and SHA-256. Windows 1.0.1 users must install 1.0.2 manually once. This small update
preserves existing AI models; it is not a full first-install package.

Apple Silicon native analysis, edit/license and detailed AI inference checks
passed in run 38073971051. The complete 1.0.2 arm64 personal .pkg includes AI models
and selectable VST3/Standalone components, and passed package structure checks:
https://github.com/maqsoul/Drumatlas/releases/tag/untagged-f806ce6776e35651a07f
SHA-256: fe1b20165bd4c89b96c3068733b526b8144869ed7fe2d59b13e5c1f5a17beb5f
It is not Developer ID signed or notarized. Actual installation/DAW interaction
still needs verification. The full Intel AI installer is unfinished. No Mac
package is advertised in the public update feed yet. Downloading the private
635 MB package through browser automation timed out; use the release page.

Activation remains on Workers Free + D1; updates use the user-approved public
DrumAtlas-Releases repository. No paid service was enabled. Public packages omit
model weights whose redistribution clearance is not established.

## Earlier rollout notes (historical)

Activation is live at `https://drumatlas-activation.miras-maksat.workers.dev/v1/activate`
and passed HTTPS issuance/activation/machine-binding tests on 10 October 2026.
Native Windows license verification accepted the cloud-issued receipt. The public
update feed and installer hosting are not configured. Windows 1.0.1 was built with live activation and passed native HTTPS activation plus all eight CTest checks. Its update endpoint is still unset. Previous Windows preview installers do not
contain this updater: users must install the new updater-enabled release once.

The owner requires zero hosting cost (10 October 2026). Do not deploy the paid
Render Blueprint. The selected replacement is Workers Free + D1:
`LicenseServer/cloudflare/README.md`. Its implementation passes the local SQLite /
WebCrypto contract test, including concurrent activation and 100-code batches.
Cloudflare account login and real activation deployment are complete. This does not yet
provide an update feed or installer hosting. The GitHub repository is private at
https://github.com/maqsoul/Drumatlas; its source archive was updated for 1.0.1 and the Cloudflare additions.

`Installer/macos-check.yml` prepares manual Apple Silicon and Intel compile checks.
It is installed as a GitHub workflow. Run 38048714692 checks commit d9ee2bc. Free Actions minutes were verified before dispatch; no paid minutes are authorised. It is a diagnostic
build only and cannot replace a tested, model-equipped macOS installer.

## Serial activation

Run Node.js 24 or newer. `LicenseServer/server.mjs init PRIVATE_DIRECTORY Source/LicenseSerialPublicKey.h` creates a signing key and an administrator token **once**. Preserve the existing private directory; never regenerate the public key for an ordinary update. Existing DA1 licenses remain accepted. DA2 licenses are signed receipts bound automatically on first activation; subsequent launches work offline. The serial itself is not saved in the customer cache.

Start `node LicenseServer/server.mjs serve PRIVATE_DIRECTORY`. It listens on loopback port 8787 (`PORT` overrides). Put an HTTPS reverse proxy in front of `/v1/activate`. Keep `/admin/serials` restricted to the owner's access. Set a process supervisor, request/rate limits and backups. The built-in rate limit sees the reverse proxy IP; for a large deployment configure per-client limits at the proxy and review capacity. Back up the SQLite database using SQLite's backup mechanism, together with its signing key. Never copy only an active SQLite main file while WAL writes are in progress.

Keep `server-secrets.json` and the database outside the public web root, source distribution and installers. Restrict their OS file permissions to the server account; POSIX mode flags alone do not configure Windows ACLs. Do not put the admin token or private key in the plugin. The owner-only Serial Manager prompts for the HTTPS server URL and masked admin token; it generates batches of 1–100 codes via `/admin/serials`. Save those codes securely when issued. Customers only enter a serial; there is no computer-ID exchange with the owner.

The server refuses a second computer. Hardware replacement, migration and revocation require an explicit future policy; the present permanent offline receipt is not remotely revocable. No licensing system makes a plugin impossible to crack.

## Updates

Compile with `DRUMATLAS_ACTIVATION_URL=https://YOUR-HOST/v1/activate` and `DRUMATLAS_UPDATE_URL=https://YOUR-HOST/releases/stable.json`. These are placeholders, not active services. Increment `project(DrumAtlas VERSION ...)` for each public release (e.g. 1.0.1); adjust Windows installer version and macOS package version too. Do not publish different binaries under the same version number.

Prepare a release input JSON with `version` and `platforms`. Each platform (`windows-x64`, `mac-arm64`, `mac-x64`) has `file` (local installer path) and `url` (direct HTTPS installer URL). Run:

```
node LicenseServer/publish-update.mjs PRIVATE_DIRECTORY release.json stable.json
```

Upload installers first, then atomically replace the signed `stable.json`. The feed must return HTTP 200 without redirects. Installer downloads allow up to three HTTPS redirects on the same host or from github.com to its release-assets.githubusercontent.com / objects.githubusercontent.com CDN; other hosts and insecure redirects are rejected. The plugin validates the signed platform/version metadata, downloads on the user's button click, then checks exact byte length and SHA-256 before exposing the installer. Failed partial downloads are deleted. No executable is run automatically. The user closes the DAW/Standalone and runs the verified installer shown in the file manager. Updating loaded VST3 files during a session is deliberately avoided.

The updater checks in the background on plugin/application initialization and periodically while open. Network failure does not disable audio or offline licensing. It skips equal/older versions and incompatible platform entries. The catalog, preferences and license remain in the per-user data directory; installers must not delete that directory.

## macOS

VST3, Standalone and pitch/tempo/license-rejection tests passed on macOS 15 for both arm64 and x86_64 in GitHub Actions run 38048714692 (commit d9ee2bc). AI model inference, DAW integration and a complete .pkg are **not yet verified on macOS**. Use JUCE 9.0.3, macOS/Xcode command line tools, CMake, and ONNX Runtime 1.24.4 built for the target architecture. Create a separate Models folder with the same ONNX model files/prompts and `libonnxruntime.dylib`; optional `libsndfile.dylib` and its dependencies must be bundled with correct `@loader_path`/`@rpath` install names. Inspect with `otool -L`. Do not copy Windows DLLs. Current AI inference uses CPU on macOS; GPU acceleration has not been validated.

`Installer/build-macos.sh` builds native Apple Silicon or Intel VST3 and Standalone and runs available platform-independent tests. `Installer/package-macos.sh` creates a .pkg from tested bundles. It supports Developer ID signing and notarization using environment variables documented in the scripts. No Apple credentials are embedded. A macOS build, DAW loading/dragging, codecs, Keychain/OAuth and actual AI inference must pass on each supported architecture before calling it a release. Windows-only codec fixture generation is not a Mac codec test.

Models' redistribution terms and JUCE/source obligations in THIRD_PARTY.md still apply. Version 1.0.0 is not evidence of redistribution clearance.
