#!/bin/bash
set -euo pipefail
# Run on macOS with Xcode command line tools and CMake installed.
: "${JUCE_DIR:?Set JUCE_DIR to JUCE 9.0.3 source}"
: "${DRUMATLAS_MODEL_DIR:?Set DRUMATLAS_MODEL_DIR to the macOS Models folder}"
: "${DRUMATLAS_ACTIVATION_URL:?Set the deployed HTTPS /v1/activate endpoint}"
: "${DRUMATLAS_UPDATE_URL:?Set the HTTPS signed release feed URL}"
[[ "$(uname -s)" == Darwin ]] || { echo 'Run this script on macOS'; exit 1; }
arch="${DRUMATLAS_ARCH:-$(uname -m)}"
[[ "$arch" == arm64 || "$arch" == x86_64 ]] || { echo 'Choose arm64 or x86_64'; exit 1; }
src="$(cd "$(dirname "$0")/.." && pwd)"
build="${DRUMATLAS_BUILD_DIR:-$src/build-macos-$arch}"
for file in yamnet.onnx htdemucs_6s.onnx mdx23c_drumsep.onnx audiosep_resunet.onnx percussion-prompts.json libonnxruntime.dylib; do
 [[ -f "$DRUMATLAS_MODEL_DIR/$file" ]] || { echo "Missing macOS model/runtime: $file"; exit 1; }
done
if find "$DRUMATLAS_MODEL_DIR" -iname '*.dll' -print -quit | grep -q .; then echo 'Use a separate macOS Models folder without Windows DLLs'; exit 1; fi
lipo "$DRUMATLAS_MODEL_DIR/libonnxruntime.dylib" -verify_arch "$arch"
cmake -S "$src" -B "$build" -DCMAKE_BUILD_TYPE=Release \
 -DCMAKE_OSX_ARCHITECTURES="$arch" -DCMAKE_OSX_DEPLOYMENT_TARGET=12.0 \
 -DJUCE_DIR="$JUCE_DIR" -DDRUMATLAS_MODEL_DIR="$DRUMATLAS_MODEL_DIR" \
 -DDRUMATLAS_ACTIVATION_URL="$DRUMATLAS_ACTIVATION_URL" -DDRUMATLAS_UPDATE_URL="$DRUMATLAS_UPDATE_URL" \
 -DDRUMATLAS_TESTS=ON
cmake --build "$build" --config Release --parallel 4
DRUMATLAS_MODEL_DIR="$DRUMATLAS_MODEL_DIR" ctest --test-dir "$build" --output-on-failure -R '^(analysis|pitch-tempo-license|splice-credentials|detail-models)$'
echo "Build complete: $build. Test VST3/Standalone on this Mac before packaging."
