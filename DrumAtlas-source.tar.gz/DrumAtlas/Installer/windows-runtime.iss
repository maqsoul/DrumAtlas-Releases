[Files]
Source: "{#Payload}\Prerequisites\vc_redist.x64.exe"; Flags: dontcopy

[Code]
function PrepareToInstall(var NeedsRestart: Boolean): String;
var
  Code: Integer;
begin
  Result := '';
  ExtractTemporaryFile('vc_redist.x64.exe');
  if not Exec(ExpandConstant('{tmp}\vc_redist.x64.exe'),
    '/install /quiet /norestart', '', SW_HIDE, ewWaitUntilTerminated, Code) then
  begin
    Result := 'Cannot start Microsoft Visual C++ x64 runtime setup. Please retry installation.';
    Exit;
  end;
  { 1638: a newer compatible version is already installed. }
  if (Code <> 0) and (Code <> 1638) and (Code <> 3010) then
    Result := 'Microsoft Visual C++ x64 runtime setup failed (code ' + IntToStr(Code) + '). Please restart Windows and retry.';
  if Code = 3010 then NeedsRestart := True;
end;
