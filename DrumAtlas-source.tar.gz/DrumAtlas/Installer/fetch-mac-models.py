import hashlib, pathlib, shutil, sys, tarfile, urllib.request
root=pathlib.Path(sys.argv[1]); root.mkdir(parents=True, exist_ok=True)
assets=[
('yamnet.onnx','https://huggingface.co/zeropointnine/yamnet-onnx/resolve/ac2ca3bd45d12ec1f19f1144205ea529b4e9dedf/yamnet.onnx','1510041dce24a2e9e84ec546807ac408ae496da6d1ed41bc3ccba649623f8e19'),
('htdemucs_6s.onnx','https://huggingface.co/StemSplitio/htdemucs-6s-onnx/resolve/49df9b6989cf2150840ea65b0bef77a2e471b678/htdemucs_6s_fp16weights.onnx','7ce55792e2231c93fbf92de95f5fd5b3a5e6c89f7db690dfd693e8f1dce56869'),
('mdx23c_drumsep.onnx','https://huggingface.co/scragnog/HOT-Step-CPP-SuperSep/resolve/440487b8300dcd61453cc52ec244a38150b03456/mdx23c_drumsep.onnx','dd94f6605e1ff42b11b6d7232117fb25ae24870613d25d8a6d083e2fd868b01d'),
('audiosep_resunet.onnx','https://huggingface.co/niobures/AudioSep/resolve/b508693e47fcb996073cd18787debfb2c40dca65/models/ailia-models/audiosep_resunet.onnx','030b1ff2af237e753ed5441c3a11358defaf2a706d7e037af681e4282b0ec179'),
('runtime.tgz','https://github.com/microsoft/onnxruntime/releases/download/v1.24.4/onnxruntime-osx-arm64-1.24.4.tgz','93787795f47e1eee369182e43ed51b9e5da0878ab0346aecf4258979b8bba989')]
for name,url,expected in assets:
    target=root/name; partial=root/(name+'.part'); digest=hashlib.sha256()
    with urllib.request.urlopen(url,timeout=120) as response, partial.open('wb') as output:
        while chunk:=response.read(1024*1024):
            digest.update(chunk); output.write(chunk)
    if digest.hexdigest()!=expected: raise RuntimeError('SHA256 mismatch: '+name)
    partial.replace(target); print('Verified',name,flush=True)
with tarfile.open(root/'runtime.tgz') as archive:
    archive.extractall(root/'runtime',filter='data')
libs=list((root/'runtime').rglob('libonnxruntime*.dylib'))
if not libs: raise RuntimeError('Runtime dylib missing')
for lib in libs: shutil.copy2(lib.resolve(),root/lib.name)
shutil.copy2(pathlib.Path(__file__).parent/'MacAssets/percussion-prompts.json',root/'percussion-prompts.json')
shutil.rmtree(root/'runtime'); (root/'runtime.tgz').unlink()
