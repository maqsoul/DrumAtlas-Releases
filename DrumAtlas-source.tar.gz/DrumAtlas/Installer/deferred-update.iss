[Code]
var
  DeferredUpdateCompleted: Boolean;
function OpenProcess(Access: LongWord; Inherit: Boolean; ProcessId: LongWord): THandle;
  external 'OpenProcess@kernel32.dll stdcall';
function WaitForSingleObject(Handle: THandle; Milliseconds: LongWord): LongWord;
  external 'WaitForSingleObject@kernel32.dll stdcall';
function CloseHandle(Handle: THandle): Boolean;
  external 'CloseHandle@kernel32.dll stdcall';
function OpenUpdateFile(Name: String; Access, Share, Security, Creation, Flags: LongWord; Template: THandle): THandle;
  external 'CreateFileW@kernel32.dll stdcall';

function WaitForUpdateFiles: String;
var
  Files: TArrayOfString;
  Index, Attempts: Integer;
  Handle: THandle;
  Busy: Boolean;
  ErrorCode: LongWord;
begin
  Result := '';
  if ExpandConstant('{param:DRUMATLASWAITPID|0}') = '0' then Exit;
  SetArrayLength(Files, 2);
  Files[0] := ExpandConstant('{app}\Standalone\DrumAtlas.exe');
  Files[1] := ExpandConstant('{commoncf64}\VST3\DrumAtlas.vst3\Contents\x86_64-win\DrumAtlas.vst3');
  Attempts := 0;
  repeat
    Busy := False;
    for Index := 0 to GetArrayLength(Files) - 1 do
      if FileExists(Files[Index]) then
      begin
        Handle := OpenUpdateFile(Files[Index], $40000000, 0, 0, 3, $80, 0);
        if Handle = THandle(-1) then
        begin
          ErrorCode := DLLGetLastError;
          if (ErrorCode = 32) or (ErrorCode = 33) then Busy := True
          else begin Result := 'Cannot access installed DrumAtlas files. Retry the update after closing all audio applications.'; Exit; end;
        end
        else CloseHandle(Handle);
      end;
    if Busy then
    begin
      if Attempts >= 17280 then begin Result := 'Update timed out waiting for other audio applications. Retry Update.'; Exit; end;
      Sleep(5000);
      Attempts := Attempts + 1;
    end;
  until not Busy;
end;

procedure CurStepChanged(CurStep: TSetupStep);
begin
  if CurStep = ssDone then DeferredUpdateCompleted := True;
#ifndef DeferredUpdateTest
  if (CurStep = ssDone) and (ExpandConstant('{param:DRUMATLASWAITPID|0}') <> '0') then
    MsgBox('DrumAtlas update is complete. You can open your DAW again.', mbInformation, MB_OK);
#endif
end;

procedure DeinitializeSetup;
begin
#ifndef DeferredUpdateTest
  if (not DeferredUpdateCompleted) and (ExpandConstant('{param:DRUMATLASWAITPID|0}') <> '0') then
    MsgBox('DrumAtlas update was not completed. Open DrumAtlas and retry Update. No audio applications were closed by the updater.', mbError, MB_OK);
#endif
end;

function InitializeSetup: Boolean;
var
  PID: Integer;
  ProcessHandle: THandle;
  WaitResult: LongWord;
  Attempts: Integer;
begin
  Result := True;
  PID := StrToIntDef(ExpandConstant('{param:DRUMATLASWAITPID|0}'), 0);
  if PID = 0 then Exit;
  Result := False;
  if PID < 0 then Exit;
  Log('Deferred update: waiting for the original DAW process. No applications will be closed.');
  ProcessHandle := OpenProcess($00100000, False, PID);
  if ProcessHandle <> 0 then
  begin
    WaitResult := WaitForSingleObject(ProcessHandle, 86400000);
    CloseHandle(ProcessHandle);
    if WaitResult <> 0 then
    begin
      Log('Deferred update cancelled: host wait failed or timed out.');
      Exit;
    end;
  end
  else if DLLGetLastError <> 87 then
  begin
    Log('Deferred update cancelled: cannot verify the original host has exited.');
    Exit;
  end;
  Attempts := 0;
  while CheckForMutexes('Local\DrumAtlas.Active') do
  begin
    if Attempts >= 17280 then Exit;
    Sleep(5000);
    Attempts := Attempts + 1;
  end;
  Log('Deferred update: host and other current DrumAtlas instances have exited.');
  Result := True;
end;
