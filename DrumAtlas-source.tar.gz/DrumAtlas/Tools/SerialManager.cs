using System;
using System.Net;
using System.Text;
using System.IO;
using System.Windows.Forms;
using System.Web.Script.Serialization;
using System.Collections;
using System.Drawing;
class SerialManager : Form {
 TextBox server=new TextBox(),token=new TextBox(),codes=new TextBox();NumericUpDown count=new NumericUpDown();Button generate=new Button();Label status=new Label();
 [STAThread] static void Main(){Application.EnableVisualStyles();Application.Run(new SerialManager());}
 SerialManager(){Text="DrumAtlas — Serial Manager (owner only)";ClientSize=new Size(780,560);MinimumSize=new Size(680,520);BackColor=Color.FromArgb(11,22,33);ForeColor=Color.White;Font=new Font("Segoe UI",10);Padding=new Padding(20);
  var grid=new TableLayoutPanel{Dock=DockStyle.Fill,ColumnCount=2,RowCount=7};grid.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,150));grid.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));Controls.Add(grid);
  AddRow(grid,"HTTPS server",server,0);AddRow(grid,"Admin token",token,1);token.UseSystemPasswordChar=true;AddRow(grid,"Number of codes",count,2);count.Minimum=1;count.Maximum=100;count.Value=1;
  generate.Text="Generate serial codes";generate.AutoSize=true;generate.ForeColor=Color.Black;grid.Controls.Add(generate,1,3);generate.Click+=async(s,e)=>{Uri url;if(!Uri.TryCreate(server.Text.Trim().TrimEnd('/')+"/admin/serials",UriKind.Absolute,out url)||url.Scheme!="https"){status.Text="Enter your HTTPS activation server address.";return;}generate.Enabled=false;status.Text="Generating…";try{ServicePointManager.SecurityProtocol=SecurityProtocolType.Tls12;using(var client=new WebClient()){client.Headers[HttpRequestHeader.ContentType]="application/json";client.Headers[HttpRequestHeader.Authorization]="Bearer "+token.Text.Trim();var result=await client.UploadStringTaskAsync(url,"POST","{\"count\":"+count.Value+"}");var json=new JavaScriptSerializer().Deserialize<System.Collections.Generic.Dictionary<string,object>>(result);var list=(IEnumerable)json["serials"];var lines=new System.Collections.Generic.List<string>();foreach(var code in list)lines.Add((string)code);codes.Text=String.Join(Environment.NewLine,lines);status.Text="Save these codes. Each code binds to the first activating computer.";}}catch(WebException){status.Text="Connection or authorization failed. Verify server address and admin token.";}catch(Exception){status.Text="Invalid server response.";}finally{generate.Enabled=true;}};
  codes.Multiline=true;codes.ReadOnly=true;codes.ScrollBars=ScrollBars.Both;codes.WordWrap=false;codes.Dock=DockStyle.Fill;grid.Controls.Add(codes,0,4);grid.SetColumnSpan(codes,2);grid.RowStyles.Clear();for(int i=0;i<4;i++)grid.RowStyles.Add(new RowStyle(SizeType.Absolute,42));grid.RowStyles.Add(new RowStyle(SizeType.Percent,100));grid.RowStyles.Add(new RowStyle(SizeType.Absolute,45));grid.RowStyles.Add(new RowStyle(SizeType.Absolute,55));
  var buttons=new FlowLayoutPanel{Dock=DockStyle.Fill};var copy=new Button{Text="Copy",AutoSize=true,ForeColor=Color.Black};copy.Click+=(s,e)=>{if(codes.TextLength>0)Clipboard.SetText(codes.Text);};var save=new Button{Text="Save codes…",AutoSize=true,ForeColor=Color.Black};save.Click+=(s,e)=>{using(var dialog=new SaveFileDialog{Filter="Text files|*.txt",FileName="DrumAtlas-serials.txt"})if(dialog.ShowDialog()==DialogResult.OK)File.WriteAllText(dialog.FileName,codes.Text,Encoding.UTF8);};buttons.Controls.Add(copy);buttons.Controls.Add(save);grid.Controls.Add(buttons,0,5);grid.SetColumnSpan(buttons,2);status.Dock=DockStyle.Fill;grid.Controls.Add(status,0,6);grid.SetColumnSpan(status,2);
  ApplyTheme(this);codes.Font=new Font("Consolas",10);AutoScaleMode=AutoScaleMode.Font;
  server.Text="https://drumatlas-activation.miras-maksat.workers.dev";
  status.Text="Сервер подключён. Введите токен администратора и выберите количество кодов.";
  status.ForeColor=Color.FromArgb(178,228,215);
  generate.Text="Создать серийные коды";copy.Text="Копировать";save.Text="Сохранить коды…";
 }
 static void ApplyTheme(Control root){
  foreach(Control control in root.Controls){
   control.ForeColor=Color.FromArgb(232,241,248);
   control.BackColor=Color.FromArgb(11,22,33);
   var text=control as TextBox;if(text!=null){text.BackColor=Color.FromArgb(24,41,57);text.ForeColor=Color.FromArgb(245,249,252);text.BorderStyle=BorderStyle.FixedSingle;}
   var number=control as NumericUpDown;if(number!=null){number.BackColor=Color.FromArgb(24,41,57);number.ForeColor=Color.FromArgb(245,249,252);}
   var button=control as Button;if(button!=null){button.UseVisualStyleBackColor=false;button.FlatStyle=FlatStyle.Flat;button.BackColor=Color.FromArgb(35,73,83);button.ForeColor=Color.White;button.FlatAppearance.BorderColor=Color.FromArgb(91,178,171);button.FlatAppearance.MouseOverBackColor=Color.FromArgb(44,94,104);button.Padding=new Padding(8,3,8,3);}
   if(number==null)ApplyTheme(control);
  }
 }
 void AddRow(TableLayoutPanel grid,string title,Control field,int row){grid.Controls.Add(new Label{Text=title,AutoSize=true,Margin=new Padding(0,7,0,0)},0,row);field.Dock=DockStyle.Fill;grid.Controls.Add(field,1,row);}
}
