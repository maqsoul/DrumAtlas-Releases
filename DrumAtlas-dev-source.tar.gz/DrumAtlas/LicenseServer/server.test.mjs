import { test } from 'node:test';
import assert from 'node:assert/strict';
import { generateKeyPairSync, verify } from 'node:crypto';
import { mkdtempSync, rmSync } from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { createService } from './server.mjs';
test('serial issuance, binding, concurrent activation and persistence', async () => {
 const dir=mkdtempSync(path.join(os.tmpdir(),'drumatlas-serial-test-'));
 const keys=generateKeyPairSync('ec',{namedCurve:'prime256v1'}),adminToken='test-only-admin-token-32-characters';
 const options={database:path.join(dir,'licenses.sqlite'),privateKey:keys.privateKey,adminToken};
 let server,base;
 const start=async()=>{server=createService(options);await new Promise(r=>server.listen(0,'127.0.0.1',r));base='http://127.0.0.1:'+server.address().port;};
 const stop=()=>new Promise((r,j)=>server.close(e=>e?j(e):r()));
 const post=async(route,body,auth=false)=>{const response=await fetch(base+route,{method:'POST',headers:{'Content-Type':'application/json',...(auth?{Authorization:'Bearer '+adminToken}:{})},body:JSON.stringify(body)});return {status:response.status,body:await response.json()};};
 try {
  await start();assert.equal((await post('/admin/serials',{count:1})).status,401);
  assert.equal((await post('/admin/serials',null,true)).status,400);
  assert.equal((await post('/admin/serials',{count:101},true)).status,400);
  const issued=await post('/admin/serials',{count:3},true);assert.equal(issued.status,201);assert.equal(new Set(issued.body.serials).size,3);
  const [serial,race]=issued.body.serials,machine='DA-PC-'+'a'.repeat(64),other='DA-PC-'+'b'.repeat(64);
  const first=await post('/v1/activate',{serial,machine});assert.equal(first.status,200);
  const [tag,payload,signature]=first.body.license.split('.');assert.equal(tag,'DA2');assert.ok(Buffer.from(payload,'base64url').toString().includes('|'+machine+'|'));assert.ok(verify('sha256',Buffer.from(payload,'base64url'),{key:keys.publicKey,dsaEncoding:'ieee-p1363'},Buffer.from(signature,'base64url')));
  assert.deepEqual((await post('/v1/activate',{serial:serial.toLowerCase(),machine})).body,first.body);
  assert.equal((await post('/v1/activate',{serial,machine:other})).status,409);
  assert.equal((await post('/v1/activate',{serial:'garbage',machine})).status,400);
  const outcomes=await Promise.all([machine,other].map(machine=>post('/v1/activate',{serial:race,machine})));assert.deepEqual(outcomes.map(r=>r.status).sort(),[200,409]);
  await stop();await start();assert.deepEqual((await post('/v1/activate',{serial,machine})).body,first.body);assert.equal((await post('/v1/activate',{serial,machine:other})).status,409);
 } finally {if(server?.listening)await stop();rmSync(dir,{recursive:true,force:true});}
});
