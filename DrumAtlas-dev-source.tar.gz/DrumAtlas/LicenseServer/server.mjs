import http from 'node:http';
import { DatabaseSync } from 'node:sqlite';
import { createHash, generateKeyPairSync, randomBytes, randomUUID, sign, timingSafeEqual } from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const hash = value => createHash('sha256').update(value).digest('hex');
const normalise = value => String(value ?? '').trim().toUpperCase().replace(/\s/g, '');
const machinePattern = /^DA-PC-[a-f0-9]{64}$/;
const serialPattern = /^DA-(?:[A-F0-9]{4}-){7}[A-F0-9]{4}$/;

export function initialise(directory, header) {
  fs.mkdirSync(directory, { recursive: true, mode: 0o700 });
  const configPath = path.join(directory, 'server-secrets.json');
  if (fs.existsSync(configPath)) throw Error('Server already initialised; refusing to replace signing key');
  const { privateKey, publicKey } = generateKeyPairSync('ec', { namedCurve: 'prime256v1' });
  const jwk = publicKey.export({ format: 'jwk' });
  const blob = Buffer.concat([Buffer.from([0x45, 0x43, 0x53, 0x31, 32, 0, 0, 0]), Buffer.from(jwk.x, 'base64url'), Buffer.from(jwk.y, 'base64url')]);
  const config = { privateKey: privateKey.export({ format: 'pem', type: 'pkcs8' }), adminToken: randomBytes(32).toString('base64url') };
  fs.writeFileSync(configPath, JSON.stringify(config, null, 2), { mode: 0o600, flag: 'wx' });
  fs.writeFileSync(header, '#pragma once\nnamespace atlas { inline constexpr unsigned char serialPublicKey[] = {' + [...blob].map(n => '0x' + n.toString(16).padStart(2, '0')).join(',') + '}; }\n');
}

export function createService({ database, privateKey, adminToken }) {
  if (!privateKey || !adminToken || adminToken.length < 32) throw Error('Signing key and strong admin token required');
  const db = new DatabaseSync(database);
  db.exec(`PRAGMA journal_mode=WAL; PRAGMA synchronous=FULL; PRAGMA busy_timeout=5000;
    CREATE TABLE IF NOT EXISTS licenses (serial_hash TEXT PRIMARY KEY, id TEXT NOT NULL UNIQUE, created TEXT NOT NULL, machine TEXT, receipt TEXT, activated TEXT);`);
  const limits = new Map();
  const reply = (res, status, body) => { res.writeHead(status, { 'Content-Type': 'application/json', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' }); res.end(JSON.stringify(body)); };
  const server = http.createServer(async (req, res) => {
    try {
      if (req.method === 'GET' && req.url === '/health') return reply(res, 200, { ok: true });
      if (req.method !== 'POST' || !['/v1/activate', '/admin/serials'].includes(req.url)) return reply(res, 404, { error: 'not_found' });
      // Bind behind a TLS reverse proxy. Never trust arbitrary forwarded-IP headers.
      const ip = req.socket.remoteAddress, now = Date.now();
      if (limits.size > 10000) for (const [key, value] of limits) if (value.until < now) limits.delete(key);
      const rate = limits.get(ip); if (!rate || rate.until < now) limits.set(ip, { until: now + 60000, count: 1 });
      else if (++rate.count > 120) return reply(res, 429, { error: 'try_later' });
      if (req.url.startsWith('/admin/')) {
        const received = hash(req.headers.authorization ?? ''); const expected = hash('Bearer ' + adminToken);
        if (!timingSafeEqual(Buffer.from(received), Buffer.from(expected))) return reply(res, 401, { error: 'unauthorised' });
      }
      if (!String(req.headers['content-type'] ?? '').startsWith('application/json')) return reply(res, 415, { error: 'json_required' });
      let bytes = 0, chunks = []; for await (const chunk of req) { bytes += chunk.length; if (bytes > 4096) return reply(res, 413, { error: 'request_too_large' }); chunks.push(chunk); }
      let body; try { body = JSON.parse(Buffer.concat(chunks)); } catch { return reply(res, 400, { error: 'invalid_json' }); }
      if (!body || typeof body !== 'object' || Array.isArray(body)) return reply(res, 400, { error: 'json_object_required' });
      if (req.url === '/admin/serials') {
        if (!Number.isInteger(body.count) || body.count < 1 || body.count > 100) return reply(res, 400, { error: 'count_1_to_100' });
        const serials = []; db.exec('BEGIN IMMEDIATE');
        try {
          for (let i = 0; i < body.count; i++) { const serial = 'DA-' + randomBytes(16).toString('hex').toUpperCase().match(/.{4}/g).join('-'); db.prepare('INSERT INTO licenses(serial_hash,id,created) VALUES(?,?,?)').run(hash(serial), randomUUID(), new Date().toISOString()); serials.push(serial); }
          db.exec('COMMIT');
        } catch (error) { db.exec('ROLLBACK'); throw error; }
        return reply(res, 201, { serials });
      }
      const serial = normalise(body.serial), machine = String(body.machine ?? '');
      if (!serialPattern.test(serial) || !machinePattern.test(machine)) return reply(res, 400, { error: 'invalid_serial' });
      db.exec('BEGIN IMMEDIATE'); let receipt;
      try {
        const row = db.prepare('SELECT * FROM licenses WHERE serial_hash=?').get(hash(serial));
        if (!row) { db.exec('ROLLBACK'); return reply(res, 404, { error: 'invalid_serial' }); }
        if (row.machine && row.machine !== machine) { db.exec('ROLLBACK'); return reply(res, 409, { error: 'already_activated' }); }
        receipt = row.receipt;
        if (!receipt) {
          const payload = Buffer.from(`DrumAtlas|2|${machine}|${row.id}`);
          receipt = 'DA2.' + payload.toString('base64url') + '.' + sign('sha256', payload, { key: privateKey, dsaEncoding: 'ieee-p1363' }).toString('base64url');
          db.prepare('UPDATE licenses SET machine=?,receipt=?,activated=? WHERE serial_hash=?').run(machine, receipt, new Date().toISOString(), hash(serial));
        }
        db.exec('COMMIT');
      } catch (error) { db.exec('ROLLBACK'); throw error; }
      return reply(res, 200, { license: receipt });
    } catch { if (!res.headersSent) reply(res, 500, { error: 'server_error' }); else res.end(); }
  });
  server.requestTimeout = 15000; server.headersTimeout = 10000;
  server.on('close', () => db.close());
  return server;
}

if (process.argv[1] && fileURLToPath(import.meta.url) === path.resolve(process.argv[1])) {
  const [mode, directory, header] = process.argv.slice(2);
  if (mode === 'init' && directory && header) { initialise(directory, header); console.log('Server keys saved privately; public header generated.'); }
  else if (mode === 'serve' && directory) {
    const config = JSON.parse(fs.readFileSync(path.join(directory, 'server-secrets.json'), 'utf8'));
    const server = createService({ ...config, database: path.join(directory, 'licenses.sqlite') });
    const port = Number(process.env.PORT || 8787); server.listen(port, '127.0.0.1', () => console.log(`Activation server listening on loopback port ${port}`));
    for (const signal of ['SIGINT', 'SIGTERM']) process.on(signal, () => server.close());
  } else { console.error('node server.mjs init PRIVATE_DIRECTORY PUBLIC_HEADER | serve PRIVATE_DIRECTORY'); process.exitCode = 2; }
}
