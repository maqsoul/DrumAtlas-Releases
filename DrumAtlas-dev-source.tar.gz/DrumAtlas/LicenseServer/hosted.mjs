// Render entry point. Secrets are configured in the host's secret environment,
// never in Git. The signing key MUST match the public key already in the plugin.
import fs from 'node:fs';
import path from 'node:path';
import { createService } from './server.mjs';
const directory=process.env.DRUMATLAS_DATA_DIR;
if(!directory||!path.isAbsolute(directory))throw Error('Persistent DRUMATLAS_DATA_DIR required');
const privateKey=process.env.DRUMATLAS_SIGNING_KEY_PEM;
const adminToken=process.env.DRUMATLAS_ADMIN_TOKEN;
if(!privateKey||!adminToken)throw Error('Configure existing signing key and administrator token in hosting secrets');
fs.mkdirSync(directory,{recursive:true,mode:0o700});
const server=createService({database:path.join(directory,'licenses.sqlite'),privateKey,adminToken});
server.listen(Number(process.env.PORT||8787),'0.0.0.0',()=>console.log('DrumAtlas activation service ready'));
for(const signal of ['SIGINT','SIGTERM'])process.on(signal,()=>server.close());
