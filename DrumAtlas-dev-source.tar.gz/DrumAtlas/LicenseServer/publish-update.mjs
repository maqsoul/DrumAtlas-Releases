// Owner-only release preparation. Upload the output feed and installer to HTTPS hosting.
import fs from 'node:fs';
import { createHash, sign } from 'node:crypto';
import path from 'node:path';
const [privateDirectory,releaseJson,output]=process.argv.slice(2);
if(!privateDirectory||!releaseJson||!output)throw Error('Usage: node publish-update.mjs PRIVATE_DIRECTORY release.json feed.json');
const release=JSON.parse(fs.readFileSync(releaseJson,'utf8'));
if(!/^(0|[1-9]\d{0,5})\.(0|[1-9]\d{0,5})\.(0|[1-9]\d{0,5})$/.test(release.version))throw Error('Use an increasing major.minor.patch version');
const platforms={};
for(const [platform,file] of Object.entries(release.platforms)){
 if(!['windows-x64','mac-arm64','mac-x64'].includes(platform)||new URL(file.url).protocol!=='https:')throw Error('Invalid platform or HTTPS URL');
 const sha=createHash('sha256');let bytes=0;for await(const chunk of fs.createReadStream(file.file)){sha.update(chunk);bytes+=chunk.length;}
 if(bytes<=0||bytes>8*1024**3)throw Error('Invalid installer size');
 platforms[platform]={url:file.url,sha256:sha.digest('hex'),bytes};
}
if(!Object.keys(platforms).length)throw Error('No installers provided');
const payload=Buffer.from(JSON.stringify({purpose:'DrumAtlas-update-v1',version:release.version,platforms}));
const {privateKey}=JSON.parse(fs.readFileSync(path.join(privateDirectory,'server-secrets.json'),'utf8'));
fs.writeFileSync(output,JSON.stringify({payload:payload.toString('base64url'),signature:sign('sha256',payload,{key:privateKey,dsaEncoding:'ieee-p1363'}).toString('base64url')},null,2));
console.log('Signed update feed written. No private key is included.');
