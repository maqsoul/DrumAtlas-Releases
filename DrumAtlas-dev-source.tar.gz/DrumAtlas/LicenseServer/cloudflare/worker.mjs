// Free Workers + D1 deployment. Never include secrets in this file.
const encoder = new TextEncoder();
const hex = bytes => [...new Uint8Array(bytes)].map(v => v.toString(16).padStart(2, '0')).join('');
const digest = text => crypto.subtle.digest('SHA-256', encoder.encode(text));
const base64url = bytes => btoa(String.fromCharCode(...new Uint8Array(bytes))).replaceAll('+', '-').replaceAll('/', '_').replace(/=+$/, '');
const reply = (status, data) => Response.json(data, { status, headers: { 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' } });
const failure = (status, error) => Object.assign(new Error(error), { status });
async function readBody(request) {
  if (!request.headers.get('Content-Type')?.startsWith('application/json')) throw failure(415, 'json_required');
  const reader = request.body?.getReader();
  if (!reader) throw failure(400, 'invalid_json');
  const chunks = []; let size = 0;
  try {
    for (;;) {
      const { done, value } = await reader.read(); if (done) break;
      size += value.length;
      if (size > 4096) { await reader.cancel(); throw failure(413, 'request_too_large'); }
      chunks.push(value);
    }
  } finally { reader.releaseLock(); }
  const bytes = new Uint8Array(size); let offset = 0;
  for (const chunk of chunks) { bytes.set(chunk, offset); offset += chunk.length; }
  let body;
  try { body = JSON.parse(new TextDecoder().decode(bytes)); } catch { throw failure(400, 'invalid_json'); }
  if (!body || typeof body !== 'object' || Array.isArray(body)) throw failure(400, 'json_object_required');
  return body;
}
async function authorised(request, token) {
  if (typeof token !== 'string' || token.length < 32) return false;
  const [a, b] = await Promise.all([digest(request.headers.get('Authorization') || ''), digest('Bearer ' + token)]);
  const x = new Uint8Array(a), y = new Uint8Array(b); let difference = 0;
  for (let i = 0; i < x.length; i++) difference |= x[i] ^ y[i];
  return difference === 0;
}
async function signReceipt(pem, machine, id) {
  const raw = atob(pem.replace(/-----BEGIN PRIVATE KEY-----|-----END PRIVATE KEY-----|\s/g, ''));
  const key = await crypto.subtle.importKey('pkcs8', Uint8Array.from(raw, c => c.charCodeAt(0)), { name: 'ECDSA', namedCurve: 'P-256' }, false, ['sign']);
  const payload = encoder.encode(`DrumAtlas|2|${machine}|${id}`);
  const signature = await crypto.subtle.sign({ name: 'ECDSA', hash: 'SHA-256' }, key, payload);
  return 'DA2.' + base64url(payload) + '.' + base64url(signature);
}
export default {
  async fetch(request, env) {
    try {
      const url = new URL(request.url), route = url.pathname;
      if (url.protocol !== 'https:') return reply(400, { error: 'https_required' });
      if (request.method === 'GET' && route === '/health') {
        await env.DB.prepare('SELECT 1 FROM licenses LIMIT 1').first();
        return reply(200, { ok: true });
      }
      if (request.method !== 'POST' || !['/v1/activate', '/admin/serials'].includes(route)) return reply(404, { error: 'not_found' });
      if (!env.DRUMATLAS_SIGNING_KEY_PEM || !env.DRUMATLAS_ADMIN_TOKEN || env.DRUMATLAS_ADMIN_TOKEN.length < 32) return reply(503, { error: 'not_configured' });
      if (route === '/admin/serials' && !await authorised(request, env.DRUMATLAS_ADMIN_TOKEN)) return reply(401, { error: 'unauthorised' });
      const body = await readBody(request);
      if (route === '/admin/serials') {
        if (!Number.isInteger(body.count) || body.count < 1 || body.count > 100) return reply(400, { error: 'count_1_to_100' });
        const serials = [], rows = [], statements = [], now = new Date().toISOString();
        for (let i = 0; i < body.count; i++) {
          const serial = 'DA-' + hex(crypto.getRandomValues(new Uint8Array(16))).toUpperCase().match(/.{4}/g).join('-');
          rows.push([hex(await digest(serial)), crypto.randomUUID(), now]);
          serials.push(serial);
        }
        // Stay below Free-plan query limits and D1's per-statement parameter limit.
        for (let offset = 0; offset < rows.length; offset += 25) {
          const chunk = rows.slice(offset, offset + 25);
          statements.push(env.DB.prepare('INSERT INTO licenses(serial_hash,id,created) VALUES ' + chunk.map(() => '(?,?,?)').join(',')).bind(...chunk.flat()));
        }
        // D1 batch is transactional: either all codes are stored or none are.
        await env.DB.batch(statements);
        return reply(201, { serials });
      }
      const serial = String(body.serial ?? '').trim().toUpperCase().replace(/\s/g, '');
      const machine = String(body.machine ?? '');
      if (!/^DA-(?:[A-F0-9]{4}-){7}[A-F0-9]{4}$/.test(serial) || !/^DA-PC-[a-f0-9]{64}$/.test(machine)) return reply(400, { error: 'invalid_serial' });
      const hash = hex(await digest(serial));
      const row = await env.DB.prepare('SELECT id,machine,receipt FROM licenses WHERE serial_hash=?').bind(hash).first();
      if (!row) return reply(404, { error: 'invalid_serial' });
      if (row.machine && row.machine !== machine) return reply(409, { error: 'already_activated' });
      if (row.receipt) return reply(200, { license: row.receipt });
      const receipt = await signReceipt(env.DRUMATLAS_SIGNING_KEY_PEM, machine, row.id);
      // Atomic compare-and-set prevents two computers winning simultaneous activation.
      const result = await env.DB.batch([
        env.DB.prepare('UPDATE licenses SET machine=?,receipt=?,activated=? WHERE serial_hash=? AND machine IS NULL AND receipt IS NULL').bind(machine, receipt, new Date().toISOString(), hash),
        env.DB.prepare('SELECT machine,receipt FROM licenses WHERE serial_hash=?').bind(hash)
      ]);
      const winner = result[1].results[0];
      if (winner?.machine !== machine) return reply(409, { error: 'already_activated' });
      if (!winner.receipt) throw Error('Missing receipt');
      return reply(200, { license: winner.receipt });
    } catch (error) {
      return reply(error.status || 503, { error: error.status ? error.message : 'service_unavailable' });
    }
  }
};
