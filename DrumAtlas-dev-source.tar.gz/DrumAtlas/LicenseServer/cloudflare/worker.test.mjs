import { test } from 'node:test';
import assert from 'node:assert/strict';
import { DatabaseSync } from 'node:sqlite';
import { generateKeyPairSync, verify } from 'node:crypto';
import { readFileSync } from 'node:fs';
import worker from './worker.mjs';

// Real SQLite with the documented asynchronous D1 surface; no remote account needed.
function database() {
  const db = new DatabaseSync(':memory:');
  db.exec(readFileSync(new URL('./schema.sql', import.meta.url), 'utf8'));
  const prepare = sql => ({ bind(...args) { return { sql, args, async first() { return db.prepare(sql).get(...args) ?? null; } }; }, async first() { return db.prepare(sql).get() ?? null; } });
  return { db, prepare, async batch(statements) {
    assert.ok(statements.length <= 50);
    db.exec('BEGIN IMMEDIATE');
    try {
      const result = statements.map(({ sql, args }) => {
        assert.ok(args.length <= 100);
        return sql.startsWith('SELECT') ? { results: db.prepare(sql).all(...args) } : { results: [], meta: db.prepare(sql).run(...args) };
      });
      db.exec('COMMIT'); return result;
    } catch (e) { db.exec('ROLLBACK'); throw e; }
  } };
}
test('Worker: generation, concurrent machine binding, persistence and signature interoperability', async () => {
  const DB = database();
  const keys = generateKeyPairSync('ec', { namedCurve: 'prime256v1' });
  const env = { DB, DRUMATLAS_ADMIN_TOKEN: 'test-only-token-'.repeat(4), DRUMATLAS_SIGNING_KEY_PEM: keys.privateKey.export({ format: 'pem', type: 'pkcs8' }) };
  const call = (route, body, auth = false) => worker.fetch(new Request('https://example.test' + route, { method: 'POST', headers: { 'Content-Type': 'application/json', ...(auth ? { Authorization: 'Bearer ' + env.DRUMATLAS_ADMIN_TOKEN } : {}) }, body: JSON.stringify(body) }), env);
  try {
    assert.equal((await call('/admin/serials', { count: 1 })).status, 401);
    assert.equal((await call('/admin/serials', { count: 0 }, true)).status, 400);
    const generated = await call('/admin/serials', { count: 100 }, true);
    assert.equal(generated.status, 201);
    const { serials } = await generated.json();
    assert.equal(new Set(serials).size, 100);
    assert.equal(DB.db.prepare('SELECT count(*) AS n FROM licenses').get().n, 100);
    const serial = serials[0], a = 'DA-PC-' + 'a'.repeat(64), b = 'DA-PC-' + 'b'.repeat(64);
    const results = await Promise.all([call('/v1/activate', { serial, machine: a }), call('/v1/activate', { serial, machine: b })]);
    assert.deepEqual(results.map(r => r.status).sort(), [200, 409]);
    const winner = results[0].status === 200 ? a : b;
    const { license } = await results.find(r => r.status === 200).json();
    const parts = license.split('.');
    assert.equal(parts[0], 'DA2');
    assert.ok(Buffer.from(parts[1], 'base64url').toString().startsWith('DrumAtlas|2|' + winner + '|'));
    assert.equal(Buffer.from(parts[2], 'base64url').length, 64);
    assert.ok(verify('sha256', Buffer.from(parts[1], 'base64url'), { key: keys.publicKey, dsaEncoding: 'ieee-p1363' }, Buffer.from(parts[2], 'base64url')));
    const repeat = await call('/v1/activate', { serial: serial.toLowerCase(), machine: winner });
    assert.equal((await repeat.json()).license, license);
    assert.equal((await call('/v1/activate', { serial, machine: 'invalid' })).status, 400);
    assert.equal((await call('/v1/activate', { padding: 'x'.repeat(5000) })).status, 413);
    assert.equal((await call('/v1/activate', [])).status, 400);
    const health = await worker.fetch(new Request('https://example.test/health'), env);
    assert.equal(health.status, 200);
    assert.equal((await worker.fetch(new Request('http://example.test/health'), env)).status, 400);
    assert.equal((await worker.fetch(new Request('https://example.test/health'), {})).status, 503);
  } finally { DB.db.close(); }
});
