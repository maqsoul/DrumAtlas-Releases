# Сопоставление 70 пунктов отчёта 12.10.2026

Статическое соответствие модулей, не сертификат исправности каждого сценария. PASS в столбце означает только указанный узкий тест; полная приёмка остаётся открытой. Нумерация соответствует порядку пунктов Word.

| № | Пункт отчёта | Код / свидетельство | Проверка и ограничения |
|---|---|---|---|
| 1 | Создан DrumAtlas | Source/Engine.cpp, Metadata.cpp, Analysis.cpp, Neural.cpp, Editor.inc | analysis PASS; integration остановлен на активации |
| 2 | Подключение нескольких папок | Source/Engine.cpp, Metadata.cpp, Analysis.cpp, Neural.cpp, Editor.inc | analysis PASS; integration остановлен на активации |
| 3 | Выбор библиотеки | Source/Engine.cpp, Metadata.cpp, Analysis.cpp, Neural.cpp, Editor.inc | analysis PASS; integration остановлен на активации |
| 4 | Автоматическая классификация | Source/Engine.cpp, Metadata.cpp, Analysis.cpp, Neural.cpp, Editor.inc | analysis PASS; integration остановлен на активации |
| 5 | Приоритет названия и папки | Source/Engine.cpp, Metadata.cpp, Analysis.cpp, Neural.cpp, Editor.inc | analysis PASS; integration остановлен на активации |
| 6 | Учёт отрицаний | Source/Engine.cpp, Metadata.cpp, Analysis.cpp, Neural.cpp, Editor.inc | analysis PASS; integration остановлен на активации |
| 7 | Категории FX и Other | Source/Engine.cpp, Metadata.cpp, Analysis.cpp, Neural.cpp, Editor.inc | analysis PASS; integration остановлен на активации |
| 8 | Строгие фильтры | Source/Engine.cpp, Metadata.cpp, Analysis.cpp, Neural.cpp, Editor.inc | analysis PASS; integration остановлен на активации |
| 9 | Жанровые метки | Source/Engine.cpp, Metadata.cpp, Analysis.cpp, Neural.cpp, Editor.inc | analysis PASS; integration остановлен на активации |
| 10 | Ручная корректировка категории | Source/Engine.cpp, Metadata.cpp, Analysis.cpp, Neural.cpp, Editor.inc | analysis PASS; integration остановлен на активации |
| 11 | Многопоточное сканирование | Source/Engine.cpp:75–139,185–211; Formats.cpp; MediaFoundation.cpp | codecs PASS; long-path integration остановлен на активации |
| 12 | Повторное использование анализа | Source/Engine.cpp:75–139,185–211; Formats.cpp; MediaFoundation.cpp | codecs PASS; long-path integration остановлен на активации |
| 13 | Меньше обращений к диску | Source/Engine.cpp:75–139,185–211; Formats.cpp; MediaFoundation.cpp | codecs PASS; long-path integration остановлен на активации |
| 14 | Проверка ускорения сканирования | Source/Engine.cpp:75–139,185–211; Formats.cpp; MediaFoundation.cpp | Только историческое утверждение отчёта; benchmark не повторён |
| 15 | Чтение длинных путей Windows | Source/Engine.cpp:75–139,185–211; Formats.cpp; MediaFoundation.cpp | codecs PASS; long-path integration остановлен на активации |
| 16 | Проверка файлов без расширения | Source/Engine.cpp:75–139,185–211; Formats.cpp; MediaFoundation.cpp | codecs PASS; long-path integration остановлен на активации |
| 17 | Поддержка аудиоформатов | Source/Engine.cpp:75–139,185–211; Formats.cpp; MediaFoundation.cpp | codecs PASS; long-path integration остановлен на активации |
| 18 | Резервное декодирование | Source/Engine.cpp:75–139,185–211; Formats.cpp; MediaFoundation.cpp | codecs PASS; long-path integration остановлен на активации |
| 19 | Отдельный список непрочитанных файлов | Source/Engine.cpp:75–139,185–211; Formats.cpp; MediaFoundation.cpp | codecs PASS; long-path integration остановлен на активации |
| 20 | Сохранение каталога | Source/Engine.cpp:75–139,185–211; Formats.cpp; MediaFoundation.cpp | codecs PASS; long-path integration остановлен на активации |
| 21 | Прослушивание внутри плагина | Source/Plugin.cpp:12–68; Editor.inc; Engine.cpp | interface-layout PASS; жесты/прослушивание требуют ручной проверки |
| 22 | Волна выбранного сэмпла | Source/Plugin.cpp:12–68; Editor.inc; Engine.cpp | interface-layout PASS; жесты/прослушивание требуют ручной проверки |
| 23 | Волны референса и стемов | Source/Plugin.cpp:12–68; Editor.inc; Engine.cpp | interface-layout PASS; жесты/прослушивание требуют ручной проверки |
| 24 | Выделение протягиванием мыши | Source/Plugin.cpp:12–68; Editor.inc; Engine.cpp | interface-layout PASS; жесты/прослушивание требуют ручной проверки |
| 25 | Раздельное поведение паузы и стопа | Source/Plugin.cpp:12–68; Editor.inc; Engine.cpp | interface-layout PASS; жесты/прослушивание требуют ручной проверки |
| 26 | Управление значками | Source/Plugin.cpp:12–68; Editor.inc; Engine.cpp | interface-layout PASS; жесты/прослушивание требуют ручной проверки |
| 27 | Громкость предпрослушки | Source/Plugin.cpp:12–68; Editor.inc; Engine.cpp | interface-layout PASS; жесты/прослушивание требуют ручной проверки |
| 28 | Недавно использованные сэмплы | Source/Plugin.cpp:12–68; Editor.inc; Engine.cpp | interface-layout PASS; жесты/прослушивание требуют ручной проверки |
| 29 | Избранное и папки коллекций | Source/Plugin.cpp:12–68; Editor.inc; Engine.cpp | interface-layout PASS; жесты/прослушивание требуют ручной проверки |
| 30 | Контекстное меню рядом с сэмплом | Source/Plugin.cpp:12–68; Editor.inc; Engine.cpp | interface-layout PASS; жесты/прослушивание требуют ручной проверки |
| 31 | Импорт референсного трека | Source/Engine.cpp; Analysis.cpp; Neural.cpp; DetailModels.inc; DetailJob.inc; StemJob.inc; Editor.inc | analysis/detail-models PASS; качество музыки не измерялось |
| 32 | Анализ участка или целого трека | Source/Engine.cpp; Analysis.cpp; Neural.cpp; DetailModels.inc; DetailJob.inc; StemJob.inc; Editor.inc | analysis/detail-models PASS; качество музыки не измерялось |
| 33 | Связь анализа с категорией | Source/Engine.cpp; Analysis.cpp; Neural.cpp; DetailModels.inc; DetailJob.inc; StemJob.inc; Editor.inc | analysis/detail-models PASS; качество музыки не измерялось |
| 34 | Поиск по аудиопризнакам | Source/Engine.cpp; Analysis.cpp; Neural.cpp; DetailModels.inc; DetailJob.inc; StemJob.inc; Editor.inc | analysis/detail-models PASS; качество музыки не измерялось |
| 35 | Быстрый режим анализа | Source/Engine.cpp; Analysis.cpp; Neural.cpp; DetailModels.inc; DetailJob.inc; StemJob.inc; Editor.inc | analysis/detail-models PASS; качество музыки не измерялось |
| 36 | Разделение Demucs | Source/Engine.cpp; Analysis.cpp; Neural.cpp; DetailModels.inc; DetailJob.inc; StemJob.inc; Editor.inc | analysis/detail-models PASS; качество музыки не измерялось |
| 37 | Разделение ударных MDX23C DrumSep | Source/Engine.cpp; Analysis.cpp; Neural.cpp; DetailModels.inc; DetailJob.inc; StemJob.inc; Editor.inc | analysis/detail-models PASS; качество музыки не измерялось |
| 38 | Подробная перкуссия AudioSep | Source/Engine.cpp; Analysis.cpp; Neural.cpp; DetailModels.inc; DetailJob.inc; StemJob.inc; Editor.inc | analysis/detail-models PASS; качество музыки не измерялось |
| 39 | Экспорт и прослушивание стемов | Source/Engine.cpp; Analysis.cpp; Neural.cpp; DetailModels.inc; DetailJob.inc; StemJob.inc; Editor.inc | analysis/detail-models PASS; качество музыки не измерялось |
| 40 | Дополнительные варианты подбора | Source/Engine.cpp; Analysis.cpp; Neural.cpp; DetailModels.inc; DetailJob.inc; StemJob.inc; Editor.inc | analysis/detail-models PASS; качество музыки не измерялось |
| 41 | Локальная работа моделей | Source/Acceleration.inc; Neural.cpp; DetailModels.inc; StemJob.inc | detail-models PASS; историческое ускорение не перепроверено |
| 42 | Ускорение подробного разделения | Source/Acceleration.inc; Neural.cpp; DetailModels.inc; StemJob.inc | detail-models PASS; историческое ускорение не перепроверено |
| 43 | Оптимизация CPU | Source/Acceleration.inc; Neural.cpp; DetailModels.inc; StemJob.inc | detail-models PASS; историческое ускорение не перепроверено |
| 44 | Контрольный замер разделения | Source/Acceleration.inc; Neural.cpp; DetailModels.inc; StemJob.inc | Только историческое утверждение отчёта; benchmark не повторён |
| 45 | Обработка блоками | Source/Acceleration.inc; Neural.cpp; DetailModels.inc; StemJob.inc | detail-models PASS; историческое ускорение не перепроверено |
| 46 | Перетаскивание в DAW | Source/AudioEdit.cpp; AudioEditEditor.inc; Plugin.cpp:84–120; Editor.inc | pitch-tempo-license PASS; полный DAW drag/Sync требует integration |
| 47 | Изменение высоты звука | Source/AudioEdit.cpp; AudioEditEditor.inc; Plugin.cpp:84–120; Editor.inc | pitch-tempo-license PASS; полный DAW drag/Sync требует integration |
| 48 | Синхронизация с темпом DAW | Source/AudioEdit.cpp; AudioEditEditor.inc; Plugin.cpp:84–120; Editor.inc | pitch-tempo-license PASS; полный DAW drag/Sync требует integration |
| 49 | Независимое изменение темпа и высоты | Source/AudioEdit.cpp; AudioEditEditor.inc; Plugin.cpp:84–120; Editor.inc | pitch-tempo-license PASS; полный DAW drag/Sync требует integration |
| 50 | Сохранение оригинала и результата | Source/AudioEdit.cpp; AudioEditEditor.inc; Plugin.cpp:84–120; Editor.inc | pitch-tempo-license PASS; полный DAW drag/Sync требует integration |
| 51 | Подключение собственного аккаунта Splice | Source/Splice.cpp; SpliceEditor.inc; SplicePreview.h; SpliceBrowser.h | splice-credentials PASS; реальный аккаунт/поиск не проверялся |
| 52 | Splice внутри DrumAtlas | Source/Splice.cpp; SpliceEditor.inc; SplicePreview.h; SpliceBrowser.h | splice-credentials PASS; реальный аккаунт/поиск не проверялся |
| 53 | Панель браузера в стиле Chrome | Source/Splice.cpp; SpliceEditor.inc; SplicePreview.h; SpliceBrowser.h | splice-credentials PASS; реальный аккаунт/поиск не проверялся |
| 54 | Поиск Splice по референсу и стемам | Source/Splice.cpp; SpliceEditor.inc; SplicePreview.h; SpliceBrowser.h | splice-credentials PASS; реальный аккаунт/поиск не проверялся |
| 55 | Предпрослушка Splice в окне результатов | Source/Splice.cpp; SpliceEditor.inc; SplicePreview.h; SpliceBrowser.h | splice-credentials PASS; реальный аккаунт/поиск не проверялся |
| 56 | Скачивание и варианты Splice | Source/Splice.cpp; SpliceEditor.inc; SplicePreview.h; SpliceBrowser.h | splice-credentials PASS; реальный аккаунт/поиск не проверялся |
| 57 | Дизайн ION | Source/Editor.inc; Locale.h | interface-layout PASS; визуальное QA всех языков не проведено |
| 58 | Очистка интерфейса | Source/Editor.inc; Locale.h | interface-layout PASS; визуальное QA всех языков не проведено |
| 59 | Изменение размера окна | Source/Editor.inc; Locale.h | interface-layout PASS; визуальное QA всех языков не проведено |
| 60 | Переключение 14 языков | Source/Editor.inc; Locale.h | interface-layout PASS; визуальное QA всех языков не проведено |
| 61 | Windows VST3 и Standalone | CMakeLists.txt; Installer/; RELEASE-1.0.9-RU.md | vst3-load PASS; Mac и installer в этом аудите не запускались |
| 62 | Оформление установщика | CMakeLists.txt; Installer/; RELEASE-1.0.9-RU.md | vst3-load PASS; Mac и installer в этом аудите не запускались |
| 63 | Релизная версия без Beta | CMakeLists.txt; Installer/; RELEASE-1.0.9-RU.md | vst3-load PASS; Mac и installer в этом аудите не запускались |
| 64 | Сборки для Mac Apple Silicon | CMakeLists.txt; Installer/; RELEASE-1.0.9-RU.md | vst3-load PASS; Mac и installer в этом аудите не запускались |
| 65 | AU для Logic Pro | CMakeLists.txt; Installer/; RELEASE-1.0.9-RU.md | vst3-load PASS; Mac и installer в этом аудите не запускались |
| 66 | Активация серийным кодом | Source/License.cpp; Updates.cpp; LicenseServer/; Tools/; RELEASE-SERVICES.md | pitch-tempo-license PASS; сервер/выдача/публикация сейчас не проверялись |
| 67 | Приложение для выдачи кодов | Source/License.cpp; Updates.cpp; LicenseServer/; Tools/; RELEASE-SERVICES.md | pitch-tempo-license PASS; сервер/выдача/публикация сейчас не проверялись |
| 68 | Публичный сервер активации | Source/License.cpp; Updates.cpp; LicenseServer/; Tools/; RELEASE-SERVICES.md | pitch-tempo-license PASS; сервер/выдача/публикация сейчас не проверялись |
| 69 | Канал обновлений Windows и Mac | Source/License.cpp; Updates.cpp; LicenseServer/; Tools/; RELEASE-SERVICES.md | pitch-tempo-license PASS; сервер/выдача/публикация сейчас не проверялись |
| 70 | Публикация и проверка релизов | Source/License.cpp; Updates.cpp; LicenseServer/; Tools/; RELEASE-SERVICES.md | pitch-tempo-license PASS; сервер/выдача/публикация сейчас не проверялись |
