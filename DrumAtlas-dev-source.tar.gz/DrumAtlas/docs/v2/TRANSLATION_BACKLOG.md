# Новые строки 2.0

Locale.h сохраняет 14 существующих языков. Quick Beat использует явный английский fallback до перевода новых терминов.

Требуются переводы: Quick Beat, Library / Reference, Generate, Vary track, Undo, Redo, Export MIDI, Save/Open project, Use selected sample, Lock MIDI, BPM, Length, Seed, Density, Bar, Preview beat, Stop; сообщения валидации MusicCore, миграции, missing assets и host worker. Locate missing downloaded samples уже имеет русский вариант.

Приёмка: у каждого ключа 14 значений либо тестируемый английский fallback; визуальная проверка полей, кириллицы/CJK, 40–200% масштаба. Текущие новые строки не следует объявлять полностью переведёнными.
