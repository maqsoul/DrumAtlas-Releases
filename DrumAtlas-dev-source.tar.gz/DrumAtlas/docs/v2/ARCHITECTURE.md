Актуальное состояние реализации: [IMPLEMENTATION_STATUS.md](IMPLEMENTATION_STATUS.md). Ниже — снимок архитектуры до изменений 2.0; локальная ветка feature/drumatlas-2 уже создана.

# DrumAtlas 2.0 — аудит архитектуры

Дата: 17.10.2026. Статус: статический аудит и локальный baseline; не релиз 2.0.
Требования: предоставленный пользователем DOCX. Первый шаг ограничен этапом 0.
Фактическая база: CMakeLists.txt, project VERSION 1.0.9; видимое имя версии 1.0.0.
Отчёт от 12.10 описывает 1.0.5: более поздние исправления сохраняются.

## Реализованные границы

| Область | Код относительно корня DrumAtlas | Состояние |
|---|---|---|
| Оболочка | CMakeLists.txt; Source/Plugin.cpp:70–126 | JUCE, C++17; Windows VST3/Standalone, Apple дополнительно AU; AAX опционально |
| Аудио | Source/Plugin.cpp:12–68,84–89 | Поток декодирования и кольцевой буфер preview; try-lock на callback, при занятости пропуск preview |
| MIDI | Source/Plugin.cpp:84,92–93 | MidiBuffer игнорируется; acceptsMidi/producesMidi=false; музыкального движка нет |
| Каталог | Source/Engine.h; Engine.cpp:26–139 | Фоновая очередь задач, несколько корней, инкрементальный анализ, ручные метки, коллекции, недавние |
| Хранение | Engine.cpp:29,185–211; Plugin.cpp:100–120 | preferences.json, library-v2.json, чтение library-v1; XML состояния DAW с корнями, UI и путями рендеров |
| Анализ | Analysis.cpp, Metadata.cpp, Neural.cpp, Separation.cpp | Акустические признаки, метаданные, YAMNet, HPSS, Demucs |
| Подробные стемы | DetailModels.inc, DetailJob.inc, StemJob.inc | MDX23C/AudioSep, локальный ONNX, управление ускорением в Acceleration.inc |
| Декодирование | Formats.cpp, MediaFoundation.cpp | JUCE, libsndfile, Windows Media Foundation |
| Обработка | AudioEdit.cpp/.h, AudioEditEditor.inc | Отдельный поток, pitch/tempo, сохранение обработанного WAV |
| UI | Editor.inc; Locale.h:4–5 | ION; панели/масштаб; 14 языков; waveform и файловый drag |
| Splice | Splice.cpp/.h, SpliceEditor.inc, SpliceBrowser.h, SplicePreview.h | Авторизация, сетевой поиск/превью/скачивание; убрать отдельной миграцией |
| Лицензия/обновления | License.*, Platform.*, MacPlatform.cpp, Updates.*; LicenseServer | Отдельные сервисы: не удалять вместе со Splice |

SongProject, стабильных MIDI event IDs, piano roll, генератора, Artist KB и worker-хоста сторонних VST3 в текущей архитектуре нет. Проверка загрузки собственного VST3 не является проверкой хостинга сторонних инструментов.

## Зависимости и ограничения

CMake требует JUCE (локально 9.0.3), WebView2 на Windows, системные криптографические/медиа API. THIRD_PARTY.md фиксирует ONNX Runtime DirectML 1.24.4, libsndfile 1.2.2, YAMNet, Demucs, MDX23C, AudioSep и Signalsmith Stretch. Это инвентаризация существующих деклараций, не новое подтверждение всех прав поставки. Сам файл имеет устаревший заголовок 0.6.1.

THIRD_PARTY.md прямо указывает неподтверждённые права публичного распространения весов MDX23C. Новая публичная поставка этих весов не входит в аудит. Windows и macOS проверять отдельно; текущая Mac-линия arm64, без подтверждённой Developer ID/notarization. AAX не считать готовым к обычному Pro Tools.

## Предлагаемые границы 2.0

Сохранить Engine/Preview/AudioEdit и текущую идентичность оболочки. Добавить независимые MusicCore (SongProject, MIDI, детерминированные генераторы), ProjectStore (версии/миграции/история), InstrumentHost (scanner и worker), ArtistKnowledgeBase (происхождение/права), ActionService (валидируемые команды), UI Quick Beat/Chat/Instruments. Audio callback получает подготовленные события и буферы; не выполняет анализ, сеть, сканирование или сериализацию.

Нельзя просто заменить XML DAW-проекта новым форматом: нужен reader старого состояния и явное сохранение неизвестных/недоступных ресурсов. Решение о MIDI I/O и категориях оболочки проверяется в DAW до изменения выпуска.

Локальная папка исходников не является Git checkout; `git status` в рабочей папке возвращает not a git repository. Ветка feature/drumatlas-2 и PR ещё не созданы. Перед реализацией нужен контролируемый checkout исходников, без частных ключей и пользовательских библиотек.
