# macOS development builds — 17 October 2026

These packages are development artifacts, not the stable DrumAtlas update.
The user-facing version remains 1.0.0. The stable update feed is unchanged.

## Reproducible checks without a personal Mac

`Installer/macos-development.yml` builds AU, VST3, Standalone and the isolated
scanner on separate macOS 15 Apple Silicon and Intel GitHub runners. Source is
exported from tracked Git files, without credentials, customer data or model
weights. It runs six CTest cases, validates AU with Apple's `auval`, then creates
a PKG. No paid service was enabled.

Current run: https://github.com/maqsoul/DrumAtlas-Releases/actions/runs/39021592317

Source archive revision: `7b12d9f`. Workflow matrix revision: `d924b4d` locally.
Apple Silicon: six tests passed; AU VALIDATION SUCCEEDED. Installer SHA-256:
`6b9a13724a7813180867fe5d0574282d731dbe90f7c2561c9cce5889a05949ed`.
Intel: six tests passed; AU VALIDATION SUCCEEDED. Installer SHA-256:
`135195718935472cd5bc3300be4a62f5a3fa45dc1ae2919f2e65c0a67fa7508b`.
Both jobs completed successfully; complete workflow duration 9m51s. Both ZIP
digests matched GitHub's published artifact digests; PKG hashes matched the
packaging output. Installer copies are kept locally under outputs/ with
`Development-7b12d9f` in their names.

## Limits

- CI checks are not a session in Logic Pro, Ableton or another commercial DAW.
- Commercial VST instruments on macOS have not been exercised.
- No Apple Developer ID signing/notarization is included.
- No AAX release or PACE signature is included.
- Earlier offline builds did not configure activation or update endpoints.
  The 02ab04a preview configures serial activation, but not an update feed.
  These builds do not bundle AI model weights. They must not be
  substituted for the customer installer or advertised as the complete 2.0.
- The full remaining requirements are tracked in IMPLEMENTATION_STATUS.md.

The CI artifacts include package checksums, actual CTest logs, auval output and
layout screenshots. Keep these together when evaluating a build.

## Current preview: source 02ab04a

Run https://github.com/maqsoul/DrumAtlas-Releases/actions/runs/39023462665
completed successfully on both architectures (10m37s total). Each passed six
CTest tests and AU validation. Artifact ZIP digests and installer checksums
were verified locally. This includes the Mix panel and streaming WAV export.

- arm64 PKG SHA-256: `e839d3b8997d0dc75808faa460eac5f06001cee3906145e2e69a22a220a49a1c`
- x86_64 PKG SHA-256: `25ccc1048d2d3ddb4878623287c0258e1b9a4c822852811f826cb976812bcd64`

Serial activation endpoint is configured for these packages. No Apple Developer
ID/notarization or actual Logic Pro session is claimed. Visible version: 1.0.0.

## Stem export preview: source 9fa60de

Run https://github.com/maqsoul/DrumAtlas-Releases/actions/runs/39024846421
passed on Apple Silicon and Intel: six CTest cases each, AU validation, PKG
packaging. Verified both artifact ZIP digests and package checksums locally.
Inspected the Apple Silicon screenshot of the Export stems control.

- arm64 PKG SHA-256: `7d9b45694043950b25e02acd0f44a537fc5357966931e91e61f6f58b2e12ce9e`
- x86_64 PKG SHA-256: `6919eb3433ecc57bff284137a28ed615d950c691021d35f6e5e799df689c5f2a`

Same activation, signing and real-DAW limitations as the previous preview.
