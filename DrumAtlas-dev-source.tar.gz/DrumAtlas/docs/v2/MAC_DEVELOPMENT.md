# macOS development builds — 17 October 2026

These packages are development artifacts, not the stable DrumAtlas update.
The user-facing version remains 1.0.0. The stable update feed is unchanged.

## Reproducible checks without a personal Mac

`Installer/macos-development.yml` builds AU, VST3, Standalone and the isolated
scanner on separate macOS 15 Apple Silicon and Intel GitHub runners. Source is
exported from tracked Git files, without credentials, customer data or model
weights. It runs six CTest cases, validates AU with Apple's `auval`, then creates
a PKG. No paid service was enabled.

Current run: https://github.com/maqsoul/DrumAtlas-Releases/actions/runs/39021592317

Source archive revision: `7b12d9f`. Workflow matrix revision: `d924b4d` locally.
Apple Silicon: six tests passed; AU VALIDATION SUCCEEDED. Installer SHA-256:
`6b9a13724a7813180867fe5d0574282d731dbe90f7c2561c9cce5889a05949ed`.
Intel: six tests passed; AU VALIDATION SUCCEEDED. Installer SHA-256:
`135195718935472cd5bc3300be4a62f5a3fa45dc1ae2919f2e65c0a67fa7508b`.
Both jobs completed successfully; complete workflow duration 9m51s. Both ZIP
digests matched GitHub's published artifact digests; PKG hashes matched the
packaging output. Installer copies are kept locally under outputs/ with
`Development-7b12d9f` in their names.

## Limits

- CI checks are not a session in Logic Pro, Ableton or another commercial DAW.
- Commercial VST instruments on macOS have not been exercised.
- No Apple Developer ID signing/notarization is included.
- No AAX release or PACE signature is included.
- These offline development builds do not configure production activation or
  update service endpoints and do not bundle AI model weights. They must not be
  substituted for the customer installer or advertised as the complete 2.0.
- The full remaining requirements are tracked in IMPLEMENTATION_STATUS.md.

The CI artifacts include package checksums, actual CTest logs, auval output and
layout screenshots. Keep these together when evaluating a build.
