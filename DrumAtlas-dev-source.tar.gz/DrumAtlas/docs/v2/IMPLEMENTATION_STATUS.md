# DrumAtlas 2.0 — рабочий статус

17.10.2026. Это разрабатываемая ветка, **не завершённая версия 2.0 и не публичное обновление**.
Ветка: feature/drumatlas-2. Базовый commit: d1c5ac5 (код 1.0.9, видимое имя 1.0.0).
Дизайн пользователя: ION с широкой волной; ION Setup с выбором компонентов.

## Реализовано в этой ветке

- Базовые 9 тестов успешно пройдены с существующей подписанной тестовой лицензией. Лицензирование не обходилось и сервер не менялся.
- Splice UI, OAuth, поиск, браузер и скачивание удалены из сборки. Удалены соответствующие исходники, тест credentials, строки локализации и Mac Keychain helper; WebView отключён. Старые пользовательские зашифрованные credentials не читаются и не удаляются этим изменением.
- Миграция сохраняет побайтовую резервную копию каталога, настроек и локального индекса скачиваний с manifest/SHA-256. Исходное аудио и старые метаданные не удаляются. Папки существующих скачанных файлов импортируются; отсутствующие ссылки сохранены. В View / panels добавлен ручной Locate, отдельный located-assets.json сохраняет выбранную замену. Базовые тесты — повторяемость, повреждённый backup, отсутствие копирования секретов, сохранение исходной ссылки.
- На изолированной копии реального каталога пользователя (~560 МБ), preferences и Splice metadata успешно проверены backup, повторный запуск и восстановление с совпадением SHA-256. Оригиналы в AppData не изменены. Большой каталог не парсится второй раз ради backup. Повторные открытия проверяют размер/mtime; полная проверка хеша выполняется при изменении backup или явной verifyHashes.
- MusicCore: schema 1, 960 PPQ, MIDI tracks/events с IDs, поддержка 1–256 тактов на уровне ядра; детерминированный первый Trap/Dark/minor профиль; девять партий, swing/density/humanize, snare anchor, проверка границ и MIDI значений.
- Сохранение .drumatlas и состояния DAW, чтение старого состояния без SongProject, отказ от перезаписи неизвестной будущей схемы. Undo/Redo до 64 снимков. Регенерация выбранной дорожки/диапазона тактов в API с сохранением MIDI locks и остальных дорожек.
- Quick Beat внутри ION: BPM, bars, seed, density, выбор дорожки/такта, grid-edit нот, MIDI lock, генерация/вариация, Undo/Redo, Save/Open, экспорт SMF1. Новые строки пока на английском (явный fallback).
- Предпрослушивание бита через существующий Preview: офлайн WAV-рендер, пользовательские one-shots или простые оригинальные синтезированные звуки для неназначенных дорожек. Отсутствующий назначенный файл вызывает ошибку, а не тихую замену. Рендер ограничен 120 секундами и 30 секундами на исходный one-shot. Это не полноценный VST-renderer; root note мелодического сэмпла пока C4/MIDI 60.
- ArtistKnowledge: отдельный тестируемый модуль registry, aliases, provenance, permissions, territory/expiry/review checks, запрет train без отдельного разрешения, отзыв источника со списком затронутых dataset/model versions, атомарное чтение версии схемы. Пока не подключён к UI и не содержит реальный каталог артистов/корпус.
- Отдельный AtlasWorker для VST3 discovery и standalone MIDI/audio/state probe. Parent watchdog проверен на abrupt exit и зависании. Worker не загружается в DAW. Это изоляция сбоев, не security sandbox.

## Дополнение: профили жанров и настроений

- Resources/MusicProfiles.json: версия схемы 1, 23 исходных жанра и 19 настроений. Это оригинальные эвристические пресеты, не обученная модель и не доказательство аутентичности каждого музыкального стиля.
- ProfileRegistry: атомарный импорт внешнего JSON без пересборки, строгая проверка диапазонов/ID/массивов; веса, слияние повторных ID, нормализация, стабильная сортировка. Числовые параметры и вероятности смешиваются; дискретные правила берутся у наиболее весомого профиля, равенство разрешается лексикографически. BPM — пересечение диапазонов; при конфликте диапазон ведущего профиля с явным notice.
- Генератор profiles-1 использует вероятности kick/snare/hat, параметры настроения, отдельные Energy/Darkness/Complexity/Groove/Humanize/Melodic Density. В текущей реализации влияние настроения ограничено velocity, плотностью мелодии, длительностью аккордов, регистром и сложностью. Рекомендации тембров, выбор гармонии по настроению и arrangement rules ещё не применяются полноценно.
- Проект хранит snapshot реестра и весов. Regenerate использует эту копию, а не обновлённый внешний файл. Legacy rules-1 сохранён. Неизвестные/повреждённые профили отвергаются без изменения проекта.
- Quick Beat: выбор одного жанра и настроения, шесть регуляторов, Import profiles. Многопрофильное смешивание есть в API, UI редактор весов ещё предстоит. Новые элементы пока English fallback.
- Верификация: 437 сочетаний с валидным MIDI, повторяемость seed, сохранение snapshot; тесты реестра проверяют конфликты BPM, веса, неизвестные ID, NaN, будущую схему и атомарность отказа. Полная художественная оценка профилей и golden MIDI для каждого жанра ещё не выполнены.

## Фактические Windows-пробы

| Инструмент | Результат | Граница подтверждения |
|---|---|---|
| DrumAtlas VST3 | Scan PASS, effect правильно не помечен instrument | Собственная FX-оболочка |
| Serum 2 2.0.20 | Scan, instantiate, MIDI→audio, state restore PASS; peak 0.2833 | Standalone 44.1 kHz / 256; Serum 2 FX распознан отдельно |
| Omnisphere 3.0.2 | Scan/instantiate/state прошли; peak=0 | Аудио не подтверждено: начальное состояние без выбранного тестового патча |
| Kontakt 8 | Scan/instantiate/state прошли; peak=0 | Аудио не подтверждено: требуется выбранный инструмент |

Пользователь подтвердил работающие активированные Serum 2, Omnisphere и Kontakt 8. Mac у пользователя отсутствует. Ни один из этих результатов не является статусом Supported для полного хоста DrumAtlas. GUI, DAW integration, IPC, latency и buffer matrix остаются открытыми.

## Остаток ТЗ (не считать сделанным)

| Раздел | Следующая работа |
|---|---|
| 2 | Довести удаление неиспользуемых installer-зависимостей; расширить миграцию old DAW paths/relocations и конкурентные экземпляры |
| 3–4 | UI смешивания Genre/Mood с весами; полноценные harmony/arrangement/texture правила; художественная оценка и golden MIDI для каждого профиля (базовый JSON registry и параметры реализованы) |
| 5–8 | Полная панель параметров, 16/32/64/triplet grids, профессиональный piano roll, velocity/duration/expression editing, тональности/voice leading, bass glide/bend, arrangement, FX/countermelody |
| 9 | AI Chat, parser/model, validated actions, dry-run/atomic changesets и контроль locks |
| 10 | UI реестра артистов, эпохи/coverage, временный reference analysis → features, style-to-MIDI, ingestion/dedup/retention/delete/audit, разрешённый корпус и модельные исследования |
| 11 | Полный UID/fingerprint cache/quarantine; persistent worker protocol, shared-memory realtime audio/MIDI, GUI windows, state snapshots/recovery, latency/PDC, offline bounce; native Windows/macOS implementation; полный набор коммерческих инструментов |
| 12–13 | Индекс пресетов только через подтверждённые возможности; text/context Sound Finder; parameter capability maps и Sound Designer adapters |
| 14 | BPM/key confidence, sections/Groove DNA, drum/bass/melody MIDI transcription |
| 15–16 | Сохраняемая история/variations/lock sound UI; MIDI CC/bend/tempo map, MIDI drag, WAV stems/per-pad/manifest/tails/PDC |
| 17–20 | Полные tabs Library/Reference/Quick Beat/AI Chat/Instruments, переводы, ресурсы/телеметрия/consent, stress/DAW matrix, Mac CI и реальные проверки, пакеты установки и подписанный release feed |

## Внешние ограничения

- Публичная поставка весов MDX23C пока не разрешена подтверждённым документом. На 17.10.2026 [карточка поставщика конверсии](https://huggingface.co/scragnog/HOT-Step-CPP-SuperSep) отдельно оговаривает: MIT относится к конверсии/упаковке, веса имеют собственные условия. Автоматически считать их MIT нельзя. Существующие пользовательские модели не изменены; новые публичные пакеты весов не создавались.
- Mac/Logic нельзя считать проверенным на Windows. Сборка CI и auval отдельно от ручного/реального DAW тестирования. Developer ID/notarization и AAX/PACE этим этапом не получены.

## Проверки и воспроизведение

Локальный инструмент: work/build.ps1 (MSVC 14.44, Windows SDK 10.0.26100.0, JUCE 9.0.3), папка work/build-native.
Базовый прогон после удаления Splice и добавления новых модулей: **11/11 PASS**, 49.13 s; work/v2-regression.log. Подробные проверки MusicCore включают registry rights gates; pitch-tempo-license дополнительно проверяет WAV beat render и отказ при потере sample.
После последующих изменений совместимости старого/будущего SongProject повторный прогон integration, interface-layout и integration-long-paths: 3/3 PASS, 42.68 s; work/v2-state-regression.log.

Никакие приватные ключи, license.key, auth.dpapi и копии пользовательских данных не входят в эту ветку. Полные копии тестовых данных находятся только в локальной work/ вне репозитория.

Проверки после подключения профилей: music-profiles + music-core — 2/2 PASS (4.19 s); integration + interface-layout + integration-long-paths — 3/3 PASS (44.17 s). UI тест выбирает House/Warm и проверяет сохранённый profiles-1; снимок layout-quick-beat-profiles.png просмотрен вручную. Windows VST3 и Standalone пересобраны. Эти проверки не подтверждают macOS или полный DAW-host matrix.

## Продолжение 17.10: MIDI-редактор и подготовка macOS

- Piano Roll: сетки 16/32/64 и 12/24/48 (триольные), выбор/создание нот, перенос по времени/высоте и растягивание правого края мышью, удаление, числовые velocity/duration/pitch. Один жест записывает одну отменяемую правку. Edit/delete/copy в ядре транзакционные и учитывают MIDI lock.
- Quick Beat: выбор тоники и major/minor, Sound lock, Vary bar, Copy to next bar. Тесты границ сеток, изменения нот и запрета locked edits проходят.
- Исправлен состав source-пакетов macOS: включены Resources, удалён устаревший Splice тест/текст. Добавлен отдельный development workflow без изменения stable feed, без весов моделей и приватных данных. Результат исполнения CI фиксируется отдельно после запуска.
- Piano Roll пока не включает marquee/multi-selection, CC/expression lanes, независимый zoom/scroll и полноценный arrangement; эти пункты остаются открытыми.
