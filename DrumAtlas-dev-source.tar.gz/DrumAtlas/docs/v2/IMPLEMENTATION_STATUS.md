# DrumAtlas 2.0 — рабочий статус

17.10.2026. Это разрабатываемая ветка, **не завершённая версия 2.0 и не публичное обновление**.
Ветка: feature/drumatlas-2. Базовый commit: d1c5ac5 (код 1.0.9, видимое имя 1.0.0).
Дизайн пользователя: ION с широкой волной; ION Setup с выбором компонентов.

## Реализовано в этой ветке

- Базовые 9 тестов успешно пройдены с существующей подписанной тестовой лицензией. Лицензирование не обходилось и сервер не менялся.
- Splice UI, OAuth, поиск, браузер и скачивание удалены из сборки. Удалены соответствующие исходники, тест credentials, строки локализации и Mac Keychain helper; WebView отключён. Старые пользовательские зашифрованные credentials не читаются и не удаляются этим изменением.
- Миграция сохраняет побайтовую резервную копию каталога, настроек и локального индекса скачиваний с manifest/SHA-256. Исходное аудио и старые метаданные не удаляются. Папки существующих скачанных файлов импортируются; отсутствующие ссылки сохранены. В View / panels добавлен ручной Locate, отдельный located-assets.json сохраняет выбранную замену. Базовые тесты — повторяемость, повреждённый backup, отсутствие копирования секретов, сохранение исходной ссылки.
- На изолированной копии реального каталога пользователя (~560 МБ), preferences и Splice metadata успешно проверены backup, повторный запуск и восстановление с совпадением SHA-256. Оригиналы в AppData не изменены. Большой каталог не парсится второй раз ради backup. Повторные открытия проверяют размер/mtime; полная проверка хеша выполняется при изменении backup или явной verifyHashes.
- MusicCore: schema 1, 960 PPQ, MIDI tracks/events с IDs, поддержка 1–256 тактов на уровне ядра; детерминированный первый Trap/Dark/minor профиль; девять партий, swing/density/humanize, snare anchor, проверка границ и MIDI значений.
- Сохранение .drumatlas и состояния DAW, чтение старого состояния без SongProject, отказ от перезаписи неизвестной будущей схемы. Undo/Redo до 64 снимков. Регенерация выбранной дорожки/диапазона тактов в API с сохранением MIDI locks и остальных дорожек.
- Quick Beat внутри ION: BPM, bars, seed, density, выбор дорожки/такта, grid-edit нот, MIDI lock, генерация/вариация, Undo/Redo, Save/Open, экспорт SMF1. Новые строки пока на английском (явный fallback).
- Предпрослушивание бита через существующий Preview: офлайн WAV-рендер, пользовательские one-shots или простые оригинальные синтезированные звуки для неназначенных дорожек. Отсутствующий назначенный файл вызывает ошибку, а не тихую замену. Рендер ограничен 120 секундами и 30 секундами на исходный one-shot. Это не полноценный VST-renderer; root note мелодического сэмпла пока C4/MIDI 60.
- ArtistKnowledge: отдельный тестируемый модуль registry, aliases, provenance, permissions, territory/expiry/review checks, запрет train без отдельного разрешения, отзыв источника со списком затронутых dataset/model versions, атомарное чтение версии схемы. Пока не подключён к UI и не содержит реальный каталог артистов/корпус.
- Отдельный AtlasWorker для VST3 discovery и standalone MIDI/audio/state probe. Parent watchdog проверен на abrupt exit и зависании. Worker не загружается в DAW. Это изоляция сбоев, не security sandbox.

## Дополнение: профили жанров и настроений

- Resources/MusicProfiles.json: версия схемы 1, 23 исходных жанра и 19 настроений. Это оригинальные эвристические пресеты, не обученная модель и не доказательство аутентичности каждого музыкального стиля.
- ProfileRegistry: атомарный импорт внешнего JSON без пересборки, строгая проверка диапазонов/ID/массивов; веса, слияние повторных ID, нормализация, стабильная сортировка. Числовые параметры и вероятности смешиваются; дискретные правила берутся у наиболее весомого профиля, равенство разрешается лексикографически. BPM — пересечение диапазонов; при конфликте диапазон ведущего профиля с явным notice.
- Генератор profiles-1 использует вероятности kick/snare/hat, параметры настроения, отдельные Energy/Darkness/Complexity/Groove/Humanize/Melodic Density. В текущей реализации влияние настроения ограничено velocity, плотностью мелодии, длительностью аккордов, регистром и сложностью. Рекомендации тембров, выбор гармонии по настроению и arrangement rules ещё не применяются полноценно.
- Проект хранит snapshot реестра и весов. Regenerate использует эту копию, а не обновлённый внешний файл. Legacy rules-1 сохранён. Неизвестные/повреждённые профили отвергаются без изменения проекта.
- Quick Beat: выбор одного жанра и настроения, шесть регуляторов, Import profiles. Многопрофильное смешивание доступно в панели Mix с отдельными вкладками Genres/Moods. Новые элементы пока English fallback.
- Верификация: 437 сочетаний с валидным MIDI, повторяемость seed, сохранение snapshot; тесты реестра проверяют конфликты BPM, веса, неизвестные ID, NaN, будущую схему и атомарность отказа. Полная художественная оценка профилей и golden MIDI для каждого жанра ещё не выполнены.

## Фактические Windows-пробы

| Инструмент | Результат | Граница подтверждения |
|---|---|---|
| DrumAtlas VST3 | Scan PASS, effect правильно не помечен instrument | Собственная FX-оболочка |
| Serum 2 2.0.20 | Scan, instantiate, MIDI→audio, state restore PASS; peak 0.2833 | Standalone 44.1 kHz / 256; Serum 2 FX распознан отдельно |
| Omnisphere 3.0.2 | Scan/instantiate/state прошли; peak=0 | Аудио не подтверждено: начальное состояние без выбранного тестового патча |
| Kontakt 8 | Scan/instantiate/state прошли; peak=0 | Аудио не подтверждено: требуется выбранный инструмент |

Пользователь подтвердил работающие активированные Serum 2, Omnisphere и Kontakt 8. Mac у пользователя отсутствует. Ни один из этих результатов не является статусом Supported для полного хоста DrumAtlas. GUI, DAW integration, IPC, latency и buffer matrix остаются открытыми.

## Остаток ТЗ (не считать сделанным)

| Раздел | Следующая работа |
|---|---|
| 2 | Довести удаление неиспользуемых installer-зависимостей; расширить миграцию old DAW paths/relocations и конкурентные экземпляры |
| 3–4 | Полноценные harmony/arrangement/texture правила; художественная оценка и golden MIDI для каждого профиля (базовый JSON registry и параметры реализованы) |
| 5–8 | Расширить уже работающие сетки и редактирование velocity/duration/pitch: multi-selection, expression, voice leading, bass glide/bend, arrangement, FX/countermelody |
| 9 | Полный AI Chat/model и история диалога; ограниченные offline commands, validated actions, dry-run/atomic changesets и контроль locks уже реализованы |
| 10 | UI реестра артистов, эпохи/coverage, временный reference analysis → features, style-to-MIDI, ingestion/dedup/retention/delete/audit, разрешённый корпус и модельные исследования |
| 11 | Полный UID/fingerprint cache/quarantine; persistent worker protocol, shared-memory realtime audio/MIDI, GUI windows, state snapshots/recovery, latency/PDC, offline bounce; native Windows/macOS implementation; полный набор коммерческих инструментов |
| 12–13 | Индекс пресетов только через подтверждённые возможности; text/context Sound Finder; parameter capability maps и Sound Designer adapters |
| 14 | BPM/key confidence, sections/Groove DNA, drum/bass/melody MIDI transcription |
| 15–16 | Сохраняемая история/variations; MIDI CC/bend/tempo map, MIDI drag, WAV stems/per-pad/manifest/tails/PDC (Sound lock UI уже реализован) |
| 17–20 | Полные tabs Library/Reference/Quick Beat/AI Chat/Instruments, переводы, ресурсы/телеметрия/consent, stress/DAW matrix, Mac CI и реальные проверки, пакеты установки и подписанный release feed |

## Внешние ограничения

- Публичная поставка весов MDX23C пока не разрешена подтверждённым документом. На 17.10.2026 [карточка поставщика конверсии](https://huggingface.co/scragnog/HOT-Step-CPP-SuperSep) отдельно оговаривает: MIT относится к конверсии/упаковке, веса имеют собственные условия. Автоматически считать их MIT нельзя. Существующие пользовательские модели не изменены; новые публичные пакеты весов не создавались.
- Mac/Logic нельзя считать проверенным на Windows. Сборка CI и auval отдельно от ручного/реального DAW тестирования. Developer ID/notarization и AAX/PACE этим этапом не получены.

## Дополнительная верификация 17.10

- Полный Windows CTest на исходниках 7b12d9f: 12/12 PASS, 225.33 s; work/v2-final-oct17-regression.log. Standalone и VST3 пересобраны и после последующего исправления подписи сетки.
- Windows VST3: pluginval strictness 5, seed 45192, без GUI-тестов — SUCCESS. Проверены загрузка, обработка аудио, state и buses. Внешний Steinberg validator не был настроен и был пропущен; pluginval не заменяет реальные сессии DAW.
- macOS Apple Silicon, source 7b12d9f: шесть CTest проверок PASS, включая isolated-vst3-scan и interface-layout. AU VALIDATION SUCCEEDED. Извлечённые логи и снимок Quick Beat просмотрены, ZIP и PKG проверены по SHA-256. Run: https://github.com/maqsoul/DrumAtlas-Releases/actions/runs/39021592317.
- Тот же прогон завершился успешно и для Intel: 6/6 CTest, auval PASS, PKG и ZIP SHA-256 проверены. Общая длительность CI 9m51s. Ограничения development-пакетов описаны в MAC_DEVELOPMENT.md; краткая инструкция реализованного редактора — QUICK_BEAT_CHECK_RU.md.
- Локально исправлена подпись сетки 48: теперь «48 triplet». Это изменение текста сделано после экспорта исходников 7b12d9f для CI.

## Проверки и воспроизведение

Локальный инструмент: work/build.ps1 (MSVC 14.44, Windows SDK 10.0.26100.0, JUCE 9.0.3), папка work/build-native.
Базовый прогон после удаления Splice и добавления новых модулей: **11/11 PASS**, 49.13 s; work/v2-regression.log. Подробные проверки MusicCore включают registry rights gates; pitch-tempo-license дополнительно проверяет WAV beat render и отказ при потере sample.
После последующих изменений совместимости старого/будущего SongProject повторный прогон integration, interface-layout и integration-long-paths: 3/3 PASS, 42.68 s; work/v2-state-regression.log.

Никакие приватные ключи, license.key, auth.dpapi и копии пользовательских данных не входят в эту ветку. Полные копии тестовых данных находятся только в локальной work/ вне репозитория.

Проверки после подключения профилей: music-profiles + music-core — 2/2 PASS (4.19 s); integration + interface-layout + integration-long-paths — 3/3 PASS (44.17 s). UI тест выбирает House/Warm и проверяет сохранённый profiles-1; снимок layout-quick-beat-profiles.png просмотрен вручную. Windows VST3 и Standalone пересобраны. Эти проверки не подтверждают macOS или полный DAW-host matrix.

## Продолжение 17.10: MIDI-редактор и подготовка macOS

- Piano Roll: сетки 16/32/64 и 12/24/48 (триольные), выбор/создание нот, перенос по времени/высоте и растягивание правого края мышью, удаление, числовые velocity/duration/pitch. Один жест записывает одну отменяемую правку. Edit/delete/copy в ядре транзакционные и учитывают MIDI lock.
- Quick Beat: выбор тоники и major/minor, Sound lock, Vary bar, Copy to next bar. Тесты границ сеток, изменения нот и запрета locked edits проходят.
- Исправлен состав source-пакетов macOS: включены Resources, удалён устаревший Splice тест/текст. Добавлен отдельный development workflow без изменения stable feed, без весов моделей и приватных данных. Результат исполнения CI фиксируется отдельно после запуска.
- Piano Roll пока не включает marquee/multi-selection, CC/expression lanes, независимый zoom/scroll и полноценный arrangement; эти пункты остаются открытыми.

## Продолжение: команды и первая фактическая macOS-проверка

- Добавлен MusicActions: версия схемы, allowlist полей/действий, dry-run, проверка MIDI locks, атомарное применение, защита от устаревшего/tampered preview и Undo. Действия: tempo, regenerate track/bar range/seed, transpose, velocity. Regenerate теперь имеет воспроизводимые event IDs в заменяемом диапазоне.
- Панель Commands / offline подключена к процессору. Парсер ограничен указанными английскими командами; это НЕ завершённый AI Chat/LLM. История диалога и command audit persistence ещё не реализованы.
- Locate legacy assets теперь синхронизируется между экземплярами перед чтением/записью relocated index.
- Windows music-core, library-migration и три integration/layout проверки прошли; commands-integration 3/3 за 45.46 s. Снимок панели проверен.
- macOS Apple Silicon CI на исходниках f17bb5e: PASS, AU/VST3/Standalone, 4 offline tests, auval и создание development PKG. Run https://github.com/maqsoul/DrumAtlas-Releases/actions/runs/39020437636, job 117360985791, 4m32s. Пакет не Developer ID signed/notarized; реального теста Logic Pro/коммерческих VST на macOS нет. Первое исполнение CI предшествует command panel. Второе: run 39020817854, commit 85648124f0f811d18ba8ecfdde73d87b97dd7008, source 89f59b5 — PASS, 4 tests и auval. Scanner был собран, но его CTest был ограничен Windows; это обнаружено по фактическому LastTest.log, проверка включена для APPLE в следующем прогоне.

## Продолжение: UI смешивания жанров и настроений

- Mix открывает вкладки Genres/Moods с относительными весами. Наборы нормализуются отдельно, ноль исключает профиль; показаны итоговые проценты и правила доминирующего профиля. Пустой набор не принимается.
- Use mix подготавливает настройки без изменения нот; Generate применяет смесь и сохраняет registry/weights в style snapshot проекта. Повторное открытие/Undo восстанавливают веса. Одиночный выбор сбрасывает только соответствующую группу.
- music-core/music-profiles/interface-layout: 3/3 PASS. Дополнительный interface-layout проверяет сброс одной группы и Undo — PASS. Проверены отсутствие неявной регенерации, две группы, project round trip, восстановление процентов и запрет пустой смеси. Снимок layout-style-mix.png просмотрен.
- Windows VST3/Standalone пересобраны. Mac development-пакеты 7b12d9f предшествуют этой панели; новую панель на macOS пока не проверяли.

## Продолжение: экспорт Quick Beat в WAV

- Export WAV открывает выбор файла и сохраняет текущий проект в фоне: stereo PCM, 24-bit, 44.1 kHz, хвост 2 секунды. Во время рендера повторный экспорт заблокирован; закрытие редактора отменяет экспорт через атомарный флаг.
- Используются назначенные one-shot сэмплы или исходный простой синтезатор MusicRender. Это не bounce внешних VST, не экспорт отдельных stems. Ограничение текущего рендера: 120 секунд музыкальной части; назначенный one-shot до 30 секунд.
- Запись через TemporaryFile: целевой файл заменяется после завершения. Отсутствующая папка/ошибка открытия возвращают сообщение вместо разыменования отсутствующего stream.
- Проверки pitch-tempo-license/interface-layout: 2/2 PASS, 2.64 s. Проверены фактический фоновый экспорт через Editor, читаемый stereo 24-bit WAV, блокировка повторной операции, отказ неправильного пути/частоты, сохранение точных байтов существующего WAV при ошибке/отмене. Снимок панели проверен.
- Windows VST3 и Standalone пересобраны. Изменение пока не опубликовано в stable feed и не включено в предыдущие macOS-пакеты.

## Продолжение: снят предел 120 секунд для WAV

- MusicRender записывает фиксированные блоки 4096 кадров с 64-битными позициями. Отдельного лимита длительности экспорта больше нет: экспортируется весь допустимый SongProject и хвост 2 секунды. Существующие ограничения схемы проекта (до 256 тактов) этим изменением не сняты; размер файла зависит от свободного места и файловой системы. JUCE WAV writer поддерживает переход в RF64; практический экспорт файла свыше 4 ГБ пока не проверялся.
- Два детерминированных прохода: поиск общего пика и запись с единым коэффициентом нормализации. Буфер микса не растёт с длительностью; загруженные one-shot сэмплы и список нот по-прежнему требуют память. Активные голоса сохраняют фазу/состояние шума между блоками.
- Ошибка записи/flush и отмена не заменяют существующий файл. Проверки: 128 секунд музыки + 2 секунды хвоста, звук последнего такта, точная длина, одинаковые SHA-256 повторных рендеров, отмена во втором проходе с сохранением исходных байтов. pitch-tempo-license/interface-layout 2/2 PASS, 3.95 s.
- Windows VST3/Standalone пересобраны. Mac-сборки и stable feed пока не обновлены.
