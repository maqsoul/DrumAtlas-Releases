# ADR-002: изолированный VST3 Instrument Host

Статус: предложено, не реализовано. Основание: раздел 11 ТЗ. Текущий vst3-load проверяет только собственный модуль DrumAtlas.

Решение: отдельный scanner и отдельный worker на экземпляр инструмента, сначала Standalone test rig. Сканер читает class UID/vendor/version/architecture/category/I-O/GUI, имеет fingerprint cache, soft/hard timeout и quarantine. Пользовательские пути обходятся без циклов; эффект не считается инструментом только по расширению.

Версионированный control IPC: HELLO/CAPS, CREATE, PREPARE, MIDI, GUI_OPEN/CLOSE, GET/SET_STATE, SUSPEND/RESUME, CLOSE. Каждый запрос имеет request_id, instance_id, deadline и error_code. PROCESS обозначает обработку блока; аудиоданные идут через предварительно выделенную shared memory, не JSON. Запуск процессов, GUI, сериализация и диагностика выполняются вне audio callback.

Audio IPC: SPSC ring buffers, sequence/block_id, sample offsets для MIDI/automation. Начальный прототип проверяет pipeline в один блок; точное значение измеряется и сообщается DAW в samples. Callback никогда не ждёт worker: при underrun — безопасная тишина и счётчик. Изменение SR/block size требует suspend/reprepare/resume. Offline bounce имеет отдельный протестированный режим; отсутствие измерений запрещает утверждать нулевую задержку.

GUI сначала отдельное нативное окно worker. Проверить DPI, фокус, клавиатуру, модальные диалоги, file picker, второй монитор, закрытие окна без уничтожения инструмента. Cross-process embedding не является обязательным. При отсутствии редактора — публичные параметры по capability map.

Состояние: UID/version/path hint, MIDI mapping, capability version, checksum state blob, last-good snapshot. Потеря инструмента сохраняет MIDI и blob; Reconnect/Replace только явно. Watchdog обрабатывает crash/hang с ограниченным завершением, без бесконечного autorestart; пользователь может Restart/Disable/Re-scan или использовать rendered fallback.

Матрица: Windows x64 и macOS arm64 раздельно; Standalone, VST3 внутри DAW, AU внутри Logic; 44.1/48/96 kHz × 64/128/256/512/1024 samples. На каждую комбинацию: scan, instantiate, GUI, MIDI/audio, automation, save/reopen, offline bounce, stop/seek/loop, crash recovery, missing-instrument fallback. Serum 2/Omnisphere/Vital/Kontakt сейчас Untested. Supported только с OS/DAW/vendor build/binary fingerprint и результатами всех применимых проверок.

Gates: H0 открытый тестовый инструмент → H1 synthetic crash/hang → H2 latency/buffer matrix → H3 реальные инструменты → H4 оболочки DAW → H5 migration/release QA. Точные API сверить с используемыми версиями JUCE/VST3 SDK перед прототипом. Ни AU hosting, ни legacy VST2 bridging не входят автоматически. Коммерческие инструменты/библиотеки не поставляются вместе с DrumAtlas.
