#pragma once
#include "MusicCore.h"
#include <regex>

namespace atlas::music {
struct ActionPreview { Project project; juce::String baseline,summary; juce::var command; };
// One authority for structured actions from UI, an offline parser, or a future
// model adapter. Parsing never executes code, opens files, or fetches audio.
inline juce::Result previewAction(const Project&current,const juce::var&command,ActionPreview&out){
    auto fail=[](const char*m){return juce::Result::fail(m);};auto valid=validate(current);if(valid.failed())return valid;
    if(!command.isObject()||!command["schema_version"].isInt()||int(command["schema_version"])!=1||!command["action"].isString())return fail("Unsupported action schema");
    auto action=command["action"].toString();juce::StringArray keys{"schema_version","action"};
    if(action=="set_tempo")keys.add("bpm");
    else if(action=="regenerate_track")keys.addArray({"track_id","first_bar","end_bar","seed"});
    else if(action=="transpose")keys.addArray({"track_id","semitones"});
    else if(action=="set_velocity")keys.addArray({"track_id","velocity"});
    else return fail("Unsupported action");
    for(const auto&property:command.getDynamicObject()->getProperties())if(!keys.contains(property.name.toString()))return fail("Unknown action field");
    auto integer=[](const juce::var&v){return v.isInt()||v.isInt64();};Project p=current;juce::String summary;
    if(action=="set_tempo"){
        if(!(integer(command["bpm"])||command["bpm"].isDouble()))return fail("Invalid BPM type");p.settings.bpm=double(command["bpm"]);summary="Tempo: "+juce::String(current.settings.bpm)+" -> "+juce::String(p.settings.bpm);
    }else{
        if(!command["track_id"].isString())return fail("Missing target track");auto id=command["track_id"].toString();auto track=std::find_if(p.tracks.begin(),p.tracks.end(),[&](const Track&t){return t.id==id;});if(track==p.tracks.end())return fail("Track not found");if(track->midiLocked)return fail("Track MIDI is locked");summary=action+": "+track->role;
        if(action=="regenerate_track"){
            for(auto key:{"first_bar","end_bar","seed"})if(!integer(command[key]))return fail("Invalid regeneration field");
            auto first=juce::int64(command["first_bar"]),end=juce::int64(command["end_bar"]),seed=juce::int64(command["seed"]);
            if(first<1||end<first||end>p.settings.bars||seed<0||seed>4294967295LL)return fail("Invalid bar range or seed");auto r=regenerate(p,id,int(first-1),int(end),uint32_t(seed));if(r.failed())return r;summary+=" / bars "+juce::String(first)+"-"+juce::String(end)+" / seed "+juce::String(seed);
        }else if(action=="transpose"){
            if(!integer(command["semitones"])||juce::int64(command["semitones"]) < -48||juce::int64(command["semitones"])>48)return fail("Transpose must be -48..48 semitones");for(auto&note:track->notes)note.pitch+=int(command["semitones"]);summary+=" / "+command["semitones"].toString()+" semitones";
        }else{
            if(!integer(command["velocity"])||juce::int64(command["velocity"])<1||juce::int64(command["velocity"])>127)return fail("Velocity must be 1..127");for(auto&note:track->notes)note.velocity=int(command["velocity"]);summary+=" / velocity "+command["velocity"].toString();
        }
    }
    valid=validate(p);if(valid.failed())return valid;ActionPreview next;next.project=std::move(p);next.baseline=juce::JSON::toString(encode(current),true);next.summary=summary;next.command=command.clone();out=std::move(next);return juce::Result::ok();
}
inline juce::Result applyAction(History&history,const ActionPreview&preview){
    if(juce::JSON::toString(encode(history.project()),true)!=preview.baseline)return juce::Result::fail("Project changed. Preview the command again.");
    // Revalidate the command and authority; apply the exact previewed notes.
    ActionPreview checked;auto r=previewAction(history.project(),preview.command,checked);if(r.failed())return r;
    auto expected=encode(checked.project),actual=encode(preview.project);
    if(juce::JSON::toString(expected,true)!=juce::JSON::toString(actual,true))return juce::Result::fail("Preview no longer matches the validated action");
    return history.apply(preview.project);
}
inline juce::Result parseLocalCommand(const Project&p,const juce::String&text,juce::var&out){
    if(text.length()>512)return juce::Result::fail("Command too long");std::smatch match;auto input=text.trim().toStdString();auto*obj=new juce::DynamicObject;juce::var result(obj);obj->setProperty("schema_version",1);
    auto target=[&](const std::string&name){juce::String wanted=juce::String::fromUTF8(name.c_str()).trim();for(auto&t:p.tracks)if(t.role.equalsIgnoreCase(wanted)||t.id.equalsIgnoreCase(wanted))return t.id;return juce::String();};
    if(std::regex_match(input,match,std::regex(R"(tempo ([0-9]+(?:\.[0-9]+)?))",std::regex::icase))){obj->setProperty("action","set_tempo");obj->setProperty("bpm",juce::String(match[1].str()).getDoubleValue());}
    else if(std::regex_match(input,match,std::regex(R"(regenerate (.+) bars ([0-9]+)-([0-9]+) seed ([0-9]+))",std::regex::icase))){obj->setProperty("action","regenerate_track");obj->setProperty("track_id",target(match[1].str()));obj->setProperty("first_bar",juce::String(match[2].str()).getLargeIntValue());obj->setProperty("end_bar",juce::String(match[3].str()).getLargeIntValue());obj->setProperty("seed",juce::String(match[4].str()).getLargeIntValue());}
    else if(std::regex_match(input,match,std::regex(R"((transpose|velocity) (.+) (-?[0-9]+))",std::regex::icase))){bool transpose=juce::String(match[1].str()).equalsIgnoreCase("transpose");obj->setProperty("action",transpose?"transpose":"set_velocity");obj->setProperty("track_id",target(match[2].str()));obj->setProperty(transpose?"semitones":"velocity",juce::String(match[3].str()).getLargeIntValue());}
    else return juce::Result::fail("Supported: tempo 130; regenerate Kick bars 1-4 seed 42; transpose Bass -12; velocity Snare 90");
    ActionPreview preview;auto r=previewAction(p,result,preview);if(r.wasOk())out=result;return r;
}
}
