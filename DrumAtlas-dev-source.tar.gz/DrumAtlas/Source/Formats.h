#pragma once
#include <juce_audio_formats/juce_audio_formats.h>
namespace atlas {
inline std::string catalogPathKey(const juce::String&path){
#if JUCE_WINDOWS
 return path.toLowerCase().toStdString();
#else
 return path.toStdString();
#endif
}
// Use extended Win32 paths only at the I/O boundary. Keep catalog paths unchanged.
inline juce::File ioFile(const juce::File&file){
 #if JUCE_WINDOWS
 auto path=file.getFullPathName();
 if(path.length()>=240&&!path.startsWith("\\\\?\\"))
   return juce::File(path.startsWith("\\\\")?"\\\\?\\UNC\\"+path.substring(2):"\\\\?\\"+path);
 #endif
 return file;
}
inline juce::File catalogFile(const juce::File&file){
 auto path=file.getFullPathName();
 if(path.startsWith("\\\\?\\UNC\\"))return juce::File("\\\\"+path.substring(8));
 if(path.startsWith("\\\\?\\"))return juce::File(path.substring(4));
 return file;
}
void registerFormats(juce::AudioFormatManager&); juce::String decoderError();
}
