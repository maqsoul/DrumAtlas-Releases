#define NOMINMAX
#include "License.h"
#include "LicensePublicKey.h"
#include "LicenseSerialPublicKey.h"
#include "Platform.h"
#if JUCE_WINDOWS
#include <windows.h>
#include <bcrypt.h>
#endif
namespace atlas {
juce::String machineCode(){static const auto code=[] {
#if JUCE_WINDOWS
 wchar_t guid[512]{};DWORD bytes=sizeof(guid);if(RegGetValueW(HKEY_LOCAL_MACHINE,L"SOFTWARE\\Microsoft\\Cryptography",L"MachineGuid",RRF_RT_REG_SZ|RRF_SUBKEY_WOW6464KEY,nullptr,guid,&bytes)!=ERROR_SUCCESS)return juce::String();
 wchar_t windows[MAX_PATH]{};GetWindowsDirectoryW(windows,MAX_PATH);juce::String root=juce::String(windows).substring(0,3);DWORD volume=0;if(!GetVolumeInformationW(root.toWideCharPointer(),nullptr,0,&volume,nullptr,nullptr,nullptr,0))return juce::String();
 const auto identity="DrumAtlas-PC-v1|"+juce::String(guid)+"|"+juce::String::toHexString(int(volume));return "DA-PC-"+juce::SHA256(identity.toRawUTF8(),identity.getNumBytesAsUTF8()).toHexString();
#elif JUCE_MAC
 return macMachineCode();
#else
 return juce::String();
#endif
 }();return code;}
static bool decode64(juce::String text,juce::MemoryBlock&bytes){text=text.replaceCharacter('-','+').replaceCharacter('_','/');while(text.length()%4)text+="=";juce::MemoryOutputStream out(bytes,false);return juce::Base64::convertFromBase64(out,text);}
static bool verify(const unsigned char*publicKey,size_t size,const juce::MemoryBlock&payload,const juce::MemoryBlock&signature){
 if(signature.getSize()!=64)return false;auto digest=juce::SHA256(payload).getRawData();
#if JUCE_WINDOWS
 BCRYPT_ALG_HANDLE alg=nullptr;BCRYPT_KEY_HANDLE key=nullptr;if(BCryptOpenAlgorithmProvider(&alg,BCRYPT_ECDSA_P256_ALGORITHM,nullptr,0)<0)return false;
 bool valid=BCryptImportKeyPair(alg,nullptr,BCRYPT_ECCPUBLIC_BLOB,&key,const_cast<PUCHAR>(publicKey),ULONG(size),0)>=0&&BCryptVerifySignature(key,nullptr,static_cast<PUCHAR>(digest.getData()),ULONG(digest.getSize()),const_cast<PUCHAR>(static_cast<const unsigned char*>(signature.getData())),ULONG(signature.getSize()),0)>=0;
 if(key)BCryptDestroyKey(key);BCryptCloseAlgorithmProvider(alg,0);return valid;
#elif JUCE_MAC
 return macVerifySignature(publicKey,size,digest,signature);
#else
 return false;
#endif
}
bool verifyServerMessage(const juce::String&encoded,const juce::String&sig,juce::String&text){
 juce::MemoryBlock payload,signature;if(encoded.length()>131072||!decode64(encoded,payload)||!decode64(sig,signature)||!verify(serialPublicKey,sizeof(serialPublicKey),payload,signature))return false;
 text=juce::String::fromUTF8(static_cast<const char*>(payload.getData()),int(payload.getSize()));return true;
}
bool verifyLicense(const juce::String&code,const juce::String&machine){
 if(code.length()>4096||machine.isEmpty())return false;auto parts=juce::StringArray::fromTokens(code.trim(),".",{});if(parts.size()!=3||(parts[0]!="DA1"&&parts[0]!="DA2"))return false;
 juce::MemoryBlock payload,signature;if(!decode64(parts[1],payload)||!decode64(parts[2],signature))return false;
 auto text=juce::String::fromUTF8(static_cast<const char*>(payload.getData()),int(payload.getSize()));auto fields=juce::StringArray::fromTokens(text,"|",{});bool serial=parts[0]=="DA2";
 if(fields.size()!=4||fields[0]!="DrumAtlas"||fields[1]!=(serial?"2":"1")||fields[2]!=machine||fields[3].isEmpty())return false;
 return verify(serial?serialPublicKey:licensePublicKey,serial?sizeof(serialPublicKey):sizeof(licensePublicKey),payload,signature);
}
juce::File licenseFile(){auto override=juce::SystemStats::getEnvironmentVariable("DRUMATLAS_CACHE_DIR",{});return (override.isNotEmpty()?juce::File(override):juce::File::getSpecialLocation(juce::File::userApplicationDataDirectory).getChildFile("DrumAtlas")).getChildFile("license.key");}
bool licensed(){return verifyLicense(licenseFile().loadFileAsString(),machineCode());}
juce::Result activateLicense(const juce::String&input){
 auto code=input.trim();if(!code.startsWith("DA1.")&&!code.startsWith("DA2.")){
  const juce::String endpoint=DRUMATLAS_ACTIVATION_URL;
  if(!endpoint.startsWith("https://"))return juce::Result::fail("Activation server is not configured in this build");
  auto serial=code.toUpperCase().removeCharacters(" \r\n\t");if(serial.length()!=42||!serial.startsWith("DA-"))return juce::Result::fail("Enter a valid serial number");
  if(machineCode().isEmpty())return juce::Result::fail("Cannot identify this computer");
  auto*obj=new juce::DynamicObject;obj->setProperty("serial",serial);obj->setProperty("machine",machineCode());
  juce::WebInputStream stream(juce::URL(endpoint).withPOSTData(juce::JSON::toString(juce::var(obj))),false);
  stream.withExtraHeaders("Content-Type: application/json\r\n").withConnectionTimeout(15000).withNumRedirectsToFollow(0);
  if(!stream.connect(nullptr))return juce::Result::fail("Cannot reach activation server. Check your connection and try again.");
  if(stream.getStatusCode()==409)return juce::Result::fail("This serial number is already activated on another computer");
  if(stream.getStatusCode()!=200)return juce::Result::fail("Activation failed. Check your serial number or try later.");
  juce::MemoryOutputStream response;response.writeFromInputStream(stream,8193);if(response.getDataSize()>8192||stream.isError())return juce::Result::fail("Invalid activation response");
  code=juce::JSON::parse(response.toString()).getProperty("license",{}).toString();
 }
 if(!verifyLicense(code,machineCode()))return juce::Result::fail("Invalid license or different computer");auto file=licenseFile();if(file.getParentDirectory().createDirectory().failed()||!file.replaceWithText(code.trim()))return juce::Result::fail("Cannot save license");return juce::Result::ok();
}
}
