#pragma once
#include <juce_cryptography/juce_cryptography.h>
namespace atlas {
juce::String machineCode();
bool verifyLicense(const juce::String&code,const juce::String&machine);
juce::File licenseFile();
bool licensed();
bool verifyServerMessage(const juce::String&payload,const juce::String&signature,juce::String&decoded);
juce::Result activateLicense(const juce::String&code);
}
