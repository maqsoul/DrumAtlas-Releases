#include "ArtistKnowledge.h"
#include <algorithm>
#include <cmath>
namespace atlas::knowledge {
namespace {
juce::var array(const juce::StringArray&a){juce::Array<juce::var>v;for(auto&s:a)v.add(s);return v;}
juce::StringArray strings(const juce::var&v){juce::StringArray out;if(auto*a=v.getArray())for(auto&s:*a)out.add(s.toString());return out;}
juce::Result fail(const char*m){return juce::Result::fail(m);}
}
juce::Result Registry::addSource(Source s){
    if(s.id.isEmpty()||s.contentHash.length()!=64||s.contentHash.containsOnly("0123456789abcdefABCDEF")==false||s.rightsHolder.isEmpty()||s.licenceDocument.isEmpty()||s.territories.isEmpty()||s.expiresAtMs<0)return fail("Incomplete source provenance");
    if(std::any_of(sources.begin(),sources.end(),[&](const Source&v){return v.id==s.id;}))return fail("Source ID already registered");
    for(auto p:s.permissions)if(int(p)<0||int(p)>4)return fail("Invalid source permission");
    sources.push_back(std::move(s));return juce::Result::ok();
}
juce::Result Registry::addArtist(Artist a){
    if(a.id.isEmpty()||a.name.isEmpty()||std::any_of(artists.begin(),artists.end(),[&](const Artist&x){return x.id==a.id;}))return fail("Invalid artist identity");
    for(auto&f:a.features){if(f.name.isEmpty()||f.value.isEmpty()||f.extractionMethod.isEmpty()||f.sourceIds.isEmpty()||f.reviewedAtMs<=0||!std::isfinite(f.confidence)||f.confidence<0||f.confidence>1)return fail("Feature lacks provenance");for(auto&id:f.sourceIds)if(std::none_of(sources.begin(),sources.end(),[&](const Source&s){return s.id==id;}))return fail("Unknown feature source");}
    artists.push_back(std::move(a));return juce::Result::ok();
}
const Artist* Registry::find(const juce::String&query)const{
    const auto q=query.trim();if(q.isEmpty())return nullptr;const Artist*result=nullptr;
    for(auto&a:artists)if(a.name.equalsIgnoreCase(q)||a.aliases.contains(q,true)){if(result)return nullptr;result=&a;}return result;
}
bool Registry::permitted(const juce::String&id,Use use,const juce::String&territory,int64_t now)const{
    for(auto&s:sources)if(s.id==id)return s.reviewed&&!s.revoked&&now>0&&(s.expiresAtMs==0||s.expiresAtMs>now)&&(s.territories.contains("*")||s.territories.contains(territory,true))&&std::find(s.permissions.begin(),s.permissions.end(),use)!=s.permissions.end();return false;
}
juce::Result Registry::registerTraining(const juce::String&version,const juce::StringArray&ids,const juce::String&territory,int64_t now){
    if(version.isEmpty()||ids.isEmpty()||std::any_of(models.begin(),models.end(),[&](const ModelUse&m){return m.version==version;}))return fail("Invalid dataset/model version");
    for(auto&id:ids)if(!permitted(id,Use::Train,territory,now))return fail("Training not permitted for a source");models.push_back({version,ids});return juce::Result::ok();
}
juce::StringArray Registry::revoke(const juce::String&id){juce::StringArray affected;for(auto&s:sources)if(s.id==id)s.revoked=true;for(auto&m:models)if(m.sourceIds.contains(id))affected.addIfNotAlreadyThere(m.version);return affected;}
juce::var Registry::encode()const{
    auto*root=new juce::DynamicObject();root->setProperty("schema_version",1);juce::Array<juce::var>ss,aa,mm;
    for(auto&s:sources){auto*v=new juce::DynamicObject();v->setProperty("id",s.id);v->setProperty("hash",s.contentHash);v->setProperty("rights_holder",s.rightsHolder);v->setProperty("licence_document",s.licenceDocument);v->setProperty("territories",array(s.territories));v->setProperty("expires",juce::int64(s.expiresAtMs));v->setProperty("reviewed",s.reviewed);v->setProperty("revoked",s.revoked);juce::Array<juce::var>uses;for(auto use:s.permissions)uses.add(int(use));v->setProperty("uses",uses);ss.add(v);}
    for(auto&a:artists){auto*v=new juce::DynamicObject();v->setProperty("id",a.id);v->setProperty("name",a.name);v->setProperty("era",a.era);v->setProperty("aliases",array(a.aliases));juce::Array<juce::var>ff;for(auto&f:a.features){auto*x=new juce::DynamicObject();x->setProperty("name",f.name);x->setProperty("value",f.value);x->setProperty("method",f.extractionMethod);x->setProperty("sources",array(f.sourceIds));x->setProperty("confidence",f.confidence);x->setProperty("reviewed_at",juce::int64(f.reviewedAtMs));ff.add(x);}v->setProperty("features",ff);aa.add(v);}
    for(auto&m:models){auto*v=new juce::DynamicObject();v->setProperty("version",m.version);v->setProperty("sources",array(m.sourceIds));mm.add(v);}root->setProperty("sources",ss);root->setProperty("artists",aa);root->setProperty("models",mm);return root;
}
juce::Result Registry::decode(const juce::var&root){
    if(int(root["schema_version"])!=1||!root["sources"].isArray()||!root["artists"].isArray()||!root["models"].isArray())return fail("Unsupported knowledge schema");Registry next;
    if(root["sources"].size()>100000||root["artists"].size()>100000||root["models"].size()>100000)return fail("Registry too large");
    for(auto&v:*root["sources"].getArray()){
        if(!v["uses"].isArray()||!v["reviewed"].isBool()||!v["revoked"].isBool())return fail("Invalid source fields");Source s;s.id=v["id"].toString();s.contentHash=v["hash"].toString();s.rightsHolder=v["rights_holder"].toString();s.licenceDocument=v["licence_document"].toString();s.territories=strings(v["territories"]);s.expiresAtMs=juce::int64(v["expires"]);s.reviewed=bool(v["reviewed"]);s.revoked=bool(v["revoked"]);for(auto&u:*v["uses"].getArray()){if(!u.isInt()||int(u)<0||int(u)>4)return fail("Invalid use");s.permissions.push_back(Use(int(u)));}auto r=next.addSource(std::move(s));if(r.failed())return r;
    }
    for(auto&v:*root["artists"].getArray()){
        if(!v["features"].isArray())return fail("Invalid features");Artist a;a.id=v["id"].toString();a.name=v["name"].toString();a.era=v["era"].toString();a.aliases=strings(v["aliases"]);for(auto&f:*v["features"].getArray())a.features.push_back({f["name"].toString(),f["value"].toString(),f["method"].toString(),strings(f["sources"]),double(f["confidence"]),juce::int64(f["reviewed_at"])});auto r=next.addArtist(std::move(a));if(r.failed())return r;
    }
    for(auto&v:*root["models"].getArray()){
        ModelUse m{v["version"].toString(),strings(v["sources"])};if(m.version.isEmpty()||m.sourceIds.isEmpty())return fail("Invalid model provenance");for(auto&id:m.sourceIds)if(std::none_of(next.sources.begin(),next.sources.end(),[&](const Source&s){return s.id==id;}))return fail("Unknown model source");next.models.push_back(m);
    }*this=std::move(next);return juce::Result::ok();
}
}
