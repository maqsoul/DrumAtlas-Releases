#include "Platform.h"
#include <juce_cryptography/juce_cryptography.h>
#include <Security/Security.h>
#include <IOKit/IOKitLib.h>
namespace atlas {
template<class T>struct CFValue {T value=nullptr;explicit CFValue(T v=nullptr):value(v){}~CFValue(){if(value)CFRelease(value);}operator T()const{return value;}CFValue(const CFValue&)=delete;};
juce::String macMachineCode(){
 auto entry=IOServiceGetMatchingService(kIOMainPortDefault,IOServiceMatching("IOPlatformExpertDevice"));if(!entry)return {};
 CFValue<CFTypeRef> value(IORegistryEntryCreateCFProperty(entry,CFSTR("IOPlatformUUID"),kCFAllocatorDefault,0));IOObjectRelease(entry);
 if(!value.value||CFGetTypeID(value.value)!=CFStringGetTypeID())return {};char uuid[256]{};if(!CFStringGetCString(static_cast<CFStringRef>(value.value),uuid,sizeof(uuid),kCFStringEncodingUTF8))return {};
 auto identity=juce::String("DrumAtlas-PC-v1|macOS|")+juce::String::fromUTF8(uuid);return "DA-PC-"+juce::SHA256(identity.toRawUTF8(),identity.getNumBytesAsUTF8()).toHexString();
}
bool macVerifySignature(const unsigned char*blob,size_t size,const juce::MemoryBlock&digest,const juce::MemoryBlock&signature){
 if(size!=72||signature.getSize()!=64)return false;unsigned char point[65]{4};std::copy(blob+8,blob+72,point+1);
 CFValue<CFDataRef> data(CFDataCreate(nullptr,point,65));const void*keys[]={kSecAttrKeyType,kSecAttrKeyClass};const void*values[]={kSecAttrKeyTypeECSECPrimeRandom,kSecAttrKeyClassPublic};
 CFValue<CFDictionaryRef> attributes(CFDictionaryCreate(nullptr,keys,values,2,&kCFTypeDictionaryKeyCallBacks,&kCFTypeDictionaryValueCallBacks));CFValue<SecKeyRef>key(SecKeyCreateWithData(data,attributes,nullptr));if(!key.value)return false;
 // CNG/IEEE-P1363 uses fixed-width r||s. Security.framework expects DER integers.
 juce::MemoryOutputStream integers;auto*sig=static_cast<const unsigned char*>(signature.getData());
 for(int part=0;part<2;++part){auto*p=sig+32*part;int length=32;while(length>1&&*p==0){++p;--length;}const bool pad=(*p&128)!=0;integers.writeByte(2);integers.writeByte(char(length+(pad?1:0)));if(pad)integers.writeByte(0);integers.write(p,size_t(length));}
 juce::MemoryOutputStream der;der.writeByte(0x30);der.writeByte(char(integers.getDataSize()));der.write(integers.getData(),integers.getDataSize());
 CFValue<CFDataRef>hash(CFDataCreate(nullptr,static_cast<const UInt8*>(digest.getData()),CFIndex(digest.getSize()))),encoded(CFDataCreate(nullptr,static_cast<const UInt8*>(der.getData()),CFIndex(der.getDataSize())));
 return SecKeyVerifySignature(key,kSecKeyAlgorithmECDSASignatureDigestX962SHA256,hash,encoded,nullptr);
}
}
