#pragma once
#include "MusicActions.h"
#include <juce_gui_basics/juce_gui_basics.h>
namespace atlas {
class CommandPanel:public juce::Component {
public:
    std::function<music::Project()> read;
    std::function<juce::Result(const music::ActionPreview&)> apply;
    std::function<void()> close;
    CommandPanel(){
        input.setComponentID("command-input");previewButton.setComponentID("command-preview");applyButton.setComponentID("command-apply");
        setOpaque(true);for(auto*c:std::initializer_list<juce::Component*>{&input,&previewButton,&applyButton,&back,&result})addAndMakeVisible(c);
        input.setTextToShowWhenEmpty("tempo 130",juce::Colour(0xff92a7be));previewButton.setButtonText("Preview change");applyButton.setButtonText("Apply change");back.setButtonText("Back to Quick Beat");applyButton.setEnabled(false);result.setMultiLine(true);result.setReadOnly(true);
        input.onTextChange=[this]{applyButton.setEnabled(false);};back.onClick=[this]{if(close)close();};
        previewButton.onClick=[this]{if(!read)return;auto p=read();juce::var command;auto r=music::parseLocalCommand(p,input.getText(),command);if(r.wasOk())r=music::previewAction(p,command,proposal);applyButton.setEnabled(r.wasOk());result.setText(r.failed()?r.getErrorMessage():proposal.summary+"\n\nNo changes applied yet. Apply to confirm; Undo restores the previous project.");};
        applyButton.onClick=[this]{if(!apply)return;auto r=apply(proposal);result.setText(r.failed()?r.getErrorMessage():"Applied: "+proposal.summary);applyButton.setEnabled(false);};
    }
    void resized()override{back.setBounds(getWidth()-220,20,196,32);input.setBounds(24,175,getWidth()-48,36);previewButton.setBounds(24,225,150,32);applyButton.setBounds(190,225,150,32);result.setBounds(24,277,getWidth()-48,getHeight()-301);}
    void paint(juce::Graphics&g)override{g.fillAll(juce::Colour(0xff090f18));g.setColour(juce::Colour(0xff57eed1));g.setFont(juce::FontOptions(24));g.drawText("COMMANDS / OFFLINE",24,20,450,32,juce::Justification::centredLeft);g.setColour(juce::Colour(0xff92a7be));g.setFont(juce::FontOptions(14));g.drawMultiLineText("Local commands, no cloud or trained language model.\nExamples: tempo 130 | transpose Bass -12 | velocity Snare 90\nregenerate Closed Hat bars 1-4 seed 42\nTrack locks are respected. Preview a change before applying it.",24,78,getWidth()-48,1.4f);}
private:
    juce::TextEditor input,result;juce::TextButton previewButton,applyButton,back;music::ActionPreview proposal;
};
}
