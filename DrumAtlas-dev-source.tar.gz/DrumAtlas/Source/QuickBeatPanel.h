#pragma once
#include "MusicCore.h"
#include "PianoRoll.h"
#include "CommandPanel.h"
#include <juce_gui_basics/juce_gui_basics.h>
namespace atlas {
class QuickBeatPanel:public juce::Component {
public:
    std::function<music::Project()> readProject;
    std::function<juce::Result(music::Project)> writeProject;
    std::function<juce::Result(const music::ActionPreview&)> applyCommand;
    std::function<void()> onClose,onUndo,onRedo,onPreview,onStop;
    std::function<juce::String()> selectedSample;
    QuickBeatPanel(){
        setOpaque(true);
        commands.setComponentID("beat-commands");commandPanel.setComponentID("command-panel");
        addChildComponent(commandPanel);addAndMakeVisible(commands);commands.setButtonText("Commands / offline");commands.onClick=[this]{commandPanel.setVisible(true);commandPanel.toFront(false);};commandPanel.read=[this]{return readProject();};commandPanel.apply=[this](const music::ActionPreview&action){return applyCommand?applyCommand(action):juce::Result::fail("Command service unavailable");};commandPanel.close=[this]{commandPanel.setVisible(false);refresh();};
        roll.read=[this]{return readProject();};roll.write=[this](music::Project p){return writeProject(p);};roll.trackIndex=[this]{return tracks.getSelectedId()-1;};roll.barIndex=[this]{return page.getSelectedId()-1;};roll.report=[this](juce::Result r){report(r);};
        for(int i=0;i<12;++i)tonic.addItem(juce::MidiMessage::getMidiNoteName(60+i,true,false,3),i+1);tonic.setSelectedId(10);scale.addItem("minor",1);scale.addItem("major",2);scale.setSelectedId(1);
        soundLock.setButtonText("Lock sound");soundLock.onClick=[this]{auto p=readProject();int i=tracks.getSelectedId()-1;if(i>=0&&i<int(p.tracks.size())){p.tracks[size_t(i)].soundLocked=soundLock.getToggleState();report(writeProject(p));}};
        varyBar.setButtonText("Vary bar");varyBar.onClick=[this]{auto p=readProject();int i=tracks.getSelectedId()-1;if(i<0||i>=int(p.tracks.size()))return;auto r=music::regenerate(p,p.tracks[size_t(i)].id,page.getSelectedId()-1,page.getSelectedId(),uint32_t(seed.getText().getLargeIntValue()));if(r.wasOk())r=writeProject(p);report(r);roll.repaint();};
        copyBar.setButtonText("Copy to next bar");copyBar.onClick=[this]{auto p=readProject();int i=tracks.getSelectedId()-1;if(i<0||i>=int(p.tracks.size()))return;auto r=music::copyBars(p,p.tracks[size_t(i)].id,page.getSelectedId()-1,page.getSelectedId(),page.getSelectedId());if(r.wasOk())r=writeProject(p);report(r);roll.repaint();};
        genre.setComponentID("beat-genre");mood.setComponentID("beat-mood");generate.setComponentID("beat-generate");
        fillProfiles();importProfiles.setButtonText("Import profiles");importProfiles.onClick=[this]{choose(3);};
        for(auto*slider:{&energy,&darkness,&complexity,&groove,&humanize,&melodicDensity}){slider->setRange(0,1,.01);slider->setValue(.5);slider->setTextBoxStyle(juce::Slider::TextBoxRight,false,38,24);}
        for(auto*c:std::initializer_list<juce::Component*>{&close,&generate,&variation,&undo,&redo,&exportMidi,&save,&load,&assign,&lock,&tracks,&bars,&page,&bpm,&seed,&density,&message,&preview,&stop,&genre,&mood,&importProfiles,&energy,&darkness,&complexity,&groove,&humanize,&melodicDensity,&roll,&tonic,&scale,&soundLock,&varyBar,&copyBar})addAndMakeVisible(c);
        preview.setButtonText("Preview beat");stop.setButtonText("Stop");preview.onClick=[this]{if(onPreview)onPreview();};stop.onClick=[this]{if(onStop)onStop();};
        close.setButtonText("Library / Reference");generate.setButtonText("Generate");variation.setButtonText("Vary track");undo.setButtonText("Undo");redo.setButtonText("Redo");exportMidi.setButtonText("Export MIDI");save.setButtonText("Save project");load.setButtonText("Open project");assign.setButtonText("Use selected sample");lock.setButtonText("Lock MIDI");
        for(int n:{1,2,4,8,16,32,64})bars.addItem(juce::String(n)+" bars",n);bars.setSelectedId(4);
        bpm.setText("140");seed.setText("45192");density.setRange(0,1,.01);density.setValue(.5);density.setTextBoxStyle(juce::Slider::TextBoxRight,false,50,24);
        message.setColour(juce::Label::textColourId,juce::Colour(0xff91a8bf));message.setText("Original rule-based profiles. Click the grid to edit notes. New controls use English fallback.",juce::dontSendNotification);
        close.onClick=[this]{if(onClose)onClose();};
        generate.onClick=[this]{if(!readProject||!writeProject)return;auto old=readProject();auto s=old.settings;s.bpm=bpm.getText().getDoubleValue();s.bars=bars.getSelectedId();s.seed=uint32_t(seed.getText().getLargeIntValue());s.density=density.getValue();s.tonic=tonic.getSelectedId()-1;s.scale=scale.getText();s.genre=genre.getText();s.mood=mood.getText();s.energy=energy.getValue();s.darkness=darkness.getValue();s.complexity=complexity.getValue();s.groove=groove.getValue();s.humanize=humanize.getValue();s.melodicDensity=melodicDensity.getValue();auto valid=music::validate(s);if(valid.failed()){report(valid);return;}music::Project p;auto result=music::generateStyled(s,registry,{{s.genre,1}},{{s.mood,1}},p);if(result.failed()){report(result);return;}p.id=old.id;
            for(auto&t:p.tracks)for(auto&o:old.tracks)if(t.id==o.id){if(o.midiLocked)t=o;else {t.soundPath=o.soundPath;t.soundLocked=o.soundLocked;}}
            report(writeProject(p));refresh();};
        variation.onClick=[this]{auto p=readProject();int i=tracks.getSelectedId()-1;if(i<0||i>=int(p.tracks.size()))return;auto r=music::regenerate(p,p.tracks[size_t(i)].id,0,p.settings.bars,uint32_t(seed.getText().getLargeIntValue()));if(r.wasOk())r=writeProject(p);report(r);refresh();};
        undo.onClick=[this]{if(onUndo)onUndo();refresh();};redo.onClick=[this]{if(onRedo)onRedo();refresh();};
        tracks.onChange=[this]{refreshLock();roll.repaint();};page.onChange=[this]{roll.repaint();};
        lock.onClick=[this]{auto p=readProject();int i=tracks.getSelectedId()-1;if(i>=0&&i<int(p.tracks.size())){p.tracks[size_t(i)].midiLocked=lock.getToggleState();report(writeProject(p));}};
        assign.onClick=[this]{if(!selectedSample)return;auto path=selectedSample();auto p=readProject();int i=tracks.getSelectedId()-1;if(i<0||i>=int(p.tracks.size())||path.isEmpty())return;auto&t=p.tracks[size_t(i)];if(t.soundLocked){report(juce::Result::fail("Track sound is locked"));return;}t.soundPath=path;report(writeProject(p));repaint();};
        exportMidi.onClick=[this]{choose(0);};save.onClick=[this]{choose(1);};load.onClick=[this]{choose(2);};
    }
    void refresh(){if(!readProject)return;auto p=readProject();bpm.setText(juce::String(p.settings.bpm),false);seed.setText(juce::String(juce::int64(p.settings.seed)),false);density.setValue(p.settings.density,juce::dontSendNotification);bars.setSelectedId(p.settings.bars,juce::dontSendNotification);
        if(p.styleSnapshot.isObject()){auto result=registry.decode(p.styleSnapshot["registry"]);if(result.wasOk())fillProfiles();}
        genre.setText(p.settings.genre,juce::dontSendNotification);mood.setText(p.settings.mood,juce::dontSendNotification);energy.setValue(p.settings.energy,juce::dontSendNotification);darkness.setValue(p.settings.darkness,juce::dontSendNotification);complexity.setValue(p.settings.complexity,juce::dontSendNotification);groove.setValue(p.settings.groove,juce::dontSendNotification);humanize.setValue(p.settings.humanize,juce::dontSendNotification);melodicDensity.setValue(p.settings.melodicDensity,juce::dontSendNotification);
        tonic.setSelectedId(p.settings.tonic+1,juce::dontSendNotification);scale.setSelectedId(p.settings.scale=="major"?2:1,juce::dontSendNotification);
        auto selected=tracks.getSelectedId();tracks.clear(juce::dontSendNotification);for(size_t i=0;i<p.tracks.size();++i)tracks.addItem(p.tracks[i].role,int(i)+1);tracks.setSelectedId(juce::jlimit(1,int(p.tracks.size()),std::max(1,selected)),juce::dontSendNotification);
        int bar=page.getSelectedId();page.clear(juce::dontSendNotification);for(int i=1;i<=p.settings.bars;++i)page.addItem("Bar "+juce::String(i),i);page.setSelectedId(juce::jlimit(1,p.settings.bars,std::max(1,bar)),juce::dontSendNotification);refreshLock();roll.repaint();repaint();
    }
    void resized()override{
        commandPanel.setBounds(getLocalBounds());commands.setBounds(400,20,180,32);
        auto w=getWidth();close.setBounds(w-220,20,196,32);bpm.setBounds(24,98,100,30);bars.setBounds(138,98,120,30);seed.setBounds(272,98,140,30);density.setBounds(426,98,210,30);generate.setBounds(650,98,130,30);
        tracks.setBounds(24,146,170,32);page.setBounds(208,146,110,32);lock.setBounds(332,146,120,32);variation.setBounds(466,146,130,32);assign.setBounds(610,146,190,32);
        genre.setBounds(24,190,220,30);mood.setBounds(258,190,220,30);importProfiles.setBounds(492,190,160,30);
        int col=0;for(auto*slider:{&energy,&darkness,&complexity,&groove,&humanize,&melodicDensity})slider->setBounds(24+col++*(w-48)/6,247,(w-60)/6,28);
        roll.setBounds(24,286,w-48,std::max(100,getHeight()-398));tonic.setBounds(666,190,100,30);scale.setBounds(780,190,120,30);soundLock.setBounds(814,146,150,30);varyBar.setBounds(794,98,80,30);copyBar.setBounds(600,20,160,32);
        preview.setBounds(632,getHeight()-92,140,30);stop.setBounds(786,getHeight()-92,80,30);
        undo.setBounds(24,getHeight()-92,80,30);redo.setBounds(114,getHeight()-92,80,30);save.setBounds(208,getHeight()-92,130,30);load.setBounds(348,getHeight()-92,130,30);exportMidi.setBounds(488,getHeight()-92,130,30);message.setBounds(24,getHeight()-50,w-48,36);
    }
    void paint(juce::Graphics&g)override{
        g.fillAll(juce::Colour(0xff090f18));g.setColour(juce::Colour(0xff57eed1));g.setFont(juce::FontOptions(24));g.drawText("QUICK BEAT",24,20,300,32,juce::Justification::centredLeft);
        g.setFont(juce::FontOptions(13));g.setColour(juce::Colour(0xff92a7be));g.drawText("Offline profile generator  |  Select notes to edit; drag to move or resize",24,55,650,24,juce::Justification::centredLeft);
        for(auto pair:std::initializer_list<std::pair<const char*,int>>{{"BPM",24},{"Length",138},{"Seed",272},{"Density",426}})g.drawText(pair.first,pair.second,77,120,20,juce::Justification::centredLeft);
        int col=0;for(auto text:{"Energy","Darkness","Complexity","Groove","Humanize","Melodic density"})g.drawText(text,24+col++*(getWidth()-48)/6,224,(getWidth()-48)/6,20,juce::Justification::centredLeft);
    }

private:
    CommandPanel commandPanel;juce::TextButton commands;
    music::ProfileRegistry registry=music::ProfileRegistry::builtIn();
    void fillProfiles(){genre.clear(juce::dontSendNotification);mood.clear(juce::dontSendNotification);int i=1;for(const auto&p:registry.genres())genre.addItem(p.id,i++);i=1;for(const auto&p:registry.moods())mood.addItem(p.id,i++);genre.setText("Trap",juce::dontSendNotification);mood.setText("Dark",juce::dontSendNotification);}
    static std::pair<int,int> pitchRange(const music::Track&t){int low=t.notes.empty()?48:127,high=t.notes.empty()?72:0;for(auto&n:t.notes){low=std::min(low,n.pitch);high=std::max(high,n.pitch);}low=std::max(0,low-6);high=std::min(127,std::max(high+6,low+23));return {low,high};}
    void refreshLock(){if(!readProject)return;auto p=readProject();int i=tracks.getSelectedId()-1;if(i>=0&&i<int(p.tracks.size())){lock.setToggleState(p.tracks[size_t(i)].midiLocked,juce::dontSendNotification);soundLock.setToggleState(p.tracks[size_t(i)].soundLocked,juce::dontSendNotification);}}
    void report(const juce::Result&r){message.setText(r.failed()?r.getErrorMessage():"Ready",juce::dontSendNotification);}
    void choose(int mode){
        chooser=std::make_unique<juce::FileChooser>(mode==3?"Import profile registry":mode==0?"Export MIDI":mode==1?"Save project":"Open project",juce::File(),mode==3?"*.json":mode==0?"*.mid":"*.drumatlas");juce::Component::SafePointer<QuickBeatPanel>safe(this);
        chooser->launchAsync((mode>=2?juce::FileBrowserComponent::openMode:juce::FileBrowserComponent::saveMode|juce::FileBrowserComponent::warnAboutOverwriting)|juce::FileBrowserComponent::canSelectFiles,[safe,mode](const juce::FileChooser&fc){if(!safe||fc.getResult()==juce::File())return;auto file=fc.getResult();if(mode==3){auto r=safe->registry.load(file);if(r.wasOk())safe->fillProfiles();safe->report(r);return;}auto p=safe->readProject();auto r=mode==0?music::exportMidi(p,file):mode==1?music::save(p,file):music::load(file,p);if(mode==2&&r.wasOk())r=safe->writeProject(p);safe->report(r);safe->refresh();});
    }
    PianoRoll roll;juce::ComboBox tonic,scale;juce::ToggleButton soundLock;juce::TextButton varyBar,copyBar;
    juce::TextButton close,generate,variation,undo,redo,exportMidi,save,load,assign,preview,stop,importProfiles;
    juce::ToggleButton lock;juce::ComboBox tracks,bars,page,genre,mood;juce::TextEditor bpm,seed;juce::Slider density,energy,darkness,complexity,groove,humanize,melodicDensity;juce::Label message;juce::Rectangle<int>grid;
    std::unique_ptr<juce::FileChooser>chooser;
};
}
