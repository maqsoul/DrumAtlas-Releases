#pragma once
#include "License.h"
#include "Locale.h"
namespace atlas {
class LicensePanel:public juce::Component{
 juce::Label title,help,error;juce::TextEditor input;juce::TextButton activate;juce::String lang;juce::ThreadPool jobs{1};
public:
 std::function<void()>onActivated;
 explicit LicensePanel(juce::String language):lang(std::move(language)){
  for(auto*c:std::initializer_list<juce::Component*>{&title,&help,&error,&input,&activate})addAndMakeVisible(c);
  title.setText(tr("activation",lang),juce::dontSendNotification);title.setFont(juce::FontOptions(24));
  help.setText(lang=="ru"?"Введите серийный код. При первой активации нужен интернет: код автоматически привязывается к этому компьютеру.":"Enter your serial number. First activation requires internet and automatically binds the serial to this computer.",juce::dontSendNotification);help.setJustificationType(juce::Justification::centredLeft);
  input.setTextToShowWhenEmpty("DA-XXXX-XXXX-XXXX-XXXX-XXXX-XXXX-XXXX-XXXX",juce::Colours::grey);activate.setButtonText(tr("activate",lang));
  for(auto*l:{&title,&help})l->setColour(juce::Label::textColourId,juce::Colour(0xffd5e7ed));error.setColour(juce::Label::textColourId,juce::Colour(0xffff9c95));
  activate.onClick=[this]{activate.setEnabled(false);error.setText(lang=="ru"?"Активация…":"Activating…",juce::dontSendNotification);juce::Component::SafePointer<LicensePanel>safe(this);auto code=input.getText();jobs.addJob([safe,code]{auto result=activateLicense(code);juce::MessageManager::callAsync([safe,result]{if(!safe)return;safe->activate.setEnabled(true);if(result.wasOk()){if(safe->onActivated)safe->onActivated();}else safe->error.setText(result.getErrorMessage(),juce::dontSendNotification);});});};
 }
 ~LicensePanel()override{jobs.removeAllJobs(false,-1);}
 void paint(juce::Graphics&g)override{g.fillAll(juce::Colour(0xff0b1621));}
 void resized()override{int left=std::max(24,(getWidth()-720)/2),width=std::min(720,getWidth()-48),top=std::max(20,(getHeight()-260)/2);title.setBounds(left,top,width,38);help.setBounds(left,top+47,width,72);input.setBounds(left,top+135,width,40);activate.setBounds(left,top+195,190,36);error.setBounds(left+200,top+185,width-200,72);}
};
}
