#include "Analysis.h"
#include <complex>
namespace atlas {
std::vector<float> drumFocus(const std::vector<float>&audio,const juce::String&category){
 auto out=audio;double low=30,high=10000;
 if(category=="Kick"){low=30;high=350;}else if(category=="Closed Hat"||category=="Open Hat"||category=="Cymbal"){low=4000;high=10000;}
 else if(category=="Snare"||category=="Clap"||category=="Rim"){low=180;high=8500;}else if(category=="Tom"){low=70;high=1200;}
 juce::dsp::IIR::Filter<float>hp,lp;hp.coefficients=juce::dsp::IIR::Coefficients<float>::makeHighPass(analysisRate,low);lp.coefficients=juce::dsp::IIR::Coefficients<float>::makeLowPass(analysisRate,high);
 for(auto&v:out)v=lp.processSample(hp.processSample(v));return out;
}
Separated separate(const std::vector<float>& audio){
 // Median-filter HPSS with soft masks (margin 2). This suppresses bleed, not isolated instrument stems.
 constexpr int n=1024,hop=256,bins=n/2+1,radius=8;
 Separated out;out.percussive.resize(audio.size());out.harmonic.resize(audio.size());if(audio.empty())return out;
 int frames=int(audio.size()/hop)+2;juce::dsp::FFT fft(10);using C=std::complex<float>;
 std::vector<C> spectra(size_t(frames)*n),buffer(n),masked(n),inverse(n);std::vector<float>magnitude(size_t(frames)*bins),normal(audio.size(),0);std::array<float,n>window{};
 for(int i=0;i<n;++i)window[i]=.5f-.5f*std::cos(juce::MathConstants<float>::twoPi*i/n);
 for(int frame=0;frame<frames;++frame){for(int i=0;i<n;++i){int pos=frame*hop+i-n/2;buffer[i]=pos>=0&&pos<int(audio.size())?audio[size_t(pos)]*window[i]:0.f;}fft.perform(buffer.data(),spectra.data()+size_t(frame)*n,false);for(int k=0;k<bins;++k)magnitude[size_t(frame)*bins+k]=std::abs(spectra[size_t(frame)*n+k]);}
 std::array<float,2*radius+1>values{};std::array<float,bins>hm{},pm{};float bassGate=0;
 for(int frame=0;frame<frames;++frame){
   // Tonal kick tails can look harmonic. Restore only transient low-frequency energy.
   double bass=0,previous=0;for(int k=1;k<=11;++k){bass+=magnitude[size_t(frame)*bins+k];for(int t=std::max(0,frame-4);t<frame;++t)previous+=magnitude[size_t(t)*bins+k];}previous/=std::max(1,std::min(4,frame));bassGate*=std::exp(-float(hop)/(float(analysisRate)*.12f));if(bass>previous*1.8&&bass>1e-4)bassGate=1.f;
   for(int k=0;k<bins;++k){int count=0;for(int t=std::max(0,frame-radius);t<=std::min(frames-1,frame+radius);++t)values[count++]=magnitude[size_t(t)*bins+k];std::nth_element(values.begin(),values.begin()+count/2,values.begin()+count);float h=values[count/2];count=0;for(int f=std::max(0,k-radius);f<=std::min(bins-1,k+radius);++f)values[count++]=magnitude[size_t(frame)*bins+f];std::nth_element(values.begin(),values.begin()+count/2,values.begin()+count);float p=values[count/2];hm[k]=h*h/(h*h+4*p*p+1e-16f);pm[k]=p*p/(p*p+4*h*h+1e-16f);}
   for(int k=1;k<=11;++k){pm[k]=std::max(pm[k],bassGate);hm[k]*=1.f-bassGate;}
   for(int channel=0;channel<2;++channel){for(int k=0;k<n;++k)masked[k]=spectra[size_t(frame)*n+k]*(channel?hm[std::min(k,n-k)]:pm[std::min(k,n-k)]);fft.perform(masked.data(),inverse.data(),true);auto&dest=channel?out.harmonic:out.percussive;
     for(int i=0;i<n;++i){int pos=frame*hop+i-n/2;if(pos>=0&&pos<int(audio.size())){dest[size_t(pos)]+=inverse[i].real()*window[i];if(!channel)normal[size_t(pos)]+=window[i]*window[i];}}}
 }
 for(size_t i=0;i<audio.size();++i)if(normal[i]>1e-8f){out.percussive[i]/=normal[i];out.harmonic[i]/=normal[i];}return out;
}
}
