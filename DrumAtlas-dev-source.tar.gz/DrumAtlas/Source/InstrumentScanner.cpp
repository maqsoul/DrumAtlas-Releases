#include "InstrumentScanner.h"
namespace atlas::hosting {
ScanResult scan(const juce::File&worker,const juce::File&plugin,const juce::File&scratch,int timeout,bool probe){
    if(!worker.existsAsFile()||!plugin.exists()||timeout<1||timeout>120000)return {"error","Worker/plugin missing or invalid timeout",{}};
    if(scratch.createDirectory().failed())return {"error","Cannot create scanner scratch directory",{}};
    const auto id=juce::Uuid().toString();const auto output=scratch.getChildFile("scan-"+id+".json");juce::ChildProcess child;
    // No shell string: paths containing spaces are separate process arguments.
    if(!child.start(juce::StringArray{worker.getFullPathName(),probe?"--probe":"--scan",plugin.getFullPathName(),output.getFullPathName(),id},0))return {"error","Cannot launch scanner",{}};
    if(!child.waitForProcessToFinish(timeout)){child.kill();child.waitForProcessToFinish(2000);return {"quarantined","Scanner timed out",{}};}
    if(child.getExitCode()!=0)return {"quarantined","Scanner exited abnormally: "+juce::String(child.getExitCode()),{}};
    if(!output.existsAsFile()||output.getSize()>4*1024*1024)return {"error","Invalid scanner response size",{}};
    auto response=juce::JSON::parse(output);output.deleteFile();
    if(int(response["protocol"])!=1||response["request_id"].toString()!=id||response["operation"].toString()!=(probe?"PROBE":"SCAN"))return {"error","Scanner protocol mismatch",{}};
    const auto status=response["status"].toString();if(status!="scanned"&&status!="not_found"&&status!="error"&&status!="probed"&&status!="silent")return {"error","Invalid scanner status",{}};
    return {status,response["error"].toString(),response["plugins"],response};
}
juce::Result testIsolation(const juce::File&worker){
    juce::ChildProcess crash;if(!crash.start(juce::StringArray{worker.getFullPathName(),"--test-crash"},0)||!crash.waitForProcessToFinish(5000)||crash.getExitCode()!=66)return juce::Result::fail("Crash fixture failed");
    juce::ChildProcess hang;if(!hang.start(juce::StringArray{worker.getFullPathName(),"--test-hang"},0))return juce::Result::fail("Hang fixture failed");
    if(hang.waitForProcessToFinish(200))return juce::Result::fail("Hang fixture exited unexpectedly");if(!hang.kill()||!hang.waitForProcessToFinish(3000))return juce::Result::fail("Watchdog could not terminate worker");return juce::Result::ok();
}
}
