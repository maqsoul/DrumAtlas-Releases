#include "LibraryMigration.h"
namespace atlas {
namespace {
juce::String hash(const juce::File&f){juce::FileInputStream in(f);return in.openedOk()?juce::SHA256(in).toHexString():juce::String();}
juce::Result write(const juce::File&f,const juce::var&v){juce::TemporaryFile tmp(f);return tmp.getFile().replaceWithText(juce::JSON::toString(v))&&tmp.overwriteTargetFileWithTemporary()?juce::Result::ok():juce::Result::fail("Cannot commit migration manifest");}
}
juce::Result prepareLibraryMigration(const juce::File&dir,bool verifyHashes){
    juce::InterProcessLock lock("DrumAtlas-migrate-"+juce::String::toHexString(dir.getFullPathName().hashCode64()));
    if(!lock.enter(5000))return juce::Result::fail("Another DrumAtlas instance is migrating the library");
    struct Release{juce::InterProcessLock&l;~Release(){l.exit();}} release{lock};
    const auto backup=dir.getChildFile("migration-v2-backup"),manifest=backup.getChildFile("manifest.json");
    if(manifest.existsAsFile()){
        auto m=juce::JSON::parse(manifest);if(int(m["version"])!=1||!m["files"].isArray())return juce::Result::fail("Invalid migration backup manifest");
        for(auto&entry:*m["files"].getArray()){
            auto path=entry["path"].toString();auto file=backup.getChildFile(path);
            if(juce::File::isAbsolutePath(path)||!file.isAChildOf(backup)||!file.existsAsFile()||entry["sha256"].toString().length()!=64)return juce::Result::fail("Migration backup verification failed");
            if(entry.hasProperty("bytes")&&file.getSize()!=juce::int64(entry["bytes"]))return juce::Result::fail("Migration backup size changed");
            const bool modified=!entry.hasProperty("modified")||file.getLastModificationTime().toMilliseconds()!=juce::int64(entry["modified"]);
            if((verifyHashes||modified)&&hash(file)!=entry["sha256"].toString())return juce::Result::fail("Migration backup checksum mismatch");
        }return juce::Result::ok();
    }
    if(backup.createDirectory().failed())return juce::Result::fail("Cannot create library migration backup");
    juce::Array<juce::var> files,assets;
    for(auto name:{"preferences.json","library-v1.json","library-v2.json","splice/settings.json","splice/downloads.json"}){
        auto source=dir.getChildFile(name);if(!source.existsAsFile())continue;
        // Large catalogues are backed up as bytes, without constructing a second
        // in-memory JSON tree. Only the small settings/download index is decoded.
        juce::var parsed;
        if(!juce::String(name).startsWith("library-")){
            if(source.getSize()>16*1024*1024)return juce::Result::fail("Legacy settings index exceeds migration limit");
            auto parse=juce::JSON::parse(source.loadFileAsString(),parsed);if(parse.failed()||!parsed.isObject())return juce::Result::fail("Invalid legacy library metadata: "+juce::String(name));
        }
        auto dest=backup.getChildFile(name);dest.getParentDirectory().createDirectory();auto before=hash(source);
        if(before.isEmpty()||!source.copyFileTo(dest)||hash(dest)!=before||hash(source)!=before)return juce::Result::fail("Library changed during backup; retry migration");
        auto*entry=new juce::DynamicObject();entry->setProperty("path",name);entry->setProperty("sha256",before);entry->setProperty("bytes",dest.getSize());entry->setProperty("modified",dest.getLastModificationTime().toMilliseconds());files.add(entry);
        if(juce::String(name)=="splice/downloads.json")for(auto&property:parsed.getDynamicObject()->getProperties()){
            const auto path=property.value.toString();const bool absolute=juce::File::isAbsolutePath(path);
            auto*a=new juce::DynamicObject();a->setProperty("source_id",property.name.toString());a->setProperty("path",path);a->setProperty("status",absolute&&juce::File(path).existsAsFile()?"local":"missing");assets.add(a);
        }
    }
    auto*root=new juce::DynamicObject();root->setProperty("version",1);root->setProperty("files",files);root->setProperty("legacy_assets",assets);root->setProperty("created_at",juce::Time::getCurrentTime().toISO8601(true));
    return write(manifest,juce::var(root));
}
std::vector<LegacyAsset> legacyAssets(const juce::File&dir){
    std::vector<LegacyAsset> result;auto manifest=juce::JSON::parse(dir.getChildFile("migration-v2-backup/manifest.json"));auto located=juce::JSON::parse(dir.getChildFile("located-assets.json"));
    if(auto*a=manifest["legacy_assets"].getArray())for(auto&v:*a){LegacyAsset asset;asset.id=v["source_id"].toString();asset.originalPath=v["path"].toString();asset.path=located.getProperty(juce::Identifier(asset.id),asset.originalPath).toString();asset.missing=!juce::File::isAbsolutePath(asset.path)||!juce::File(asset.path).existsAsFile();result.push_back(asset);}return result;
}
juce::Result locateLegacyAsset(const juce::File&dir,const juce::String&id,const juce::File&replacement){
    if(!replacement.existsAsFile())return juce::Result::fail("Replacement file is missing");
    auto assets=legacyAssets(dir);if(std::none_of(assets.begin(),assets.end(),[&](const LegacyAsset&a){return a.id==id;}))return juce::Result::fail("Unknown asset ID");
    auto target=dir.getChildFile("located-assets.json");auto data=juce::JSON::parse(target);
    if(target.existsAsFile()&&!data.isObject())return juce::Result::fail("Invalid located-assets index");if(!data.isObject())data=new juce::DynamicObject();data.getDynamicObject()->setProperty(juce::Identifier(id),replacement.getFullPathName());return write(target,data);
}
}
