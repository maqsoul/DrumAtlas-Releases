#pragma once
#include <juce_core/juce_core.h>
#include <array>
#include <vector>

namespace atlas::music {
struct StyleWeight { juce::String id; double weight=1; };
struct GenreProfile {
    juce::String id, revision;
    double bpmMin=60,bpmMax=180,swing=0,microtiming=0,density=.5;
    std::array<double,16> kick{},snare{},hat{};
    juce::StringArray roles,scalePreferences,arrangement,tags;
};
struct MoodProfile {
    juce::String id,revision;
    double energy=.5,darkness=.5,complexity=.5,groove=.5,melodicDensity=.5,articulation=.5;
    juce::StringArray scalePreferences,timbres;
};
struct StyleBlend {
    GenreProfile genre;
    MoodProfile mood;
    std::vector<StyleWeight> genres,moods;
    juce::StringArray notices;
};
// Parsing and blending are transactional. No network or audio ingestion.
// Numeric distributions are weighted means. Discrete constraints use the
// greatest-weight profile, with lexical ID as a stable tie-breaker.
class ProfileRegistry {
public:
    static ProfileRegistry builtIn();
    juce::Result load(const juce::File&);
    juce::Result decode(const juce::var&);
    juce::var encode()const;
    juce::Result blend(std::vector<StyleWeight> genres,std::vector<StyleWeight> moods,StyleBlend&)const;
    const std::vector<GenreProfile>& genres()const{return genreProfiles;}
    const std::vector<MoodProfile>& moods()const{return moodProfiles;}
    juce::String revision()const{return registryRevision;}
private:
    juce::String registryRevision;
    std::vector<GenreProfile> genreProfiles;
    std::vector<MoodProfile> moodProfiles;
};
}
