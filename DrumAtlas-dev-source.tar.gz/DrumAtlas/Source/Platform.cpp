#include "Platform.h"
#if JUCE_WINDOWS
#define NOMINMAX
#include <windows.h>
#else
#include <dlfcn.h>
#endif
namespace atlas {
static thread_local juce::String libraryError;
juce::File bundledModels(){
 auto override=juce::SystemStats::getEnvironmentVariable("DRUMATLAS_MODEL_DIR",{});if(override.isNotEmpty())return juce::File(override);
#if JUCE_WINDOWS
 HMODULE module{};GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS|GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,reinterpret_cast<LPCWSTR>(&bundledModels),&module);wchar_t path[32768]{};GetModuleFileNameW(module,path,32768);return juce::File(juce::String(path)).getParentDirectory().getChildFile("Models");
#else
 Dl_info info{};if(!dladdr(reinterpret_cast<const void*>(&bundledModels),&info)||!info.dli_fname)return {};
 auto binary=juce::File(juce::String::fromUTF8(info.dli_fname)).getParentDirectory();auto models=binary.getFileName()=="MacOS"?binary.getSiblingFile("Resources").getChildFile("Models"):binary.getChildFile("Models");
 if(models.isDirectory())return models;
 return juce::File("/Library/Application Support/DrumAtlas/Models");
#endif
}
void* loadNativeLibrary(const juce::File&file){
 libraryError.clear();
 if(!file.existsAsFile()){libraryError="File missing: "+file.getFullPathName()+". Reinstall the latest DrumAtlas update.";return nullptr;}
#if JUCE_WINDOWS
 auto module=LoadLibraryExW(file.getFullPathName().toWideCharPointer(),nullptr,LOAD_LIBRARY_SEARCH_DLL_LOAD_DIR|LOAD_LIBRARY_SEARCH_DEFAULT_DIRS);
 if(!module){auto code=GetLastError();wchar_t message[1024]{};FormatMessageW(FORMAT_MESSAGE_FROM_SYSTEM|FORMAT_MESSAGE_IGNORE_INSERTS,nullptr,code,0,message,1024,nullptr);
  libraryError=file.getFullPathName()+" | Windows "+juce::String(int(code))+": "+juce::String(message).trim();
  if(code==ERROR_MOD_NOT_FOUND)libraryError+=" | A dependency is missing. Run the latest DrumAtlas update to install Microsoft Visual C++ x64 and AI runtime files.";
  if(code==ERROR_BAD_EXE_FORMAT)libraryError+=" | Use the Windows x64 installer; the DLL is incompatible or damaged.";
 }
 return module;
#else
 auto module=dlopen(file.getFullPathName().toRawUTF8(),RTLD_NOW|RTLD_LOCAL);if(!module){auto*error=dlerror();libraryError=error?juce::String::fromUTF8(error):"Unable to load "+file.getFullPathName();}return module;
#endif
}
juce::String nativeLibraryError(){return libraryError;}
void* nativeSymbol(void*library,const char*name){
#if JUCE_WINDOWS
 return reinterpret_cast<void*>(GetProcAddress(static_cast<HMODULE>(library),name));
#else
 return dlsym(library,name);
#endif
}
}
