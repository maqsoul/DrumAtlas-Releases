#pragma once
#include <juce_core/juce_core.h>
namespace atlas::hosting {
// Must be called from a background thread. Crash isolation is not a security sandbox.
struct ScanResult {juce::String status,error;juce::var plugins,report;};
ScanResult scan(const juce::File& worker,const juce::File& plugin,const juce::File& scratch,int timeoutMs=30000,bool probe=false);
juce::Result testIsolation(const juce::File& worker);
}
