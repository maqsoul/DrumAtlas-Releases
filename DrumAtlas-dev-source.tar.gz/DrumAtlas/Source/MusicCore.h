#pragma once
#include <juce_audio_basics/juce_audio_basics.h>
#include <cstdint>
#include <vector>
#include "MusicProfiles.h"

namespace atlas::music {
constexpr int ppq = 960;
struct Note {
    juce::String id;
    int pitch=60, velocity=90, channel=1;
    int64_t tick=0, duration=240, microtiming=0;
    double probability=1;
};
struct Track {
    juce::String id, role, soundPath;
    bool midiLocked=false, soundLocked=false;
    std::vector<Note> notes;
};
struct Settings {
    double bpm=140, swing=0, humanize=0.1, density=0.5;
    double energy=.5,darkness=.5,complexity=.5,groove=.5,melodicDensity=.5;
    int bars=4, numerator=4, denominator=4, tonic=9;
    uint32_t seed=45192;
    juce::String genre="Trap", mood="Dark", scale="minor";
};
struct Project {
    juce::String id, generatorVersion="rules-1";
    Settings settings;
    std::vector<Track> tracks;
    juce::var styleSnapshot;
};
juce::Result validate(const Project&);
juce::Result validate(const Settings&);
Project generate(const Settings&);
juce::Result generateStyled(const Settings&,const ProfileRegistry&,const std::vector<StyleWeight>& genres,const std::vector<StyleWeight>& moods,Project&);
// Atomic edit: locks and tracks outside the scope retain their exact state.
juce::Result regenerate(Project&, const juce::String& trackId, int firstBar, int endBar, uint32_t seed);
juce::var encode(const Project&);
juce::Result decode(const juce::var&, Project&);
juce::Result save(const Project&, const juce::File&);
juce::Result load(const juce::File&, Project&);
juce::Result exportMidi(const Project&, const juce::File&);
int64_t barTicks(const Settings&);
bool validGrid(int steps);
int64_t gridTick(const Settings&,int bar,int step,int steps);
juce::Result editNote(Project&,const juce::String& track,const Note& replacement);
juce::Result removeNote(Project&,const juce::String& track,const juce::String& note);
juce::Result copyBars(Project&,const juce::String& track,int first,int end,int destination);
class History {
public:
    explicit History(Project initial): current(std::move(initial)) {}
    const Project& project()const{return current;}
    juce::Result apply(Project);
    bool undo(); bool redo();
private:
    Project current;
    std::vector<Project> past,future;
};
}
