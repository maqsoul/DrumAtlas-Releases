#include "Engine.h"
#include "AudioEdit.h"
#include "LicensePanel.h"
#include "Updates.h"
#include "Locale.h"
#include "QuickBeatPanel.h"
#include "MusicRender.h"
#include "LibraryMigration.h"
#include <juce_audio_utils/juce_audio_utils.h>

namespace atlas {
class Preview : private juce::Thread {
public:
    Preview():juce::Thread("DrumAtlas preview"),ring(2,capacity){registerFormats(formats);startThread();}
    ~Preview()override{signalThreadShouldExit();notify();stopThread(-1);}
    void load(const juce::File&f,double start=0,double length=-1){
        std::lock_guard<std::mutex>g(requestMutex);++requestId;file=f;offset=std::max(0.,start);duration=length;pending=true;paused=false;playing=false;
        const juce::SpinLock::ScopedLockType audio(lock);readIndex=writeIndex=filled=0;fraction=0;eof=false;ready=false;playhead=offset;notify();
    }
    void stop(){std::lock_guard<std::mutex>g(requestMutex);++requestId;pending=false;playing=false;paused=false;ready=false;const juce::SpinLock::ScopedLockType a(lock);playhead=0;}
    void pause(){std::lock_guard<std::mutex>g(requestMutex);if(playing||pending||ready){paused=true;playing=false;}}
    bool resume(const juce::File&f){std::lock_guard<std::mutex>g(requestMutex);if(file!=f||!paused)return false;paused=false;playing=ready;return true;}
    bool isPlaying()const{return playing.load();}bool isPaused()const{return paused.load();}
    juce::File currentFile(){std::lock_guard<std::mutex>g(requestMutex);return file;}
    juce::String message(){std::lock_guard<std::mutex>g(requestMutex);return info;}
    std::atomic<double>playhead{0};std::atomic<float>gain{.25f};
    void render(juce::AudioBuffer<float>&out,double hostRate){
        if(!playing||hostRate<=0)return;const juce::SpinLock::ScopedTryLockType guard(lock);if(!guard.isLocked()||!playing)return;
        const double step=sourceRate/hostRate;const float level=gain.load();
        for(int i=0;i<out.getNumSamples();++i){
            const int advance=int(fraction+step);
            if(filled<std::max(2,advance+1)){if(eof){playing=false;}break;}
            float fade=float(std::min({1.,consumed/(sourceRate*.003),double(totalFrames-consumed)/(sourceRate*.008)}));
            for(int ch=0;ch<out.getNumChannels();++ch){const auto*src=ring.getReadPointer(std::min(ch,1));float a=src[readIndex],b=src[(readIndex+1)%capacity];out.addSample(ch,i,(a+float(fraction)*(b-a))*level*fade);}
            fraction+=step;int count=int(fraction);fraction-=count;readIndex=(readIndex+count)%capacity;filled-=count;consumed+=count;
        }
        playhead=playbackStart+(consumed+fraction)/sourceRate;
    }
private:
    void run()override{
        std::unique_ptr<juce::AudioFormatReader>reader;int active=-1;juce::int64 next=0,end=0;juce::AudioBuffer<float>chunk(2,8192);
        while(!threadShouldExit()){
            juce::File target;double start=0,length=0;int requested=-1;bool opening=false;
            {std::lock_guard<std::mutex>g(requestMutex);if(pending){target=file;start=offset;length=duration;requested=requestId;pending=false;opening=true;}else if(active!=requestId)reader.reset();}
            if(opening){
                auto fresh=std::unique_ptr<juce::AudioFormatReader>(formats.createReaderFor(ioFile(target)));
                std::lock_guard<std::mutex>g(requestMutex);if(requested!=requestId)continue;
                if(!fresh||fresh->sampleRate<1000||fresh->sampleRate>384000){info="Cannot open preview file";reader.reset();continue;}
                active=requested;next=juce::jlimit<juce::int64>(0,fresh->lengthInSamples,juce::int64(start*fresh->sampleRate));
                end=length<0?fresh->lengthInSamples:std::min(fresh->lengthInSamples,next+juce::int64(length*fresh->sampleRate));
                {const juce::SpinLock::ScopedLockType a(lock);sourceRate=fresh->sampleRate;playbackStart=double(next)/sourceRate;consumed=0;totalFrames=end-next;}
                reader=std::move(fresh);info.clear();
            }
            if(!reader){wait(10);continue;}
            int free=0;{const juce::SpinLock::ScopedLockType a(lock);free=capacity-filled;}
            if(free<8192||next>=end){wait(5);continue;}
            int count=int(std::min<juce::int64>(8192,end-next));chunk.clear();bool ok=reader->read(&chunk,0,count,next,true,true);
            {std::lock_guard<std::mutex>g(requestMutex);if(active!=requestId){reader.reset();continue;}
                const juce::SpinLock::ScopedLockType a(lock);
                if(!ok){info="Cannot decode preview";playing=false;ready=false;reader.reset();continue;}
                int first=std::min(count,capacity-writeIndex);for(int ch=0;ch<2;++ch){ring.copyFrom(ch,writeIndex,chunk,ch,0,first);if(first<count)ring.copyFrom(ch,0,chunk,ch,first,count-first);}
                writeIndex=(writeIndex+count)%capacity;filled+=count;next+=count;eof=next>=end;
                if(!ready){ready=true;playing=!paused.load();}
            }
        }
    }
    static constexpr int capacity=131072;
    juce::AudioFormatManager formats;juce::AudioBuffer<float>ring;juce::SpinLock lock;std::mutex requestMutex;
    juce::File file;juce::String info;int requestId=0,readIndex=0,writeIndex=0,filled=0;
    double offset=0,duration=-1,sourceRate=44100,playbackStart=0,fraction=0;juce::int64 consumed=0,totalFrames=0;
    bool pending=false,ready=false,eof=false;std::atomic<bool>playing{false},paused{false};
};

class Processor : public juce::AudioProcessor {
public:
    Processor() : AudioProcessor(BusesProperties().withInput("Input", juce::AudioChannelSet::stereo(), true)
                                                  .withOutput("Output", juce::AudioChannelSet::stereo(), true)) {}
    const juce::String getName() const override { return "DrumAtlas"; }
    void prepareToPlay(double sampleRate, int) override { rate = sampleRate; preview.stop(); }
    void releaseResources() override { preview.stop(); }
    bool isBusesLayoutSupported(const BusesLayout& b) const override {
        return b.getMainOutputChannelSet() == juce::AudioChannelSet::stereo()
            && (b.getMainInputChannelSet() == juce::AudioChannelSet::stereo() || b.getMainInputChannelSet().isDisabled());
    }
    void processBlock(juce::AudioBuffer<float>& audio, juce::MidiBuffer&) override {
        juce::ScopedNoDenormals guard;
        double bpm=0;if(auto*head=getPlayHead())if(auto position=head->getPosition())if(auto tempo=position->getBpm())bpm=*tempo;hostBpm=std::isfinite(bpm)&&bpm>0?bpm:0;
        for (int i = getTotalNumInputChannels(); i < audio.getNumChannels(); ++i) audio.clear(i, 0, audio.getNumSamples());
        if(isLicensed)preview.render(audio, rate);
    }
    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }
    double getTailLengthSeconds() const override { return 0; }
    bool acceptsMidi() const override { return false; }
    bool producesMidi() const override { return false; }
    int getNumPrograms() override { return 1; }
    int getCurrentProgram() override { return 0; }
    void setCurrentProgram(int) override {}
    const juce::String getProgramName(int) override { return {}; }
    void changeProgramName(int, const juce::String&) override {}
    void getStateInformation(juce::MemoryBlock& dest) override {
        juce::XmlElement xml("DrumAtlas"); xml.setAttribute("gain", double(preview.gain.load()));
        {std::lock_guard<std::mutex>g(musicMutex);xml.createNewChildElement("music-project")->addTextElement(musicStateUnsupported?unparsedMusicState:juce::JSON::toString(music::encode(musicHistory.project())));}
        xml.setAttribute("width",editorWidth);xml.setAttribute("height",editorHeight);
        xml.setAttribute("zoom",editorZoom);xml.setAttribute("split",editorSplit);
        xml.setAttribute("showReference",showReference);xml.setAttribute("showResults",showResults);xml.setAttribute("showSampleWave",showSampleWave);
        for (const auto& root : engine.roots()) xml.createNewChildElement("root")->setAttribute("path", root);
        {std::lock_guard<std::mutex>g(renderMutex);for(const auto&pair:renderedFiles){auto*node=xml.createNewChildElement("render");node->setAttribute("source",pair.first);node->setAttribute("output",pair.second);}}
        copyXmlToBinary(xml, dest);
    }
    void setStateInformation(const void* data, int size) override {
        if (auto xml = getXmlFromBinary(data, size); xml && xml->hasTagName("DrumAtlas")) {
            if(auto*node=xml->getChildByName("music-project")){
                music::Project project;auto valid=music::decode(juce::JSON::parse(node->getAllSubText()),project);
                std::lock_guard<std::mutex>g(musicMutex);
                musicStateUnsupported=valid.failed();
                if(valid.wasOk()){musicHistory=music::History(std::move(project));unparsedMusicState.clear();}
                else unparsedMusicState=node->getAllSubText();
            }else {std::lock_guard<std::mutex>g(musicMutex);musicHistory=music::History(music::generate(music::Settings{}));unparsedMusicState.clear();musicStateUnsupported=false;}
            editorWidth=juce::jlimit(400,7680,xml->getIntAttribute("width",1280));editorHeight=juce::jlimit(288,4320,xml->getIntAttribute("height",840));
            editorZoom=juce::jlimit(.4,2.,xml->getDoubleAttribute("zoom",1.));editorSplit=juce::jlimit(.4,.75,xml->getDoubleAttribute("split",.62));
            showReference=xml->getBoolAttribute("showReference",true);showResults=xml->getBoolAttribute("showResults",true);showSampleWave=xml->getBoolAttribute("showSampleWave",true);
            preview.gain = float(juce::jlimit(0.0, 1.0, xml->getDoubleAttribute("gain", 0.25)));
            juce::StringArray roots;
            for (auto* child : xml->getChildIterator()) if (child->hasTagName("root")) roots.add(child->getStringAttribute("path"));
            {std::lock_guard<std::mutex>g(renderMutex);renderedFiles.clear();for(auto*child:xml->getChildIterator())if(child->hasTagName("render"))renderedFiles[child->getStringAttribute("source")]=child->getStringAttribute("output");}
            engine.setRoots(roots);
        }
    }
    juce::String renderedPath(const juce::String&source){std::lock_guard<std::mutex>g(renderMutex);auto i=renderedFiles.find(source);return i!=renderedFiles.end()&&ioFile(juce::File(i->second)).existsAsFile()?i->second:source;}
    void setRendered(const juce::String&source,const juce::String&output){std::lock_guard<std::mutex>g(renderMutex);if(output.isEmpty())renderedFiles.erase(source);else renderedFiles[source]=output;}
    std::mutex renderMutex;std::map<juce::String,juce::String>renderedFiles;
    Engine engine;
    music::Project musicProject(){std::lock_guard<std::mutex>g(musicMutex);return musicHistory.project();}
    juce::Result applyMusicAction(const music::ActionPreview&action){std::lock_guard<std::mutex>g(musicMutex);if(musicStateUnsupported)return juce::Result::fail("Unsupported music project schema; original state preserved");return music::applyAction(musicHistory,action);}
    juce::Result setMusicProject(music::Project p){std::lock_guard<std::mutex>g(musicMutex);if(musicStateUnsupported)return juce::Result::fail("Unsupported music project schema; original state preserved");return musicHistory.apply(std::move(p));}
    juce::String musicStateError(){std::lock_guard<std::mutex>g(musicMutex);return musicStateUnsupported?"Unsupported music project schema; original state preserved":juce::String();}
    void undoMusic(){std::lock_guard<std::mutex>g(musicMutex);musicHistory.undo();}
    void redoMusic(){std::lock_guard<std::mutex>g(musicMutex);musicHistory.redo();}
    std::mutex musicMutex;juce::String unparsedMusicState;bool musicStateUnsupported=false;music::History musicHistory{music::generate(music::Settings{})};
    std::atomic<bool>isLicensed{licensed()};Updates updates;AudioEditService audioEdit;std::atomic<double>hostBpm{0};
    int editorWidth=1280,editorHeight=840;
    double editorZoom=1.,editorSplit=.62;
    bool showReference=true,showResults=true,showSampleWave=true;
    Preview preview;
private:
    double rate = 44100;
};

class FileDragButton : public juce::TextButton {
public:
    FileDragButton() : juce::TextButton("Drag to DAW") {}
    std::function<juce::String()> path;
    void mouseDrag(const juce::MouseEvent& e) override {
        if (!sent && e.getDistanceFromDragStart() > 5 && path) {
            const auto file = path();
            if (atlas::ioFile(juce::File(file)).existsAsFile()) { sent = true; juce::DragAndDropContainer::performExternalDragDropOfFiles({file}, false, this); }
        }
    }
    void mouseDown(const juce::MouseEvent& e) override { sent = false; juce::TextButton::mouseDown(e); }
private:
    bool sent = false;
};

class CatalogList : public juce::ListBox {
public:
    CatalogList(const juce::String& name, juce::ListBoxModel* model) : juce::ListBox(name, model) {}
    juce::String emptyText = "Add a sample folder to start";
    void paintOverChildren(juce::Graphics& g) override {
        if (getModel() && getModel()->getNumRows() == 0) {
            g.setColour(juce::Colour(0xff91a8a7)); g.setFont(juce::FontOptions(16.0f));
            g.drawFittedText(emptyText, getLocalBounds().reduced(24), juce::Justification::centred, 3);
        }
    }
};



#include "Editor.inc"
#include "Platform.h"
#if DRUMATLAS_ENABLE_SMOKE_TESTS
#include <iostream>
#include <stdexcept>
int runAtlasLayout(const juce::File& scratch) {
    const auto check=[](bool ok,const char*message){if(!ok)throw std::runtime_error(message);};
    scratch.createDirectory();atlas::Processor processor;processor.isLicensed=true;
    std::unique_ptr<juce::AudioProcessorEditor>base(processor.createEditor());auto*editor=dynamic_cast<atlas::Editor*>(base.get());
    auto child=[&](const juce::String&id)->juce::Component*{for(auto*c:editor->getChildren())if(c->getComponentID()==id)return c;return nullptr;};
    auto*zoom=dynamic_cast<juce::ComboBox*>(child("interface-zoom"));auto*list=child("library");check(zoom&&list,"Layout controls missing");
    auto shot=[&](const char*name){juce::FileOutputStream out(scratch.getChildFile(name));out.setPosition(0);out.truncate();juce::PNGImageFormat().writeImageToStream(editor->createComponentSnapshot(editor->getLocalBounds()),out);};
    editor->setSize(1000,720);shot("layout-normal.png");const auto normal=list->getBounds();
    editor->applyView(4);check(!child("reference-wave")->isVisible()&&!child("reference-results")->isVisible()&&!child("sample-wave")->isVisible(),"Focus hides optional panels");
    check(list->getWidth()>normal.getWidth()&&list->getHeight()>normal.getHeight(),"Focus expands library in both dimensions");shot("layout-focus.png");
    juce::MemoryBlock state;processor.getStateInformation(state);processor.showReference=true;processor.showResults=true;processor.setStateInformation(state.getData(),int(state.getSize()));check(!processor.showReference&&!processor.showResults,"Panel state persists");
    editor->applyView(5);zoom->setSelectedId(40,juce::sendNotificationSync);check(std::abs(list->getTransform().mat00-.4f)<.01f,"40 percent zoom applies to controls");shot("layout-40.png");
    zoom->setSelectedId(200,juce::sendNotificationSync);check(processor.editorZoom==2.,"200 percent option available");shot("layout-large.png");
    editor->setSize(400,288);check(list->getHeight()>0&&child("reference-results")->getHeight()>0,"Minimum window retains usable logical layout");shot("layout-minimum.png");
    auto*divider=dynamic_cast<atlas::LibraryDivider*>(child("library-divider"));const int oldWidth=list->getWidth();divider->moved(180);check(list->getWidth()!=oldWidth,"Divider changes library width");
    check(!atlas::loadNativeLibrary(scratch.getChildFile("missing-runtime.dll"))&&atlas::nativeLibraryError().contains("missing-runtime.dll"),"Runtime diagnostic identifies absent file");
    editor->setSize(1000,720);dynamic_cast<juce::TextButton*>(child("quick-beat"))->onClick();shot("layout-quick-beat.png");
    auto*beat=child("quick-beat-panel");check(beat!=nullptr,"Quick Beat exists");
    auto*genre=dynamic_cast<juce::ComboBox*>(beat->findChildWithID("beat-genre"));auto*mood=dynamic_cast<juce::ComboBox*>(beat->findChildWithID("beat-mood"));auto*generate=dynamic_cast<juce::TextButton*>(beat->findChildWithID("beat-generate"));
    check(genre&&mood&&generate&&genre->getNumItems()==23&&mood->getNumItems()==19,"Profile selectors populated");
    genre->setText("House",juce::dontSendNotification);mood->setText("Warm",juce::dontSendNotification);generate->onClick();
    check(processor.musicProject().settings.genre=="House"&&processor.musicProject().settings.mood=="Warm"&&processor.musicProject().generatorVersion=="profiles-1","Selected styles generate and persist");
    shot("layout-quick-beat-profiles.png");
    atlas::PianoRoll*roll=nullptr;for(auto*c:beat->getChildren())if(auto*r=dynamic_cast<atlas::PianoRoll*>(c))roll=r;check(roll!=nullptr,"Piano Roll exists");
    auto beforeGesture=juce::JSON::toString(atlas::music::encode(processor.musicProject()));auto beforeCount=processor.musicProject().tracks[0].notes.size();auto source=juce::Desktop::getInstance().getMainMouseSource();auto now=juce::Time::getCurrentTime();
    juce::MouseEvent down(source,{100,90},juce::ModifierKeys::leftButtonModifier,1,0,0,0,0,roll,roll,now,{100,90},now,1,false);
    juce::MouseEvent moved(source,{220,104},juce::ModifierKeys::leftButtonModifier,1,0,0,0,0,roll,roll,now,{100,90},now,1,true);
    roll->mouseDown(down);roll->mouseDrag(moved);check(juce::JSON::toString(atlas::music::encode(processor.musicProject()))==beforeGesture,"Dragging is only a preview until release");roll->mouseUp(moved);check(processor.musicProject().tracks[0].notes.size()==beforeCount+1,"Mouse gesture creates a note");processor.undoMusic();check(juce::JSON::toString(atlas::music::encode(processor.musicProject()))==beforeGesture,"One Undo reverses entire mouse gesture");
    auto*mixButton=dynamic_cast<juce::TextButton*>(beat->findChildWithID("beat-mix"));check(mixButton!=nullptr,"Mix button exists");mixButton->onClick();
    auto*blendPanel=dynamic_cast<atlas::StyleBlendPanel*>(beat->findChildWithID("blend-panel"));check(blendPanel&&blendPanel->isVisible(),"Mix panel opens");
    blendPanel->weightControl(true,"House")->setValue(75,juce::sendNotificationSync);blendPanel->weightControl(true,"Trap")->setValue(25,juce::sendNotificationSync);blendPanel->weightControl(false,"Warm")->setValue(60,juce::sendNotificationSync);blendPanel->weightControl(false,"Dark")->setValue(40,juce::sendNotificationSync);
    auto unmixed=juce::JSON::toString(atlas::music::encode(processor.musicProject()));shot("layout-style-mix.png");dynamic_cast<juce::TextButton*>(blendPanel->findChildWithID("blend-apply"))->onClick();check(juce::JSON::toString(atlas::music::encode(processor.musicProject()))==unmixed,"Mix editing does not silently regenerate song");
    generate->onClick();auto mixed=processor.musicProject();check(mixed.styleSnapshot["genres"].size()==2&&mixed.styleSnapshot["moods"].size()==2,"Generation stores both weighted groups");
    atlas::music::Project reloaded;check(atlas::music::decode(atlas::music::encode(mixed),reloaded).wasOk()&&juce::JSON::toString(reloaded.styleSnapshot)==juce::JSON::toString(mixed.styleSnapshot),"Mix survives project round trip");
    mixButton->onClick();check(std::abs(blendPanel->weightControl(true,"House")->getValue()-75)<.01,"Mix weights restored on reopen");blendPanel->weightControl(true,"House")->setValue(0,juce::sendNotificationSync);blendPanel->weightControl(true,"Trap")->setValue(0,juce::sendNotificationSync);check(!blendPanel->findChildWithID("blend-apply")->isEnabled(),"Empty genre mix cannot apply");blendPanel->setVisible(false);
    genre->setText("Trap",juce::sendNotificationSync);generate->onClick();check(processor.musicProject().styleSnapshot["genres"].size()==1&&processor.musicProject().styleSnapshot["moods"].size()==2,"Single genre selection resets only genre weights");processor.undoMusic();dynamic_cast<atlas::QuickBeatPanel*>(beat)->refresh();check(processor.musicProject().styleSnapshot["genres"].size()==2,"Undo restores weighted project");
    dynamic_cast<juce::TextButton*>(beat->findChildWithID("beat-commands"))->onClick();auto*commands=beat->findChildWithID("command-panel");check(commands&&commands->isVisible(),"Commands panel opens");
    dynamic_cast<juce::TextEditor*>(commands->findChildWithID("command-input"))->setText("tempo 130");dynamic_cast<juce::TextButton*>(commands->findChildWithID("command-preview"))->onClick();check(processor.musicProject().settings.bpm==140,"Command preview does not edit song");dynamic_cast<juce::TextButton*>(commands->findChildWithID("command-apply"))->onClick();check(processor.musicProject().settings.bpm==130,"Command applies after preview");shot("layout-commands.png");
    auto*beatTyped=dynamic_cast<atlas::QuickBeatPanel*>(beat);auto*wavButton=beat->findChildWithID("beat-export-wav");check(wavButton&&bool(beatTyped->onExportWav),"WAV export wired to editor");
    auto*stemsButton=beat->findChildWithID("beat-export-stems");check(stemsButton&&bool(beatTyped->onExportStems),"Stem export wired to editor");beatTyped->exportStatus(true,"Rendering stems...");check(!stemsButton->isEnabled()&&!wavButton->isEnabled(),"Both export buttons disabled together");beatTyped->exportStatus(false,"Ready");check(stemsButton->isEnabled()&&wavButton->isEnabled(),"Both export buttons restored");commands->setVisible(false);shot("layout-stem-export.png");
    auto wavOutput=scratch.getChildFile("beat-export-"+juce::Uuid().toString()+".wav");beatTyped->onExportWav(wavOutput);check(!wavButton->isEnabled(),"Duplicate export disabled while rendering");auto deadline=juce::Time::getMillisecondCounter()+10000;while(!wavOutput.existsAsFile()&&juce::Time::getMillisecondCounter()<deadline)juce::Thread::sleep(10);check(wavOutput.getSize()>44,"Background export commits WAV");juce::WavAudioFormat wavFormat;std::unique_ptr<juce::AudioFormatReader>wavReader(wavFormat.createReaderFor(wavOutput.createInputStream().release(),true));check(wavReader&&wavReader->bitsPerSample==24&&wavReader->numChannels==2,"Exported WAV readable");
    std::cout<<"PASS: layout zoom, compact view, panel persistence, draggable divider, runtime diagnostic\n";return 0;
}
int runAtlasSmoke(const juce::File& scratch) {
    const auto check = [](bool ok, const char* message) { if (!ok) throw std::runtime_error(message); };
    check(juce::SystemStats::getEnvironmentVariable("DRUMATLAS_CACHE_DIR", {}).isNotEmpty(), "Set test cache directory");
    scratch.createDirectory(); auto fixtures = scratch.getChildFile("samples-"+juce::String(juce::Time::currentTimeMillis()));
    if(juce::SystemStats::getEnvironmentVariable("DRUMATLAS_TEST_LONG_PATHS",{})=="1")for(int i=0;i<5;++i)fixtures=fixtures.getChildFile(juce::String::repeatedString("nested library ",5)+juce::String(i));
    check(atlas::ioFile(fixtures).createDirectory().wasOk(),"Create fixture directory including long paths");
    juce::WavAudioFormat format;
    const auto write = [&](const juce::String& name, double hz, int seconds) {
        const auto file = fixtures.getChildFile(name);
        juce::AudioBuffer<float> audio(2, 44100 * seconds);
        for (int i = 0; i < audio.getNumSamples(); ++i) {
            const double t = (i % 22050) / 44100.0;
            const float value = float(0.8 * std::sin(juce::MathConstants<double>::twoPi * hz * t) * std::exp(-t * 18));
            audio.setSample(0, i, value); audio.setSample(1, i, value);
        }
        auto stream = atlas::ioFile(file).createOutputStream(); check(stream != nullptr, "Fixture stream"); stream->setPosition(0); stream->truncate();
        std::unique_ptr<juce::AudioFormatWriter> writer(format.createWriterFor(stream.release(), 44100, 2, 16, {}, 0));
        check(writer != nullptr && writer->writeFromAudioSampleBuffer(audio, 0, audio.getNumSamples()), "Fixture WAV writing");
        return file;
    };
    const auto kick = write("Pack_Kick_01.wav", 65, 1);
    write("Pack_Piano_C4.wav", 262, 1);
    const auto loop = write("Drum_Loop_120BPM.wav", 90, 4);
    atlas::ioFile(fixtures.getChildFile("broken.wav")).replaceWithText("not audio");
    atlas::Processor processor;
    check(processor.isLicensed,"Test fixture must contain a valid signed activation");
    struct TestPlayHead:juce::AudioPlayHead{juce::Optional<PositionInfo>getPosition()const override{PositionInfo position;position.setBpm(137.0);return position;}} testPlayHead;
    processor.setPlayHead(&testPlayHead);
    const auto wait = [&] {
        const auto end = juce::Time::getMillisecondCounter() + 45000;
        while (processor.engine.snapshot().busy && juce::Time::getMillisecondCounter() < end) juce::Thread::sleep(20);
        check(!processor.engine.snapshot().busy, "Analysis job timeout");
    };
    processor.engine.setRoots({fixtures.getFullPathName(), fixtures.getFullPathName()}); wait();
    auto snap = processor.engine.snapshot();
    check(snap.samples->size() == 4, "Recursive scan, duplicate roots, corrupt file handling");
    check(snap.issues==1,"Corrupt files remain visible with an error");
    check(snap.neural,"Scanner loads bundled audio model");
    const auto second=scratch.getChildFile(juce::String::fromUTF8("Екінші кітапхана"));second.createDirectory();
    atlas::ioFile(kick).copyFileTo(second.getChildFile("Another_Kick.wav"));
    processor.engine.addRoots({second,fixtures});wait();
    check(processor.engine.snapshot().samples->size()==5&&processor.engine.roots().size()==2,"Multiple roots add without replacement or duplication");
    processor.engine.createCollection(juce::String::fromUTF8("Любимые кики"));
    processor.engine.favourite(kick.getFullPathName(),juce::String::fromUTF8("Любимые кики"),true);processor.engine.used(kick.getFullPathName());processor.engine.used(loop.getFullPathName());processor.engine.used(kick.getFullPathName());
    snap=processor.engine.snapshot();check(snap.recent.size()==2&&snap.recent[0]==kick.getFullPathName(),"Recent samples ordered and deduplicated");
    check(snap.favourites.at(kick.getFullPathName()).contains(juce::String::fromUTF8("Любимые кики")),"Favourite collection membership");
    processor.engine.relabel(kick.getFullPathName(), "Tom", "One-shot");
    processor.engine.rescan(); wait();
    snap = processor.engine.snapshot();
    bool manual = false;
    for (const auto& s : *snap.samples) if (s.path == kick.getFullPathName()) manual = s.category == "Tom" && s.method == "Manual";
    check(manual, "Manual tags survive rescan");
    processor.engine.analyseReference(loop, 0, 4); wait();
    check(processor.engine.snapshot().hits.size() >= 1, "Reference attack extraction");
    auto longReference=write("Reference_40s.wav",65,40);
    processor.engine.analyseReference(longReference,34,3);wait();
    snap=processor.engine.snapshot();check(!snap.hits.empty(),"Reference analysis beyond old 30 second cap");
    for(auto&hit:snap.hits)check(hit.time>=34&&hit.time<37,"Selection boundaries respected");
    processor.engine.analyseReference(longReference,34,3,"Kick");wait();
    snap=processor.engine.snapshot();check(!snap.hits.empty(),"Targeted Kick analysis detects a low-frequency rhythm");for(auto&hit:snap.hits)check(hit.category=="Kick"&&hit.time>=34&&hit.time<37,"Targeted analysis only returns selected instrument and time");
    processor.engine.analyseReference(longReference);wait();
    check(processor.engine.snapshot().processed==40,"Full-track analysis reaches the end");
    for(auto&m:processor.engine.snapshot().matches){bool same=false;for(auto&s:*processor.engine.snapshot().samples)if(s.path==m.path)same=s.category==m.category;check(same,"Reference matches keep detected category");}
    processor.prepareToPlay(48000, 512);
    juce::AudioBuffer<float> block(2, 512); juce::MidiBuffer midi;
    for (int ch = 0; ch < 2; ++ch) for (int i = 0; i < 512; ++i) block.setSample(ch, i, 0.125f);
    processor.processBlock(block, midi);
    check(std::abs(processor.hostBpm.load()-137.0)<.001,"DAW tempo read from host playhead");
    check(std::abs(block.getSample(0, 100) - 0.125f) < 0.000001f, "Idle audio passthrough");
    processor.preview.load(kick);
    for (int i = 0; i < 100 && !processor.preview.isPlaying(); ++i) juce::Thread::sleep(10);
    block.clear(); processor.processBlock(block, midi);
    check(block.getMagnitude(0, 512) > 0.01f, "Preview decoding and 44.1 to 48 kHz playback");
    processor.preview.pause();const auto pausedAt=processor.preview.playhead.load();block.clear();processor.processBlock(block,midi);
    check(block.getMagnitude(0,512)==0&&processor.preview.playhead.load()==pausedAt,"Pause is silent and preserves position");
    check(!processor.preview.resume(loop)&&processor.preview.resume(kick),"Resume is scoped to the paused file");block.clear();processor.processBlock(block,midi);check(processor.preview.playhead.load()>pausedAt,"Resume continues from paused cursor");
    processor.preview.stop(); block.clear(); processor.processBlock(block, midi);
    check(block.getMagnitude(0, 512) == 0, "Stop silences preview");
    processor.preview.load(kick); processor.preview.stop(); juce::Thread::sleep(100);
    check(!processor.preview.isPlaying(), "Stop cancels pending preview");
    const auto edited=atlas::renderAudioEdit({kick,7,0,0},scratch.getChildFile("rendered"));processor.setRendered(kick.getFullPathName(),edited.getFullPathName());
    juce::MemoryBlock state; processor.preview.gain = 0.42f; processor.getStateInformation(state);
    processor.setRendered(kick.getFullPathName(),{});
    processor.preview.gain = 0.1f; processor.setStateInformation(state.getData(), int(state.getSize())); wait();
    check(std::abs(processor.preview.gain.load() - 0.42f) < 0.001f, "Host state roundtrip");
    check(processor.renderedPath(kick.getFullPathName())==edited.getFullPathName(),"Rendered sample path survives DAW state roundtrip");processor.setRendered(kick.getFullPathName(),{});
    processor.engine.analyseReference(loop,0,2,"Kick",true);wait();
    auto stemCheck=processor.engine.snapshot();check(stemCheck.status=="referenceReady"&&stemCheck.stems.size()==1&&atlas::ioFile(juce::File(stemCheck.stems[0].path)).existsAsFile(),"AI analysis creates the selected drum stem");
    std::unique_ptr<juce::AudioProcessorEditor> editor(processor.createEditor());
    for (int i = 0; i < editor->getNumChildComponents(); ++i)
        if (auto* combo = dynamic_cast<juce::ComboBox*>(editor->getChildComponent(i)); combo && combo->getComponentID() == "language")
            combo->setSelectedId(2, juce::sendNotificationSync);
    for (int i = 0; i < editor->getNumChildComponents(); ++i)
        if (auto* list = dynamic_cast<juce::ListBox*>(editor->getChildComponent(i))) list->selectRow(0);
    atlas::ReferenceWave* selectedWave=nullptr;for(auto*c:editor->getChildren())if(c->getComponentID()=="sample-wave")selectedWave=dynamic_cast<atlas::ReferenceWave*>(c);
    check(selectedWave&&selectedWave->file!=juce::File(),"Selecting a result loads its sample waveform");
    check(selectedWave->dragAudio.path()==selectedWave->file.getFullPathName(),"Waveform drag exports the previewed file");
    atlas::RowsModel dragModel;dragModel.dragPath=[&](int){return edited.getFullPathName();};juce::SparseSet<int>dragRows;dragRows.addRange({0,1});check(dragModel.getDragSourceDescription(dragRows).toString()==edited.getFullPathName(),"Sample row drag carries rendered WAV path");
    const auto auditionedPath=selectedWave->file.getFullPathName();
    {auto now=juce::Time::getCurrentTime();auto source=juce::Desktop::getInstance().getMainMouseSource();float x1=12+(selectedWave->getWidth()-24)*.25f,x2=12+(selectedWave->getWidth()-24)*.75f;
      juce::MouseEvent down(source,{x1,45},juce::ModifierKeys::leftButtonModifier,1,0,0,0,0,selectedWave,selectedWave,now,{x1,45},now,1,false);
      juce::MouseEvent drag(source,{x2,45},juce::ModifierKeys::leftButtonModifier,1,0,0,0,0,selectedWave,selectedWave,now,{x1,45},now,1,true);
      selectedWave->mouseDown(down);selectedWave->mouseDrag(drag);selectedWave->mouseUp(drag);
      for(int i=0;i<100&&!processor.preview.isPlaying();++i)juce::Thread::sleep(10);
      check(processor.preview.isPlaying()&&std::abs(selectedWave->start()-.25)<.02&&std::abs(selectedWave->length()-.5)<.02,"Dragging the sample waveform auditions the selected interval");
      selectedWave->pause.onClick();check(processor.preview.isPaused(),"Waveform pause button pauses the active track");selectedWave->play.onClick();check(processor.preview.isPlaying(),"Waveform play button resumes");
      selectedWave->stop.onClick();check(!processor.preview.isPlaying()&&processor.preview.playhead.load()==0&&selectedWave->cursor==0&&selectedWave->playbackStart()==0,"Waveform stop rewinds audio and cursor to track beginning");
      selectedWave->mouseDown(down);selectedWave->mouseUp(down);check(!selectedWave->hasSelection()&&selectedWave->start()==0&&std::abs(selectedWave->length()-1)<.02,"A left click seeks without creating a selection");processor.preview.stop();
      juce::MouseEvent right(source,{x2,45},juce::ModifierKeys::rightButtonModifier,1,0,0,0,0,selectedWave,selectedWave,now,{x2,45},now,1,false);auto seekBefore=selectedWave->playbackStart();selectedWave->mouseDown(right);selectedWave->mouseUp(right);check(selectedWave->playbackStart()==seekBefore&&!selectedWave->hasSelection(),"Right click does not select or seek a waveform");
      atlas::RowsModel popupModel;juce::Point<int>popupPoint;popupModel.context=[&](int,juce::Point<int>point){popupPoint=point;};popupModel.listBoxItemClicked(0,right);check(popupPoint==right.getScreenPosition(),"Context menu receives the clicked sample screen location");
      selectedWave->mouseDoubleClick(down);check(selectedWave->start()==0&&std::abs(selectedWave->length()-1)<.02,"Double click restores whole sample");processor.preview.stop();
    }
    auto image = editor->createComponentSnapshot(editor->getLocalBounds(), true, 1.0f);
    juce::FileOutputStream out(scratch.getChildFile("DrumAtlas-preview.png"));
    out.setPosition(0); out.truncate();
    check(juce::PNGImageFormat().writeImageToStream(image, out), "Editor snapshot");
    for(int language=1;language<=14;++language){
      for(int i=0;i<editor->getNumChildComponents();++i)if(auto*combo=dynamic_cast<juce::ComboBox*>(editor->getChildComponent(i));combo&&combo->getComponentID()=="language")combo->setSelectedId(language,juce::sendNotificationSync);
      editor->setSize(1120,780);auto render=editor->createComponentSnapshot(editor->getLocalBounds(),true,1.f);check(render.isValid(),"All 14 language layouts render");
      if(language==7){juce::FileOutputStream chinese(scratch.getChildFile("DrumAtlas-zh.png"));chinese.setPosition(0);chinese.truncate();juce::PNGImageFormat().writeImageToStream(render,chinese);}
    }
    juce::ComboBox*category=nullptr;juce::ListBox*library=nullptr;
    for(int i=0;i<editor->getNumChildComponents();++i){auto*c=editor->getChildComponent(i);if(c->getComponentID()=="category")category=dynamic_cast<juce::ComboBox*>(c);if(c->getComponentID()=="library")library=dynamic_cast<juce::ListBox*>(c);}
    check(category&&library,"Library filtering controls exist");category->setSelectedId(2,juce::sendNotificationSync);
    check(library->getModel()->getNumRows()==1,"Localized Kick filter only shows the actual Kick category");
    juce::ComboBox*scope=nullptr;juce::ResizableCornerComponent*corner=nullptr;
    for(int i=0;i<editor->getNumChildComponents();++i){auto*c=editor->getChildComponent(i);if(c->getComponentID()=="scope")scope=dynamic_cast<juce::ComboBox*>(c);if(auto*r=dynamic_cast<juce::ResizableCornerComponent*>(c))corner=r;}
    check(scope&&corner&&corner->getWidth()>=20,"Folder selection and mouse resize corner are available");category->setSelectedId(1,juce::sendNotificationSync);scope->setSelectedId(1001,juce::sendNotificationSync);check(library->getModel()->getNumRows()==1,"Selected root excludes files in other roots");scope->setSelectedId(1,juce::sendNotificationSync);check(library->getModel()->getNumRows()==6,"All roots view restores the full catalog");
    auto now=juce::Time::getCurrentTime();auto source=juce::Desktop::getInstance().getMainMouseSource();
    juce::MouseEvent down(source,{20,20},juce::ModifierKeys::leftButtonModifier,1,0,0,0,0,corner,corner,now,{20,20},now,1,false);static_cast<juce::Component*>(corner)->mouseDown(down);
    int beforeWidth=editor->getWidth();juce::MouseEvent move(source,{110,80},juce::ModifierKeys::leftButtonModifier,1,0,0,0,0,corner,corner,now,{20,20},now,1,true);static_cast<juce::Component*>(corner)->mouseDrag(move);static_cast<juce::Component*>(corner)->mouseUp(move);check(editor->getWidth()>beforeWidth,"Mouse drag actually resizes the editor");
    editor->setSize(1600,1000);check(editor->getWidth()==1600&&editor->getHeight()==1000,"Editor supports arbitrary dimensions");
    editor->setSize(1000,720);processor.getStateInformation(state);processor.editorWidth=1280;processor.editorHeight=840;processor.setStateInformation(state.getData(),int(state.getSize()));wait();check(processor.editorWidth==1000&&processor.editorHeight==720,"Window dimensions saved in host state");
    {auto compact=editor->createComponentSnapshot(editor->getLocalBounds(),true,1.f);juce::FileOutputStream outMin(scratch.getChildFile("DrumAtlas-compact.png"));outMin.setPosition(0);outMin.truncate();juce::PNGImageFormat().writeImageToStream(compact,outMin);}
    for(int i=0;i<editor->getNumChildComponents();++i)
        check(!editor->getChildComponent(i)->getComponentID().startsWith("splice-"),"Splice UI removed");
    {
      auto project=processor.musicProject();project.settings.seed=777;project.tracks.front().midiLocked=true;
      check(processor.setMusicProject(project).wasOk(),"Music project commit");processor.getStateInformation(state);
      project.settings.seed=99;check(processor.setMusicProject(project).wasOk(),"Music project alternate");
      processor.setStateInformation(state.getData(),int(state.getSize()));
      check(processor.musicProject().settings.seed==777&&processor.musicProject().tracks.front().midiLocked,"Music project restored in DAW state");
      auto legacy=juce::AudioProcessor::getXmlFromBinary(state.getData(),int(state.getSize()));legacy->removeChildElement(legacy->getChildByName("music-project"),true);juce::MemoryBlock legacyState;juce::AudioProcessor::copyXmlToBinary(*legacy,legacyState);processor.setStateInformation(legacyState.getData(),int(legacyState.getSize()));check(processor.musicProject().settings.seed==45192,"Legacy DAW state resets previous song");
      const juce::String future="{\"schema_version\":999,\"preserve\":\"future data\"}";legacy->createNewChildElement("music-project")->addTextElement(future);juce::AudioProcessor::copyXmlToBinary(*legacy,legacyState);processor.setStateInformation(legacyState.getData(),int(legacyState.getSize()));juce::MemoryBlock futureState;processor.getStateInformation(futureState);auto preserved=juce::AudioProcessor::getXmlFromBinary(futureState.getData(),int(futureState.getSize()));check(preserved->getChildByName("music-project")->getAllSubText()==future&&processor.setMusicProject(project).failed(),"Unknown future song preserved without overwrite");processor.setStateInformation(state.getData(),int(state.getSize()));
      for(int i=0;i<editor->getNumChildComponents();++i)if(auto*c=editor->getChildComponent(i);c->getComponentID()=="quick-beat")dynamic_cast<juce::TextButton*>(c)->onClick();
      bool found=false;for(int i=0;i<editor->getNumChildComponents();++i)if(auto*c=editor->getChildComponent(i);c->getComponentID()=="quick-beat-panel"){found=true;check(c->isVisible()&&c->getWidth()>=1000,"Quick Beat panel available");}
      check(found,"Quick Beat opens");auto image=editor->createComponentSnapshot(editor->getLocalBounds(),true,1.f);juce::FileOutputStream output(scratch.getChildFile("DrumAtlas-QuickBeat.png"));output.setPosition(0);output.truncate();check(juce::PNGImageFormat().writeImageToStream(image,output),"Quick Beat screenshot");
    }
    processor.engine.preferences("ru","ion");
    editor.reset();
    juce::Thread::sleep(600);
    {atlas::Engine restored;juce::Thread::sleep(400);auto saved=restored.snapshot();check(saved.language=="ru"&&saved.collections.contains(juce::String::fromUTF8("Любимые кики"))&&saved.favourites.count(kick.getFullPathName())&&saved.recent.contains(kick.getFullPathName())&&saved.recent[0]==auditionedPath,"Language, favourites and recent history persist");}
    const auto bench=scratch.getChildFile("benchmark");bench.createDirectory();
    for(int i=0;i<160;++i)atlas::ioFile(loop).copyFileTo(bench.getChildFile("House_Kick_Loop_"+juce::String(i)+".wav"));
    processor.engine.setRoots({bench.getFullPathName()});wait();double cold=processor.engine.snapshot().elapsed;
    processor.engine.rescan();wait();snap=processor.engine.snapshot();check(snap.samples->size()==160&&snap.cached==160,"All unchanged files use cached features");
    std::cout<<"BENCHMARK: 160 stereo WAV files, 4 seconds each; cold="<<cold<<"s, cached="<<snap.elapsed<<"s\n";
    processor.engine.analyseReference(longReference,0,3,"Kick");wait();snap=processor.engine.snapshot();
    check(snap.matches.size()==160,"Ranking retains alternatives beyond the first eight");
    {std::unique_ptr<juce::AudioProcessorEditor> paging(processor.createEditor());juce::TextButton*more=nullptr,*previous=nullptr;juce::ListBox*matches=nullptr;atlas::ReferenceWave*sampleWave=nullptr;
      for(auto*c:paging->getChildren()){auto id=c->getComponentID();if(id=="more-matches")more=dynamic_cast<juce::TextButton*>(c);if(id=="previous-matches")previous=dynamic_cast<juce::TextButton*>(c);if(id=="reference-results")matches=dynamic_cast<juce::ListBox*>(c);if(id=="sample-wave")sampleWave=dynamic_cast<atlas::ReferenceWave*>(c);}
      check(more&&previous&&matches&&sampleWave,"Alternative navigation and sample waveform exist");
      auto pagePaths=[&]{juce::StringArray paths;for(int i=0;i<matches->getModel()->getNumRows();++i){matches->selectRow(i);paths.add(sampleWave->file.getFullPathName());}return paths;};
      check(matches->getModel()->getNumRows()==8&&!previous->isEnabled()&&more->isEnabled(),"First batch has eight candidates");auto first=pagePaths();more->onClick();auto secondPage=pagePaths();for(auto&path:secondPage)check(!first.contains(path),"Next batch contains new candidates");previous->onClick();check(pagePaths()==first,"Previous restores exactly the earlier batch");
      for(int i=0;i<19;++i)more->onClick();check(!more->isEnabled()&&previous->isEnabled(),"Last batch disables further alternatives");
    }
    juce::File exported;auto copyResult=atlas::exportStemCopies({{"Drums",kick.getFullPathName()},{"Keys",loop.getFullPathName()}},scratch,"Export test",exported);
    check(copyResult.wasOk()&&atlas::ioFile(exported.getChildFile("Drums.wav")).getSize()==atlas::ioFile(kick).getSize(),"Stem export copies playable WAV files");
    juce::File exportedAgain;check(atlas::exportStemCopies({{"Drums",kick.getFullPathName()}},scratch,"Export test",exportedAgain).wasOk()&&exportedAgain!=exported,"Repeated export preserves previous files");
    check(!atlas::exportStemCopies({{"Missing",scratch.getChildFile("missing.wav").getFullPathName()}},scratch,"Bad export",exportedAgain).wasOk(),"Export reports missing source");
    const auto longPreview=write("Long_preview_62s.wav",65,62);processor.preview.load(longPreview,59,3);for(int i=0;i<100&&!processor.preview.isPlaying();++i)juce::Thread::sleep(10);
    for(int i=0;i<400&&processor.preview.isPlaying();++i){block.clear();processor.processBlock(block,midi);juce::Thread::sleep(1);}
    check(processor.preview.playhead.load()>61.9&&!processor.preview.isPlaying(),"Waveform audition seeks beyond sixty seconds and stops at selection end");
    processor.preview.load(longPreview);for(int i=0;i<100&&!processor.preview.isPlaying();++i)juce::Thread::sleep(10);
    for(int i=0;i<6500&&processor.preview.isPlaying();++i){block.clear();processor.processBlock(block,midi);juce::Thread::sleep(1);}
    check(processor.preview.playhead.load()>61.9&&!processor.preview.isPlaying(),"Streaming plays a complete long file with bounded buffer memory");
    processor.engine.selectReference(kick);snap=processor.engine.snapshot();check(snap.matches.empty()&&snap.stems.empty()&&snap.hits.empty(),"New reference clears stale matches and stems");
    processor.engine.setRoots({}); wait();
    check(processor.engine.snapshot().samples->empty(), "Remove library folders");
    std::cout << "PASS: WAV scan, deduplication, corrupt-file handling, cached rescan, manual tags, reference attacks, audio passthrough, resampled preview, stop race, host state, editor render, folder removal\n";
    return 0;
}
#endif

