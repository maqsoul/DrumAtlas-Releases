#include "MusicRender.h"
#include "Formats.h"
#include <cmath>
#include <juce_cryptography/juce_cryptography.h>
namespace atlas::music {
static juce::Result renderPart(const Project&p,const juce::File&file,double rate,const std::function<bool()>&cancel,
    const std::vector<size_t>*selection=nullptr,int bits=24,float fixedGain=-1,float*measuredPeak=nullptr){
    auto cancelled=[&]{return cancel&&cancel();};
    if(cancelled())return juce::Result::fail("Render cancelled");
    if(!measuredPeak&&!file.getParentDirectory().isDirectory())return juce::Result::fail("Output folder does not exist");
    auto valid=validate(p);if(valid.failed())return valid;
    if(!std::isfinite(rate)||rate<22050||rate>96000)return juce::Result::fail("Unsupported sample rate");
    const double seconds=barTicks(p.settings)*p.settings.bars*60./(ppq*p.settings.bpm);
    const int64_t total=int64_t(std::ceil((seconds+2)*rate));
    // Only this fixed-size mix buffer scales with channels, never song duration.
    constexpr int blockSize=4096;juce::AudioBuffer<float>mix(2,blockSize);
    struct Source{juce::AudioBuffer<float>audio;double rate=44100;};
    struct Voice{size_t track;Note note;int64_t start,length;double step,duration,frequency;uint32_t seed;};
    std::vector<Source>sources(p.tracks.size());std::vector<Voice>voices;
    juce::AudioFormatManager fm;registerFormats(fm);
    uint32_t seed=p.settings.seed;auto next=[&]{seed=seed*1664525u+1013904223u;return seed;};
    for(size_t track=0;track<p.tracks.size();++track){
        if(cancelled())return juce::Result::fail("Render cancelled");
        const auto&t=p.tracks[track];auto&source=sources[track];source.rate=rate;
        if(t.soundPath.isNotEmpty()){
            if(!juce::File::isAbsolutePath(t.soundPath))return juce::Result::fail("Invalid assigned sample path");
            std::unique_ptr<juce::AudioFormatReader>reader(fm.createReaderFor(ioFile(juce::File(t.soundPath))));
            if(!reader||reader->lengthInSamples<1||reader->sampleRate<1000||reader->lengthInSamples>reader->sampleRate*30||reader->lengthInSamples>INT_MAX||reader->numChannels<1||reader->numChannels>2)return juce::Result::fail("Assigned sample missing or unsuitable for one-shot render: "+t.role);
            source.rate=reader->sampleRate;source.audio.setSize(2,int(reader->lengthInSamples));
            if(!reader->read(&source.audio,0,source.audio.getNumSamples(),0,true,true))return juce::Result::fail("Cannot decode assigned sample");
        }
        for(const auto&n:t.notes){
            if(double(next())/4294967296.>=n.probability)continue;
            const auto start=int64_t(std::llround((n.tick+n.microtiming)*60.*rate/(ppq*p.settings.bpm)));
            const double duration=n.duration*60./(ppq*p.settings.bpm),frequency=440*std::pow(2.,(n.pitch-69)/12.);
            const bool drum=n.channel==10;const double step=source.rate/rate*(drum?1:std::pow(2.,(n.pitch-60)/12.));
            auto length=std::min(total-start,source.audio.getNumSamples()>0?int64_t(std::ceil(source.audio.getNumSamples()/step)):int64_t(rate*(drum?(t.role=="Open Hat"?.4:.25):duration+.12)));
            voices.push_back({track,n,start,length,step,duration,frequency,next()});
        }
    }
    std::stable_sort(voices.begin(),voices.end(),[](const Voice&a,const Voice&b){return a.start<b.start;});
    float peak=0;
    // Two deterministic streaming passes retain whole-song peak normalization
    // without buffering the song or using block-dependent gain changes.
    auto pass=[&](juce::AudioFormatWriter*writer,float gain){
        struct State{double phase=0;uint32_t noise=0;};std::vector<State>states(voices.size());
        for(size_t i=0;i<voices.size();++i)states[i].noise=voices[i].seed;
        std::vector<size_t>active;size_t upcoming=0;
        for(int64_t offset=0;offset<total;offset+=blockSize){
            if(cancelled())return juce::Result::fail("Render cancelled");
            int count=int(std::min<int64_t>(blockSize,total-offset));mix.clear();
            active.erase(std::remove_if(active.begin(),active.end(),[&](size_t i){return voices[i].start+voices[i].length<=offset;}),active.end());
            while(upcoming<voices.size()&&voices[upcoming].start<offset+count)active.push_back(upcoming++);
            for(auto index:active){
                if(selection&&std::find(selection->begin(),selection->end(),voices[index].track)==selection->end())continue;
                const auto&v=voices[index];auto&state=states[index];const auto&source=sources[v.track].audio;const auto&role=p.tracks[v.track].role;
                auto begin=std::max(offset,v.start),end=std::min(offset+count,v.start+v.length);
                for(auto frame=begin;frame<end;++frame){
                    auto i=frame-v.start;int destination=int(frame-offset);double time=i/rate;float velocity=v.note.velocity/127.f;
                    if(source.getNumSamples()>0){double pos=i*v.step;int a=int(pos);if(a>=source.getNumSamples())break;int b=std::min(a+1,source.getNumSamples()-1);
                        for(int ch=0;ch<2;++ch){float sample=source.getSample(ch,a)+float(pos-a)*(source.getSample(ch,b)-source.getSample(ch,a));if(!std::isfinite(sample))return juce::Result::fail("Non-finite source audio");mix.addSample(ch,destination,sample*velocity*.3f);}
                    }else{
                        double value;
                        if(role=="Kick"){state.phase+=juce::MathConstants<double>::twoPi*(48+95*std::exp(-time*35))/rate;value=std::sin(state.phase)*std::exp(-time*19);}
                        else if(v.note.channel==10){state.noise=state.noise*1664525u+1013904223u;value=(double(state.noise)/2147483648.-1.)*std::exp(-time*(role=="Open Hat"?15:role=="Closed Hat"?65:24));}
                        else{double env=std::min(1.,time/.005)*std::min(1.,std::max(0.,(v.duration+.12-time)/.12));value=std::sin(juce::MathConstants<double>::twoPi*v.frequency*time)*env*(role=="Chords"?.2:.55);}
                        for(int ch=0;ch<2;++ch)mix.addSample(ch,destination,float(value)*velocity*.32f);
                    }
                }
            }
            float magnitude=mix.getMagnitude(0,count);if(!std::isfinite(magnitude))return juce::Result::fail("Invalid render");
            if(writer){mix.applyGain(gain);if(!writer->writeFromAudioSampleBuffer(mix,0,count))return juce::Result::fail("Cannot write beat WAV: check free disk space");}
            else peak=std::max(peak,magnitude);
        }
        return juce::Result::ok();
    };
    auto result=juce::Result::ok();
    if(fixedGain<0||measuredPeak){result=pass(nullptr,1);if(result.failed())return result;}
    if(measuredPeak){*measuredPeak=peak;return result;}
    juce::TemporaryFile tmp(file);auto stream=tmp.getFile().createOutputStream();if(!stream||stream->failedToOpen())return juce::Result::fail("Cannot open output WAV");juce::WavAudioFormat wav;
    // JUCE automatically promotes large WAV files to RF64.
    std::unique_ptr<juce::AudioFormatWriter>writer(wav.createWriterFor(stream.release(),rate,2,bits,{},0));
    if(!writer)return juce::Result::fail("Cannot create WAV writer");
    result=pass(writer.get(),fixedGain>=0?fixedGain:peak>.95f?.95f/peak:1.f);if(result.failed())return result;
    if(!writer->flush())return juce::Result::fail("Cannot finish WAV: check free disk space");writer.reset();
    if(cancelled())return juce::Result::fail("Render cancelled");
    return tmp.overwriteTargetFileWithTemporary()?juce::Result::ok():juce::Result::fail("Cannot commit beat WAV");
}
juce::Result renderWav(const Project&p,const juce::File&file,double rate,const std::function<bool()>&cancel){
    return renderPart(p,file,rate,cancel);
}

juce::Result renderStems(const Project&p,const juce::File&destination,const StemExportOptions&options,const std::function<bool()>&cancel){
    auto cancelled=[&]{return cancel&&cancel();};
    if(cancelled())return juce::Result::fail("Render cancelled");
    auto valid=validate(p);if(valid.failed())return valid;
    if(options.sampleRate!=44100&&options.sampleRate!=48000&&options.sampleRate!=96000)return juce::Result::fail("Choose 44.1, 48 or 96 kHz");
    if(options.bits!=16&&options.bits!=24)return juce::Result::fail("Choose 16 or 24 bit PCM");
    if(destination.exists()||!destination.getParentDirectory().isDirectory())return juce::Result::fail("Choose a new export folder inside an existing folder");
    struct Part{juce::String name;std::vector<size_t>tracks;};
    std::vector<Part>parts;
    if(options.perTrack){
        for(size_t i=0;i<p.tracks.size();++i)parts.push_back({juce::String(int(i)+1).paddedLeft('0',3)+"-"+juce::File::createLegalFileName(p.tracks[i].role).substring(0,60),{i}});
    }else{
        for(auto name:{"Drums","Bass","Chords","Melody","Other"}){
            Part part{name,{}};
            for(size_t i=0;i<p.tracks.size();++i){const auto&role=p.tracks[i].role;
                auto group=juce::StringArray{"Kick","Snare","Clap","Closed Hat","Open Hat","Percussion"}.contains(role)?juce::String("Drums"):
                    juce::StringArray{"Bass","Chords","Melody"}.contains(role)?role:juce::String("Other");
                if(group==name)part.tracks.push_back(i);
            }
            if(!part.tracks.empty())parts.push_back(std::move(part));
        }
    }
    if(parts.empty())return juce::Result::fail("No tracks to export");
    auto hash=[](const juce::File&f){juce::FileInputStream input(f);return input.openedOk()?juce::SHA256(input).toHexString():juce::String();};
    juce::Array<juce::var>outputs,sources;
    // Fingerprint before all passes; reject samples changed during rendering.
    for(const auto&t:p.tracks)if(t.soundPath.isNotEmpty()){
        if(cancelled())return juce::Result::fail("Render cancelled");
        if(!juce::File::isAbsolutePath(t.soundPath))return juce::Result::fail("Invalid assigned sample path");
        auto digest=hash(ioFile(juce::File(t.soundPath)));if(digest.isEmpty())return juce::Result::fail("Cannot fingerprint source sample");
        auto*entry=new juce::DynamicObject;entry->setProperty("track_id",t.id);entry->setProperty("path",t.soundPath);entry->setProperty("sha256",digest);sources.add(juce::var(entry));
    }
    // One gain for every file, including stems whose peaks cancel in the mix.
    float maximum=0,peak=0;auto r=renderPart(p,{},options.sampleRate,cancel,nullptr,options.bits,-1,&maximum);if(r.failed())return r;
    for(const auto&part:parts){r=renderPart(p,{},options.sampleRate,cancel,&part.tracks,options.bits,-1,&peak);if(r.failed())return r;maximum=std::max(maximum,peak);}
    const float gain=maximum>.95f?.95f/maximum:1.f;
    const auto staging=destination.getParentDirectory().getChildFile(".drumatlas-export-"+juce::Uuid().toString());
    r=staging.createDirectory();if(r.failed())return r;
    struct Cleanup{juce::File folder;~Cleanup(){folder.deleteRecursively();}}cleanup{staging};
    auto output=[&](const juce::String&name,const std::vector<size_t>*tracks){
        auto file=staging.getChildFile(name+".wav");auto result=renderPart(p,file,options.sampleRate,cancel,tracks,options.bits,gain);if(result.failed())return result;
        auto digest=hash(file);if(digest.isEmpty())return juce::Result::fail("Cannot fingerprint output");
        auto*entry=new juce::DynamicObject;entry->setProperty("file",file.getFileName());entry->setProperty("sha256",digest);
        juce::Array<juce::var>ids;for(size_t i=0;i<p.tracks.size();++i)if(!tracks||std::find(tracks->begin(),tracks->end(),i)!=tracks->end())ids.add(p.tracks[i].id);
        entry->setProperty("track_ids",ids);outputs.add(juce::var(entry));return juce::Result::ok();
    };
    r=output("Mix",nullptr);if(r.failed())return r;
    for(const auto&part:parts){r=output(part.name,&part.tracks);if(r.failed())return r;}
    for(const auto&source:sources)if(hash(ioFile(juce::File(source["path"].toString())))!=source["sha256"].toString())return juce::Result::fail("Source changed during export; retry");
    auto*manifest=new juce::DynamicObject;juce::var data(manifest);
    manifest->setProperty("schema_version",1);manifest->setProperty("renderer","one-shot-and-original-synthesis-1");manifest->setProperty("project",encode(p));
    manifest->setProperty("sample_rate",options.sampleRate);manifest->setProperty("bits_per_sample",options.bits);manifest->setProperty("channels",2);
    manifest->setProperty("frames",juce::int64(std::ceil((barTicks(p.settings)*p.settings.bars*60./(ppq*p.settings.bpm)+2)*options.sampleRate)));
    manifest->setProperty("tail_seconds",2);manifest->setProperty("latency_frames",0);manifest->setProperty("common_gain",double(gain));
    manifest->setProperty("per_track",options.perTrack);manifest->setProperty("outputs",outputs);manifest->setProperty("sources",sources);
    if(!staging.getChildFile("manifest.json").replaceWithText(juce::JSON::toString(data)))return juce::Result::fail("Cannot write export manifest");
    if(cancelled())return juce::Result::fail("Render cancelled");
    if(destination.exists()||!staging.moveFileTo(destination))return juce::Result::fail("Cannot commit export folder");
    return juce::Result::ok();
}
}
