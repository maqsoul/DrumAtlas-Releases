#include "MusicRender.h"
#include "Formats.h"
#include <cmath>
namespace atlas::music {
juce::Result renderWav(const Project&p,const juce::File&file,double rate,const std::function<bool()>&cancel){
    auto valid=validate(p);if(valid.failed())return valid;if(!std::isfinite(rate)||rate<22050||rate>96000)return juce::Result::fail("Unsupported sample rate");
    const double seconds=barTicks(p.settings)*p.settings.bars*60./(ppq*p.settings.bpm);
    if(seconds>120)return juce::Result::fail("Preview renderer currently supports at most 120 seconds");
    const int total=int(std::ceil((seconds+2)*rate));juce::AudioBuffer<float> mix(2,total);mix.clear();juce::AudioFormatManager fm;registerFormats(fm);
    uint32_t noise=p.settings.seed;auto random=[&]{noise=noise*1664525u+1013904223u;return float(double(noise)/2147483648.-1.);};
    for(const auto&t:p.tracks){
        juce::AudioBuffer<float> source;double sourceRate=rate;
        if(t.soundPath.isNotEmpty()){
            if(!juce::File::isAbsolutePath(t.soundPath))return juce::Result::fail("Invalid assigned sample path");
            std::unique_ptr<juce::AudioFormatReader> reader(fm.createReaderFor(ioFile(juce::File(t.soundPath))));
            if(!reader||reader->lengthInSamples<1||reader->sampleRate<1000||reader->lengthInSamples>reader->sampleRate*30||reader->numChannels<1||reader->numChannels>2)return juce::Result::fail("Assigned sample missing or unsuitable for one-shot preview: "+t.role);
            sourceRate=reader->sampleRate;source.setSize(2,int(reader->lengthInSamples));if(!reader->read(&source,0,source.getNumSamples(),0,true,true))return juce::Result::fail("Cannot decode assigned sample");
        }
        for(const auto&n:t.notes){
            if(cancel&&cancel())return juce::Result::fail("Render cancelled");
            if((random()+1)*.5>=n.probability)continue;
            const int start=int(std::llround((n.tick+n.microtiming)*60.*rate/(ppq*p.settings.bpm)));
            const double duration=n.duration*60./(ppq*p.settings.bpm),frequency=440*std::pow(2.,(n.pitch-69)/12.);
            const bool drum=n.channel==10;const double step=sourceRate/rate*(drum?1:std::pow(2.,(n.pitch-60)/12.));
            const int length=std::min(total-start,source.getNumSamples()>0?int(std::ceil(source.getNumSamples()/step)):int(rate*(drum?(t.role=="Open Hat"?.4:.25):duration+.12)));
            double phase=0;
            for(int i=0;i<length;++i){
                if(i%4096==0&&cancel&&cancel())return juce::Result::fail("Render cancelled");
                const double time=i/rate;const float velocity=n.velocity/127.f;
                if(source.getNumSamples()>0){double pos=i*step;int a=int(pos),b=std::min(a+1,source.getNumSamples()-1);if(a>=source.getNumSamples())break;
                    for(int ch=0;ch<2;++ch){float sample=source.getSample(ch,a)+float(pos-a)*(source.getSample(ch,b)-source.getSample(ch,a));if(!std::isfinite(sample))return juce::Result::fail("Non-finite source audio");mix.addSample(ch,start+i,sample*velocity*.3f);}
                }else{
                    double value=0;
                    if(t.role=="Kick"){phase+=juce::MathConstants<double>::twoPi*(48+95*std::exp(-time*35))/rate;value=std::sin(phase)*std::exp(-time*19);}
                    else if(drum){value=random()*std::exp(-time*(t.role=="Open Hat"?15:t.role=="Closed Hat"?65:24));}
                    else {double env=std::min(1.,time/.005)*std::min(1.,std::max(0.,(duration+.12-time)/.12));value=std::sin(juce::MathConstants<double>::twoPi*frequency*time)*env*(t.role=="Chords"?.2:.55);}
                    for(int ch=0;ch<2;++ch)mix.addSample(ch,start+i,float(value)*velocity*.32f);
                }
            }
        }
    }
    const float peak=mix.getMagnitude(0,total);if(!std::isfinite(peak))return juce::Result::fail("Invalid render");if(peak>.95f)mix.applyGain(.95f/peak);
    juce::TemporaryFile tmp(file);auto stream=tmp.getFile().createOutputStream();juce::WavAudioFormat wav;
    std::unique_ptr<juce::AudioFormatWriter>writer(wav.createWriterFor(stream.release(),rate,2,24,{},0));
    if(!writer||!writer->writeFromAudioSampleBuffer(mix,0,total))return juce::Result::fail("Cannot write beat WAV");writer.reset();if(cancel&&cancel())return juce::Result::fail("Render cancelled");return tmp.overwriteTargetFileWithTemporary()?juce::Result::ok():juce::Result::fail("Cannot commit beat WAV");
}
}
