#define NOMINMAX
#include "Formats.h"
#include "Platform.h"
#include <sndfile.h>
namespace atlas {
static thread_local juce::String lastError;
struct SndApi {
 decltype(&sf_open_virtual) open=nullptr;decltype(&sf_readf_float) read=nullptr;decltype(&sf_seek) seek=nullptr;decltype(&sf_close) close=nullptr;decltype(&sf_strerror) error=nullptr;decltype(&sf_error) errorCode=nullptr;
 SndApi(){
#if JUCE_WINDOWS
 auto dll=loadNativeLibrary(bundledModels().getChildFile("sndfile.dll"));
#else
 auto dll=loadNativeLibrary(bundledModels().getChildFile("libsndfile.dylib"));
#endif
 if(!dll)return; open=reinterpret_cast<decltype(open)>(nativeSymbol(dll,"sf_open_virtual"));read=reinterpret_cast<decltype(read)>(nativeSymbol(dll,"sf_readf_float"));seek=reinterpret_cast<decltype(seek)>(nativeSymbol(dll,"sf_seek"));close=reinterpret_cast<decltype(close)>(nativeSymbol(dll,"sf_close"));error=reinterpret_cast<decltype(error)>(nativeSymbol(dll,"sf_strerror"));errorCode=reinterpret_cast<decltype(errorCode)>(nativeSymbol(dll,"sf_error"));
 }
 bool available()const{return open&&read&&seek&&close&&error&&errorCode;}
};
static SndApi& api(){static SndApi a;return a;}
static sf_count_t size(void*p){return static_cast<juce::InputStream*>(p)->getTotalLength();}
static sf_count_t seek(sf_count_t offset,int origin,void*p){auto*s=static_cast<juce::InputStream*>(p);auto pos=offset+(origin==SEEK_CUR?s->getPosition():origin==SEEK_END?s->getTotalLength():0);return s->setPosition(pos)?s->getPosition():-1;}
static sf_count_t read(void*dst,sf_count_t count,void*p){return static_cast<juce::InputStream*>(p)->read(dst,int(std::min<sf_count_t>(count,INT_MAX)));}
static sf_count_t tell(void*p){return static_cast<juce::InputStream*>(p)->getPosition();}
class SndReader final:public juce::AudioFormatReader {
public:
 SndReader(juce::InputStream*s,SNDFILE*f,const SF_INFO&i):AudioFormatReader(s,"libsndfile"),handle(f){sampleRate=i.samplerate;numChannels=unsigned(i.channels);lengthInSamples=i.frames;bitsPerSample=32;usesFloatingPointData=true;buffer.resize(size_t(4096)*numChannels);}
 ~SndReader()override{api().close(handle);}
 bool readSamples(int*const*dest,int channels,int offset,juce::int64 start,int count)override{
   clearSamplesBeyondAvailableLength(dest,channels,offset,start,count,lengthInSamples);if(count<=0)return true;if(api().seek(handle,start,SEEK_SET)!=start)return false;
   while(count>0){int n=std::min(count,4096);auto got=api().read(handle,buffer.data(),n);if(got<0||api().errorCode(handle)!=SF_ERR_NO_ERROR)return false;
     // MP3 frame counts may include encoder padding. A clean short read at EOF is not corruption.
     if(got<n)std::fill(buffer.begin()+size_t(got)*numChannels,buffer.begin()+size_t(n)*numChannels,0.f);
     for(int ch=0;ch<channels;++ch)if(dest[ch]){auto*out=reinterpret_cast<float*>(dest[ch])+offset;for(int i=0;i<n;++i)out[i]=buffer[size_t(i)*numChannels+std::min(unsigned(ch),numChannels-1)];}
     count-=n;offset+=n;}return true;
 }
private:SNDFILE*handle;std::vector<float>buffer;
};
class ExtendedFormat final:public juce::AudioFormat {
public:
 explicit ExtendedFormat(bool first=false):AudioFormat("Extended audio","wav wave aif aiff aifc flac ogg oga opus mp3 mp2 w64 rf64 au snd caf voc iff svx mat xi paf pvf sds sd2"),preferred(first){}
 bool canHandleFile(const juce::File&f)override{return !preferred||f.hasFileExtension("mp3;mp2;opus;caf;w64");}
 juce::Array<int>getPossibleSampleRates()override{return {8000,16000,22050,44100,48000,96000,192000};}
 juce::Array<int>getPossibleBitDepths()override{return {8,16,24,32,64};}bool canDoStereo()override{return true;}bool canDoMono()override{return true;}
 juce::AudioFormatReader*createReaderFor(juce::InputStream*s,bool deleteOnFail)override{
   auto&a=api();if(a.available()){SF_VIRTUAL_IO io{&size,&seek,&read,nullptr,&tell};SF_INFO info{};s->setPosition(0);auto*f=a.open(&io,SFM_READ,&info,s);
     if(f){if(info.samplerate>0&&info.channels>0&&info.channels<=64&&info.frames>0)return new SndReader(s,f,info);a.close(f);lastError="Unsupported channel layout or empty audio";}else lastError=juce::String::fromUTF8(a.error(nullptr));
   }else lastError="Extended decoder is missing";if(deleteOnFail)delete s;return nullptr;
 }
 std::unique_ptr<juce::AudioFormatWriter>createWriterFor(std::unique_ptr<juce::OutputStream>&,const juce::AudioFormatWriterOptions&)override{return {};}
private:bool preferred;
};
void registerMediaFoundation(juce::AudioFormatManager&);
void registerFormats(juce::AudioFormatManager&fm){fm.registerFormat(new ExtendedFormat(true),false);fm.registerBasicFormats();fm.registerFormat(new ExtendedFormat(),false);registerMediaFoundation(fm);}
juce::String decoderError(){return lastError;}
}
