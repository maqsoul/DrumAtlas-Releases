#pragma once
#include <juce_core/juce_core.h>
#include <mutex>
namespace atlas {
struct UpdateRelease {juce::String version,url,sha256;juce::int64 bytes=0;};
bool parseUpdate(const juce::String&envelope,const juce::String&platform,const juce::String&current,UpdateRelease&out);
bool verifyUpdateFile(const juce::File&,const UpdateRelease&);
bool allowedUpdateRedirect(const juce::String&from,const juce::String&to);
class Updates:private juce::Thread {
public:
 enum Phase {Idle,Checking,Available,Downloading,Ready,Failed,Unconfigured,Queued};
 struct State {Phase phase=Idle;juce::String version,message;juce::File installer;};
 Updates();~Updates()override;
 State snapshot();void check();void download();void install();
private:
 friend struct UpdateDownloadProbe;
 void run()override;void launchInstaller();bool fetch(const juce::String&,juce::MemoryBlock&,juce::int64 limit,const juce::File&destination={});
 void* installerProcess=nullptr;void* instanceMutex=nullptr;
 juce::ChildProcess macInstaller;
 std::mutex mutex,networkMutex;State state;UpdateRelease release;juce::WebInputStream*active=nullptr;int action=1;
};
}
