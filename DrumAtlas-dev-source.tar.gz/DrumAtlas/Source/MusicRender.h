#pragma once
#include "MusicCore.h"
namespace atlas::music {
// Offline only: assigned one-shots or a simple original synthesis fallback.
juce::Result renderWav(const Project&,const juce::File&,double sampleRate=44100,const std::function<bool()>&cancel={});
}
