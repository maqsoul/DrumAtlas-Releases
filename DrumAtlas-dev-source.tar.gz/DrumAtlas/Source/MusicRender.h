#pragma once
#include "MusicCore.h"
namespace atlas::music {
// Offline only: assigned one-shots or a simple original synthesis fallback.
juce::Result renderWav(const Project&,const juce::File&,double sampleRate=44100,const std::function<bool()>&cancel={});
struct StemExportOptions { double sampleRate=44100; int bits=24; bool perTrack=false; };
// New folder only; aligned files, common gain and manifest. No partial bundle on failure.
juce::Result renderStems(const Project&,const juce::File&,const StemExportOptions& options={},const std::function<bool()>&cancel={});
}
