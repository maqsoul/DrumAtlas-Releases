#include <juce_audio_formats/juce_audio_formats.h>
#if JUCE_WINDOWS
#define NOMINMAX
#include "Formats.h"
#include <windows.h>
#include <mfapi.h>
#include <mfidl.h>
#include <mfreadwrite.h>
#include <propvarutil.h>
#include <wrl/client.h>
#include <mutex>
namespace atlas {
using Microsoft::WRL::ComPtr;
struct ComScope { HRESULT hr=CoInitializeEx(nullptr,COINIT_MULTITHREADED); ~ComScope(){if(SUCCEEDED(hr))CoUninitialize();} };
// Media Foundation's URL resolver does not accept every extended Win32 path.
// Supply the already-open seekable stream instead of opening the path again.
class InputBridge final:public IStream {
public:
 explicit InputBridge(juce::InputStream*s):input(s){}
 HRESULT STDMETHODCALLTYPE QueryInterface(REFIID id,void**out)override{if(!out)return E_POINTER;*out=nullptr;if(id==IID_IUnknown||id==IID_IStream||id==IID_ISequentialStream){*out=static_cast<IStream*>(this);AddRef();return S_OK;}return E_NOINTERFACE;}
 ULONG STDMETHODCALLTYPE AddRef()override{return ++references;}
 ULONG STDMETHODCALLTYPE Release()override{auto n=--references;if(!n)delete this;return n;}
 HRESULT STDMETHODCALLTYPE Read(void*buffer,ULONG bytes,ULONG*read)override{std::lock_guard<std::mutex>g(mutex);int n=input->read(buffer,int(std::min<ULONG>(bytes,INT_MAX)));if(read)*read=ULONG(std::max(0,n));return n<0?STG_E_READFAULT:ULONG(n)==bytes?S_OK:S_FALSE;}
 HRESULT STDMETHODCALLTYPE Seek(LARGE_INTEGER offset,DWORD origin,ULARGE_INTEGER*position)override{std::lock_guard<std::mutex>g(mutex);if(origin>STREAM_SEEK_END)return STG_E_INVALIDFUNCTION;auto at=offset.QuadPart+(origin==STREAM_SEEK_CUR?input->getPosition():origin==STREAM_SEEK_END?input->getTotalLength():0);if(at<0||!input->setPosition(at))return STG_E_SEEKERROR;if(position)position->QuadPart=input->getPosition();return S_OK;}
 HRESULT STDMETHODCALLTYPE Stat(STATSTG*out,DWORD)override{if(!out)return E_POINTER;std::lock_guard<std::mutex>g(mutex);*out={};out->type=STGTY_STREAM;out->cbSize.QuadPart=input->getTotalLength();out->grfMode=STGM_READ;return S_OK;}
 HRESULT STDMETHODCALLTYPE Write(const void*,ULONG,ULONG*)override{return STG_E_ACCESSDENIED;}
 HRESULT STDMETHODCALLTYPE SetSize(ULARGE_INTEGER)override{return STG_E_ACCESSDENIED;}
 HRESULT STDMETHODCALLTYPE CopyTo(IStream*,ULARGE_INTEGER,ULARGE_INTEGER*,ULARGE_INTEGER*)override{return E_NOTIMPL;}
 HRESULT STDMETHODCALLTYPE Commit(DWORD)override{return S_OK;}
 HRESULT STDMETHODCALLTYPE Revert()override{return E_NOTIMPL;}
 HRESULT STDMETHODCALLTYPE LockRegion(ULARGE_INTEGER,ULARGE_INTEGER,DWORD)override{return E_NOTIMPL;}
 HRESULT STDMETHODCALLTYPE UnlockRegion(ULARGE_INTEGER,ULARGE_INTEGER,DWORD)override{return E_NOTIMPL;}
 HRESULT STDMETHODCALLTYPE Clone(IStream**)override{return E_NOTIMPL;}
private:juce::InputStream*input;std::atomic<ULONG>references{1};std::mutex mutex;
};
class MediaReader final:public juce::AudioFormatReader {
public:
 MediaReader(juce::InputStream*stream,ComPtr<IMFSourceReader> r,double rate,unsigned channels,juce::int64 frames)
 :AudioFormatReader(stream,"Windows Media Foundation"),reader(std::move(r)){sampleRate=rate;numChannels=channels;lengthInSamples=frames;bitsPerSample=32;usesFloatingPointData=true;}
 bool readSamples(int*const*dest,int channels,int offset,juce::int64 start,int count)override{
   ComScope com;clearSamplesBeyondAvailableLength(dest,channels,offset,start,count,lengthInSamples);if(count<=0)return true;
   for(int c=0;c<channels;++c)if(dest[c])std::fill_n(reinterpret_cast<float*>(dest[c])+offset,count,0.f);
   PROPVARIANT position;InitPropVariantFromInt64(juce::int64(start*10000000.0/sampleRate),&position);
   auto hr=reader->SetCurrentPosition(GUID_NULL,position);PropVariantClear(&position);if(FAILED(hr))return false;
   const auto end=start+count;int empty=0;
   for(;;){DWORD flags=0;LONGLONG time=0;ComPtr<IMFSample> sample;
     hr=reader->ReadSample(MF_SOURCE_READER_FIRST_AUDIO_STREAM,0,nullptr,&flags,&time,&sample);
     if(FAILED(hr)||(flags&MF_SOURCE_READERF_ERROR))return false;
     if(sample){ComPtr<IMFMediaBuffer> buffer;if(FAILED(sample->ConvertToContiguousBuffer(&buffer)))return false;BYTE*bytes=nullptr;DWORD size=0;
       if(FAILED(buffer->Lock(&bytes,nullptr,&size)))return false;
       auto first=juce::int64(std::llround(time*sampleRate/10000000.0));auto n=juce::int64(size/(sizeof(float)*numChannels));
       auto lo=std::max(first,start),hi=std::min(first+n,end);auto*values=reinterpret_cast<const float*>(bytes);
       for(int c=0;c<channels;++c)if(dest[c]&&unsigned(c)<numChannels){auto*out=reinterpret_cast<float*>(dest[c])+offset;for(auto i=lo;i<hi;++i)out[i-start]=values[(i-first)*numChannels+c];}
       buffer->Unlock();if(first+n>=end)return true;empty=0;
     }else if(++empty>256)return false;
     if(flags&MF_SOURCE_READERF_ENDOFSTREAM)return true;
   }
 }
private:ComPtr<IMFSourceReader> reader;
};
class MediaFormat final:public juce::AudioFormat {
public:
 MediaFormat():AudioFormat("Windows Media Foundation","m4a mp4 aac wma wav mp3"){}
 bool canHandleFile(const juce::File&)override{return true;}
 juce::Array<int>getPossibleSampleRates()override{return {22050,44100,48000,96000};}
 juce::Array<int>getPossibleBitDepths()override{return {16,24,32};}
 bool canDoStereo()override{return true;}bool canDoMono()override{return true;}
 juce::AudioFormatReader*createReaderFor(juce::InputStream*s,bool deleteOnFail)override{
   ComScope com;static std::once_flag once;static HRESULT startup=E_FAIL;std::call_once(once,[]{startup=MFStartup(MF_VERSION,MFSTARTUP_FULL);});
   ComPtr<IMFSourceReader> reader;ComPtr<IMFMediaType> wanted,actual;ComPtr<IStream>bridge;bridge.Attach(new InputBridge(s));ComPtr<IMFByteStream>bytes;s->setPosition(0);
   if(SUCCEEDED(startup)&&SUCCEEDED(MFCreateMFByteStreamOnStream(bridge.Get(),&bytes))&&SUCCEEDED(MFCreateSourceReaderFromByteStream(bytes.Get(),nullptr,&reader))&&SUCCEEDED(MFCreateMediaType(&wanted))){
     reader->SetStreamSelection(MF_SOURCE_READER_ALL_STREAMS,FALSE);reader->SetStreamSelection(MF_SOURCE_READER_FIRST_AUDIO_STREAM,TRUE);
     wanted->SetGUID(MF_MT_MAJOR_TYPE,MFMediaType_Audio);wanted->SetGUID(MF_MT_SUBTYPE,MFAudioFormat_Float);
     if(SUCCEEDED(reader->SetCurrentMediaType(MF_SOURCE_READER_FIRST_AUDIO_STREAM,nullptr,wanted.Get()))&&SUCCEEDED(reader->GetCurrentMediaType(MF_SOURCE_READER_FIRST_AUDIO_STREAM,&actual))){
       UINT32 rate=0,channels=0;actual->GetUINT32(MF_MT_AUDIO_SAMPLES_PER_SECOND,&rate);actual->GetUINT32(MF_MT_AUDIO_NUM_CHANNELS,&channels);PROPVARIANT duration;PropVariantInit(&duration);
       auto hr=reader->GetPresentationAttribute(MF_SOURCE_READER_MEDIASOURCE,MF_PD_DURATION,&duration);ULONGLONG ticks=0;if(SUCCEEDED(hr))hr=PropVariantToUInt64(duration,&ticks);PropVariantClear(&duration);
       if(SUCCEEDED(hr)&&rate>=1000&&rate<=768000&&channels>0&&channels<=64&&ticks>0)return new MediaReader(s,reader,rate,channels,juce::int64(ticks*double(rate)/10000000.0));
     }
   }
   reader.Reset();bytes.Reset();bridge.Reset();if(deleteOnFail)delete s;return nullptr;
 }
 std::unique_ptr<juce::AudioFormatWriter>createWriterFor(std::unique_ptr<juce::OutputStream>&,const juce::AudioFormatWriterOptions&)override{return {};}
};
void registerMediaFoundation(juce::AudioFormatManager&fm){fm.registerFormat(new MediaFormat(),false);}
}

#else
namespace atlas { void registerMediaFoundation(juce::AudioFormatManager&){} }
#endif
