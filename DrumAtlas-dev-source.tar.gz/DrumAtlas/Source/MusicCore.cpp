#include "MusicCore.h"
#include <algorithm>
#include <cmath>
#include <set>
#include <stdexcept>

namespace atlas::music {
namespace {
// Defined integer PRNG, independent of std::uniform_distribution implementations.
struct Random { uint32_t state; uint32_t next(){state=state*1664525u+1013904223u;return state;} int bounded(int n){return int(next()%uint32_t(n));} };
uint32_t roleHash(const juce::String& role){uint32_t h=2166136261u;for(auto c:role.toStdString()){h^=uint8_t(c);h*=16777619u;}return h;}
juce::var object(){return new juce::DynamicObject();}
void put(juce::var&v,const char*k,const juce::var&x){v.getDynamicObject()->setProperty(k,x);}
bool number(const juce::var&v){return v.isInt()||v.isInt64()||v.isDouble();}
bool integer(const juce::var&v){return v.isInt()||v.isInt64();}
juce::Result fail(const char*s){return juce::Result::fail(s);}
juce::Result resolveStyle(const juce::var&snapshot,StyleBlend&style){
    if(!snapshot.isObject()||!snapshot["genres"].isArray()||!snapshot["moods"].isArray())return fail("Missing style snapshot");
    ProfileRegistry registry;auto r=registry.decode(snapshot["registry"]);if(r.failed())return r;
    std::vector<StyleWeight>genres,moods;
    for(auto key:{"genres","moods"}){if(snapshot[key].size()>64)return fail("Too many profile weights");for(auto&w:*snapshot[key].getArray()){if(!w["id"].isString()||!number(w["weight"]))return fail("Invalid profile weight");(juce::String(key)=="genres"?genres:moods).push_back({w["id"].toString(),double(w["weight"])});}}
    return registry.blend(genres,moods,style);
}
Track makeStyledTrack(const Settings&s,const StyleBlend&style,const juce::String&role){
    Track t;t.id="track-"+role;t.role=role;Random r{s.seed^roleHash(role)};const auto bar=barTicks(s);
    const bool melodic=role=="Bass"||role=="Chords"||role=="Melody";
    const double energy=(s.energy+style.mood.energy)*.5,complexity=(s.complexity+style.mood.complexity)*.5;
    auto add=[&](int b,int step,int pitch,int64_t duration,int velocity){
        Note n;n.id=t.id+"-"+juce::String(int(t.notes.size()));n.channel=melodic?1:10;n.pitch=juce::jlimit(0,127,pitch);n.tick=b*bar+bar*step/16;
        if(step%2)n.tick+=int64_t(bar/16*(s.swing+style.genre.swing)*.225*s.groove);
        n.duration=std::min(duration,(b+1)*bar-n.tick);n.velocity=juce::jlimit(1,127,int(velocity*(.65+.7*energy))+r.bounded(9)-4);
        n.microtiming=int64_t((r.bounded(41)-20)*s.humanize);n.microtiming=juce::jlimit(-n.tick,bar*s.bars-n.tick-n.duration,n.microtiming);t.notes.push_back(n);
    };
    const int minor[]{0,2,3,5,7,8,10},major[]{0,2,4,5,7,9,11};const auto*scale=s.scale=="major"?major:minor;
    const int progression[]{0,5,3,4};
    for(int b=0;b<s.bars;++b){
        const int degree=progression[b%4],root=36+s.tonic+scale[degree];
        auto chordNote=[&](int d){return 48+s.tonic+scale[d%7]+12*(d/7);};
        if(role=="Chords"){for(int interval:{0,2,4})add(b,0,chordNote(degree+interval),std::max<int64_t>(1,int64_t(bar*(.45+.5*(1-style.mood.articulation)))),64);if(complexity>.6)add(b,0,chordNote(degree+6),bar*3/4,55);}
        else if(role=="Bass"){for(int step=0;step<16;++step)if(style.genre.kick[size_t(step)]>.5){int next=step+1;while(next<16&&style.genre.kick[size_t(next)]<=.5)++next;add(b,step,root-12,std::max<int64_t>(1,bar*(next-step)/16-10),95);}}
        else if(role=="Melody"){
            const double density=(s.melodicDensity+style.mood.melodicDensity)*.5;
            for(int step=0;step<16;step+=complexity>.65?2:4)if(double(r.next())/4294967296.<density){int d=(degree+r.bounded(complexity>.5?7:3))%7;int octave=(s.darkness+style.mood.darkness)>1.2?48:60;add(b,step,octave+s.tonic+scale[d],bar/8,75);}
        }else{
            for(int step=0;step<16;++step){double chance=0;int pitch=36,velocity=100;
                if(role=="Kick")chance=style.genre.kick[size_t(step)];
                else if(role=="Snare"||role=="Clap"){chance=style.genre.snare[size_t(step)];pitch=role=="Snare"?38:39;velocity=role=="Snare"?100:65;}
                else if(role=="Closed Hat"){chance=style.genre.hat[size_t(step)];pitch=42;velocity=step%4?65:82;}
                else if(role=="Open Hat"){chance=step%8==6?.5:0;pitch=46;velocity=72;}
                else if(role=="Percussion"){chance=step%4==3?.4*complexity:0;pitch=64;velocity=60;}
                chance*=juce::jlimit(0.,1.5,(s.density+style.genre.density));
                if(double(r.next())/4294967296.<chance)add(b,step,pitch,std::min<int64_t>(120,bar/16),velocity);
            }
        }
    }return t;
}
Track makeTrack(const Settings&s,const juce::String&role){
    Track t;t.id="track-"+role;t.role=role;
    Random r{s.seed^roleHash(role)};const auto bar=barTicks(s);
    auto add=[&](int b,int64_t offset,int pitch,int64_t duration,int velocity,bool anchor=false){
        Note n;n.id=t.id+"-"+juce::String(b)+"-"+juce::String(int(t.notes.size()));n.pitch=pitch;n.channel=(role=="Bass"||role=="Chords"||role=="Melody")?1:10;
        n.tick=b*bar+offset;n.duration=std::min(duration,bar-offset);n.velocity=juce::jlimit(1,127,velocity+r.bounded(11)-5);
        if(!anchor)n.microtiming=int64_t((r.bounded(41)-20)*s.humanize);
        n.microtiming=std::max(-n.tick,std::min(n.microtiming,bar*s.bars-n.tick-n.duration));t.notes.push_back(n);
    };
    const int roots[]={0,8,5,7};const int intervals[]={0,2,3,5,7,8,10};
    for(int b=0;b<s.bars;++b){
        const int root=36+s.tonic+roots[b%4];
        if(role=="Kick"){add(b,0,36,120,112,true);if(s.density>.25)add(b,bar*3/8,36,120,94);if(s.density>.6||b%2)add(b,bar*13/16,36,120,103);}
        else if(role=="Snare"||role=="Clap"){add(b,bar/2,role=="Snare"?38:39,120,role=="Snare"?105:75,true);}
        else if(role=="Closed Hat"){
            const int steps=s.density>.65?16:8;
            for(int i=0;i<steps;++i){if(i==steps-1)continue;int64_t tick=bar*i/steps;if(i%2)tick+=int64_t((bar/steps)*s.swing*.45);add(b,tick,42,90,i%2?64:84);}
        }else if(role=="Open Hat")add(b,bar*7/8,46,std::min<int64_t>(240,bar/8),75);
        else if(role=="Percussion"){if(s.density>.3)add(b,bar*11/16,64,120,65);}
        else if(role=="Bass"){add(b,0,root-12,bar*3/8,100,true);add(b,bar/2,root-12,bar*3/8,92,true);}
        else if(role=="Chords"){
            // A-minor family: Am(add9), Fmaj7, Dm9, Em7, transposed by tonic.
            const std::vector<std::vector<int>> chords{{0,3,7,14},{0,4,7,11},{0,3,7,10,14},{0,3,7,10}};
            for(int n:chords[size_t(b%4)])add(b,0,root+12+n,bar-120,68,true);
        }else if(role=="Melody"){
            for(int i=0;i<4;++i){if(i==2&&b%2==0)continue;int degree=(i+(b%2?2:0))%7;add(b,bar*i/4,60+s.tonic+intervals[degree],bar/8,80);}
        }
    }
    std::stable_sort(t.notes.begin(),t.notes.end(),[](const Note&a,const Note&b){return a.tick<b.tick;});return t;
}
}
int64_t barTicks(const Settings&s){return int64_t(ppq)*4*s.numerator/s.denominator;}
bool validGrid(int steps){return steps==16||steps==32||steps==64||steps==12||steps==24||steps==48;}
int64_t gridTick(const Settings&s,int bar,int step,int steps){if(!validGrid(steps)||bar<0||bar>=s.bars||step<0||step>steps)return -1;return barTicks(s)*bar+barTicks(s)*step/steps;}
juce::Result editNote(Project&p,const juce::String&track,const Note&note){
    auto next=p;auto t=std::find_if(next.tracks.begin(),next.tracks.end(),[&](const Track&t){return t.id==track;});
    if(t==next.tracks.end()||t->midiLocked)return fail("Missing or locked MIDI track");
    auto n=std::find_if(t->notes.begin(),t->notes.end(),[&](const Note&n){return n.id==note.id;});if(n==t->notes.end())t->notes.push_back(note);else *n=note;
    std::stable_sort(t->notes.begin(),t->notes.end(),[](const Note&a,const Note&b){return a.tick<b.tick;});auto r=validate(next);if(r.wasOk())p=std::move(next);return r;
}
juce::Result removeNote(Project&p,const juce::String&track,const juce::String&note){
    auto next=p;auto t=std::find_if(next.tracks.begin(),next.tracks.end(),[&](const Track&t){return t.id==track;});if(t==next.tracks.end()||t->midiLocked)return fail("Missing or locked MIDI track");
    auto n=std::find_if(t->notes.begin(),t->notes.end(),[&](const Note&n){return n.id==note;});if(n==t->notes.end())return fail("Note not found");t->notes.erase(n);auto r=validate(next);if(r.wasOk())p=std::move(next);return r;
}
juce::Result copyBars(Project&p,const juce::String&track,int first,int end,int destination){
    auto r=validate(p);if(r.failed())return r;if(first<0||end<=first||end>p.settings.bars||destination<0||destination>p.settings.bars-(end-first))return fail("Invalid copy range");
    auto next=p;auto t=std::find_if(next.tracks.begin(),next.tracks.end(),[&](const Track&t){return t.id==track;});if(t==next.tracks.end()||t->midiLocked)return fail("Missing or locked MIDI track");
    auto bar=barTicks(p.settings),begin=bar*first,finish=bar*end,dest=bar*destination;std::vector<Note>copied;
    for(auto n:t->notes)if(n.tick>=begin&&n.tick<finish){n.id=juce::Uuid().toString();n.duration=std::min(n.duration,finish-n.tick);n.tick+=dest-begin;n.microtiming=juce::jlimit(-n.tick,bar*p.settings.bars-n.tick-n.duration,n.microtiming);copied.push_back(n);}
    t->notes.erase(std::remove_if(t->notes.begin(),t->notes.end(),[&](const Note&n){return n.tick>=dest&&n.tick<dest+finish-begin;}),t->notes.end());t->notes.insert(t->notes.end(),copied.begin(),copied.end());
    std::stable_sort(t->notes.begin(),t->notes.end(),[](const Note&a,const Note&b){return a.tick<b.tick;});r=validate(next);if(r.wasOk())p=std::move(next);return r;
}
juce::Result validate(const Settings&s){
    if(!std::isfinite(s.bpm)||s.bpm<20||s.bpm>300)return fail("BPM must be 20..300");
    if(s.bars<1||s.bars>256||s.numerator<1||s.numerator>12||(s.denominator!=4&&s.denominator!=8))return fail("Invalid bars or meter");
    if(s.tonic<0||s.tonic>11)return fail("Invalid key");
    for(double x:{s.swing,s.humanize,s.density,s.energy,s.darkness,s.complexity,s.groove,s.melodicDensity})if(!std::isfinite(x)||x<0||x>1)return fail("Control outside 0..1");
    // Explicit supported scope; unknown styles must not silently generate a claimed profile.
    if(s.scale!="minor"&&s.scale!="major")return fail("Supported scales: minor / major");
    if(s.genre.isEmpty()||s.mood.isEmpty())return fail("Missing style");
    return juce::Result::ok();
}
juce::Result validate(const Project&p){
    auto result=validate(p.settings);if(result.failed())return result;
    if(p.id.isEmpty()||(p.generatorVersion!="rules-1"&&p.generatorVersion!="profiles-1")||p.tracks.size()>128)return fail("Unsupported project identity, generator or track count");
    if(p.generatorVersion=="rules-1"&&(p.settings.genre!="Trap"||p.settings.mood!="Dark"||p.settings.scale!="minor"))return fail("Invalid legacy generator style");
    if(p.generatorVersion=="profiles-1"){StyleBlend style;auto r=resolveStyle(p.styleSnapshot,style);if(r.failed())return r;if(p.settings.genre!=style.genre.id||p.settings.mood!=style.mood.id)return fail("Style snapshot identity mismatch");}
    std::set<juce::String> ids;const auto end=barTicks(p.settings)*p.settings.bars;
    size_t instrumentBytes=0;
    for(const auto&t:p.tracks){if(t.id.isEmpty()||!ids.insert(t.id).second||t.notes.size()>100000)return fail("Invalid track ID or event count");
        if(!t.instrument.isVoid()){
            if(!t.instrument.isObject()||!integer(t.instrument["schema"])||int(t.instrument["schema"])!=1)return fail("Invalid instrument schema");
            for(auto key:{"path","uid","name","xml","state","sha256"})if(!t.instrument[key].isString())return fail("Invalid instrument field");
            if(!juce::File::isAbsolutePath(t.instrument["path"].toString())||t.instrument["uid"].toString().isEmpty()||t.instrument["xml"].toString().length()>65536||t.instrument["sha256"].toString().length()!=64)return fail("Invalid instrument identity");
            instrumentBytes+=size_t(t.instrument["state"].toString().length());if(instrumentBytes>48*1024*1024)return fail("Instrument states exceed project size budget");
        }
        for(const auto&n:t.notes){if(n.id.isEmpty()||!ids.insert(n.id).second)return fail("Duplicate or empty event ID");
            if(n.tick<0||n.tick>=end||n.duration<=0||n.duration>end-n.tick||n.microtiming < -n.tick||n.microtiming>end-n.tick-n.duration||n.pitch<0||n.pitch>127||n.velocity<1||n.velocity>127||n.channel<1||n.channel>16||!std::isfinite(n.probability)||n.probability<0||n.probability>1)return fail("Invalid MIDI event");}
    }return juce::Result::ok();
}
Project generate(const Settings&s){auto v=validate(s);if(s.genre!="Trap"||s.mood!="Dark"||s.scale!="minor")throw std::invalid_argument("Legacy generator requires Trap / Dark / minor");if(v.failed())throw std::invalid_argument(v.getErrorMessage().toStdString());Project p;p.id=juce::Uuid().toString();p.settings=s;for(auto role:{"Kick","Snare","Clap","Closed Hat","Open Hat","Percussion","Bass","Chords","Melody"})p.tracks.push_back(makeTrack(s,role));return p;}
juce::Result generateStyled(const Settings&s,const ProfileRegistry&registry,const std::vector<StyleWeight>&genres,const std::vector<StyleWeight>&moods,Project&target){
    auto r=validate(s);if(r.failed())return r;StyleBlend style;r=registry.blend(genres,moods,style);if(r.failed())return r;
    Project p;p.id=juce::Uuid().toString();p.generatorVersion="profiles-1";p.settings=s;p.settings.genre=style.genre.id;p.settings.mood=style.mood.id;p.styleSnapshot=object();put(p.styleSnapshot,"registry",registry.encode());
    for(auto key:{"genres","moods"}){juce::Array<juce::var>weights;for(const auto&w:juce::String(key)=="genres"?style.genres:style.moods){auto v=object();put(v,"id",w.id);put(v,"weight",w.weight);weights.add(v);}put(p.styleSnapshot,key,weights);}
    for(auto role:{"Kick","Snare","Clap","Closed Hat","Open Hat","Percussion","Bass","Chords","Melody"})p.tracks.push_back(makeStyledTrack(p.settings,style,role));
    r=validate(p);if(r.wasOk())target=std::move(p);return r;
}
juce::Result regenerate(Project&p,const juce::String&id,int first,int last,uint32_t seed){
    auto valid=validate(p);if(valid.failed())return valid;
    if(first<0||last<=first||last>p.settings.bars)return fail("Invalid bar range");
    auto next=p;auto it=std::find_if(next.tracks.begin(),next.tracks.end(),[&](const Track&t){return t.id==id;});
    if(it==next.tracks.end())return fail("Track not found");if(it->midiLocked)return fail("Track MIDI is locked");
    if(!juce::StringArray{"Kick","Snare","Clap","Closed Hat","Open Hat","Percussion","Bass","Chords","Melody"}.contains(it->role))return fail("No generator for this track role");
    Settings s=p.settings;s.seed=seed;Track replacement;
    if(p.generatorVersion=="profiles-1"){StyleBlend style;auto r=resolveStyle(p.styleSnapshot,style);if(r.failed())return r;replacement=makeStyledTrack(s,style,it->role);}else replacement=makeTrack(s,it->role);
    const auto begin=first*barTicks(s),end=last*barTicks(s);
    it->notes.erase(std::remove_if(it->notes.begin(),it->notes.end(),[&](const Note&n){return n.tick>=begin&&n.tick<end;}),it->notes.end());
    for(auto n:replacement.notes)if(n.tick>=begin&&n.tick<end){n.id=p.id+":"+id+":"+juce::String(first)+":"+juce::String(last)+":"+juce::String(juce::int64(seed))+":"+n.id;it->notes.push_back(n);}
    std::stable_sort(it->notes.begin(),it->notes.end(),[](const Note&a,const Note&b){return a.tick<b.tick;});
    valid=validate(next);if(valid.failed())return valid;p=std::move(next);return juce::Result::ok();
}
juce::var encode(const Project&p){
    auto o=object();bool instruments=false;for(const auto&t:p.tracks)instruments|=!t.instrument.isVoid();put(o,"schema_version",instruments?2:1);put(o,"ppq",ppq);put(o,"project_id",p.id);put(o,"generator_version",p.generatorVersion);
    auto s=object();put(s,"bpm",p.settings.bpm);put(s,"bars",p.settings.bars);put(s,"numerator",p.settings.numerator);put(s,"denominator",p.settings.denominator);put(s,"tonic",p.settings.tonic);put(s,"seed",juce::int64(p.settings.seed));put(s,"genre",p.settings.genre);put(s,"mood",p.settings.mood);put(s,"scale",p.settings.scale);put(s,"swing",p.settings.swing);put(s,"humanize",p.settings.humanize);put(s,"density",p.settings.density);put(s,"energy",p.settings.energy);put(s,"darkness",p.settings.darkness);put(s,"complexity",p.settings.complexity);put(s,"groove",p.settings.groove);put(s,"melodic_density",p.settings.melodicDensity);put(o,"settings",s);
    juce::Array<juce::var> tracks;
    for(const auto&t:p.tracks){auto a=object();put(a,"id",t.id);put(a,"role",t.role);put(a,"sound",t.soundPath);if(!t.instrument.isVoid())put(a,"instrument",t.instrument.clone());put(a,"midi_locked",t.midiLocked);put(a,"sound_locked",t.soundLocked);juce::Array<juce::var>notes;
        for(const auto&n:t.notes){auto b=object();put(b,"id",n.id);put(b,"pitch",n.pitch);put(b,"velocity",n.velocity);put(b,"channel",n.channel);put(b,"tick",juce::int64(n.tick));put(b,"duration",juce::int64(n.duration));put(b,"microtiming",juce::int64(n.microtiming));put(b,"probability",n.probability);notes.add(b);}put(a,"notes",notes);tracks.add(a);}
    put(o,"tracks",tracks);if(!p.styleSnapshot.isVoid())put(o,"style_snapshot",p.styleSnapshot.clone());return o;
}
juce::Result decode(const juce::var&o,Project&target){
    if(!o.isObject()||!integer(o["schema_version"])||(int(o["schema_version"])!=1&&int(o["schema_version"])!=2)||int(o["ppq"])!=ppq||!o["settings"].isObject()||!o["tracks"].isArray())return fail("Unsupported project schema");
    Project p;p.id=o["project_id"].toString();p.generatorVersion=o["generator_version"].toString();auto s=o["settings"];
    for(auto key:{"bpm","swing","humanize","density"})if(!number(s[key]))return fail("Missing numeric setting");
    for(auto key:{"bars","numerator","denominator","tonic","seed"})if(!integer(s[key]))return fail("Missing integer setting");
    auto seed=juce::int64(s["seed"]);if(seed<0||seed>4294967295LL)return fail("Invalid seed");
    p.settings.bpm=double(s["bpm"]);p.settings.bars=int(s["bars"]);p.settings.numerator=int(s["numerator"]);p.settings.denominator=int(s["denominator"]);p.settings.tonic=int(s["tonic"]);p.settings.seed=uint32_t(seed);p.settings.genre=s["genre"].toString();p.settings.mood=s["mood"].toString();p.settings.scale=s["scale"].toString();p.settings.swing=double(s["swing"]);p.settings.humanize=double(s["humanize"]);p.settings.density=double(s["density"]);
    for(auto key:{"energy","darkness","complexity","groove","melodic_density"})if(s.hasProperty(key)&&!number(s[key]))return fail("Invalid expression setting");
    p.settings.energy=double(s.getProperty("energy",.5));p.settings.darkness=double(s.getProperty("darkness",.5));p.settings.complexity=double(s.getProperty("complexity",.5));p.settings.groove=double(s.getProperty("groove",.5));p.settings.melodicDensity=double(s.getProperty("melodic_density",.5));p.styleSnapshot=o["style_snapshot"].clone();
    if(o["tracks"].size()>128)return fail("Too many tracks");
    for(auto&a:*o["tracks"].getArray()){
        if(!a.isObject()||!a["notes"].isArray()||a["notes"].size()>100000||!a["midi_locked"].isBool()||!a["sound_locked"].isBool())return fail("Invalid track");
        Track t;t.id=a["id"].toString();t.role=a["role"].toString();t.soundPath=a["sound"].toString();t.midiLocked=bool(a["midi_locked"]);t.soundLocked=bool(a["sound_locked"]);
        if(a.hasProperty("instrument")){if(int(o["schema_version"])!=2)return fail("Instrument requires schema 2");t.instrument=a["instrument"].clone();}
        for(auto&b:*a["notes"].getArray()){
            for(auto key:{"pitch","velocity","channel","tick","duration","microtiming"})if(!integer(b[key]))return fail("Invalid MIDI field type");
            if(!number(b["probability"]))return fail("Invalid probability type");
            Note n;n.id=b["id"].toString();n.pitch=int(b["pitch"]);n.velocity=int(b["velocity"]);n.channel=int(b["channel"]);n.tick=juce::int64(b["tick"]);n.duration=juce::int64(b["duration"]);n.microtiming=juce::int64(b["microtiming"]);n.probability=double(b["probability"]);t.notes.push_back(n);
        }p.tracks.push_back(t);
    }auto result=validate(p);if(result.wasOk())target=std::move(p);return result;
}
juce::Result save(const Project&p,const juce::File&f){auto v=validate(p);if(v.failed())return v;juce::TemporaryFile tmp(f);if(!tmp.getFile().replaceWithText(juce::JSON::toString(encode(p)))||!tmp.overwriteTargetFileWithTemporary())return fail("Cannot save project");return juce::Result::ok();}
juce::Result load(const juce::File&f,Project&p){if(!f.existsAsFile()||f.getSize()>64*1024*1024)return fail("Missing or oversized project");juce::var v;auto result=juce::JSON::parse(f.loadFileAsString(),v);return result.failed()?result:decode(v,p);}
juce::Result exportMidi(const Project&p,const juce::File&f){
    auto v=validate(p);if(v.failed())return v;juce::MidiFile midi;midi.setTicksPerQuarterNote(ppq);juce::MidiMessageSequence conductor;
    conductor.addEvent(juce::MidiMessage::tempoMetaEvent(int(std::round(60000000./p.settings.bpm))));conductor.addEvent(juce::MidiMessage::timeSignatureMetaEvent(p.settings.numerator,p.settings.denominator));
    auto end=juce::MidiMessage::endOfTrack();end.setTimeStamp(double(barTicks(p.settings)*p.settings.bars));conductor.addEvent(end);midi.addTrack(conductor);
    for(const auto&t:p.tracks){juce::MidiMessageSequence seq;seq.addEvent(juce::MidiMessage::textMetaEvent(3,t.role));Random r{p.settings.seed^roleHash(t.id)};
        for(const auto&n:t.notes){if(double(r.next())/4294967296.>=n.probability)continue;auto on=juce::MidiMessage::noteOn(n.channel,n.pitch,juce::uint8(n.velocity));on.setTimeStamp(double(n.tick+n.microtiming));seq.addEvent(on);auto off=juce::MidiMessage::noteOff(n.channel,n.pitch);off.setTimeStamp(double(n.tick+n.microtiming+n.duration));seq.addEvent(off);}seq.addEvent(end);seq.updateMatchedPairs();midi.addTrack(seq);}
    juce::TemporaryFile tmp(f);{juce::FileOutputStream out(tmp.getFile());if(out.failedToOpen()||!midi.writeTo(out,1))return fail("Cannot write MIDI");out.flush();if(out.getStatus().failed())return out.getStatus();}return tmp.overwriteTargetFileWithTemporary()?juce::Result::ok():fail("Cannot replace MIDI file");
}
juce::Result History::apply(Project p){auto v=validate(p);if(v.failed())return v;past.push_back(current);if(past.size()>64)past.erase(past.begin());current=std::move(p);future.clear();return juce::Result::ok();}
bool History::undo(){if(past.empty())return false;future.push_back(current);current=std::move(past.back());past.pop_back();return true;}
bool History::redo(){if(future.empty())return false;past.push_back(current);current=std::move(future.back());future.pop_back();return true;}
}
