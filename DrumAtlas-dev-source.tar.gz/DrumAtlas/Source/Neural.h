#pragma once
#include "Analysis.h"
#include <memory>
namespace atlas {
struct NeuralResult {
    std::vector<std::pair<juce::String, float>> instruments;
    juce::StringArray genres;
    std::vector<uint8_t> embedding;
    bool valid = false;
};
class Neural {
public:
    Neural(); ~Neural();
    bool available() const;
    juce::String error() const;
    NeuralResult analyse(const std::vector<float>& audio);
private:
    struct Impl; std::unique_ptr<Impl> impl;
};
juce::StringArray genreNames();
juce::StringArray genreTags(const juce::String& name);
class DetailSeparator {
public:
 enum Mode{Drums,Percussion};explicit DetailSeparator(Mode);~DetailSeparator();
 bool available()const;juce::String error()const;juce::String backend()const;
 // Drums: planar stereo 44100 Hz, 130560 frames, 6 outputs.
 // Percussion: mono 32000 Hz, arbitrary segment, one query-conditioned output.
 std::vector<std::vector<float>> drums(const std::vector<float>&);
 std::vector<float> percussion(const std::vector<float>&,const juce::String&);
private:struct Impl;std::unique_ptr<Impl>impl;
};
class StemSeparator {
public:
 static constexpr int frames=343980;
 StemSeparator();~StemSeparator();
 bool available()const;juce::String error()const;
 // Planar stereo at 44.1 kHz, padded to frames; six planar stereo outputs.
 std::vector<std::vector<float>> process(const std::vector<float>& stereo);
private:struct Impl;std::unique_ptr<Impl>impl;
};
}
