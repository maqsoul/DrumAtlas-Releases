#pragma once
#include "MusicCore.h"
#include <juce_audio_formats/juce_audio_formats.h>
#include <cmath>

namespace atlas::music::instruments {
inline juce::File workerFile(){
    auto overridePath=juce::SystemStats::getEnvironmentVariable("DRUMATLAS_WORKER",{});
    if(juce::File::isAbsolutePath(overridePath))return juce::File(overridePath);
    auto exe=juce::File::getSpecialLocation(juce::File::currentExecutableFile).getParentDirectory();
   #if JUCE_WINDOWS
    const juce::String name="AtlasWorker.exe";
    auto installed=juce::File::getSpecialLocation(juce::File::globalApplicationsDirectory).getChildFile("DrumAtlas/Tools/"+name);
   #else
    const juce::String name="AtlasWorker";
    auto installed=juce::File("/Library/Application Support/DrumAtlas/Tools/"+name);
   #endif
    for(auto file:{exe.getChildFile("Tools/"+name),exe.getParentDirectory().getChildFile("Tools/"+name),installed,exe.getParentDirectory().getParentDirectory().getChildFile("AtlasWorker_artefacts/Release/"+name)})if(file.existsAsFile())return file;
    auto ancestor=exe;for(int i=0;i<5;++i){auto candidate=ancestor.getChildFile("AtlasWorker_artefacts/Release/"+name);if(candidate.existsAsFile())return candidate;ancestor=ancestor.getParentDirectory();}
    return installed;
}
inline juce::Result request(juce::var payload,const juce::File&folder,bool configure,juce::var&response,const std::function<bool()>&cancel){
    if(cancel&&cancel())return juce::Result::fail("Render cancelled");
    auto worker=workerFile();if(!worker.existsAsFile())return juce::Result::fail("AtlasWorker missing. Reinstall DrumAtlas; MIDI remains available.");
    auto result=folder.createDirectory();if(result.failed())return result;
    auto id=juce::Uuid().toString();payload.getDynamicObject()->setProperty("request_id",id);
    auto input=folder.getChildFile("request.json"),output=folder.getChildFile("response.json"),progress=folder.getChildFile("progress");
    if(!input.replaceWithText(juce::JSON::toString(payload)))return juce::Result::fail("Cannot write instrument request: "+input.getFullPathName());
    juce::ChildProcess child;
    if(!child.start(juce::StringArray{worker.getFullPathName(),configure?"--configure":"--render",input.getFullPathName(),output.getFullPathName(),id},0))return juce::Result::fail("Cannot start instrument worker");
    auto last=juce::Time::getMillisecondCounterHiRes();juce::String previous;
    while(child.isRunning()){
        auto now=juce::Time::getMillisecondCounterHiRes();auto current=progress.loadFileAsString();if(current!=previous){previous=current;last=now;}
        if((cancel&&cancel())||now-last>(configure?3600000.:120000.)){
            child.kill();child.waitForProcessToFinish(5000);
            return juce::Result::fail(cancel&&cancel()?"Render cancelled":"Instrument stopped responding");
        }
        juce::Thread::sleep(20);
    }
    if(child.getExitCode()!=0||!output.existsAsFile()||output.getSize()>32*1024*1024)return juce::Result::fail("Instrument worker failed; MIDI remains available");
    response=juce::JSON::parse(output);
    if(int(response["protocol"])!=2||response["request_id"].toString()!=id)return juce::Result::fail("Invalid instrument response");
    auto status=response["status"].toString();
    return status==(configure?"configured":"rendered")?juce::Result::ok():juce::Result::fail(status=="cancelled"?"Instrument setup cancelled":response.getProperty("error","Instrument render failed").toString());
}
struct Cache {
    juce::File folder=juce::File::getSpecialLocation(juce::File::tempDirectory).getChildFile("DrumAtlas-instruments-"+juce::Uuid().toString());
    std::vector<juce::File> files;juce::Array<juce::var> reports;juce::int64 frames=0;
    ~Cache(){if(folder.exists())folder.deleteRecursively();}
    juce::Result prepare(const Project&p,double rate,const std::function<bool()>&cancel){
        auto valid=validate(p);if(valid.failed())return valid;
        if(!std::isfinite(rate)||rate<22050||rate>96000)return juce::Result::fail("Unsupported sample rate");
        const double seconds=barTicks(p.settings)*p.settings.bars*60./(ppq*p.settings.bpm);
        frames=juce::int64(std::ceil((seconds+2)*rate));files.resize(p.tracks.size());
        uint32_t seed=p.settings.seed;auto next=[&]{seed=seed*1664525u+1013904223u;return seed;};
        for(size_t i=0;i<p.tracks.size();++i){
            const auto&t=p.tracks[i];juce::Array<juce::var>notes;
            for(const auto&n:t.notes){if(double(next())/4294967296.>=n.probability)continue;next();
                if(t.instrument.isVoid())continue;
                auto start=juce::int64(std::llround((n.tick+n.microtiming)*60.*rate/(ppq*p.settings.bpm)));
                auto end=std::min(juce::int64(std::ceil(seconds*rate)),start+juce::int64(std::llround(n.duration*60.*rate/(ppq*p.settings.bpm))));
                if(end<=start)continue;
                auto*o=new juce::DynamicObject;o->setProperty("start",start);o->setProperty("end",end);o->setProperty("pitch",n.pitch);o->setProperty("velocity",n.velocity);o->setProperty("channel",n.channel);notes.add(juce::var(o));
            }
            if(t.instrument.isVoid())continue;
            auto*o=new juce::DynamicObject;juce::var payload(o);o->setProperty("instrument",t.instrument.clone());o->setProperty("sample_rate",rate);o->setProperty("song_seconds",seconds);o->setProperty("bpm",p.settings.bpm);o->setProperty("numerator",p.settings.numerator);o->setProperty("denominator",p.settings.denominator);o->setProperty("notes",notes);
            auto directory=folder.getChildFile(juce::String(int(i)));juce::var response;auto r=request(payload,directory,false,response,cancel);if(r.failed())return r;
            auto file=directory.getChildFile("audio.wav");juce::AudioFormatManager fm;fm.registerBasicFormats();std::unique_ptr<juce::AudioFormatReader>reader(fm.createReaderFor(file));
            if(!reader||reader->sampleRate!=rate||reader->numChannels!=2||reader->lengthInSamples!=juce::int64(response["frames"])||reader->lengthInSamples<juce::int64(std::ceil((seconds+2)*rate))||reader->lengthInSamples>juce::int64(std::ceil((seconds+600)*rate)))return juce::Result::fail("Invalid instrument audio response");
            files[i]=file;frames=std::max(frames,reader->lengthInSamples);response.getDynamicObject()->setProperty("track_id",t.id);reports.add(response);
        }
        return juce::Result::ok();
    }
};
inline juce::Result configure(const juce::var&config,juce::var&saved,const std::function<bool()>&cancel){
    Cache temporary;auto*o=new juce::DynamicObject;juce::var payload(o);o->setProperty("instrument",config);o->setProperty("sample_rate",44100);juce::var response;
    auto r=request(payload,temporary.folder,true,response,cancel);if(r.wasOk())saved=response["instrument"].clone();return r;
}
}
