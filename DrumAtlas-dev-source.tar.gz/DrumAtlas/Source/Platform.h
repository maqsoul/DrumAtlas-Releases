#pragma once
#include <juce_core/juce_core.h>
namespace atlas {
juce::File bundledModels();
void* loadNativeLibrary(const juce::File&);
juce::String nativeLibraryError();
void* nativeSymbol(void*,const char*);
#if JUCE_MAC
juce::String macMachineCode();
bool macVerifySignature(const unsigned char*,size_t,const juce::MemoryBlock&,const juce::MemoryBlock&);
#endif
}
#if JUCE_WINDOWS
#define ATLAS_ORT_PATH(file) ((file).getFullPathName().toWideCharPointer())
#else
#define ATLAS_ORT_PATH(file) ((file).getFullPathName().toRawUTF8())
#endif
