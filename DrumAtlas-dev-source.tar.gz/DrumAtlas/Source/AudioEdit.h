#pragma once
#include "Analysis.h"
#include <atomic>
#include <mutex>
namespace atlas {
struct EditRequest{juce::File source;double semitones=0,sourceBpm=0,targetBpm=0;};
struct EditState{bool busy=false;int revision=0;juce::String source,output,error;};
juce::File renderAudioEdit(const EditRequest&,const juce::File& directory,const std::function<bool()>&cancel={});
class AudioEditService:private juce::Thread{
public:
 AudioEditService();~AudioEditService()override;void render(EditRequest);EditState snapshot();
private:
 void run()override;std::mutex mutex;EditRequest pending;EditState state;bool queued=false;std::atomic<int>generation{0};
};
}
