#pragma once
#include "MusicProfiles.h"
#include <juce_gui_basics/juce_gui_basics.h>
namespace atlas {
class StyleBlendPanel final: public juce::Component {
public:
    std::function<void(const music::StyleBlend&)> accepted;
    StyleBlendPanel(){
        setOpaque(true);addAndMakeVisible(view);view.setViewedComponent(&rows,false);
        for(auto*c:std::initializer_list<juce::Component*>{&apply,&cancel,&summary,&genres,&moods})addAndMakeVisible(c);
        genres.setButtonText("Genres");moods.setButtonText("Moods");genres.onClick=[this]{showGenres=true;resized();view.setViewPosition(0,0);};moods.onClick=[this]{showGenres=false;resized();view.setViewPosition(0,0);};
        apply.setButtonText("Use mix for next Generate");apply.setComponentID("blend-apply");
        cancel.setButtonText("Cancel");cancel.onClick=[this]{setVisible(false);};
        apply.onClick=[this]{music::StyleBlend blend;auto r=registry.blend(weights(true),weights(false),blend);if(r.failed()){summary.setText(r.getErrorMessage(),juce::dontSendNotification);return;}if(accepted)accepted(blend);setVisible(false);};
    }
    void open(const music::ProfileRegistry&r,const std::vector<music::StyleWeight>&g,const std::vector<music::StyleWeight>&m){
        registry=r;controls.clear();
        auto add=[&](const juce::String&id,bool genre,const std::vector<music::StyleWeight>&values){
            auto row=std::make_unique<Row>();row->id=id;row->genre=genre;row->label.setText(id,juce::dontSendNotification);row->slider.setRange(0,100,.01);row->slider.setTextBoxStyle(juce::Slider::TextBoxRight,false,70,26);row->slider.setComponentID((genre?"genre-":"mood-")+id);
            for(auto&w:values)if(w.id==id)row->slider.setValue(w.weight*100,juce::dontSendNotification);
            rows.addAndMakeVisible(row->label);rows.addAndMakeVisible(row->slider);row->slider.onValueChange=[this]{update();};controls.push_back(std::move(row));
        };
        for(auto&p:r.genres())add(p.id,true,g);for(auto&p:r.moods())add(p.id,false,m);
        resized();view.setViewPosition(0,0);update();setVisible(true);toFront(false);
    }
    void resized()override{
        genres.setBounds(getWidth()-270,20,110,30);moods.setBounds(getWidth()-148,20,110,30);genres.setToggleState(showGenres,juce::dontSendNotification);moods.setToggleState(!showGenres,juce::dontSendNotification);
        view.setBounds(24,100,getWidth()-48,std::max(100,getHeight()-230));int width=std::max(200,view.getWidth()-20);
        int y=0;for(auto&r:controls){bool visible=r->genre==showGenres;r->label.setVisible(visible);r->slider.setVisible(visible);if(visible){r->label.setBounds(0,y,width/3,30);r->slider.setBounds(width/3,y,width*2/3,30);y+=34;}}rows.setSize(width,y);
        summary.setBounds(24,getHeight()-124,getWidth()-48,64);apply.setBounds(24,getHeight()-50,270,30);cancel.setBounds(getWidth()-124,getHeight()-50,100,30);
    }
    void paint(juce::Graphics&g)override{g.fillAll(juce::Colour(0xff090f18));g.setColour(juce::Colour(0xff57eed1));g.setFont(juce::FontOptions(24));g.drawText("GENRE / MOOD MIX",24,20,getWidth()-310,32,juce::Justification::centredLeft);g.setColour(juce::Colour(0xff92a7be));g.setFont(juce::FontOptions(14));g.drawFittedText("Relative weights. Each group is normalized separately. Zero excludes a profile.",24,56,getWidth()-48,38,juce::Justification::centredLeft,2);}
    juce::Slider* weightControl(bool genre,const juce::String&id){for(auto&r:controls)if(r->genre==genre&&r->id==id)return &r->slider;return nullptr;}
private:
    struct Row{juce::String id;bool genre=false;juce::Label label;juce::Slider slider;};
    std::vector<music::StyleWeight> weights(bool genre)const{std::vector<music::StyleWeight>result;for(auto&r:controls)if(r->genre==genre&&r->slider.getValue()>0)result.push_back({r->id,r->slider.getValue()});return result;}
    void update(){music::StyleBlend b;auto r=registry.blend(weights(true),weights(false),b);apply.setEnabled(r.wasOk());juce::String text=r.getErrorMessage();if(r.wasOk()){auto describe=[](const std::vector<music::StyleWeight>&v){juce::StringArray a;for(auto&w:v)a.add(w.id+" "+juce::String(w.weight*100,1)+"%");return a.joinIntoString(", ");};text=describe(b.genres)+" | "+describe(b.moods);if(!b.notices.isEmpty())text+="\n"+b.notices.joinIntoString("; ");}summary.setText(text,juce::dontSendNotification);}
    music::ProfileRegistry registry;juce::Component rows;juce::Viewport view;std::vector<std::unique_ptr<Row>>controls;juce::TextButton apply,cancel,genres,moods;juce::Label summary;bool showGenres=true;
};
}
