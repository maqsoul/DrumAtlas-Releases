#include "Analysis.h"
namespace atlas {
struct NameTag { const char* category; const char* aliases; };
static const NameTag tags[]{
 {"Vocal","vocal|vocals|vox|voice|voices|acapella|acappella|speech|singing|вокал"},
 {"Kick","kick|kicks|bassdrum|bass drum|кик|бочка"},
 {"Snare","snare|snares|снейр|снэйр"}, {"Clap","clap|claps|хлопок"},
 {"Open Hat","openhat|open hat|open hats|open hihat|oh|ohh"},
 {"Closed Hat","closedhat|closed hat|hihat|hi hat|hi hats|hat|hats|hh|chh|хэт|хэты"},
 {"Tom","tom|toms"}, {"Rim","rim|rimshot|rim shot|stick"},
 {"Cymbal","cymbal|cymbals"}, {"Ride","ride|rides"}, {"Crash","crash|crashes"},
 {"Shaker","shaker|shakers|maraca|maracas|шейкер"}, {"Conga","conga|congas|конга|конги"}, {"Bongo","bongo|bongos|bongоs|бонго"},
 {"Tambourine","tambourine|tambourines"}, {"Cowbell","cowbell|cowbells"}, {"Claves","clave|claves"}, {"Guiro","guiro"}, {"Woodblock","woodblock|wood block"},
 {"Percussion","perc|percs|percussion|перкуссия"},
 {"Bass","bass|sub|808|бас"}, {"Keys","piano|keys|keyboard|organ|rhodes|пиано|пианино"},
 {"Guitar","guitar|gtr|гитара"}, {"Strings","strings|violin|cello|viola|скрипка"},
 {"Brass","brass|trumpet|trombone|horn"}, {"Synth","synth|lead|pad|pluck|arp|синт"},
 {"FX","fx|sfx|effect|effects|riser|risers|downlifter|uplifter|sweep|transition|foley|impact"}
};
static juce::String wordsOf(juce::String name){
 name=name.toLowerCase().replace("808","eightoeight");for(auto ch:juce::String("_-./\\()[]{},;:+0123456789"))name=name.replaceCharacter(ch,' ');
 juce::StringArray words=juce::StringArray::fromTokens(name," \t\r\n",{});words.removeEmptyStrings();return " "+words.joinIntoString(" ").replace("eightoeight","808")+" ";
}
static bool negative(const juce::String& text,int index,const juce::String& alias){
 auto before=juce::StringArray::fromTokens(text.substring(0,index).trim()," ",{});
 for(int i=std::max(0,before.size()-2);i<before.size();++i)if(before[i]=="no"||before[i]=="without"||before[i]=="minus"||before[i]=="без"||before[i]=="not")return true;
 return text.contains(" "+alias+"less ")||text.contains(" "+alias+" free ");
}
juce::StringArray excludedCategories(const juce::String& name){
 auto text=wordsOf(name);juce::StringArray out;
 for(auto&tag:tags)for(auto alias:juce::StringArray::fromTokens(juce::String::fromUTF8(tag.aliases),"|",{})){
   int at=0;while((at=text.indexOf(at," "+alias+" "))>=0){if(negative(text,at,alias))out.addIfNotAlreadyThere(tag.category);++at;}
   if(text.contains(" "+alias+"less ")||text.contains(" "+alias+" free "))out.addIfNotAlreadyThere(tag.category);
 }
 if(out.contains("Closed Hat")||out.contains("Open Hat")){out.addIfNotAlreadyThere("Closed Hat");out.addIfNotAlreadyThere("Open Hat");}
 if(text.contains(" no drums ")||text.contains(" without drums "))for(auto&c:categories())if(isDrum(c))out.addIfNotAlreadyThere(c);
 return out;
}
Label nameLabel(const juce::String& name){
 Label out;auto text=wordsOf(name);auto excluded=excludedCategories(name);juce::StringArray found;
 for(auto&tag:tags){if(excluded.contains(tag.category))continue;
   for(auto alias:juce::StringArray::fromTokens(juce::String::fromUTF8(tag.aliases),"|",{}))if(text.contains(" "+alias+" ")){found.addIfNotAlreadyThere(tag.category);break;}
 }
 if(found.size()>1){for(auto&c:found)if(c=="Shaker"||c=="Conga"||c=="Bongo"||c=="Tambourine"||c=="Cowbell"||c=="Claves"||c=="Guiro"||c=="Woodblock"){found.removeString("Percussion");break;}if(found.contains("Ride")||found.contains("Crash"))found.removeString("Cymbal");}
 if(found.contains("Open Hat"))found.removeString("Closed Hat");
 if(text.contains(" bass drum ")||(found.contains("Kick")&&text.contains(" 808 ")))found.removeString("Bass");
 // Vocal phrases often contain words such as 'kick back'.
 if(found.contains("Vocal")){out.category="Vocal";out.method="Filename tag";}
 else if(found.size()==1){out.category=found[0];out.method="Filename tag";}
 else if(found.size()>1){out.category="Other";out.method="Ambiguous tag";}
 return out;
}
Label pathLabel(const juce::File& file,const juce::StringArray& roots){
 const auto excluded=excludedCategories(file.getFullPathName());
 auto result=nameLabel(file.getFileNameWithoutExtension());
 if(excluded.contains(result.category)){result.category="Other";result.method="Excluded tag";return result;}
 if(result.method=="Filename tag"||result.method=="Ambiguous tag")return result;
 juce::File boundary;for(auto&root:roots){juce::File r(root);if(file.isAChildOf(r)&&(boundary==juce::File()||r.getFullPathName().length()>boundary.getFullPathName().length()))boundary=r;}
 auto folder=file.getParentDirectory();for(int i=0;i<12&&folder!=juce::File();++i){
   auto label=nameLabel(folder.getFileName());
   if(label.method=="Ambiguous tag")return label;
   if(label.method=="Filename tag"&&!excluded.contains(label.category)){label.method="Folder tag";return label;}
   if(folder==boundary||folder==folder.getParentDirectory())break;folder=folder.getParentDirectory();
 }
 result.category="Other";return result;
}
}
