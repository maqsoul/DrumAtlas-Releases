#pragma once
#include "MusicCore.h"
#include <juce_gui_basics/juce_gui_basics.h>
namespace atlas {
class PianoRoll final:public juce::Component {
public:
    std::function<music::Project()> read;
    std::function<juce::Result(music::Project)> write;
    std::function<int()> trackIndex,barIndex;
    std::function<void(juce::Result)> report;
    PianoRoll(){
        setWantsKeyboardFocus(true);
        for(auto*c:std::initializer_list<juce::Component*>{&steps,&velocity,&duration,&pitch,&erase,&hint})addAndMakeVisible(c);
        steps.setComponentID("note-grid");velocity.setComponentID("note-velocity");duration.setComponentID("note-duration");pitch.setComponentID("note-pitch");
        for(int n:{16,32,64,12,24,48})steps.addItem(juce::String(n)+((n==12||n==24||n==48)?" triplet":" steps"),n);steps.setSelectedId(16);
        steps.onChange=[this]{repaint();};velocity.setRange(1,127,1);duration.setRange(1,245760,1);pitch.setRange(0,127,1);
        velocity.setValue(90);duration.setValue(240);pitch.setValue(60);
        for(auto*s:{&velocity,&duration,&pitch}){s->setSliderStyle(juce::Slider::IncDecButtons);s->setTextBoxStyle(juce::Slider::TextBoxLeft,false,62,26);}
        velocity.onValueChange=[this]{change(0);};duration.onValueChange=[this]{change(1);};pitch.onValueChange=[this]{change(2);};
        erase.setButtonText("Delete note");erase.onClick=[this]{remove();};hint.setText("Velocity       Length (ticks)       Pitch",juce::dontSendNotification);
    }
    void resized()override{steps.setBounds(0,20,140,26);velocity.setBounds(150,20,120,26);duration.setBounds(280,20,140,26);pitch.setBounds(430,20,120,26);erase.setBounds(560,20,110,26);hint.setVisible(false);grid={40,56,getWidth()-40,std::max(1,getHeight()-56)};}
    void paint(juce::Graphics&g)override{
        g.setColour(juce::Colour(0xff92a7be));g.setFont(juce::FontOptions(12));for(auto pair:std::initializer_list<std::pair<const char*,int>>{{"Grid",0},{"Velocity",150},{"Length (ticks)",280},{"Pitch",430}})g.drawText(pair.first,pair.second,0,140,18,juce::Justification::centredLeft);
        if(!read)return;auto p=dragging?draft:read();int i=trackIndex();if(i<0||i>=int(p.tracks.size()))return;auto&t=p.tracks[size_t(i)];auto range=dragging?dragRange:pitchRange(t);int lanes=range.second-range.first+1;
        g.setColour(juce::Colour(0xff111c29));g.fillRect(grid);int count=steps.getSelectedId();
        for(int x=0;x<=count;++x){g.setColour(juce::Colour(x%(count/4)?0xff253748:0xff506477));g.drawVerticalLine(grid.getX()+grid.getWidth()*x/count,float(grid.getY()),float(grid.getBottom()));}
        for(int y=0;y<=lanes;++y){g.setColour(juce::Colour(0xff253748));g.drawHorizontalLine(grid.getY()+grid.getHeight()*y/lanes,float(grid.getX()),float(grid.getRight()));if(y<lanes){g.setColour(juce::Colour(0xff92a7be));g.setFont(juce::FontOptions(10));g.drawText(juce::MidiMessage::getMidiNoteName(range.second-y,true,true,3),0,grid.getY()+grid.getHeight()*y/lanes,38,grid.getHeight()/lanes,juce::Justification::centredLeft);}}
        const auto bar=music::barTicks(p.settings),start=barIndex()*bar;
        for(auto&n:t.notes)if(n.tick>=start&&n.tick<start+bar){auto box=noteBox(n,range,start,bar);g.setColour(t.midiLocked?juce::Colour(0xff92a7be):n.id==selected?juce::Colour(0xffffd281):juce::Colour(0xff57eed1).withAlpha(.35f+.65f*n.velocity/127.f));g.fillRoundedRectangle(box.toFloat().reduced(1),2);}
    }
    void mouseDown(const juce::MouseEvent&e)override{
        if(!e.mods.isLeftButtonDown()||!grid.contains(e.getPosition())||!read||!write)return;grabKeyboardFocus();draft=read();dragBaseline=juce::JSON::toString(music::encode(draft),true);int i=trackIndex();dragTrack=i;if(i<0||i>=int(draft.tracks.size()))return;auto&t=draft.tracks[size_t(i)];if(t.midiLocked){notify(juce::Result::fail("Track MIDI is locked"));return;}
        dragRange=pitchRange(t);const auto bar=music::barTicks(draft.settings),start=barIndex()*bar;int lanes=dragRange.second-dragRange.first+1;
        auto found=std::find_if(t.notes.rbegin(),t.notes.rend(),[&](const music::Note&n){return n.tick>=start&&n.tick<start+bar&&noteBox(n,dragRange,start,bar).contains(e.getPosition());});
        if(found!=t.notes.rend()){original=*found;selected=original.id;resizeNote=e.x>=noteBox(original,dragRange,start,bar).getRight()-6;}
        else{original={};original.id=juce::Uuid().toString();original.pitch=dragRange.second-juce::jlimit(0,lanes-1,(e.y-grid.getY())*lanes/grid.getHeight());original.tick=start+bar*juce::jlimit(0,steps.getSelectedId()-1,(e.x-grid.getX())*steps.getSelectedId()/grid.getWidth())/steps.getSelectedId();original.duration=std::max<int64_t>(1,bar/steps.getSelectedId());original.velocity=int(velocity.getValue());original.channel=i<6?10:1;t.notes.push_back(original);selected=original.id;resizeNote=false;}
        velocity.setValue(original.velocity,juce::dontSendNotification);duration.setValue(double(original.duration),juce::dontSendNotification);pitch.setValue(original.pitch,juce::dontSendNotification);dragging=true;repaint();
    }
    void mouseDrag(const juce::MouseEvent&e)override{
        if(!dragging)return;auto&t=draft.tracks[size_t(dragTrack)];auto n=std::find_if(t.notes.begin(),t.notes.end(),[&](const music::Note&n){return n.id==selected;});if(n==t.notes.end())return;
        const auto bar=music::barTicks(draft.settings),end=bar*draft.settings.bars,quantum=std::max<int64_t>(1,bar/steps.getSelectedId());int64_t delta=int64_t(std::llround(double(e.getDistanceFromDragStartX())*steps.getSelectedId()/grid.getWidth()))*quantum;
        *n=original;if(resizeNote)n->duration=juce::jlimit<int64_t>(std::min(quantum,end-n->tick),end-n->tick,original.duration+delta);
        else{n->tick=juce::jlimit<int64_t>(0,end-n->duration,original.tick+delta);n->pitch=juce::jlimit(0,127,original.pitch-int(std::round(double(e.getDistanceFromDragStartY())*(dragRange.second-dragRange.first+1)/grid.getHeight())));}
        n->microtiming=juce::jlimit(-n->tick,end-n->tick-n->duration,n->microtiming);duration.setValue(double(n->duration),juce::dontSendNotification);pitch.setValue(n->pitch,juce::dontSendNotification);repaint();
    }
    void mouseUp(const juce::MouseEvent&)override{if(!dragging)return;dragging=false;auto p=read();if(juce::JSON::toString(music::encode(p),true)!=dragBaseline){notify(juce::Result::fail("Project changed during drag; retry the edit"));repaint();return;}auto&t=draft.tracks[size_t(dragTrack)];auto n=std::find_if(t.notes.begin(),t.notes.end(),[&](const music::Note&n){return n.id==selected;});if(n!=t.notes.end()){auto r=music::editNote(p,t.id,*n);if(r.wasOk())r=write(p);notify(r);}repaint();}
    bool keyPressed(const juce::KeyPress&key)override{if(key==juce::KeyPress::deleteKey||key==juce::KeyPress::backspaceKey){remove();return true;}if(key==juce::KeyPress::escapeKey){dragging=false;repaint();return true;}return false;}
private:
    void notify(juce::Result r){if(report)report(r);}
    void change(int field){if(selected.isEmpty()||!read)return;auto p=read();int i=trackIndex();if(i<0||i>=int(p.tracks.size()))return;auto&t=p.tracks[size_t(i)];auto n=std::find_if(t.notes.begin(),t.notes.end(),[&](const music::Note&n){return n.id==selected;});if(n==t.notes.end())return;auto replacement=*n;if(field==0)replacement.velocity=int(velocity.getValue());if(field==1)replacement.duration=int64_t(duration.getValue());if(field==2)replacement.pitch=int(pitch.getValue());auto r=music::editNote(p,t.id,replacement);if(r.wasOk())r=write(p);notify(r);repaint();}
    void remove(){if(selected.isEmpty()||!read)return;auto p=read();int i=trackIndex();if(i<0||i>=int(p.tracks.size()))return;auto r=music::removeNote(p,p.tracks[size_t(i)].id,selected);if(r.wasOk()){r=write(p);if(r.wasOk())selected.clear();}notify(r);repaint();}
    static std::pair<int,int> pitchRange(const music::Track&t){int low=t.notes.empty()?48:127,high=t.notes.empty()?72:0;for(auto&n:t.notes){low=std::min(low,n.pitch);high=std::max(high,n.pitch);}low=std::max(0,low-4);high=std::min(127,std::max(high+4,low+23));return {low,high};}
    juce::Rectangle<int>noteBox(const music::Note&n,std::pair<int,int>range,int64_t start,int64_t bar)const{return {grid.getX()+int((n.tick-start)*grid.getWidth()/bar),grid.getY()+(range.second-n.pitch)*grid.getHeight()/(range.second-range.first+1),std::max(4,int(std::min(n.duration,start+bar-n.tick)*grid.getWidth()/bar)),std::max(3,grid.getHeight()/(range.second-range.first+1))};}
    juce::ComboBox steps;juce::Slider velocity,duration,pitch;juce::TextButton erase;juce::Label hint;juce::Rectangle<int>grid;juce::String selected,dragBaseline;int dragTrack=0;music::Project draft;music::Note original;std::pair<int,int>dragRange;bool dragging=false,resizeNote=false;
};
}
