#pragma once
#include <juce_cryptography/juce_cryptography.h>
namespace atlas {
struct LegacyAsset {juce::String id, originalPath, path;bool missing=true;};
std::vector<LegacyAsset> legacyAssets(const juce::File& userDirectory);
juce::Result locateLegacyAsset(const juce::File& userDirectory,const juce::String& id,const juce::File& replacement);
// Background-only. Originals, credentials, licences and audio are never removed.
juce::Result prepareLibraryMigration(const juce::File& userDirectory,bool verifyHashes=false);
}
