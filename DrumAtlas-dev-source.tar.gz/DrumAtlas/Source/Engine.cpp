#define NOMINMAX
#include "Engine.h"
#include "LibraryMigration.h"
#include <unordered_map>
#include <unordered_set>
#include <thread>
#include <juce_cryptography/juce_cryptography.h>
#if JUCE_WINDOWS
#include <windows.h>
#else
#include <sys/stat.h>
#endif
namespace atlas {
juce::Result exportStemCopies(const std::vector<ReferenceStem>&stems,const juce::File&folder,const juce::String&name,juce::File&output){
    if(stems.empty())return juce::Result::fail("No stems");
    output=catalogFile(ioFile(folder).getNonexistentChildFile(juce::File::createLegalFileName(name)+" - stems",{},false));
    if(!ioFile(output).createDirectory())return juce::Result::fail("Cannot create export folder");
    for(auto&s:stems){auto dest=ioFile(output.getChildFile(juce::File::createLegalFileName(s.name)+".wav"));if(!ioFile(juce::File(s.path)).copyFileTo(dest))return juce::Result::fail("Cannot copy "+s.name);}
    return juce::Result::ok();
}
bool matchesFilters(const Sample& s, const juce::String& category, const juce::String& kind, const juce::String& genre, const juce::String& query) {
    if(category.isNotEmpty() && s.category!=category)return false;
    if(kind.isNotEmpty() && s.kind!=kind)return false;
    if(genre.isNotEmpty() && !(genre=="Unknown"?s.genres.isEmpty():s.genres.contains(genre)))return false;
    return query.isEmpty()||s.name.containsIgnoreCase(query);
}
Engine::Engine():juce::Thread("DrumAtlas catalog") {
    registerFormats(formats);auto override=juce::SystemStats::getEnvironmentVariable("DRUMATLAS_CACHE_DIR",{});
    auto dir=override.isNotEmpty()?juce::File(override):juce::File::getSpecialLocation(juce::File::userApplicationDataDirectory).getChildFile("DrumAtlas");
    settings=dir.getChildFile("preferences.json");cache=dir.getChildFile("library-v2.json");oldCache=dir.getChildFile("library-v1.json");startThread();
}
Engine::~Engine(){signalThreadShouldExit();++generation;notify();stopThread(-1);}
void Engine::selectReference(const juce::File&file){std::lock_guard<std::mutex>g(stateMutex);state.reference=file.getFullPathName();state.stems.clear();state.hits.clear();state.matches.clear();++state.matchRevision;state.status="ready";state.detail.clear();changed();}
Snapshot Engine::snapshot(){std::lock_guard<std::mutex>g(stateMutex);return state;}
juce::StringArray Engine::roots(){std::lock_guard<std::mutex>g(stateMutex);return state.roots;}
void Engine::status(const juce::String& text,bool busy,const juce::String& detail){std::lock_guard<std::mutex>g(stateMutex);state.status=text;state.busy=busy;state.detail=detail;changed();}
void Engine::enqueue(Job j){j.generation=++generation;{std::lock_guard<std::mutex>g(queueMutex);jobs.clear();jobs.push_back(j);}status("queued",true);notify();}
void Engine::addRoot(const juce::File& f){addRoots({f});}
void Engine::addRoots(const juce::Array<juce::File>& files){
    {std::lock_guard<std::mutex>g(stateMutex);rootsSet=true;for(const auto& f:files)if(ioFile(f).isDirectory())state.roots.addIfNotAlreadyThere(catalogFile(f).getFullPathName(),true);changed();}rescan();
}
void Engine::setRoots(const juce::StringArray& r){{std::lock_guard<std::mutex>g(stateMutex);rootsSet=true;state.roots=r;state.roots.removeDuplicates(true);changed();}rescan();}
void Engine::rescan(){enqueue({0});}
void Engine::analyseReference(const juce::File& f,double start,double length,const juce::String& category,bool aiStems,bool detailedStems){Job j;j.type=1;j.file=f;j.start=std::max(0.0,start);j.length=length;j.category=category;j.aiStems=aiStems;j.detailedStems=detailedStems;enqueue(j);}
void Engine::cancel(){++generation;{std::lock_guard<std::mutex>g(queueMutex);jobs.clear();}status("ready",false);}
void Engine::relabel(const juce::String& path,const juce::String& category,const juce::String& kind){
    {std::lock_guard<std::mutex>g(stateMutex);if(state.busy)return;auto copy=std::make_shared<std::vector<Sample>>(*state.samples);
     for(auto& s:*copy)if(s.path==path){s.category=category;s.kind=kind;s.method="Manual";}state.samples=copy;++state.catalogRevision;changed();}catalogDirty=true;markDirty();
}
void Engine::used(const juce::String& path){
    {std::lock_guard<std::mutex>g(stateMutex);state.recent.removeString(path);state.recent.insert(0,path);while(state.recent.size()>150)state.recent.remove(state.recent.size()-1);changed();}markDirty();
}
void Engine::favourite(const juce::String& path,const juce::String& collection,bool add){
    {std::lock_guard<std::mutex>g(stateMutex);if(add)state.favourites[path].addIfNotAlreadyThere(collection);
     else if(collection.isEmpty())state.favourites.erase(path);
     else if(auto it=state.favourites.find(path);it!=state.favourites.end()){it->second.removeString(collection);if(it->second.isEmpty())state.favourites.erase(it);}changed();}markDirty();
}
void Engine::createCollection(const juce::String& name){auto cleaned=name.trim().substring(0,80);if(cleaned.isEmpty())return;{std::lock_guard<std::mutex>g(stateMutex);state.collections.addIfNotAlreadyThere(cleaned);changed();}markDirty();}
void Engine::preferences(const juce::String& language,const juce::String& theme){{std::lock_guard<std::mutex>g(stateMutex);preferencesSet=true;state.language=language;state.theme=theme;changed();}markDirty();}
void Engine::run(){
    auto migration=prepareLibraryMigration(settings.getParentDirectory());
    while(migration.failed()&&migration.getErrorMessage().startsWith("Another DrumAtlas")&&!threadShouldExit()){
        wait(100);migration=prepareLibraryMigration(settings.getParentDirectory());
    }
    if(threadShouldExit())return;
    if(migration.failed()){status("failed",false,migration.getErrorMessage());return;}
    loadCache();{Neural model;std::lock_guard<std::mutex>g(stateMutex);state.neural=model.available();changed();}while(!threadShouldExit()){Job job;bool found=false;{std::lock_guard<std::mutex>g(queueMutex);if(!jobs.empty()){job=jobs.front();jobs.pop_front();found=true;}}
        if(!found){if(dirty.exchange(false)){if(catalogDirty.exchange(false))saveCache();savePreferences();}wait(350);continue;}
        try{if(!cancelled(job)){if(job.type==0)scan(job);else reference(job);}}
        catch(const std::exception&e){status("failed",false,juce::String::fromUTF8(e.what()));}catch(...){status("failed",false);}
    }if(dirty.exchange(false)){if(catalogDirty.exchange(false))saveCache();savePreferences();}
}
static std::string directoryIdentity(const juce::File& file){
#if JUCE_WINDOWS
    HANDLE h=CreateFileW(ioFile(file).getFullPathName().toWideCharPointer(),0,FILE_SHARE_READ|FILE_SHARE_WRITE|FILE_SHARE_DELETE,nullptr,OPEN_EXISTING,FILE_FLAG_BACKUP_SEMANTICS,nullptr);BY_HANDLE_FILE_INFORMATION info{};
    if(h!=INVALID_HANDLE_VALUE){bool ok=GetFileInformationByHandle(h,&info)!=0;CloseHandle(h);if(ok)return std::to_string(info.dwVolumeSerialNumber)+":"+std::to_string(info.nFileIndexHigh)+":"+std::to_string(info.nFileIndexLow);}
    return file.getFullPathName().toLowerCase().toStdString();
#else
    struct stat info{};if(::stat(file.getFullPathName().toRawUTF8(),&info)==0)return std::to_string(info.st_dev)+":"+std::to_string(info.st_ino);
    return file.getFullPathName().toStdString();
#endif
}
void Engine::scan(const Job& job){
    double started=juce::Time::getMillisecondCounterHiRes();auto old=snapshot();status("scanning",true);
    std::unordered_map<std::string,const Sample*>previous;for(const auto&s:*old.samples)previous.emplace(catalogPathKey(s.path),&s);
    struct IndexedFile{juce::File file;juce::int64 modified,bytes;};std::vector<IndexedFile>files;std::unordered_set<std::string>seenDirs,seenFiles;std::deque<juce::File>dirs;for(const auto&root:old.roots)dirs.emplace_back(root);
    int missing=0;for(const auto&root:old.roots)if(!ioFile(juce::File(root)).isDirectory())++missing;
    while(!dirs.empty()){
        if(cancelled(job))return;auto dir=dirs.front();dirs.pop_front();if(!seenDirs.insert(directoryIdentity(dir)).second)continue;
        for(const auto&entry:juce::RangedDirectoryIterator(ioFile(dir),false,"*",juce::File::findFilesAndDirectories)){
            const auto f=catalogFile(entry.getFile());if(entry.isDirectory()){dirs.push_back(f);continue;}
            if(f.getFileExtension().isNotEmpty()&&!formats.findFormatForFileExtension(f.getFileExtension())&&!f.hasFileExtension("wav;wave;aif;aiff;aifc;flac;ogg;oga;opus;mp3;mp2;mp4;m4a;aac;wma;w64;rf64;au;snd"))continue;
            if(seenFiles.insert(catalogPathKey(f.getFullPathName())).second)files.push_back({f,entry.getModificationTime().toMilliseconds(),entry.getFileSize()});
        }
    }
    auto result=std::make_shared<std::vector<Sample>>(files.size());std::atomic<size_t>cursor{0};std::atomic<int>done{0},reused{0},errors{missing},active{0};std::atomic<bool>metadataChanged{false};std::atomic<bool>nnReady{old.neural};std::mutex inferenceMutex;std::unordered_map<std::string,NeuralResult> inferenceCache;
    int workers=std::min(8,std::max(1,int(std::thread::hardware_concurrency())/2));std::vector<std::thread>pool;
    active=workers;
    for(int worker=0;worker<workers;++worker)pool.emplace_back([&]{
        try{
            juce::AudioFormatManager fm;registerFormats(fm);std::unique_ptr<Neural> neural;
            for(;;){size_t index=cursor.fetch_add(1);if(index>=files.size()||cancelled(job))break;
                const auto&file=files[index].file;Sample s;s.path=file.getFullPathName();s.name=file.getFileName();s.category="Other";s.kind="One-shot";s.modified=files[index].modified;s.bytes=files[index].bytes;
                auto cached=previous.find(catalogPathKey(s.path));const Sample*oldSample=cached==previous.end()?nullptr:cached->second;
                if(oldSample&&oldSample->classificationVersion==5&&oldSample->modified==s.modified&&oldSample->bytes==s.bytes&&oldSample->error.isEmpty()&&(!oldSample->features.embedding.empty()||oldSample->features.peak<1e-7f)){s=*oldSample;++reused;}
                else{
                    auto audio=decode(fm,file,0,5);s.duration=audio.duration;
                    if(audio.error.isNotEmpty()){s.error=audio.error;++errors;}
                    else{
                        s.features=describe(audio.mono);
                        if(s.features.peak<1e-7f&&s.duration>5){audio=decode(fm,file,std::min(5.0,s.duration/2),5);s.features=describe(audio.mono);}
                        auto label=classify(file.getFileNameWithoutExtension(),s.features,s.duration,s.duration>1.2?onsets(audio.mono):std::vector<int>{});
                        const auto metadata=pathLabel(file,old.roots);label.category=metadata.category;label.method=metadata.method;
                        NeuralResult inference;auto digest=juce::SHA256(audio.mono.data(),audio.mono.size()*sizeof(float)).toHexString().toStdString();
                        {std::lock_guard<std::mutex>guard(inferenceMutex);auto found=inferenceCache.find(digest);if(found!=inferenceCache.end())inference=found->second;}
                        if(!inference.valid){if(!neural)neural=std::make_unique<Neural>();if(neural->available())nnReady=true;inference=neural->analyse(audio.mono);if(inference.valid){std::lock_guard<std::mutex>guard(inferenceMutex);if(inferenceCache.size()<2048)inferenceCache.emplace(std::move(digest),inference);}}
                        s.features.embedding=inference.embedding;
                        if(inference.valid&&!inference.instruments.empty()){
                            auto best=inference.instruments.front();if(best.first=="Percussion")for(const auto&c:inference.instruments)if(isDrum(c.first)&&c.first!="Percussion"&&c.second>0.12f){best=c;break;}
                            bool explicitTag=label.method=="Filename tag"||label.method=="Folder tag"||label.method=="Ambiguous tag";
                            if(!explicitTag&&best.second>=0.55f&&!excludedCategories(file.getFullPathName()).contains(best.first)){label.category=best.first;label.method="Neural";if(label.category=="Closed Hat"&&s.features.duration>0.24f)label.category="Open Hat";}
                        }
                        s.category=label.category;s.kind=label.kind;s.method=label.method;if(s.kind=="Loop?")s.kind="Loop";
                        s.genres=genreTags(file.getFullPathName());if(s.genres.isEmpty())s.genres=inference.genres;
                    }
                    if(oldSample&&oldSample->method=="Manual"){s.category=oldSample->category;s.kind=oldSample->kind;s.method="Manual";}
                }
                // Metadata is reapplied even to cached audio, so existing libraries pick up fixes.
                if(s.method!="Manual"&&s.error.isEmpty()){
                    auto metadata=pathLabel(file,old.roots);
                    if(metadata.method=="Filename tag"||metadata.method=="Folder tag"||metadata.method=="Ambiguous tag"){s.category=metadata.category;s.method=metadata.method;}
                    else if(s.method!="Neural"||excludedCategories(file.getFullPathName()).contains(s.category)){s.category="Other";s.method="Unknown";}
                }
                if(oldSample&&(s.category!=oldSample->category||s.kind!=oldSample->kind||s.method!=oldSample->method))metadataChanged=true;
                s.classificationVersion=5;(*result)[index]=std::move(s);++done;
            }
        }catch(...){++errors;}--active;
    });
    while(active>0&&!cancelled(job)){
        {std::lock_guard<std::mutex>g(stateMutex);state.processed=done;state.total=int(files.size());state.cached=reused;state.issues=errors;state.elapsed=(juce::Time::getMillisecondCounterHiRes()-started)/1000;state.neural=nnReady;changed();}wait(150);
    }
    for(auto&t:pool)t.join();if(cancelled(job))return;
    for(size_t i=0;i<files.size();++i)if((*result)[i].path.isEmpty()){auto&s=(*result)[i];s.path=files[i].file.getFullPathName();s.name=files[i].file.getFileName();s.category="Other";s.kind="One-shot";s.error="Worker could not decode file";}
    std::sort(result->begin(),result->end(),[](const Sample&a,const Sample&b){return a.name.compareIgnoreCase(b.name)<0;});
    {std::lock_guard<std::mutex>g(stateMutex);state.samples=result;++state.catalogRevision;state.processed=int(files.size());state.total=int(files.size());state.cached=reused;state.issues=errors;state.neural=nnReady;state.elapsed=(juce::Time::getMillisecondCounterHiRes()-started)/1000;changed();}
    savePreferences();const bool unchanged=reused==int(files.size())&&files.size()==old.samples->size()&&!metadataChanged&&!catalogDirty.load()&&cache.existsAsFile();if((unchanged||saveCache())&&!cancelled(job))status("ready",false);
}
#include "DetailJob.inc"
#include "StemJob.inc"
void Engine::reference(const Job& job){
    const auto started=juce::Time::getMillisecondCounterHiRes();
    std::unique_ptr<juce::AudioFormatReader>reader(formats.createReaderFor(ioFile(job.file)));if(!reader||reader->sampleRate<=0){status("failed",false,job.file.getFileName());return;}
    double total=double(reader->lengthInSamples)/reader->sampleRate;reader.reset();double end=job.length<0?total:std::min(total,job.start+job.length);if(end<=job.start){status("failed",false);return;}
    Neural neural;const auto library=snapshot().samples;
    {std::lock_guard<std::mutex>g(stateMutex);state.reference=job.file.getFullPathName();state.hits.clear();state.matches.clear();state.stems.clear();++state.matchRevision;state.neural=neural.available();state.status="analysing";state.busy=true;state.processed=0;state.total=int(std::ceil(end-job.start));changed();}
    std::vector<ReferenceStem> isolated;
    if(job.aiStems){isolated=splitReference(job,end);if(cancelled(job))return;if(isolated.empty())throw std::runtime_error("No stems were produced");{std::lock_guard<std::mutex>g(stateMutex);state.stems=isolated;state.processed=0;state.total=int(std::ceil(end-job.start));state.status="analysing";changed();}}
    std::map<juce::String,std::vector<Hit>>detections;
    const auto remember=[&](Hit hit){if(job.category.isNotEmpty()&&job.category!=hit.category)return;auto&items=detections[hit.category];if(items.size()<16){items.push_back(std::move(hit));return;}auto weakest=std::min_element(items.begin(),items.end(),[](const Hit&a,const Hit&b){return a.confidence<b.confidence;});if(hit.confidence>weakest->confidence)*weakest=std::move(hit);};
    for(double time=job.start;time<end;time+=4){
        if(cancelled(job))return;const double context=std::max(job.start,time-.15);auto audio=decode(formats,job.file,context,std::min(end,time+4.15)-context);if(audio.error.isNotEmpty()){status("failed",false,audio.error);return;}
        Separated stems;
        if(job.aiStems){
          for(const auto&stem:isolated){auto part=decode(formats,juce::File(stem.path),context-job.start,std::min(end,time+4.15)-context);if(part.error.isNotEmpty())throw std::runtime_error(part.error.toStdString());
            if(stem.name=="Drums"){if(!job.detailedStems)stems.percussive=std::move(part.mono);continue;}
            double energy=0,original=0;for(auto x:part.mono)energy+=x*x;for(auto x:audio.mono)original+=x*x;
            if(energy<std::max(1e-10,original*.0004))continue;
            if(job.detailedStems&&(isDrum(stem.name)||stem.name=="Hi Hat")){
              auto positions=onsets(part.mono);int considered=0;for(auto onset:positions){double at=context+onset/analysisRate;if(at<time||at>=std::min(end,time+4)||++considered>24)continue;int finish=std::min(int(part.mono.size()),onset+int(analysisRate*.5));if(finish-onset<220)continue;std::vector<float>cut(part.mono.begin()+onset,part.mono.begin()+finish);auto f=describe(cut);if(f.peak<1e-5f)continue;auto nr=neural.analyse(cut);f.embedding=std::move(nr.embedding);auto cat=stem.name;
                if(cat=="Hi Hat")cat=job.category=="Open Hat"?"Open Hat":job.category=="Closed Hat"?"Closed Hat":f.duration>.24f?"Open Hat":"Closed Hat";
                if(job.category=="Clap"||job.category=="Rim"||job.category=="Cymbal")cat=job.category;
                remember({at,cat,std::move(f),.5f});}
              continue;
            }
            auto inference=neural.analyse(part.mono);auto features=describe(part.mono);features.embedding=inference.embedding;
            if(stem.name!="Other"){float confidence=0;for(auto&c:inference.instruments)if(c.first==stem.name)confidence=c.second;if(confidence>=.12f||job.category==stem.name)remember({time,stem.name,features,std::max(.12f,confidence)});}
            else for(const auto&c:inference.instruments)if(!isDrum(c.first)&&c.second>=.3f&&(c.first=="Synth"||c.first=="Strings"||c.first=="Brass"||c.first=="Instrument"))remember({time,c.first,features,c.second});
          }
        }else{stems=separate(audio.mono);auto inference=neural.analyse(stems.harmonic);auto features=describe(stems.harmonic);features.embedding=inference.embedding;
          for(const auto&c:inference.instruments)if(!isDrum(c.first)&&c.second>=0.3f&&c.first!="Instrument")remember({time,c.first,features,c.second});}
        const bool focused=isDrum(job.category);const auto detector=focused?drumFocus(stems.percussive,job.category):stems.percussive;const auto positions=onsets(detector);int considered=0;
        for(auto onset:positions){double at=context+onset/analysisRate;if(at<time||at>=std::min(end,time+4))continue;if(++considered>24)break;if(cancelled(job))return;int finish=std::min(int(stems.percussive.size()),onset+int(analysisRate*0.5));if(finish-onset<220)continue;
            std::vector<float>cut(stems.percussive.begin()+onset,stems.percussive.begin()+finish);auto f=describe(cut);auto label=classify({},f,double(finish-onset)/analysisRate,{});auto nr=neural.analyse(cut);f.embedding=std::move(nr.embedding);float confidence=0.12f;
            for(const auto&c:nr.instruments)if(isDrum(c.first)&&c.first!="Percussion"&&c.second>confidence){label.category=c.first;confidence=c.second;}
            if(focused&&describe(std::vector<float>(detector.begin()+onset,detector.begin()+finish)).peak>f.peak*.05f)label.category=job.category;
            if(isDrum(label.category)&&f.peak>1e-5f){if(!focused&&label.category=="Closed Hat"&&f.duration>0.24f)label.category="Open Hat";remember({at,label.category,std::move(f),confidence});}
        }
        {std::lock_guard<std::mutex>g(stateMutex);state.processed=int(std::min(end-job.start,time-job.start+4));changed();}
    }
    std::vector<Hit>hits;std::vector<Match>matches;
    for(const auto&pair:detections){const auto&queries=pair.second;if(queries.empty())continue;for(const auto&q:queries)hits.push_back(q);std::vector<Match>ranked;
        for(const auto&s:*library)if(s.category==pair.first&&s.error.isEmpty()&&s.features.peak>=1e-6f){std::vector<std::pair<float,size_t>>scores;for(size_t q=0;q<queries.size();++q)scores.emplace_back(referenceDistance(queries[q].features,s.features,pair.first),q);std::sort(scores.begin(),scores.end());size_t n=std::min(size_t(3),scores.size());float score=0;for(size_t i=0;i<n;++i)score+=scores[i].first;const auto&best=queries[scores[0].second];ranked.push_back({s.path,pair.first,score/float(n),best.confidence,best.time});}
        std::sort(ranked.begin(),ranked.end(),[](const Match&a,const Match&b){return a.distance==b.distance?a.path<b.path:a.distance<b.distance;});matches.insert(matches.end(),ranked.begin(),ranked.end());
    }
    if(cancelled(job))return;{std::lock_guard<std::mutex>g(stateMutex);state.hits=std::move(hits);state.matches=std::move(matches);state.elapsed=(juce::Time::getMillisecondCounterHiRes()-started)/1000;++state.matchRevision;changed();}status("referenceReady",false);
}
static juce::StringArray stringArray(const juce::var&v){juce::StringArray r;if(auto*a=v.getArray())for(const auto&s:*a)r.add(s.toString());return r;}
static juce::var arrayVar(const juce::StringArray&v){juce::Array<juce::var>a;for(const auto&s:v)a.add(s);return a;}
void Engine::loadCache(){
    auto json=juce::JSON::parse(cache.existsAsFile()?cache:oldCache);auto prefs=juce::JSON::parse(settings);if(auto*o=prefs.getDynamicObject()){if(!json.isObject())json=new juce::DynamicObject();for(auto&v:o->getProperties())json.getDynamicObject()->setProperty(v.name,v.value);}auto samples=std::make_shared<std::vector<Sample>>();
    if(auto*a=json["samples"].getArray())for(const auto&v:*a){Sample s;s.path=v["path"].toString();if(s.path.isEmpty())continue;s.name=juce::File(s.path).getFileName();s.category=v["category"].toString();if(s.category=="Unsorted")s.category="Other";s.kind=v["kind"].toString();if(s.kind=="Loop?")s.kind="Loop";s.method=v["method"].toString();s.duration=double(v["duration"]);s.classificationVersion=int(v["classificationVersion"]);s.modified=juce::int64(v["modified"]);s.bytes=juce::int64(v["bytes"]);s.features=fromJson(v["features"]);s.genres=stringArray(v["genres"]);s.error=v["error"].toString();samples->push_back(std::move(s));}
    // Keep locally acquired audio discoverable after the network integration is removed.
    // The legacy index is read-only; missing paths remain in the backup manifest.
    juce::StringArray importedRoots;
    auto assets=legacyAssets(settings.getParentDirectory());
    for(auto&asset:assets)if(!asset.missing)importedRoots.addIfNotAlreadyThere(juce::File(asset.path).getParentDirectory().getFullPathName());
    std::lock_guard<std::mutex>g(stateMutex);state.samples=samples;++state.catalogRevision;if(!rootsSet){state.roots=stringArray(json["roots"]);for(auto&root:importedRoots)state.roots.addIfNotAlreadyThere(root);}state.recent=stringArray(json["recent"]);state.collections=stringArray(json["collections"]);
    if(auto*o=json["favourites"].getDynamicObject())for(const auto&property:o->getProperties())state.favourites[property.name.toString()]=stringArray(property.value);
    for(auto&asset:assets)if(!asset.missing&&asset.path!=asset.originalPath){auto found=state.favourites.find(asset.originalPath);if(found!=state.favourites.end()){state.favourites[asset.path].addArray(found->second);state.favourites[asset.path].removeDuplicates(false);}int index=state.recent.indexOf(asset.originalPath);if(index>=0)state.recent.set(index,asset.path);}
    if(!preferencesSet&&json["language"].toString().isNotEmpty())state.language=json["language"].toString();if(!preferencesSet&&json["theme"].toString().isNotEmpty())state.theme=json["theme"].toString();changed();
}
bool Engine::saveCache(){
    auto copy=snapshot();auto*o=new juce::DynamicObject();o->setProperty("version",2);juce::Array<juce::var>samples;
    for(const auto&s:*copy.samples){auto*v=new juce::DynamicObject();v->setProperty("path",s.path);v->setProperty("category",s.category);v->setProperty("kind",s.kind);v->setProperty("method",s.method);v->setProperty("duration",s.duration);v->setProperty("classificationVersion",s.classificationVersion);v->setProperty("modified",s.modified);v->setProperty("bytes",s.bytes);v->setProperty("features",toJson(s.features));v->setProperty("genres",arrayVar(s.genres));v->setProperty("error",s.error);samples.add(v);}
    auto*f=new juce::DynamicObject();for(const auto&entry:copy.favourites)f->setProperty(juce::Identifier(entry.first),arrayVar(entry.second));
    o->setProperty("samples",samples);o->setProperty("roots",arrayVar(copy.roots));o->setProperty("recent",arrayVar(copy.recent));o->setProperty("collections",arrayVar(copy.collections));o->setProperty("favourites",juce::var(f));o->setProperty("language",copy.language);o->setProperty("theme",copy.theme);
    cache.getParentDirectory().createDirectory();juce::TemporaryFile temp(cache);
    if(!temp.getFile().replaceWithText(juce::JSON::toString(juce::var(o),true))||!temp.overwriteTargetFileWithTemporary()){status("cacheError",false);return false;}return true;
}
// Settings are small and saved independently from the potentially very large audio index.
bool Engine::savePreferences(){
    auto copy=snapshot();auto*o=new juce::DynamicObject();auto*f=new juce::DynamicObject();
    for(const auto&entry:copy.favourites)f->setProperty(juce::Identifier(entry.first),arrayVar(entry.second));
    o->setProperty("roots",arrayVar(copy.roots));o->setProperty("recent",arrayVar(copy.recent));o->setProperty("collections",arrayVar(copy.collections));o->setProperty("favourites",juce::var(f));o->setProperty("language",copy.language);o->setProperty("theme",copy.theme);
    settings.getParentDirectory().createDirectory();juce::TemporaryFile temp(settings);
    return temp.getFile().replaceWithText(juce::JSON::toString(juce::var(o),true))&&temp.overwriteTargetFileWithTemporary();
}}
