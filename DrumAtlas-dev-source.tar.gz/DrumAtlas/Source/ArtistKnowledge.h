#pragma once
#include <juce_core/juce_core.h>
#include <vector>
namespace atlas::knowledge {
enum class Use { Metadata, AnalyzeOnce, RetainFeatures, Train, Redistribute };
struct Source {
    juce::String id, contentHash, rightsHolder, licenceDocument;
    std::vector<Use> permissions;
    juce::StringArray territories;
    int64_t expiresAtMs=0;
    bool reviewed=false, revoked=false;
};
struct Feature { juce::String name, value, extractionMethod;juce::StringArray sourceIds;double confidence=0;int64_t reviewedAtMs=0; };
struct Artist {juce::String id,name,era;juce::StringArray aliases;std::vector<Feature> features;};
struct ModelUse {juce::String version;juce::StringArray sourceIds;};
class Registry {
public:
    juce::Result addSource(Source);
    juce::Result addArtist(Artist);
    const Artist* find(const juce::String& name)const;
    bool permitted(const juce::String& sourceId,Use,const juce::String& territory,int64_t nowMs)const;
    juce::Result registerTraining(const juce::String& version,const juce::StringArray& sources,const juce::String& territory,int64_t nowMs);
    juce::StringArray revoke(const juce::String& sourceId);
    juce::var encode()const;
    juce::Result decode(const juce::var&);
private:
    std::vector<Source> sources;std::vector<Artist> artists;std::vector<ModelUse> models;
};
}
