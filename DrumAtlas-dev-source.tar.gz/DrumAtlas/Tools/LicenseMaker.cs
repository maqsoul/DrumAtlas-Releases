using System;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Security.Cryptography;
using System.Drawing;
using System.Windows.Forms;
class LicenseMaker {
 static string Folder=AppDomain.CurrentDomain.BaseDirectory;
 static string KeyPath=Path.Combine(Folder,"issuer-key.dpapi");
 static string B64(byte[] v){return Convert.ToBase64String(v).TrimEnd('=').Replace('+','-').Replace('/','_');}
 static string Issue(string machine){machine=machine.Trim();if(!Regex.IsMatch(machine,"^DA-PC-[a-f0-9]{64}$"))throw new Exception("Вставьте полный код компьютера DA-PC-… из DrumAtlas.");byte[] secret=ProtectedData.Unprotect(File.ReadAllBytes(KeyPath),null,DataProtectionScope.CurrentUser);try{using(var key=CngKey.Import(secret,CngKeyBlobFormat.EccPrivateBlob))using(var signer=new ECDsaCng(key)){signer.HashAlgorithm=CngAlgorithm.Sha256;string id=Guid.NewGuid().ToString();byte[] payload=Encoding.UTF8.GetBytes("DrumAtlas|1|"+machine+"|"+id);string code="DA1."+B64(payload)+"."+B64(signer.SignData(payload));File.AppendAllText(Path.Combine(Folder,"issued-licenses.csv"),DateTime.UtcNow.ToString("o")+","+id+","+machine+Environment.NewLine);return code;}}finally{Array.Clear(secret,0,secret.Length);}}
 [STAThread] static int Main(string[] args){try{
  if(args.Length==2&&args[0]=="--init"){if(File.Exists(KeyPath))throw new Exception("Signing key already exists; refusing to replace it.");var options=new CngKeyCreationParameters();options.ExportPolicy=CngExportPolicies.AllowPlaintextExport;using(var key=CngKey.Create(CngAlgorithm.ECDsaP256,null,options)){byte[] secret=key.Export(CngKeyBlobFormat.EccPrivateBlob);File.WriteAllBytes(KeyPath,ProtectedData.Protect(secret,null,DataProtectionScope.CurrentUser));Array.Clear(secret,0,secret.Length);byte[] pub=key.Export(CngKeyBlobFormat.EccPublicBlob);var sb=new StringBuilder("#pragma once\nnamespace atlas { inline constexpr unsigned char licensePublicKey[] = {");foreach(byte b in pub)sb.Append("0x"+b.ToString("x2")+",");sb.Append("}; }\n");File.WriteAllText(args[1],sb.ToString());}return 0;}
  if(args.Length==3&&args[0]=="--issue"){File.WriteAllText(args[2],Issue(args[1]));return 0;}
  Application.EnableVisualStyles();var form=new Form{Text="DrumAtlas — License Maker",ClientSize=new Size(740,420),BackColor=Color.FromArgb(11,22,33),ForeColor=Color.White,Font=new Font("Segoe UI",11),StartPosition=FormStartPosition.CenterScreen};
  var title=new Label{Text="DRUMATLAS  /  LICENSE MAKER",Location=new Point(24,20),Size=new Size(685,35),ForeColor=Color.Turquoise,Font=new Font("Segoe UI",17,FontStyle.Bold)};
  var note=new Label{Text="Только для владельца продукта. Не передавайте приложение вместе с ключом.\nОдин код активации привязан к одному коду компьютера.",Location=new Point(24,65),Size=new Size(690,55)};
  var label=new Label{Text="Код компьютера пользователя",Location=new Point(24,126),Size=new Size(600,24)};
  var machineBox=new TextBox{Location=new Point(24,155),Size=new Size(690,32)};
  var generate=new Button{Text="Создать код активации",Location=new Point(24,199),Size=new Size(260,38),BackColor=Color.FromArgb(26,106,100),FlatStyle=FlatStyle.Flat};
  var output=new TextBox{Location=new Point(24,249),Size=new Size(690,95),Multiline=true,ReadOnly=true,ScrollBars=ScrollBars.Vertical};
  var copy=new Button{Text="Копировать код",Location=new Point(24,361),Size=new Size(220,36),BackColor=Color.FromArgb(32,54,73),FlatStyle=FlatStyle.Flat};
  generate.Click+=delegate{try{output.Text=Issue(machineBox.Text);}catch(Exception e){MessageBox.Show(e.Message,"DrumAtlas");}};copy.Click+=delegate{if(output.Text.Length>0)Clipboard.SetText(output.Text);};form.Controls.AddRange(new Control[]{title,note,label,machineBox,generate,output,copy});Application.Run(form);return 0;
 }catch(Exception e){if(args.Length==0)MessageBox.Show(e.Message,"DrumAtlas");return 1;}}
}
