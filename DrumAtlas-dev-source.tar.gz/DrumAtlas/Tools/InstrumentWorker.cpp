// Standalone scanner: third-party modules never load in the DAW process.
#include <juce_audio_processors/juce_audio_processors.h>
#include <iostream>
#include <cstdlib>
#include <cmath>
#include "InstrumentOffline.h"
int main(int argc,char**argv){
    if(argc==2&&juce::String(argv[1])=="--test-crash")std::_Exit(66);
    if(argc==2&&juce::String(argv[1])=="--test-hang"){for(;;)juce::Thread::sleep(1000);}
    if(argc==5&&(juce::String(argv[1])=="--render"||juce::String(argv[1])=="--configure"||juce::String(argv[1])=="--capture")){
        juce::ScopedJuceInitialiser_GUI gui;
        return offline::run(juce::File(juce::String::fromUTF8(argv[2])),juce::File(juce::String::fromUTF8(argv[3])),juce::String::fromUTF8(argv[4]),juce::String(argv[1])=="--configure",juce::String(argv[1])=="--capture");
    }
    if(argc!=5||(juce::String(argv[1])!="--scan"&&juce::String(argv[1])!="--probe"))return 2;
    const bool probe=juce::String(argv[1])=="--probe";
    juce::ScopedJuceInitialiser_GUI gui;
    const auto path=juce::String::fromUTF8(argv[2]),request=juce::String::fromUTF8(argv[4]);
    auto*result=new juce::DynamicObject();juce::var root(result);result->setProperty("protocol",1);result->setProperty("request_id",request);result->setProperty("operation",probe?"PROBE":"SCAN");result->setProperty("status","error");
    try {
        if(!juce::File::isAbsolutePath(path))throw std::runtime_error("Absolute plugin path required");
        juce::VST3PluginFormat format;juce::OwnedArray<juce::PluginDescription> descriptions;format.findAllTypesForFile(descriptions,path);
        juce::Array<juce::var> plugins;
        for(auto*d:descriptions){auto*v=new juce::DynamicObject();v->setProperty("uid",d->createIdentifierString());v->setProperty("name",d->name);v->setProperty("vendor",d->manufacturerName);v->setProperty("version",d->version);v->setProperty("category",d->category);v->setProperty("instrument",d->isInstrument);v->setProperty("inputs",d->numInputChannels);v->setProperty("outputs",d->numOutputChannels);v->setProperty("path",d->fileOrIdentifier);v->setProperty("description_xml",d->createXml()->toString());v->setProperty("compatibility","Untested");plugins.add(v);}
        result->setProperty("plugins",plugins);result->setProperty("status",plugins.isEmpty()?"not_found":"scanned");
        if(probe){
            juce::PluginDescription*description=nullptr;for(auto*d:descriptions)if(d->isInstrument){description=d;break;}if(!description)throw std::runtime_error("No instrument class in this module");
            juce::String error;auto instance=format.createInstanceFromDescription(*description,44100,256,error);if(!instance)throw std::runtime_error(error.toStdString());
            instance->setRateAndBufferSizeDetails(44100,256);instance->prepareToPlay(44100,256);const int channels=std::max({2,instance->getTotalNumInputChannels(),instance->getTotalNumOutputChannels()});if(channels>64)throw std::runtime_error("Probe channel limit exceeded");
            juce::AudioBuffer<float> audio(channels,256);float peak=0;
            for(int frame=0;frame<88200;frame+=256){audio.clear();juce::MidiBuffer midi;if(frame==0)midi.addEvent(juce::MidiMessage::noteOn(1,60,juce::uint8(90)),0);if(frame<=44100&&frame+256>44100)midi.addEvent(juce::MidiMessage::noteOff(1,60),44100-frame);instance->processBlock(audio,midi);for(int ch=0;ch<channels;++ch)for(int i=0;i<256;++i){auto sample=audio.getSample(ch,i);if(!std::isfinite(sample))throw std::runtime_error("Non-finite instrument output");peak=std::max(peak,std::abs(sample));}}
            juce::MemoryBlock state;instance->getStateInformation(state);if(state.getSize()>32*1024*1024)throw std::runtime_error("Probe state limit exceeded");instance->setStateInformation(state.getData(),int(state.getSize()));instance->releaseResources();
            result->setProperty("probe_name",description->name);result->setProperty("sample_rate",44100);result->setProperty("block_size",256);result->setProperty("peak",peak);result->setProperty("state_bytes",juce::int64(state.getSize()));result->setProperty("latency_samples",instance->getLatencySamples());result->setProperty("has_editor",instance->hasEditor());result->setProperty("status",peak>0?"probed":"silent");result->setProperty("scope","Standalone MIDI/audio/state only; GUI, DAW integration and realtime IPC untested");
        }
    }catch(const std::exception&e){result->setProperty("status","error");result->setProperty("error",juce::String::fromUTF8(e.what()));}
    juce::File output(juce::String::fromUTF8(argv[3]));return output.replaceWithText(juce::JSON::toString(root))?0:3;
}
