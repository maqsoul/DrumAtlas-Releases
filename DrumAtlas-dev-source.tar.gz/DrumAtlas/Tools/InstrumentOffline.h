#pragma once
#include <juce_audio_formats/juce_audio_formats.h>
#include <juce_cryptography/juce_cryptography.h>

namespace offline {
inline void require(bool ok,const juce::String&why){if(!ok)throw std::runtime_error(why.toStdString());}
inline juce::String checksum(const juce::MemoryBlock&b){return juce::SHA256(b).toHexString();}
struct PlayHead:juce::AudioPlayHead {
    PositionInfo position;
    juce::Optional<PositionInfo>getPosition()const override{return position;}
};
class ConfigureWindow:public juce::DocumentWindow {
public:
    ConfigureWindow(juce::AudioPluginInstance&p,bool&accepted):DocumentWindow(p.getName()+" — save sound then close",juce::Colours::darkgrey,allButtons),accept(accepted){
        setUsingNativeTitleBar(true);auto*editor=p.createEditorIfNeeded();require(editor!=nullptr,"Instrument has no editor");
        content=std::make_unique<juce::Component>();content->addAndMakeVisible(editor);pluginEditor.reset(editor);
        content->addAndMakeVisible(save);content->addAndMakeVisible(cancel);save.setButtonText("Save sound and close");cancel.setButtonText("Cancel");
        save.setBounds(8,8,190,28);cancel.setBounds(208,8,90,28);editor->setTopLeftPosition(0,44);
        content->setSize(std::max(320,editor->getWidth()),editor->getHeight()+44);setContentNonOwned(content.get(),true);
        save.onClick=[this]{accept=true;juce::MessageManager::getInstance()->stopDispatchLoop();};
        cancel.onClick=[this]{closeButtonPressed();};centreWithSize(getWidth(),getHeight());setVisible(true);
    }
    ~ConfigureWindow()override{clearContentComponent();pluginEditor.reset();}
    void closeButtonPressed()override{juce::MessageManager::getInstance()->stopDispatchLoop();}
private:
    bool&accept;juce::TextButton save,cancel;std::unique_ptr<juce::Component>content;std::unique_ptr<juce::AudioProcessorEditor>pluginEditor;
};

inline int run(const juce::File&requestFile,const juce::File&responseFile,const juce::String&id,bool configure,bool capture=false){
    auto*out=new juce::DynamicObject;juce::var response(out);out->setProperty("request_id",id);out->setProperty("protocol",2);out->setProperty("status","error");
    try{
        require(requestFile.getSize()>0&&requestFile.getSize()<=64*1024*1024,"Invalid render request size");
        auto request=juce::JSON::parse(requestFile);require(request.isObject()&&request["request_id"].toString()==id,"Invalid request identity");
        auto config=request["instrument"];auto path=config["path"].toString();require(juce::File::isAbsolutePath(path)&&juce::File(path).exists(),"Instrument is missing; MIDI remains available");
        double rate=double(request.getProperty("sample_rate",44100));int block=int(request.getProperty("block_size",256));
        require((rate==44100||rate==48000||rate==96000)&&(block==64||block==128||block==256||block==512||block==1024),"Invalid render format");
        juce::VST3PluginFormat format;juce::OwnedArray<juce::PluginDescription>found;format.findAllTypesForFile(found,path);juce::PluginDescription*description=nullptr;
        auto uid=config["uid"].toString();
        for(auto*d:found)if(d->isInstrument&&(uid.isEmpty()||d->createIdentifierString()==uid)){description=d;break;}
        require(description!=nullptr,"Saved instrument class not found");
        juce::String error;auto instance=format.createInstanceFromDescription(*description,rate,block,error);require(bool(instance),"Cannot create instrument: "+error);
        auto layout=instance->getBusesLayout();for(auto&bus:layout.inputBuses)bus=juce::AudioChannelSet::disabled();for(auto&bus:layout.outputBuses)bus=juce::AudioChannelSet::disabled();
        require(!layout.outputBuses.isEmpty(),"Instrument has no output");layout.outputBuses.getReference(0)=juce::AudioChannelSet::stereo();
        if(!instance->setBusesLayout(layout)){layout.outputBuses.getReference(0)=juce::AudioChannelSet::mono();require(instance->setBusesLayout(layout),"Only mono/stereo main output is supported");}
        require(instance->getTotalNumOutputChannels()>=1&&instance->getTotalNumOutputChannels()<=2,"Unsupported output layout");
        auto encoded=config["state"].toString();if(encoded.isNotEmpty()){
            juce::MemoryBlock state;require(encoded.length()<=24*1024*1024&&state.fromBase64Encoding(encoded)&&state.getSize()<=16*1024*1024,"Invalid instrument state");
            require(checksum(state)==config["sha256"].toString(),"Instrument state checksum mismatch");instance->setStateInformation(state.getData(),int(state.getSize()));
        }
        instance->setNonRealtime(!configure);instance->setRateAndBufferSizeDetails(rate,block);instance->prepareToPlay(rate,block);
        require(instance->getTotalNumOutputChannels()>=1&&instance->getTotalNumOutputChannels()<=2&&instance->getTotalNumInputChannels()==0,"Instrument state changed output layout");
        if(configure||capture){
            bool accepted=capture;
            if(capture){if(auto*parameters=request["parameters"].getArray())for(auto&entry:*parameters){int index=int(entry["index"]);float value=float(entry["value"]);require(index>=0&&index<instance->getParameters().size()&&std::isfinite(value)&&value>=0&&value<=1,"Invalid parameter");instance->getParameters()[index]->setValueNotifyingHost(value);}}
            else{ConfigureWindow window(*instance,accepted);juce::MessageManager::getInstance()->runDispatchLoop();}
            if(!accepted){out->setProperty("status","cancelled");}
            else{
                juce::MemoryBlock state;instance->getStateInformation(state);require(state.getSize()<=16*1024*1024,"Instrument state too large");
                auto*c=new juce::DynamicObject;juce::var saved(c);c->setProperty("schema",1);c->setProperty("path",path);c->setProperty("uid",description->createIdentifierString());c->setProperty("name",description->name);c->setProperty("xml",description->createXml()->toString());c->setProperty("state",state.toBase64Encoding());c->setProperty("sha256",checksum(state));out->setProperty("instrument",saved);out->setProperty("status","configured");
            }
        }else{
            const double seconds=double(request["song_seconds"]),bpm=double(request["bpm"]);
            require(std::isfinite(seconds)&&seconds>0&&seconds<=100000&&std::isfinite(bpm)&&bpm>=20&&bpm<=300,"Invalid timeline");
            const int numerator=int(request["numerator"]),denominator=int(request["denominator"]);require(numerator>=1&&numerator<=12&&(denominator==4||denominator==8),"Invalid meter");
            const double tail=std::max(2.,instance->getTailLengthSeconds());require(std::isfinite(tail)&&tail<=600,"Instrument reports unsupported/infinite tail");
            const int latency=instance->getLatencySamples();require(latency>=0&&latency<=int(rate*60),"Invalid instrument latency");
            const int64_t frames=int64_t(std::ceil((seconds+tail)*rate)),processFrames=frames+latency;
            struct Event{int64_t frame;juce::MidiMessage midi;};std::vector<Event>events;
            auto*notes=request["notes"].getArray();require(notes&&notes->size()<=100000,"Invalid MIDI payload");
            for(auto&n:*notes){auto start=juce::int64(n["start"]),end=juce::int64(n["end"]);int channel=int(n["channel"]),pitch=int(n["pitch"]),velocity=int(n["velocity"]);
                require(start>=0&&end>start&&end<=int64_t(std::ceil(seconds*rate))+1&&pitch>=0&&pitch<=127&&velocity>=1&&velocity<=127&&channel>=1&&channel<=16,"Invalid MIDI event");
                events.push_back({start,juce::MidiMessage::noteOn(channel,pitch,juce::uint8(velocity))});events.push_back({end,juce::MidiMessage::noteOff(channel,pitch)});
            }
            std::stable_sort(events.begin(),events.end(),[](const Event&a,const Event&b){return a.frame<b.frame||(a.frame==b.frame&&a.midi.isNoteOff()&&!b.midi.isNoteOff());});
            auto output=responseFile.getSiblingFile("audio.wav");juce::TemporaryFile temporary(output);std::unique_ptr<juce::OutputStream>stream=temporary.getFile().createOutputStream();require(bool(stream),"Cannot create render file");
            juce::WavAudioFormat wav;auto writer=wav.createWriterFor(stream,juce::AudioFormatWriterOptions{}.withSampleRate(rate).withNumChannels(2).withBitsPerSample(32).withSampleFormat(juce::AudioFormatWriterOptions::SampleFormat::floatingPoint));require(bool(writer),"Cannot create float WAV");
            PlayHead head;struct ResetHead{juce::AudioPluginInstance&instance;~ResetHead(){instance.setPlayHead(nullptr);}}resetHead{*instance};instance->setPlayHead(&head);head.position.setBpm(bpm);head.position.setTimeSignature(juce::AudioPlayHead::TimeSignature{numerator,denominator});head.position.setIsPlaying(true);
            juce::AudioBuffer<float>audio(2,block);size_t next=0;double peak=0;auto progress=responseFile.getSiblingFile("progress");uint32_t lastProgress=0;
            for(int64_t offset=0;offset<processFrames;offset+=block){
                int count=int(std::min<int64_t>(block,processFrames-offset));audio.setSize(2,count,false,false,true);audio.clear();juce::MidiBuffer midi;
                while(next<events.size()&&events[next].frame<offset+count){if(events[next].frame>=offset)midi.addEvent(events[next].midi,int(events[next].frame-offset));++next;}
                head.position.setTimeInSamples(offset);head.position.setTimeInSeconds(offset/rate);head.position.setPpqPosition(offset/rate*bpm/60.);head.position.setPpqPositionOfLastBarStart(std::floor(offset/rate*bpm/60./(numerator*4./denominator))*(numerator*4./denominator));
                instance->processBlock(audio,midi);require(instance->getLatencySamples()==latency,"Instrument latency changed during render; retry");
                if(instance->getTotalNumOutputChannels()==1)audio.copyFrom(1,0,audio,0,0,count);
                for(int ch=0;ch<2;++ch)for(int i=0;i<count;++i){float sample=audio.getSample(ch,i);require(std::isfinite(sample)&&std::abs(sample)<1000000,"Invalid instrument output");peak=std::max(peak,double(std::abs(sample)));}
                const int skip=int(std::max<int64_t>(0,std::min<int64_t>(count,latency-offset)));if(count>skip)require(writer->writeFromAudioSampleBuffer(audio,skip,count-skip),"Instrument WAV write failed");
                auto now=juce::Time::getMillisecondCounter();if(now-lastProgress>500){require(progress.replaceWithText(juce::String(offset)),"Cannot report progress");lastProgress=now;}
            }
            require(writer->flush(),"Cannot finish instrument WAV");writer.reset();require(temporary.overwriteTargetFileWithTemporary(),"Cannot commit instrument render");
            out->setProperty("status","rendered");out->setProperty("latency_samples",latency);out->setProperty("tail_seconds",tail);out->setProperty("frames",juce::int64(frames));out->setProperty("peak",peak);
            instance->setPlayHead(nullptr);
        }
        instance->releaseResources();
    }catch(const std::exception&e){out->setProperty("error",juce::String::fromUTF8(e.what()));}
    return responseFile.replaceWithText(juce::JSON::toString(response))?0:3;
}
}
