# DrumAtlas AAX Native

Windows x64 AAX compilation succeeded on 11 October 2026 (JUCE 9.0.3 bundled SDK).
This is an UNSIGNED development build. It is not ready for retail Pro Tools.
No signing keys, paid services or purchases were used.

Enable with -DDRUMATLAS_BUILD_AAX=ON, then build target DrumAtlas_AAX.
The local Windows helper accepts: work/build.ps1 -Configure -Aax -Target DrumAtlas_AAX.
The same CMake option is available on macOS; no macOS AAX build has been verified.
Do not change the AAX identifier audio.drumatlas.browser between updates.

Windows bundle: DrumAtlas_artefacts/Release/AAX/DrumAtlas.aaxplugin
Models are copied beside the x64 binary when DRUMATLAS_MODEL_DIR is configured.
On macOS, the existing model lookup supports bundle Resources/Models or the
shared /Library/Application Support/DrumAtlas/Models directory.

Retail Pro Tools requires PACE AAX signing. This is separate from DrumAtlas
serial activation and does not switch customers to iLok licensing.
JUCE says Avid provides signing tools free of charge, after developer testing.
Avid states commercial signing requires an iLok USB key. Zero-cost completion
cannot be promised if the owner has no hardware key or approved signing access.

Required external steps:
1. Owner registers with Avid Developer and accepts applicable agreements.
2. Obtain Pro Tools Developer access; test the unsigned plug-in with audio,
   UI resize, preview, DAW tempo, drag/drop, reopening sessions and offline license.
3. Request PACE Eden signing tools from audiosdk@avid.com with the evidence and
   developer information required by Avid. Do not send account passwords.
4. Sign and validate the completed bundle, then test in retail Pro Tools.
5. Only then add the signed bundle to customer installers / public releases.

No email has been sent on the owner's behalf.
Official references:
https://developer.avid.com/aax/
https://github.com/juce-framework/JUCE#aax-plug-ins
https://paceap.com/juce/
