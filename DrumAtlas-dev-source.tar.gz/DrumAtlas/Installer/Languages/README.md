# Installer translations

ChineseSimplified.isl and Korean.isl: https://github.com/jrsoftware/issrc/tree/main/Files/Languages
Kazakh.islu and Uzbek.isl: https://github.com/jrsoftware/issrc/tree/main/Files/Languages/Unofficial
Retrieved 2026-10-16. Contributor credits retained in source files. Encodings normalized to UTF-8 with BOM.
Other standard languages use the translations bundled with Inno Setup.
Kyrgyz.isl: DrumAtlas wizard translation; uncommon system diagnostics fall back to English. License text and third-party legal notices retain their original language.
