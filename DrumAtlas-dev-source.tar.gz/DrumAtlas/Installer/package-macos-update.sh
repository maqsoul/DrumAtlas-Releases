#!/bin/bash
set -euo pipefail
: "${DRUMATLAS_BUILD_DIR:?}"

: "${DRUMATLAS_VERSION:?}"
[[ "$(uname -s)" == Darwin ]] || exit 1
src="$(cd "$(dirname "$0")/.." && pwd)"
stage="$(mktemp -d "${TMPDIR:-/tmp}/drumatlas-package.XXXXXX")"
app="$DRUMATLAS_BUILD_DIR/DrumAtlas_artefacts/Release/Standalone/DrumAtlas.app"
vst="$DRUMATLAS_BUILD_DIR/DrumAtlas_artefacts/Release/VST3/DrumAtlas.vst3"
cmake --build "$DRUMATLAS_BUILD_DIR" --config Release --parallel 3 --target DrumAtlas_AU
au="$DRUMATLAS_BUILD_DIR/DrumAtlas_artefacts/Release/AU/DrumAtlas.component"
[[ -d "$app" && -d "$vst" && -d "$au" ]] || exit 1
# Seal the finished AU bundle for native Apple Silicon loading. This is a local
# ad-hoc signature, not Developer ID signing or Apple notarization.
/usr/bin/codesign --force --sign - "$au"
/usr/bin/codesign --verify --deep --strict "$au"
# Validate the actual AU bundle on the disposable macOS build runner.
if [[ "${CI:-}" == true ]]; then
 # Use the same system-wide destination as the customer installer. A headless
 # runner's registrar does not always scan its user Library immediately.
 sudo mkdir -p /Library/Audio/Plug-Ins/Components
 sudo ditto "$au" /Library/Audio/Plug-Ins/Components/DrumAtlas.component
 sudo touch /Library/Audio/Plug-Ins/Components
else
 mkdir -p "$HOME/Library/Audio/Plug-Ins/Components"
 ditto "$au" "$HOME/Library/Audio/Plug-Ins/Components/DrumAtlas.component"
fi
/usr/bin/plutil -p "$au/Contents/Info.plist"
# Refresh only the disposable CI runner registration service after copying the AU.
if [[ "${CI:-}" == true ]]; then killall AudioComponentRegistrar 2>/dev/null || true; fi
for attempt in {1..10}; do
 /usr/bin/auval -a > "$DRUMATLAS_BUILD_DIR/au-list.txt"
 if grep -Eq 'aufx[[:space:]]+Da01[[:space:]]+DAtl' "$DRUMATLAS_BUILD_DIR/au-list.txt"; then break; fi
 sleep 3
done
cat "$DRUMATLAS_BUILD_DIR/au-list.txt"
/usr/bin/auval -v aufx Da01 DAtl | tee "$DRUMATLAS_BUILD_DIR/auval.txt"
mkdir -p "$stage/app/Applications" "$stage/vst/Library/Audio/Plug-Ins/VST3" "$stage/au/Library/Audio/Plug-Ins/Components" "$stage/packages"
ditto "$app" "$stage/app/Applications/DrumAtlas.app"
ditto "$vst" "$stage/vst/Library/Audio/Plug-Ins/VST3/DrumAtlas.vst3"
ditto "$au" "$stage/au/Library/Audio/Plug-Ins/Components/DrumAtlas.component"
shared="$stage/data/Library/Application Support/DrumAtlas"
mkdir -p "$shared/Source" "$shared/Tools"
cmake --build "$DRUMATLAS_BUILD_DIR" --config Release --target AtlasWorker
worker="$DRUMATLAS_BUILD_DIR/AtlasWorker_artefacts/Release/AtlasWorker"
[[ -x "$worker" ]] || { echo 'Missing AtlasWorker'; exit 1; }
ditto "$worker" "$shared/Tools/AtlasWorker"
codesign --force --sign "${DRUMATLAS_APP_IDENTITY:--}" "$shared/Tools/AtlasWorker"
codesign --verify --strict "$shared/Tools/AtlasWorker"

ditto "$src/Installer/MacAssets/Notices" "$shared/Licenses"
for entry in Source Resources ThirdParty Tests Tools Installer LicenseServer CMakeLists.txt LICENSE JUCE-LICENSE.md THIRD_PARTY.md README.md RELEASE-SERVICES.md; do
 ditto "$src/$entry" "$shared/Source/$entry"
done
if find "$stage" \( -name server-secrets.json -o -name '*.pem' -o -name '*.sqlite*' -o -name '*.dpapi' -o -name '*.dll' -o -name '*.onnx' \) -print -quit | grep -q .; then
 echo 'Unexpected private or Windows files'; exit 1
fi
for component in app vst au; do
 pkgbuild --analyze --root "$stage/$component" "$stage/$component.plist"
 python3 - "$stage/$component.plist" <<'PY'
import plistlib,sys
p=sys.argv[1]
with open(p,'rb') as f: rows=plistlib.load(f)
for row in rows:
 row['BundleIsRelocatable']=False
 row['BundleOverwriteAction']='upgrade'
with open(p,'wb') as f: plistlib.dump(rows,f)
PY
 pkgbuild --root "$stage/$component" --component-plist "$stage/$component.plist" --identifier "audio.drumatlas.$component" --version "$DRUMATLAS_VERSION" --install-location / "$stage/packages/$component.pkg"
done
pkgbuild --root "$stage/data" --identifier audio.drumatlas.update-metadata --version "$DRUMATLAS_VERSION" --install-location / "$stage/packages/data.pkg"
cat > "$stage/welcome.html" <<'HTML'
<html><body style="background:white;color:#17212b;font-family:Helvetica;padding:20px"><h1 style="color:#176d65">DrumAtlas / ION</h1><p>Sample library, reference analysis and AI stems.</p><p>Choose AU for Logic Pro, VST3 for other compatible DAWs, and/or the Standalone application. Existing AI models are preserved. Install this update over a complete DrumAtlas installation.</p><p>This package is not signed with Apple Developer ID. DrumAtlas checks the signed update feed automatically; close your DAW before installing an update.</p></body></html>
HTML
cat > "$stage/Distribution.xml" <<XML
<installer-gui-script minSpecVersion="2">
 <title>DrumAtlas 1.0.0</title>
 <welcome file="welcome.html"/>
 <options customize="always" require-scripts="false" hostArchitectures="$(uname -m)"/>
 <domains enable_localSystem="true" enable_currentUserHome="false"/>
 <choices-outline><line choice="au"/><line choice="vst"/><line choice="app"/><line choice="data"/></choices-outline>
 <choice id="au" title="DrumAtlas AU (Logic Pro)" start_selected="true"><pkg-ref id="audio.drumatlas.au"/></choice>
 <choice id="vst" title="DrumAtlas VST3" start_selected="true"><pkg-ref id="audio.drumatlas.vst"/></choice>
 <choice id="app" title="DrumAtlas Standalone" start_selected="true"><pkg-ref id="audio.drumatlas.app"/></choice>
 <choice id="data" title="Source and licences" visible="false" start_selected="true" enabled="false"><pkg-ref id="audio.drumatlas.update-metadata"/></choice>
 <pkg-ref id="audio.drumatlas.au" version="$DRUMATLAS_VERSION">au.pkg</pkg-ref>
 <pkg-ref id="audio.drumatlas.vst" version="$DRUMATLAS_VERSION">vst.pkg</pkg-ref>
 <pkg-ref id="audio.drumatlas.app" version="$DRUMATLAS_VERSION">app.pkg</pkg-ref>
 <pkg-ref id="audio.drumatlas.update-metadata" version="$DRUMATLAS_VERSION">data.pkg</pkg-ref>
</installer-gui-script>
XML
output="$DRUMATLAS_BUILD_DIR/DrumAtlas-$DRUMATLAS_VERSION-$(uname -m)-Update.pkg"
productbuild --distribution "$stage/Distribution.xml" --resources "$stage" --package-path "$stage/packages" "$output"
shasum -a 256 "$output" > "$output.sha256"
pkgutil --expand "$output" "$stage/check"
test -f "$stage/check/Distribution"
echo "Verified package structure: $output"
