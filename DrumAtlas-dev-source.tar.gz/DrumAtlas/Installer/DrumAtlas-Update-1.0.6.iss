#ifndef Payload
  #define Payload "..\..\DrumAtlas-1.0.6-Update-Windows"
#endif
[Setup]
AppId={{91F64D32-933B-4FF4-88A8-023DAAD82DB1}
AppName=DrumAtlas
AppVersion=1.0.6
AppVerName=DrumAtlas 1.0.6
AppPublisher=DrumAtlas
DefaultDirName={autopf64}\DrumAtlas
DefaultGroupName=DrumAtlas
OutputDir=..\..
OutputBaseFilename=DrumAtlas-1.0.6-Update
Compression=lzma2/ultra64
SolidCompression=yes
ArchitecturesAllowed=x64
ArchitecturesInstallIn64BitMode=x64
PrivilegesRequired=admin
MinVersion=10.0
WizardStyle=modern
WizardSizePercent=110
WizardImageFile=banner.bmp
WizardSmallImageFile=mark.bmp
WizardImageStretch=yes
DisableWelcomePage=no
InfoBeforeFile=update-notice.txt
DisableProgramGroupPage=yes
UninstallDisplayName=DrumAtlas 1.0.6
UninstallDisplayIcon={app}\Standalone\DrumAtlas.exe
LicenseFile=..\LICENSE
CloseApplications=yes
RestartApplications=no
SetupLogging=yes

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"
Name: "russian"; MessagesFile: "compiler:Languages\Russian.isl"

[Types]
Name: "full"; Description: "VST3 + Standalone"
Name: "plugin"; Description: "VST3"
Name: "custom"; Description: "Custom"; Flags: iscustom

[Components]
Name: "vst3"; Description: "DrumAtlas VST3 (64-bit)"; Types: full plugin custom; Flags: fixed
Name: "standalone"; Description: "DrumAtlas Standalone"; Types: full

[Files]
Source: "{#Payload}\DRUM-SEPARATION-RU.md"; DestDir: "{app}"; Flags: ignoreversion
Source: "{#Payload}\VST3\DrumAtlas.vst3\*"; DestDir: "{commoncf64}\VST3\DrumAtlas.vst3"; Flags: ignoreversion recursesubdirs createallsubdirs; Components: vst3
Source: "{#Payload}\Standalone\*"; DestDir: "{app}\Standalone"; Flags: ignoreversion recursesubdirs createallsubdirs; Components: standalone
Source: "{#Payload}\README-RU.md"; DestDir: "{app}"; Flags: ignoreversion
Source: "{#Payload}\Licenses\*"; DestDir: "{app}\Licenses"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "{#Payload}\Source\*"; DestDir: "{app}\Source"; Flags: ignoreversion recursesubdirs createallsubdirs

[Icons]
Name: "{group}\DrumAtlas"; Filename: "{app}\Standalone\DrumAtlas.exe"; Components: standalone
Name: "{group}\Uninstall DrumAtlas"; Filename: "{uninstallexe}"

[Run]
Filename: "{app}\Standalone\DrumAtlas.exe"; Description: "Launch DrumAtlas"; Flags: nowait postinstall skipifsilent unchecked; Components: standalone

[Code]
var
  LaunchCheck: TNewCheckBox;

procedure LaunchCheckClick(Sender: TObject);
begin
  if WizardForm.RunList.Items.Count = 1 then
    WizardForm.RunList.Checked[0] := LaunchCheck.Checked;
end;

procedure InitializeWizard;
begin
  WizardForm.Color := $F4F1EC;
  WizardForm.MainPanel.Color := $291C11;
  WizardForm.InnerPage.Color := $F4F1EC;
  WizardForm.Font.Name := 'Segoe UI';
  WizardForm.Font.Color := $291C11;
  WizardForm.WelcomeLabel1.Font.Color := $5F6617;
  WizardForm.WelcomeLabel2.Font.Color := $291C11;
  WizardForm.FinishedHeadingLabel.Font.Color := $5F6617;
  WizardForm.FinishedLabel.Font.Color := $291C11;
  WizardForm.PageNameLabel.Font.Color := $D1EE57;
  WizardForm.PageDescriptionLabel.Font.Color := $FFF2E8;
  WizardForm.LicenseMemo.Color := clWhite;
  WizardForm.LicenseMemo.Font.Color := clBlack;
  WizardForm.ReadyMemo.Color := clWhite;
  WizardForm.ReadyMemo.Font.Color := clBlack;
  WizardForm.ComponentsList.Color := clWhite;
  WizardForm.ComponentsList.Font.Color := clBlack;
  WizardForm.DirEdit.Color := clWhite;
  WizardForm.DirEdit.Font.Color := clBlack;
  WizardForm.GroupEdit.Color := clWhite;
  WizardForm.GroupEdit.Font.Color := clBlack;
  LaunchCheck := TNewCheckBox.Create(WizardForm);
  LaunchCheck.Parent := WizardForm.FinishedPage;
  LaunchCheck.Color := clWhite;
  LaunchCheck.Font.Color := $291C11;
  LaunchCheck.Visible := False;
  LaunchCheck.OnClick := @LaunchCheckClick;
end;

procedure CurPageChanged(CurPageID: Integer);
begin
  if CurPageID = wpFinished then
  begin
    { A native checkbox avoids the owner's clipped glyph in the themed RunList. }
    LaunchCheck.Visible := WizardForm.RunList.Visible and
      (WizardForm.RunList.Items.Count = 1);
    if LaunchCheck.Visible then
    begin
      LaunchCheck.Caption := WizardForm.RunList.ItemCaption[0];
      LaunchCheck.Checked := WizardForm.RunList.Checked[0];
      LaunchCheck.SetBounds(WizardForm.FinishedLabel.Left + ScaleX(4),
        WizardForm.RunList.Top, WizardForm.FinishedLabel.Width - ScaleX(8), ScaleY(30));
      WizardForm.RunList.Visible := False;
    end;
  end;
end;




#include "windows-runtime.iss"
