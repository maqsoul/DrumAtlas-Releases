Add-Type -AssemblyName System.Drawing
$bitmap = [Drawing.Bitmap]::new(328,628)
$g = [Drawing.Graphics]::FromImage($bitmap)
$g.SmoothingMode = 'AntiAlias'
$g.Clear([Drawing.ColorTranslator]::FromHtml('#0d1925'))
$accent = [Drawing.SolidBrush]::new([Drawing.ColorTranslator]::FromHtml('#57eed1'))
$muted = [Drawing.SolidBrush]::new([Drawing.ColorTranslator]::FromHtml('#a5bbd1'))
$font = [Drawing.Font]::new('Segoe UI',27,[Drawing.FontStyle]::Bold)
$small = [Drawing.Font]::new('Segoe UI',12)
$g.DrawString("DRUM`nATLAS",$font,$accent,28,28)
$g.DrawString('1.0.0 / ION',$small,$muted,32,151)
for($i=0;$i -lt 32;$i++) {
  $amplitude=18+78*[Math]::Abs([Math]::Sin($i*.29))+35*[Math]::Abs([Math]::Sin($i*.83))
  $g.FillRectangle($accent,[float](30+$i*8),[float](346-$amplitude),[float]2,[float](2*$amplitude))
}
$g.DrawString("YOUR SOUNDS.`nCONNECTED.",$small,$muted,32,537)
$bitmap.Save((Join-Path $PSScriptRoot 'banner.bmp'),[Drawing.Imaging.ImageFormat]::Bmp)
$g.Dispose();$bitmap.Dispose()
$mark = [Drawing.Bitmap]::new(64,64);$mg=[Drawing.Graphics]::FromImage($mark)
$mg.Clear([Drawing.ColorTranslator]::FromHtml('#111c29'))
$mg.FillRectangle($accent,12,16,4,32);$mg.FillRectangle($accent,24,7,4,50);$mg.FillRectangle($accent,36,20,4,25);$mg.FillRectangle($accent,48,13,4,38)
$mark.Save((Join-Path $PSScriptRoot 'mark.bmp'),[Drawing.Imaging.ImageFormat]::Bmp)
$mg.Dispose();$mark.Dispose();$accent.Dispose();$muted.Dispose();$font.Dispose();$small.Dispose()

