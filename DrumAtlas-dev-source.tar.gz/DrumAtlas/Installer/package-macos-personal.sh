#!/bin/bash
set -euo pipefail
: "${DRUMATLAS_BUILD_DIR:?}"
: "${DRUMATLAS_MODEL_DIR:?}"
: "${DRUMATLAS_VERSION:?}"
[[ "$(uname -s)" == Darwin ]] || exit 1
src="$(cd "$(dirname "$0")/.." && pwd)"
stage="$(mktemp -d "${TMPDIR:-/tmp}/drumatlas-package.XXXXXX")"
app="$DRUMATLAS_BUILD_DIR/DrumAtlas_artefacts/Release/Standalone/DrumAtlas.app"
vst="$DRUMATLAS_BUILD_DIR/DrumAtlas_artefacts/Release/VST3/DrumAtlas.vst3"
[[ -d "$app" && -d "$vst" ]] || exit 1
for model in yamnet.onnx htdemucs_6s.onnx mdx23c_drumsep.onnx audiosep_resunet.onnx percussion-prompts.json libonnxruntime.dylib; do
 [[ -s "$DRUMATLAS_MODEL_DIR/$model" ]] || { echo "Missing $model"; exit 1; }
done
lipo "$DRUMATLAS_MODEL_DIR/libonnxruntime.dylib" -verify_arch "$(uname -m)"
mkdir -p "$stage/app/Applications" "$stage/vst/Library/Audio/Plug-Ins/VST3" "$stage/packages"
ditto "$app" "$stage/app/Applications/DrumAtlas.app"
ditto "$vst" "$stage/vst/Library/Audio/Plug-Ins/VST3/DrumAtlas.vst3"
shared="$stage/data/Library/Application Support/DrumAtlas"
mkdir -p "$shared/Source" "$shared/Tools"
cmake --build "$DRUMATLAS_BUILD_DIR" --config Release --target AtlasWorker
worker="$DRUMATLAS_BUILD_DIR/AtlasWorker_artefacts/Release/AtlasWorker"
[[ -x "$worker" ]] || { echo 'Missing AtlasWorker'; exit 1; }
ditto "$worker" "$shared/Tools/AtlasWorker"
codesign --force --sign "${DRUMATLAS_APP_IDENTITY:--}" "$shared/Tools/AtlasWorker"
codesign --verify --strict "$shared/Tools/AtlasWorker"
ditto "$DRUMATLAS_MODEL_DIR" "$shared/Models"
ditto "$src/Installer/MacAssets/Notices" "$shared/Licenses"
for entry in Source Resources ThirdParty Tests Tools Installer LicenseServer CMakeLists.txt LICENSE JUCE-LICENSE.md THIRD_PARTY.md README.md RELEASE-SERVICES.md; do
 ditto "$src/$entry" "$shared/Source/$entry"
done
if find "$stage" \( -name server-secrets.json -o -name '*.pem' -o -name '*.sqlite*' -o -name '*.dpapi' -o -name '*.dll' \) -print -quit | grep -q .; then
 echo 'Unexpected private or Windows files'; exit 1
fi
for component in app vst; do
 pkgbuild --analyze --root "$stage/$component" "$stage/$component.plist"
 python3 - "$stage/$component.plist" <<'PY'
import plistlib,sys
p=sys.argv[1]
with open(p,'rb') as f: rows=plistlib.load(f)
for row in rows:
 row['BundleIsRelocatable']=False
 row['BundleOverwriteAction']='upgrade'
with open(p,'wb') as f: plistlib.dump(rows,f)
PY
 pkgbuild --root "$stage/$component" --component-plist "$stage/$component.plist" --identifier "audio.drumatlas.$component" --version "$DRUMATLAS_VERSION" --install-location / "$stage/packages/$component.pkg"
done
pkgbuild --root "$stage/data" --identifier audio.drumatlas.models --version "$DRUMATLAS_VERSION" --install-location / "$stage/packages/data.pkg"
cat > "$stage/welcome.html" <<'HTML'
<html><body style="background:white;color:#17212b;font-family:Helvetica;padding:20px"><h1 style="color:#176d65">DrumAtlas / ION</h1><p>Sample library, reference analysis and AI stems.</p><p>Choose VST3 for your DAW and/or the Standalone application. AI models are shared by both components.</p><p>This personal test build is not signed with Apple Developer ID. Internet is required for initial serial activation. Automatic updates are not connected yet.</p></body></html>
HTML
cat > "$stage/Distribution.xml" <<XML
<installer-gui-script minSpecVersion="2">
 <title>DrumAtlas $DRUMATLAS_VERSION</title>
 <welcome file="welcome.html"/>
 <options customize="always" require-scripts="false" hostArchitectures="$(uname -m)"/>
 <domains enable_localSystem="true" enable_currentUserHome="false"/>
 <choices-outline><line choice="vst"/><line choice="app"/><line choice="data"/></choices-outline>
 <choice id="vst" title="DrumAtlas VST3" start_selected="true"><pkg-ref id="audio.drumatlas.vst"/></choice>
 <choice id="app" title="DrumAtlas Standalone" start_selected="true"><pkg-ref id="audio.drumatlas.app"/></choice>
 <choice id="data" title="AI models and licences" visible="false" start_selected="true" enabled="false"><pkg-ref id="audio.drumatlas.models"/></choice>
 <pkg-ref id="audio.drumatlas.vst" version="$DRUMATLAS_VERSION">vst.pkg</pkg-ref>
 <pkg-ref id="audio.drumatlas.app" version="$DRUMATLAS_VERSION">app.pkg</pkg-ref>
 <pkg-ref id="audio.drumatlas.models" version="$DRUMATLAS_VERSION">data.pkg</pkg-ref>
</installer-gui-script>
XML
output="$DRUMATLAS_BUILD_DIR/DrumAtlas-$DRUMATLAS_VERSION-$(uname -m)-Personal.pkg"
productbuild --distribution "$stage/Distribution.xml" --resources "$stage" --package-path "$stage/packages" "$output"
shasum -a 256 "$output" > "$output.sha256"
pkgutil --expand "$output" "$stage/check"
test -f "$stage/check/Distribution"
echo "Verified package structure: $output"
