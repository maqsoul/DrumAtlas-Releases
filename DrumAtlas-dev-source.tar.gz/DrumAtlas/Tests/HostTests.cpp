#include "../Source/InstrumentScanner.h"
#include <iostream>
int main(int argc,char**argv){if(argc!=4&&argc!=5)return 2;bool probe=argc==5&&juce::String(argv[4])=="--probe";auto worker=juce::File(juce::String::fromUTF8(argv[1]));auto r=atlas::hosting::testIsolation(worker);if(r.failed()){std::cerr<<r.getErrorMessage()<<"\n";return 1;}
 auto result=atlas::hosting::scan(worker,juce::File(juce::String::fromUTF8(argv[2])),juce::File(juce::String::fromUTF8(argv[3])),30000,probe);
 juce::File(juce::String::fromUTF8(argv[3])).getChildFile("last-probe.json").replaceWithText(juce::JSON::toString(result.report));
 if(result.status!=(probe?"probed":"scanned")||!result.plugins.isArray()||result.plugins.size()==0){std::cerr<<result.status<<": "<<result.error<<"\n";return 1;}
 for(auto&p:*result.plugins.getArray())if(p["name"].toString()=="DrumAtlas"&&bool(p["instrument"])){std::cerr<<"Fx misclassified as instrument\n";return 1;}
 juce::File(juce::String::fromUTF8(argv[3])).getChildFile("last-scan.json").replaceWithText(juce::JSON::toString(result.plugins));
 for(auto&p:*result.plugins.getArray())std::cout<<p["name"].toString()<<" "<<p["version"].toString()<<" instrument="<<bool(p["instrument"])<<" (scan only)\n";
 std::cout<<(probe?"PASS standalone instrument MIDI/audio/state probe; other compatibility gates remain open\n":"PASS scanner worker: isolated abrupt exit, bounded hang termination, VST3 discovery, effect/instrument distinction\n");return 0;
}
