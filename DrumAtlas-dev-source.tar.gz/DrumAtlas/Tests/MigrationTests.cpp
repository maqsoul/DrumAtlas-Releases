#include "../Source/LibraryMigration.h"
#include <iostream>
#include <stdexcept>
static void check(bool b,const char*m){if(!b)throw std::runtime_error(m);}
int main(int argc,char**argv){try{
    if(argc==3&&juce::String(argv[1])=="--copy-fixture"){
        const auto root=juce::File(juce::String::fromUTF8(argv[2]));auto r=atlas::prepareLibraryMigration(root,true);check(r.wasOk(),r.getErrorMessage().toRawUTF8());check(atlas::prepareLibraryMigration(root,true).wasOk(),"real fixture repeat");
        auto manifest=juce::JSON::parse(root.getChildFile("migration-v2-backup/manifest.json"));auto restored=root.getChildFile("rollback-verification");restored.createDirectory();
        for(auto&entry:*manifest["files"].getArray()){auto relative=entry["path"].toString();auto source=root.getChildFile("migration-v2-backup").getChildFile(relative),target=restored.getChildFile(relative);target.getParentDirectory().createDirectory();check(source.copyFileTo(target),"rollback copy");juce::FileInputStream a(target),b(root.getChildFile(relative));check(juce::SHA256(a).toHexString()==juce::SHA256(b).toHexString(),"rollback hash mismatch");}
        std::cout<<"PASS copied real metadata: backup, repeated migration and rollback byte hashes\n";return 0;
    }
    check(argc==2,"scratch required");auto dir=juce::File(juce::String::fromUTF8(argv[1])).getChildFile(juce::Uuid().toString());dir.createDirectory();dir.getChildFile("splice").createDirectory();
    const juce::String prefs=R"({"roots":["C:/Samples"],"collections":["My kicks"],"favourites":{"C:/Samples/kick.wav":["My kicks"]},"language":"ru"})";
    dir.getChildFile("preferences.json").replaceWithText(prefs);dir.getChildFile("library-v1.json").replaceWithText("{\"version\":1,\"samples\":[]}");dir.getChildFile("splice/downloads.json").replaceWithText("{\"remote-1\":\"missing.wav\"}");
    dir.getChildFile("license.key").replaceWithText("private-fixture");dir.getChildFile("splice/auth.dpapi").replaceWithText("credential-fixture");
    check(atlas::prepareLibraryMigration(dir).wasOk(),"migration");auto backup=dir.getChildFile("migration-v2-backup");auto manifest=backup.getChildFile("manifest.json").loadFileAsString();
    check(backup.getChildFile("preferences.json").loadFileAsString()==prefs&&dir.getChildFile("preferences.json").loadFileAsString()==prefs,"exact original and backup");
    check(juce::JSON::parse(manifest)["legacy_assets"][0]["status"].toString()=="missing","missing assets preserved");
    check(!backup.getChildFile("license.key").exists()&&!backup.getChildFile("splice/auth.dpapi").exists(),"secrets excluded");
    check(atlas::prepareLibraryMigration(dir).wasOk()&&manifest==backup.getChildFile("manifest.json").loadFileAsString(),"idempotent");
    auto replacement=dir.getChildFile("user-selected.wav");replacement.replaceWithText("fixture bytes");check(atlas::locateLegacyAsset(dir,"remote-1",replacement).wasOk(),"explicit locate");auto assets=atlas::legacyAssets(dir);check(assets.size()==1&&!assets[0].missing&&assets[0].originalPath=="missing.wav"&&assets[0].path==replacement.getFullPathName(),"original reference retained after locate");check(atlas::locateLegacyAsset(dir,"unknown",replacement).failed(),"no implicit substitutions");
    backup.getChildFile("preferences.json").replaceWithText("{}");check(atlas::prepareLibraryMigration(dir).failed(),"backup corruption fails closed");
    auto bad=dir.getSiblingFile(juce::Uuid().toString());bad.createDirectory();bad.getChildFile("preferences.json").replaceWithText("broken");check(atlas::prepareLibraryMigration(bad).failed()&&!bad.getChildFile("migration-v2-backup/manifest.json").exists(),"invalid input must not commit");
    std::cout<<"PASS library migration: exact backup, idempotence, missing assets, secret isolation, corruption rejection\n";return 0;
}catch(const std::exception&e){std::cerr<<e.what()<<"\n";return 1;}}
