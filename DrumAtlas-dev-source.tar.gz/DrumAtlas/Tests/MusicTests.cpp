#include "../Source/MusicCore.h"
#include "../Source/MusicActions.h"
#include <iostream>
#include <stdexcept>
using namespace atlas::music;
void testKnowledge();
static void check(bool condition,const char*message){if(!condition)throw std::runtime_error(message);}
static juce::String json(const Project&p){return juce::JSON::toString(encode(p));}
int main(int argc,char**argv){try{
    testKnowledge();
    check(argc==2,"scratch directory required");juce::File dir(juce::String::fromUTF8(argv[1]));check(dir.createDirectory().wasOk(),"scratch");
    Settings s;auto p=generate(s),same=generate(s);same.id=p.id;
    check(json(p)==json(same),"fixed seed must reproduce MIDI across projects");
    check(validate(p).wasOk()&&p.tracks.size()==9,"golden project");
    for(const auto&t:p.tracks)if(t.role=="Snare")for(const auto&n:t.notes)check(n.tick%3840==1920&&n.microtiming==0,"trap snare anchor");
    auto baseline=json(p);check(save(p,dir.getChildFile("golden.drumatlas")).wasOk(),"save");Project restored;
    check(load(dir.getChildFile("golden.drumatlas"),restored).wasOk()&&json(restored)==baseline,"lossless save reopen");
    auto bad=encode(p);bad.getDynamicObject()->setProperty("schema_version",99);check(decode(bad,restored).failed()&&json(restored)==baseline,"unknown schema must not overwrite project");
    bad=encode(p);bad["tracks"].getArray()->getReference(0)["notes"].getArray()->getReference(0).getDynamicObject()->setProperty("duration",juce::int64(-1));check(decode(bad,restored).failed(),"negative note length rejected");
    p.tracks[0].midiLocked=true;baseline=json(p);check(regenerate(p,p.tracks[0].id,0,2,72).failed()&&json(p)==baseline,"MIDI lock");
    auto before=p;check(regenerate(p,p.tracks[3].id,1,3,72).wasOk(),"scoped regenerate");
    for(size_t i=0;i<p.tracks.size();++i)if(i!=3){Project a=p,b=p;a.tracks={p.tracks[i]};b.tracks={before.tracks[i]};check(json(a)==json(b),"unrelated tracks unchanged");}
    for(const auto&n:before.tracks[3].notes)if(n.tick<3840||n.tick>=11520){auto it=std::find_if(p.tracks[3].notes.begin(),p.tracks[3].notes.end(),[&](const Note&v){return v.id==n.id&&v.tick==n.tick&&v.velocity==n.velocity;});check(it!=p.tracks[3].notes.end(),"outside bars unchanged");}
    History history(before);check(history.apply(p).wasOk()&&history.undo()&&json(history.project())==json(before)&&history.redo()&&json(history.project())==json(p),"undo redo exact");
    check(exportMidi(p,dir.getChildFile("golden.mid")).wasOk(),"SMF export");juce::FileInputStream in(dir.getChildFile("golden.mid"));juce::MidiFile midi;check(midi.readFrom(in)&&midi.getTimeFormat()==960&&midi.getNumTracks()==10,"SMF1 tracks/PPQ roundtrip");
    int count=0;for(int t=1;t<midi.getNumTracks();++t){auto*seq=midi.getTrack(t);for(int i=0;i<seq->getNumEvents();++i)if(seq->getEventPointer(i)->message.isNoteOn())++count;}int expected=0;for(auto&t:p.tracks)expected+=int(t.notes.size());check(count==expected,"MIDI note count");
    for(int bars:{1,2,4,8,16,64}){s.bars=bars;for(int numerator:{3,4,6}){s.numerator=numerator;for(int denominator:{4,8}){s.denominator=denominator;check(validate(generate(s)).wasOk(),"meter and bounds matrix");}}}
    s.genre="Unknown artist";Project invalid;check(generateStyled(s,ProfileRegistry::builtIn(),{{s.genre,1}},{{"Dark",1}},invalid).failed(),"unknown profile must not be fabricated");
    auto registry=ProfileRegistry::builtIn();s=Settings{};
    for(const auto&g:registry.genres())for(const auto&m:registry.moods()){
        Project a,b;check(generateStyled(s,registry,{{g.id,1}},{{m.id,1}},a).wasOk(),"profile MIDI valid");
        check(generateStyled(s,registry,{{g.id,1}},{{m.id,1}},b).wasOk(),"profile repeated");b.id=a.id;check(json(a)==json(b),"profile seed deterministic");
        Project reopened;check(decode(encode(a),reopened).wasOk()&&json(a)==json(reopened),"profile snapshot roundtrip");
    }
    Project styled;check(generateStyled(s,registry,{{"House",1}},{{"Warm",1}},styled).wasOk(),"House generate");
    auto originalStyled=json(styled);check(regenerate(styled,styled.tracks[0].id,0,1,42).wasOk(),"snapshot regeneration");
    auto broken=encode(styled);broken["style_snapshot"].getDynamicObject()->setProperty("registry",juce::var());Project kept=styled;check(decode(broken,kept).failed()&&json(kept)==json(styled),"damaged style snapshot rejected atomically");
    auto saved=encode(styled);auto savedText=json(styled);saved["style_snapshot"].getDynamicObject()->setProperty("registry",juce::var());check(json(styled)==savedText,"encoded snapshots do not alias live project");
    auto oldRegistry=registry.encode();auto updated=oldRegistry.clone();updated["genres"].getArray()->getReference(12)["kick"].getArray()->set(0,0.0);check(registry.decode(updated).wasOk(),"update profiles externally");
    auto first=styled,second=styled;check(regenerate(first,first.tracks[0].id,0,1,90).wasOk()&&regenerate(second,second.tracks[0].id,0,1,90).wasOk(),"regenerate persisted style");
    for(size_t i=0;i<first.tracks[0].notes.size();++i)check(first.tracks[0].notes[i].tick==second.tracks[0].notes[i].tick,"registry update does not mutate snapshot rhythm");
    for(int grid:{12,16,24,32,48,64}){s=Settings{};int64_t previous=-1;for(int step=0;step<=grid;++step){auto tick=gridTick(s,0,step,grid);check(tick>previous,"grid is monotonic");previous=tick;}check(previous==barTicks(s),"grid ends exactly at bar boundary");}
    auto edited=generate(Settings{});auto note=edited.tracks[0].notes[0];note.pitch=40;note.velocity=17;note.duration=600;check(editNote(edited,edited.tracks[0].id,note).wasOk(),"edit pitch duration velocity");auto editBefore=json(edited);note.duration=-1;check(editNote(edited,edited.tracks[0].id,note).failed()&&json(edited)==editBefore,"invalid edit atomic");
    edited.tracks[0].midiLocked=true;editBefore=json(edited);check(removeNote(edited,edited.tracks[0].id,note.id).failed()&&copyBars(edited,edited.tracks[0].id,0,1,1).failed()&&json(edited)==editBefore,"locked delete and copy rejected");edited.tracks[0].midiLocked=false;
    auto source=edited.tracks[0].notes;check(copyBars(edited,edited.tracks[0].id,0,1,1).wasOk(),"copy bar");for(auto&n:source)if(n.tick<3840){bool exists=false;for(auto&copy:edited.tracks[0].notes)if(copy.tick==n.tick+3840&&copy.pitch==n.pitch&&copy.velocity==n.velocity&&copy.id!=n.id)exists=true;check(exists,"copied notes retain values with unique IDs");}
    check(removeNote(edited,edited.tracks[0].id,note.id).wasOk(),"delete note");
    auto actionBase=generate(Settings{});History actionHistory(actionBase);juce::var command;ActionPreview proposal;
    check(parseLocalCommand(actionBase,"tempo 130",command).wasOk()&&previewAction(actionBase,command,proposal).wasOk(),"local command dry run");check(json(actionHistory.project())==json(actionBase),"dry run never mutates");check(applyAction(actionHistory,proposal).wasOk()&&actionHistory.project().settings.bpm==130,"apply validated action");check(applyAction(actionHistory,proposal).failed(),"reject stale action");check(actionHistory.undo()&&json(actionHistory.project())==json(actionBase),"action undo exact");
    check(parseLocalCommand(actionBase,"regenerate Closed Hat bars 1-2 seed 42",command).wasOk()&&previewAction(actionBase,command,proposal).wasOk()&&applyAction(actionHistory,proposal).wasOk(),"scoped regeneration action");actionHistory.undo();
    check(parseLocalCommand(actionBase,"transpose Bass -12",command).wasOk()&&previewAction(actionBase,command,proposal).wasOk(),"transpose preview");proposal.project.tracks[0].notes[0].velocity=1;check(applyAction(actionHistory,proposal).failed(),"tampered preview rejected");
    actionBase.tracks[0].midiLocked=true;check(parseLocalCommand(actionBase,"velocity Kick 90",command).failed(),"command cannot bypass lock");check(parseLocalCommand(actionBase,"download https://example.com/model",command).failed(),"unrecognised external command rejected");
    std::cout<<"PASS music-core: deterministic generation, anchors, scoped locks, schema, persistence, undo/redo, SMF1, meter bounds\n";return 0;
}catch(const std::exception&e){std::cerr<<"FAIL "<<e.what()<<"\n";return 1;}}
