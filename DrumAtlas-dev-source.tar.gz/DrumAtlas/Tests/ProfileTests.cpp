#include "../Source/MusicProfiles.h"
#include <iostream>
#include <limits>
#include <stdexcept>
using namespace atlas::music;
void check(bool c,const char*m){if(!c)throw std::runtime_error(m);}
int main(int argc,char**argv){try{
    check(argc==2,"registry path required");ProfileRegistry r;check(r.load(juce::File(juce::String::fromUTF8(argv[1]))).wasOk(),"load external registry");
    check(r.genres().size()==23&&r.moods().size()==19,"all initial profiles present");auto original=juce::JSON::toString(r.encode());
    for(const auto&g:r.genres())for(const auto&m:r.moods()){StyleBlend b;check(r.blend({{g.id,100}},{{m.id,100}},b).wasOk(),"every genre/mood pair");check(b.genre.id==g.id&&b.mood.id==m.id&&b.genres[0].weight==1,"single profile identity");for(size_t i=0;i<16;++i)check(b.genre.kick[i]==g.kick[i]&&b.genre.snare[i]==g.snare[i],"single profile patterns exact");}
    StyleBlend b,c;check(r.blend({{"Trap",25},{"House",75}},{{"Dark",1},{"Warm",1}},b).wasOk(),"blend");
    check(b.genre.id=="House"&&b.mood.id=="Dark"&&b.genre.bpmMin==120&&b.genre.bpmMax==130,"dominant, tie and intersection policy");
    check(b.genre.kick[4]==.75&&b.genre.kick[6]==.25,"weighted pattern distribution");
    check(r.blend({{"House",50},{"Trap",25},{"House",25}},{{"Warm",1},{"Dark",1}},c).wasOk()&&c.genre.kick==b.genre.kick&&c.mood.id==b.mood.id,"ordering and duplicate merge deterministic");
    check(r.blend({{"DnB",60},{"Lo-Fi",40}},{{"Dark",1}},b).wasOk()&&b.genre.bpmMin==160&&b.notices.size()==2,"incompatible BPM explicit fallback");
    auto before=b.genre.id;check(r.blend({{"Unknown",1}},{{"Dark",1}},b).failed()&&b.genre.id==before,"unknown profile fails atomically");
    check(r.blend({{"Trap",0}},{{"Dark",1}},b).failed(),"zero weights rejected");
    check(r.blend({{"Trap",std::numeric_limits<double>::quiet_NaN()}},{{"Dark",1}},b).failed(),"NaN rejected");
    auto v=r.encode();v.getDynamicObject()->setProperty("schema_version",2);check(r.decode(v).failed()&&juce::JSON::toString(r.encode())==original,"future schema atomic");
    v=r.encode();v["genres"].getArray()->getReference(0).getDynamicObject()->setProperty("bpm_min",301);check(r.decode(v).failed()&&juce::JSON::toString(r.encode())==original,"corrupt profile atomic");
    v=r.encode();v["genres"].getArray()->getReference(1).getDynamicObject()->setProperty("id",r.genres()[0].id);check(r.decode(v).failed(),"duplicate IDs rejected");
    ProfileRegistry restored;check(restored.decode(r.encode()).wasOk()&&juce::JSON::toString(restored.encode())==original,"lossless registry roundtrip");
    std::cout<<"PASS profiles: 437 pairs, weighted blends, conflicts, schema validation, atomic load\n";return 0;
}catch(const std::exception&e){std::cerr<<"FAIL "<<e.what()<<"\n";return 1;}}
