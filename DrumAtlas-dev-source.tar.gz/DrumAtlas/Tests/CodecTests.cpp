#define NOMINMAX
#include "../Source/Analysis.h"
#include <windows.h>
#include <mfapi.h>
#include <mfidl.h>
#include <mfreadwrite.h>
#include <wrl/client.h>
#include <iostream>
#include <stdexcept>
using Microsoft::WRL::ComPtr;
static void ok(HRESULT hr){if(FAILED(hr))throw std::runtime_error("Media Foundation fixture failure: "+std::to_string(unsigned(hr)));}
int main(){try{
 auto folder=juce::File::getCurrentWorkingDirectory().getChildFile("codec-fixtures-"+juce::Uuid().toString());folder.createDirectory();auto aac=folder.getChildFile("AAC sample.m4a");
 ok(CoInitializeEx(nullptr,COINIT_MULTITHREADED));ok(MFStartup(MF_VERSION));
 {
 ComPtr<IMFSinkWriter>writer;ok(MFCreateSinkWriterFromURL(aac.getFullPathName().toWideCharPointer(),nullptr,nullptr,&writer));
 ComPtr<IMFMediaType>out,in;ok(MFCreateMediaType(&out));ok(out->SetGUID(MF_MT_MAJOR_TYPE,MFMediaType_Audio));ok(out->SetGUID(MF_MT_SUBTYPE,MFAudioFormat_AAC));
 ok(out->SetUINT32(MF_MT_AUDIO_NUM_CHANNELS,2));ok(out->SetUINT32(MF_MT_AUDIO_SAMPLES_PER_SECOND,44100));ok(out->SetUINT32(MF_MT_AUDIO_BITS_PER_SAMPLE,16));ok(out->SetUINT32(MF_MT_AUDIO_AVG_BYTES_PER_SECOND,16000));
 DWORD stream=0;ok(writer->AddStream(out.Get(),&stream));ok(MFCreateMediaType(&in));ok(in->SetGUID(MF_MT_MAJOR_TYPE,MFMediaType_Audio));ok(in->SetGUID(MF_MT_SUBTYPE,MFAudioFormat_PCM));ok(in->SetUINT32(MF_MT_AUDIO_NUM_CHANNELS,2));ok(in->SetUINT32(MF_MT_AUDIO_SAMPLES_PER_SECOND,44100));ok(in->SetUINT32(MF_MT_AUDIO_BITS_PER_SAMPLE,16));ok(in->SetUINT32(MF_MT_AUDIO_BLOCK_ALIGNMENT,4));ok(in->SetUINT32(MF_MT_AUDIO_AVG_BYTES_PER_SECOND,176400));ok(writer->SetInputMediaType(stream,in.Get(),nullptr));ok(writer->BeginWriting());
 for(int block=0;block<20;++block){constexpr int n=4410;ComPtr<IMFMediaBuffer>buffer;ok(MFCreateMemoryBuffer(n*4,&buffer));BYTE*data=nullptr;ok(buffer->Lock(&data,nullptr,nullptr));auto*pcm=reinterpret_cast<short*>(data);for(int i=0;i<n;++i){pcm[i*2]=short(12000*std::sin(2*juce::MathConstants<double>::pi*440*(i+block*n)/44100));pcm[i*2+1]=pcm[i*2];}ok(buffer->Unlock());ok(buffer->SetCurrentLength(n*4));ComPtr<IMFSample>sample;ok(MFCreateSample(&sample));ok(sample->AddBuffer(buffer.Get()));ok(sample->SetSampleTime(block*1000000LL));ok(sample->SetSampleDuration(1000000));ok(writer->WriteSample(stream,sample.Get()));}
 ok(writer->Finalize());
 }
 juce::AudioFormatManager fm;atlas::registerFormats(fm);auto decoded=atlas::decode(fm,aac);if(decoded.error.isNotEmpty()||atlas::describe(decoded.mono).peak<.05f)throw std::runtime_error("AAC decode failed: "+decoded.error.toStdString());
 auto middle=atlas::decode(fm,aac,.8,.2),tail=atlas::decode(fm,aac,std::max(0.,decoded.duration-.1),.1);if(middle.error.isNotEmpty()||tail.error.isNotEmpty())throw std::runtime_error("AAC seeking failed");
 auto renamed=folder.getChildFile("wrong extension.wav");aac.copyFileTo(renamed);if(atlas::decode(fm,renamed).error.isNotEmpty())throw std::runtime_error("Content-based AAC fallback failed");
 auto deep=folder;for(int i=0;i<5;++i)deep=deep.getChildFile(juce::String::repeatedString("audio samples ",5)+juce::String(i));if(atlas::ioFile(deep).createDirectory().failed())throw std::runtime_error("Cannot create long path fixture");
 auto deepFile=deep.getChildFile("AAC sample.m4a");if(!aac.copyFileTo(atlas::ioFile(deepFile)))throw std::runtime_error("Cannot copy long path fixture");if(atlas::decode(fm,deepFile).error.isNotEmpty())throw std::runtime_error("Long-path AAC decoding failed");
 if(atlas::catalogFile(atlas::ioFile(deepFile))!=deepFile)throw std::runtime_error("Catalog path roundtrip failed");
 auto bad=folder.getChildFile("broken.wav");bad.replaceWithText("not audio");if(atlas::decode(fm,bad).error.isEmpty())throw std::runtime_error("Corrupt file was accepted");
 std::cout<<"PASS: AAC/M4A, seek, tail, mislabeled AAC, corrupt file rejection\n";return 0;
 }catch(const std::exception&e){std::cerr<<"FAIL: "<<e.what()<<"\n";return 1;}}
