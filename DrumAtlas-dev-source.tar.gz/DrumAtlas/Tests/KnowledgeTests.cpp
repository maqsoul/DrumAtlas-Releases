#include "../Source/ArtistKnowledge.h"
#include <stdexcept>
using namespace atlas::knowledge;
void testKnowledge(){
    auto check=[](bool b,const char*m){if(!b)throw std::runtime_error(m);};Registry r;
    Source s;s.id="own-recording";s.contentHash=juce::String::repeatedString("a",64);s.rightsHolder="Test owner";s.licenceDocument="fixture permission";s.permissions={Use::AnalyzeOnce};s.territories={"KZ"};s.reviewed=true;s.expiresAtMs=2000;
    check(r.addSource(s).wasOk(),"register source");check(r.permitted(s.id,Use::AnalyzeOnce,"KZ",1000),"analysis allowed");check(!r.permitted(s.id,Use::Train,"KZ",1000),"analysis is not training permission");check(!r.permitted(s.id,Use::AnalyzeOnce,"US",1000)&&!r.permitted(s.id,Use::AnalyzeOnce,"KZ",2000),"territory and expiry enforced");
    check(r.registerTraining("illegal",{s.id},"KZ",1000).failed(),"training gate");check(r.find("Unknown Artist")==nullptr,"unknown artist");
    Artist a;a.id="fixture-artist";a.name="Fixture Artist";a.aliases={"Fixture"};a.features={{"tempo","140","manual review",{s.id},.8,1000}};check(r.addArtist(a).wasOk()&&r.find("fixture"),"artist alias/provenance");
    s.id="licensed-training";s.permissions={Use::Train};check(r.addSource(s).wasOk()&&r.registerTraining("dataset-1",{s.id},"KZ",1000).wasOk(),"explicit train grant");
    check(r.revoke(s.id).contains("dataset-1")&&!r.permitted(s.id,Use::Train,"KZ",1000),"revocation tracks affected versions");
    Registry loaded;check(loaded.decode(r.encode()).wasOk()&&loaded.find("Fixture Artist")&&!loaded.permitted(s.id,Use::Train,"KZ",1000),"registry round trip preserves revocation");
    auto bad=r.encode();bad.getDynamicObject()->setProperty("schema_version",2);check(loaded.decode(bad).failed()&&loaded.find("Fixture"),"invalid schema atomic rejection");
}
