// Original test instrument; never installed. Reports a nonzero processing delay
// and a long tail to exercise the same hosting path as commercial VST3s.
#include <juce_audio_processors/juce_audio_processors.h>
#include <cmath>
class RenderInstrument final:public juce::AudioProcessor {
public:
 RenderInstrument():AudioProcessor(BusesProperties().withOutput("Output",juce::AudioChannelSet::stereo(),true)){
  addParameter(gain=new juce::AudioParameterFloat("gain","Gain",0.f,1.f,.25f));setLatencySamples(137);
 }
 const juce::String getName()const override{return "Atlas Render Fixture";}
 void prepareToPlay(double rate,int)override{sampleRate=rate;phase=0;active=false;release=0;cursor=0;std::fill(std::begin(delay),std::end(delay),0.f);}
 void releaseResources()override{}
 bool isBusesLayoutSupported(const BusesLayout&l)const override{return l.getMainOutputChannelSet()==juce::AudioChannelSet::stereo()&&l.getMainInputChannelSet().isDisabled();}
 void processBlock(juce::AudioBuffer<float>&audio,juce::MidiBuffer&midi)override{
  auto iterator=midi.begin();audio.clear();
  for(int i=0;i<audio.getNumSamples();++i){
   while(iterator!=midi.end()&&(*iterator).samplePosition==i){auto message=(*iterator).getMessage();if(message.isNoteOn()){active=true;frequency=juce::MidiMessage::getMidiNoteInHertz(message.getNoteNumber());velocity=message.getFloatVelocity();}else if(message.isNoteOff()){active=false;release=1.;}++iterator;}
   auto value=float(std::sin(phase))*gain->get()*velocity*float(active?1.:release);phase+=juce::MathConstants<double>::twoPi*frequency/sampleRate;release*=std::exp(-8./sampleRate);
   float delayed=delay[cursor];delay[cursor]=value;cursor=(cursor+1)%137;for(int ch=0;ch<audio.getNumChannels();++ch)audio.setSample(ch,i,delayed);
  }
 }
 bool acceptsMidi()const override{return true;}bool producesMidi()const override{return false;}double getTailLengthSeconds()const override{return 3.5;}
 bool hasEditor()const override{return true;}juce::AudioProcessorEditor*createEditor()override{return new juce::GenericAudioProcessorEditor(*this);}
 int getNumPrograms()override{return 1;}int getCurrentProgram()override{return 0;}void setCurrentProgram(int)override{}const juce::String getProgramName(int)override{return "Test";}void changeProgramName(int,const juce::String&)override{}
 void getStateInformation(juce::MemoryBlock&state)override{float value=gain->get();state.replaceAll(&value,sizeof(value));}
 void setStateInformation(const void*data,int bytes)override{if(bytes==sizeof(float)){float value;std::memcpy(&value,data,sizeof(value));if(std::isfinite(value))*gain=value;}}
private:
 juce::AudioParameterFloat*gain=nullptr;double sampleRate=44100,phase=0,frequency=261.625565,release=0;float velocity=1,delay[137]{};int cursor=0;bool active=false;
};
juce::AudioProcessor*JUCE_CALLTYPE createPluginFilter(){return new RenderInstrument;}
