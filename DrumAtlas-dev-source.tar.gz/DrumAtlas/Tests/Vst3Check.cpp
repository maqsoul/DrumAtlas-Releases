#include <windows.h>
#include <pluginterfaces/base/ipluginbase.h>
#include <pluginterfaces/vst/ivstaudioprocessor.h>
#include <iostream>
#include <cstring>
#include <cmath>

int wmain(int argc, wchar_t** argv) {
    using namespace Steinberg;
    using namespace Steinberg::Vst;
    if (argc != 2) return 2;
    HMODULE module = LoadLibraryW(argv[1]);
    if (!module) { std::cerr << "LoadLibrary failed: " << GetLastError() << '\n'; return 1; }
    auto init = reinterpret_cast<bool(*)()>(GetProcAddress(module, "InitDll"));
    auto exit = reinterpret_cast<bool(*)()>(GetProcAddress(module, "ExitDll"));
    auto getFactory = reinterpret_cast<IPluginFactory*(*)()>(GetProcAddress(module, "GetPluginFactory"));
    if (!init || !exit || !getFactory || !init()) { std::cerr << "Missing VST3 entry points\n"; return 1; }
    IPluginFactory* factory = getFactory(); IComponent* component = nullptr;
    for (int i = 0; i < factory->countClasses(); ++i) {
        PClassInfo info{}; factory->getClassInfo(i, &info);
        if (std::strcmp(info.category, kVstAudioEffectClass) == 0) {
            factory->createInstance(info.cid, INLINE_UID_OF(IComponent), reinterpret_cast<void**>(&component)); break;
        }
    }
    if (!component || component->initialize(nullptr) != kResultOk) { std::cerr << "Component creation/initialization failed\n"; return 1; }
    IAudioProcessor* audio = nullptr;
    component->queryInterface(INLINE_UID_OF(IAudioProcessor), reinterpret_cast<void**>(&audio));
    if (!audio) { std::cerr << "No audio processor\n"; return 1; }
    bool ok = component->getBusCount(kAudio, kOutput) == 1;
    ProcessSetup setup{}; setup.processMode = kRealtime; setup.symbolicSampleSize = kSample32;
    setup.maxSamplesPerBlock = 512; setup.sampleRate = 48000;
    ok &= audio->setupProcessing(setup) == kResultOk;
    component->activateBus(kAudio, kInput, 0, true); component->activateBus(kAudio, kOutput, 0, true);
    ok &= component->setActive(true) == kResultOk; audio->setProcessing(true);
    float inL[512], inR[512], outL[512]{}, outR[512]{};
    for (int i = 0; i < 512; ++i) { inL[i] = 0.125f; inR[i] = -0.0625f; }
    float* inputs[]{inL, inR}; float* outputs[]{outL, outR};
    AudioBusBuffers in{}, out{}; in.numChannels = 2; out.numChannels = 2;
    in.channelBuffers32 = inputs; out.channelBuffers32 = outputs;
    ProcessData data{}; data.processMode = kRealtime; data.symbolicSampleSize = kSample32;
    data.numSamples = 512; data.numInputs = 1; data.numOutputs = 1; data.inputs = &in; data.outputs = &out;
    ok &= audio->process(data) == kResultOk;
    ok &= std::abs(outL[100] - 0.125f) < 1e-6f && std::abs(outR[100] + 0.0625f) < 1e-6f;
    audio->setProcessing(false); component->setActive(false); audio->release();
    component->terminate(); component->release(); factory->release(); exit(); FreeLibrary(module);
    std::cout << (ok ? "PASS" : "FAIL") << ": VST3 DLL load, factory, component initialization, bus setup and stereo processing\n";
    return ok ? 0 : 1;
}
