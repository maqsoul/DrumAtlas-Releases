#include "../Source/AudioEdit.h"
#include "../Source/License.h"
#include "../Source/Updates.h"
#include "../Source/MusicRender.h"
#include <iostream>
namespace atlas { struct UpdateDownloadProbe {static bool fetch(Updates&u,const juce::String&url,juce::MemoryBlock&body,juce::int64 limit,const juce::File&file={}){return u.fetch(url,body,limit,file);}}; }
static void require(bool b,const char*m){if(!b)throw std::runtime_error(m);}
int main(int argc,char**argv){try{
 if(argc==3&&juce::String(argv[1])=="--download-release"){
  auto cache=juce::SystemStats::getEnvironmentVariable("DRUMATLAS_CACHE_DIR",{});require(cache.isNotEmpty(),"Set isolated cache");juce::File folder(cache);folder.createDirectory();atlas::Updates updates;juce::MemoryBlock body;
  require(atlas::UpdateDownloadProbe::fetch(updates,juce::String::fromUTF8(argv[2]),body,131072),"Feed HTTPS request failed");atlas::UpdateRelease release;
  require(atlas::parseUpdate(body.toString(),"windows-x64","0.0.0",release),"Public feed signature rejected");auto file=folder.getChildFile("verified-update.exe");
  require(atlas::UpdateDownloadProbe::fetch(updates,release.url,body,release.bytes,file),"Native installer download failed");require(atlas::verifyUpdateFile(file,release),"Downloaded installer integrity failed");std::cout<<"PASS: public signed feed, native HTTPS/CDN download, size and SHA256\n";return 0;
 }
 if(argc==3&&juce::String(argv[1])=="--activate"){require(juce::SystemStats::getEnvironmentVariable("DRUMATLAS_CACHE_DIR",{}).isNotEmpty(),"Activation test requires an isolated cache directory");auto result=atlas::activateLicense(juce::File(juce::String::fromUTF8(argv[2])).loadFileAsString());require(result.wasOk(),result.getErrorMessage().toRawUTF8());require(atlas::licensed(),"Activated license was not saved or accepted");std::cout<<"PASS: native HTTPS serial activation and saved offline license\n";return 0;}
 if(argc==3&&juce::String(argv[1])=="--updates"){auto cases=juce::JSON::parse(juce::File(juce::String::fromUTF8(argv[2])).loadFileAsString());require(cases.isArray(),"Missing update test fixtures");int count=0;for(const auto&c:*cases.getArray()){atlas::UpdateRelease release;bool accepted=atlas::parseUpdate(c.getProperty("envelope",{}).toString(),c.getProperty("platform",{}).toString(),c.getProperty("current",{}).toString(),release);require(accepted==bool(c.getProperty("expected",false)),c.getProperty("name",{}).toString().toRawUTF8());++count;}std::cout<<"PASS: "<<count<<" signed-update validation cases\n";return 0;}
 if(argc==3&&juce::String(argv[1])=="--machine"){require(juce::File(juce::String::fromUTF8(argv[2])).replaceWithText(atlas::machineCode()),"Machine code save failed");return 0;}
 if(argc==3&&juce::String(argv[1])=="--license"){auto code=juce::File(juce::String::fromUTF8(argv[2])).loadFileAsString();require(atlas::verifyLicense(code,atlas::machineCode()),"Signed license rejected");require(!atlas::verifyLicense(code,"DA-PC-different-computer"),"License accepted on another computer");require(!atlas::verifyLicense(code+"tamper",atlas::machineCode()),"Tampered license accepted");std::cout<<"PASS: signature, machine binding, tamper rejection\n";return 0;}
 require(atlas::allowedUpdateRedirect("https://github.com/maqsoul/DrumAtlas-Releases/releases/download/v1/file.exe","https://release-assets.githubusercontent.com/github-production-release-asset/file?token=abc"),"GitHub release CDN redirect rejected");
 require(atlas::allowedUpdateRedirect("https://example.com/a","https://example.com/b"),"Same HTTPS host rejected");
 for(auto bad:{"http://release-assets.githubusercontent.com/a","https://evil.example/a","https://github.com.evil.example/a","https://user@github.com/a","https://github.com:8443/a","https://github.com/a#fragment"})require(!atlas::allowedUpdateRedirect("https://github.com/a",bad),"Unsafe update redirect accepted");
 require(argc==2,"Pass scratch directory");auto folder=juce::File(juce::String::fromUTF8(argv[1]));folder.createDirectory();auto source=folder.getChildFile("source.wav");constexpr int rate=44100,frames=rate*3;
 {auto file=folder.getChildFile("update-integrity.fixture");file.replaceWithText("verified-update");atlas::UpdateRelease release;release.bytes=file.getSize();juce::FileInputStream input(file);release.sha256=juce::SHA256(input).toHexString();require(atlas::verifyUpdateFile(file,release),"Valid update rejected");release.sha256=juce::String::repeatedString("0",64);require(!atlas::verifyUpdateFile(file,release),"Corrupt update accepted");--release.bytes;require(!atlas::verifyUpdateFile(file,release),"Wrong-size update accepted");}
 {std::unique_ptr<juce::OutputStream>stream=source.createOutputStream();stream->setPosition(0);juce::WavAudioFormat wav;auto writer=wav.createWriterFor(stream,juce::AudioFormatWriterOptions{}.withSampleRate(rate).withNumChannels(2).withBitsPerSample(32).withSampleFormat(juce::AudioFormatWriterOptions::SampleFormat::floatingPoint));require(bool(writer),"Fixture writer");juce::AudioBuffer<float>audio(2,frames);for(int i=0;i<frames;++i){float v=float(.25*std::sin(2*juce::MathConstants<double>::pi*440*i/rate));audio.setSample(0,i,v);audio.setSample(1,i,-v);}require(writer->writeFromAudioSampleBuffer(audio,0,frames),"Fixture write");}
 auto verify=[&](const juce::File&file,double duration,double hz){juce::AudioFormatManager fm;atlas::registerFormats(fm);std::unique_ptr<juce::AudioFormatReader>r(fm.createReaderFor(file));require(r&&r->numChannels==2&&r->sampleRate==rate,"Stereo/sample rate changed");require(std::abs(r->lengthInSamples-duration*rate)<=1,"Rendered length incorrect");juce::AudioBuffer<float>audio(2,rate);require(r->read(&audio,0,rate,rate,true,true),"Rendered read failed");int crossings=0;double stereoError=0,energy=0;for(int i=1;i<rate;++i){float v=audio.getSample(0,i);require(std::isfinite(v)&&std::abs(v)<1,"Non-finite/clipped render");crossings+=v>=0&&audio.getSample(0,i-1)<0;stereoError+=std::abs(v+audio.getSample(1,i));energy+=std::abs(v);}require(std::abs(crossings-hz)<hz*.03,"Pitch not preserved/shifted correctly");require(stereoError/std::max(energy,1e-6)<.1,"Stereo phase coherence lost");};
 auto pitch=atlas::renderAudioEdit({source,12,0,0},folder);verify(pitch,3,880);
 {
  auto project=atlas::music::generate(atlas::music::Settings{});auto beat=folder.getChildFile("quick-beat.wav");
  require(atlas::music::renderWav(project,beat).wasOk(),"Beat render failed");
  juce::AudioFormatManager fm;atlas::registerFormats(fm);std::unique_ptr<juce::AudioFormatReader>reader(fm.createReaderFor(beat));require(reader&&reader->numChannels==2&&reader->sampleRate==44100&&reader->bitsPerSample==24,"Beat format");
  juce::AudioBuffer<float>audio(2,int(reader->lengthInSamples));require(reader->read(&audio,0,audio.getNumSamples(),0,true,true),"Beat audio read");require(audio.getMagnitude(0,audio.getNumSamples())>.01f&&audio.getMagnitude(0,audio.getNumSamples())<=.96f,"Beat audible and unclipped");
  reader.reset();juce::MemoryBlock originalBytes;require(beat.loadFileAsData(originalBytes),"Read original WAV");
  auto invalidParent=folder.getChildFile("not-a-directory.fixture");require(invalidParent.replaceWithText("keep"),"Write parent fixture");require(atlas::music::renderWav(project,invalidParent.getChildFile("output.wav")).failed()&&invalidParent.loadFileAsString()=="keep","Invalid output path fails without damaging parent");
  require(atlas::music::renderWav(project,beat,123).failed(),"Invalid sample rate preserves existing WAV");
  auto before=beat.getSize();require(atlas::music::renderWav(project,beat,44100,[]{return true;}).failed()&&beat.getSize()==before,"Cancelled beat preserves existing file");
  juce::MemoryBlock afterCancel;require(beat.loadFileAsData(afterCancel)&&afterCancel==originalBytes,"Failed and cancelled writes preserve exact WAV bytes");
  auto longProject=project;longProject.settings.bars=64;longProject.settings.bpm=120;for(auto&t:longProject.tracks)t.notes.clear();auto last=project.tracks.front().notes.front();last.tick=atlas::music::barTicks(longProject.settings)*63+atlas::music::ppq*3;last.duration=atlas::music::ppq/2;last.microtiming=0;last.probability=1;longProject.tracks.front().notes.push_back(last);
  auto longWav=folder.getChildFile("long-beat.wav");require(atlas::music::renderWav(longProject,longWav).wasOk(),"Export longer than 120 seconds");
  std::unique_ptr<juce::AudioFormatReader>longReader(fm.createReaderFor(longWav));require(longReader&&longReader->lengthInSamples==130LL*44100,"Exact 128 second song plus two second tail");juce::AudioBuffer<float>late(2,44100);require(longReader->read(&late,0,44100,127LL*44100,true,true)&&late.getMagnitude(0,44100)>.01f,"Final bar survives streamed export");longReader.reset();
  juce::FileInputStream firstRender(longWav);auto firstHash=juce::SHA256(firstRender).toHexString();auto repeated=folder.getChildFile("long-beat-repeat.wav");require(atlas::music::renderWav(longProject,repeated).wasOk(),"Repeat streamed export");juce::FileInputStream secondRender(repeated);require(juce::SHA256(secondRender).toHexString()==firstHash,"Streaming render deterministic");
  int calls=0;const int peakBlocks=int(std::ceil(130.*44100/4096));require(atlas::music::renderWav(longProject,beat,44100,[&]{return ++calls>peakBlocks+int(longProject.tracks.size())+5;}).failed(),"Cancel during output pass");juce::MemoryBlock afterWriteCancel;require(beat.loadFileAsData(afterWriteCancel)&&afterWriteCancel==originalBytes,"Mid-write cancellation preserves original bytes");
  auto stemProject=atlas::music::generate(atlas::music::Settings{});stemProject.tracks.front().soundPath=source.getFullPathName();
  for(auto&t:stemProject.tracks)for(auto&n:t.notes)n.probability=.65;
  const auto originalProject=juce::JSON::toString(atlas::music::encode(stemProject));
  for(auto options:{atlas::music::StemExportOptions{44100,24,false},atlas::music::StemExportOptions{48000,16,true},atlas::music::StemExportOptions{96000,24,false}}){
    auto bundle=folder.getChildFile("stems-"+juce::Uuid().toString());require(atlas::music::renderStems(stemProject,bundle,options).wasOk(),"Stem export succeeds");
    auto manifest=juce::JSON::parse(bundle.getChildFile("manifest.json"));auto*outputs=manifest["outputs"].getArray();require(outputs&&outputs->size()==(options.perTrack?10:5),"Manifest lists mix and expected stems");
    require(manifest["sources"].size()==1&&manifest["sources"][0]["path"].toString()==source.getFullPathName(),"Manifest source provenance");
    juce::FileInputStream srcHash(source);require(manifest["sources"][0]["sha256"].toString()==juce::SHA256(srcHash).toHexString(),"Manifest source checksum");
    const int count=int(juce::int64(manifest["frames"]));juce::AudioBuffer<float>sum(2,count),master(2,count);sum.clear();
    for(auto&entry:*outputs){auto file=bundle.getChildFile(entry["file"].toString());juce::FileInputStream input(file);require(juce::SHA256(input).toHexString()==entry["sha256"].toString(),"Output checksum matches manifest");
      std::unique_ptr<juce::AudioFormatReader>r(fm.createReaderFor(file));require(r&&r->sampleRate==options.sampleRate&&r->bitsPerSample==options.bits&&r->numChannels==2&&r->lengthInSamples==count,"Every stem has selected format and exact aligned duration");
      juce::AudioBuffer<float>part(2,count);require(r->read(&part,0,count,0,true,true),"Read stem");
      require(part.getMagnitude(0,count)<=.951f,"Stem peak is safe");
      if(entry["file"].toString()=="Mix.wav")master.makeCopyOf(part);else for(int ch=0;ch<2;++ch)sum.addFrom(ch,0,part,ch,0,count);
    }
    for(int ch=0;ch<2;++ch)sum.addFrom(ch,0,master,ch,0,count,-1.f);
    require(sum.getMagnitude(0,count)<(options.bits==16?.0004f:.000004f),"Stems sum to mix within PCM quantization tolerance, preserving probability and noise seed");
    auto beforeManifest=bundle.getChildFile("manifest.json").loadFileAsString();require(atlas::music::renderStems(stemProject,bundle,options).failed()&&bundle.getChildFile("manifest.json").loadFileAsString()==beforeManifest,"Existing export is never overwritten");
  }
  require(juce::JSON::toString(atlas::music::encode(stemProject))==originalProject,"Stem export does not mutate song");
  // A near-silent mix may conceal overloaded opposite-phase stems.
  auto inverse=folder.getChildFile("inverse.wav");
  {juce::WavAudioFormat wav;auto out=inverse.createOutputStream();std::unique_ptr<juce::AudioFormatWriter>w(wav.createWriterFor(out.release(),rate,2,24,{},0));require(bool(w),"Inverse fixture writer");juce::AudioBuffer<float>a(2,frames);for(int i=0;i<frames;++i)for(int ch=0;ch<2;++ch)a.setSample(ch,i,float((ch==0?-.25:.25)*std::sin(2*juce::MathConstants<double>::pi*440*i/rate)));require(w->writeFromAudioSampleBuffer(a,0,frames),"Inverse fixture write");}
  auto phaseProject=stemProject;phaseProject.settings.bars=1;phaseProject.tracks.resize(2);
  for(size_t i=0;i<2;++i){auto&t=phaseProject.tracks[i];t.soundPath=(i==0?source:inverse).getFullPathName();t.notes.clear();for(int n=0;n<20;++n){atlas::music::Note note;note.id=t.id+"-"+juce::String(n);note.channel=10;note.velocity=127;note.tick=0;t.notes.push_back(note);}}
  auto phaseBundle=folder.getChildFile("phase-stems-"+juce::Uuid().toString());require(atlas::music::renderStems(phaseProject,phaseBundle,{44100,24,true}).wasOk(),"Opposite-phase stem export");
  auto phaseManifest=juce::JSON::parse(phaseBundle.getChildFile("manifest.json"));require(double(phaseManifest["common_gain"])<.9,"Shared gain includes isolated stem peak");
  for(auto&entry:*phaseManifest["outputs"].getArray()){std::unique_ptr<juce::AudioFormatReader>r(fm.createReaderFor(phaseBundle.getChildFile(entry["file"].toString())));require(bool(r),"Read phase stem");juce::AudioBuffer<float>a(2,int(r->lengthInSamples));require(r->read(&a,0,a.getNumSamples(),0,true,true)&&a.getMagnitude(0,a.getNumSamples())<.951f,"No clipped isolated stem");}
  auto cancelledBundle=folder.getChildFile("cancelled-stems-"+juce::Uuid().toString());
  auto stagingBefore=folder.findChildFiles(juce::File::findDirectories,false,".drumatlas-export-*").size();bool cancelledDuringWrite=false;
  require(atlas::music::renderStems(stemProject,cancelledBundle,{},[&]{
    for(const auto&dir:folder.findChildFiles(juce::File::findDirectories,false,".drumatlas-export-*"))
      if(dir.getChildFile("Mix.wav").existsAsFile()){cancelledDuringWrite=true;return true;}
    return false;
  }).failed()&&cancelledDuringWrite&&!cancelledBundle.exists(),"Cancellation during bundle output leaves no partial destination");
  require(folder.findChildFiles(juce::File::findDirectories,false,".drumatlas-export-*").size()==stagingBefore,"Cancelled staging is removed");
  require(atlas::music::renderStems(stemProject,cancelledBundle,{44100,8,false}).failed()&&!cancelledBundle.exists(),"Invalid PCM format rejected");
  project.tracks.front().soundPath=folder.getChildFile("missing-sample.wav").getFullPathName();require(atlas::music::renderWav(project,beat).failed()&&beat.getSize()==before,"Missing assigned sample must not be silently substituted");
  require(atlas::music::renderStems(project,cancelledBundle).failed()&&!cancelledBundle.exists(),"Missing source leaves no incomplete bundle");
 }
 auto tempo=atlas::renderAudioEdit({source,0,120,90},folder);verify(tempo,4,440);
 auto both=atlas::renderAudioEdit({source,-12,120,150},folder);verify(both,2.4,220);
 bool cancelled=false;try{atlas::renderAudioEdit({source,4,0,0},folder,[]{return true;});}catch(...){cancelled=true;}require(cancelled,"Render cancellation failed");
 require(!atlas::verifyLicense("forged",atlas::machineCode()),"Unsigned license accepted");
 std::cout<<"PASS: independent pitch/tempo, exact lengths, stereo coherence, finite samples, cancellation and unsigned-license rejection\n";return 0;
}catch(const std::exception&e){std::cerr<<e.what()<<"\n";return 1;}}
