"""Local MuS3D adapter. Receives aligned stereo WAVs from DrumAtlas, never uploads audio.

The native host supplies a runtime manifest and an isolated job folder. Models and
encoders must already be installed. No network downloads take place in a DAW job.
"""
import argparse
import json
import os
from pathlib import Path
import sys
import time


def save_json(path, value, *, required=True):
    """Publish atomically, tolerating Windows readers without FILE_SHARE_DELETE.

    Progress is advisory: losing an update must never abort audio processing.
    Final results are mandatory and still report persistent filesystem errors.
    """
    temp = path.with_suffix(path.suffix + '.tmp')
    payload = json.dumps(value, ensure_ascii=False)
    deadline = time.monotonic() + (2.0 if required else 0.15)
    try:
        temp.write_text(payload, encoding='utf-8')
        while True:
            try:
                temp.replace(path)
                return True
            except OSError as error:
                remaining = deadline - time.monotonic()
                if getattr(error, 'winerror', None) not in (5, 32, 33) or remaining <= 0:
                    raise
                time.sleep(min(0.02, remaining))
    except OSError:
        if required:
            raise
        return False
    finally:
        try:
            temp.unlink(missing_ok=True)
        except OSError:
            pass


def candidate_anchors(energies, total, window, limit=6):
    """Loudest accompaniment, then coverage across the complete song."""
    if not energies:
        return [0]
    selected = [max(energies, key=lambda row: row[1])[0]]
    for section in range(limit):
        rows = [row for row in energies if section*total/limit <= row[0] < (section+1)*total/limit]
        for pos, energy in sorted(rows, key=lambda row: row[1], reverse=True):
            if energy > 1e-10 and all(abs(pos-old) >= window//2 for old in selected):
                selected.append(pos)
                break
    return selected[:limit+1]


def synth_candidates(embeddings, classifier):
    """Use calibrated multi-label evidence without relabelling arbitrary sounds."""
    probabilities, names = classifier.proba(embeddings, 'track')
    accepted = {'Synth Part': ('synth_lead', 'organ,_electric_organ'), 'Synth Pad': ('synth_pad',)}
    rows = []
    for index, scores in enumerate(probabilities):
        for label, tags in accepted.items():
            for tag in tags:
                if tag not in names:
                    continue
                column = names.index(tag)
                score = float(scores[column])
                if score >= max(.5, float(classifier.thresholds[column])) and score >= float(max(scores))*.85:
                    rows.append((score, label, index, tag))
    return sorted(rows, reverse=True)


def run(job_path, runtime_path):
    job = json.loads(job_path.read_text(encoding='utf-8-sig'))
    runtime = json.loads(runtime_path.read_text(encoding='utf-8-sig'))
    folder = job_path.parent
    if job.get('protocol') != 1 or runtime.get('protocol') != 1:
        raise ValueError('Unsupported synth worker protocol')
    os.environ['HF_HOME'] = runtime['hf_home']
    os.environ['TORCH_HOME'] = runtime['torch_home']
    os.environ['HF_HUB_OFFLINE'] = '1'
    os.environ['TRANSFORMERS_OFFLINE'] = '1'
    os.environ['HF_HUB_DISABLE_TELEMETRY'] = '1'
    sys.path.insert(0, runtime['source_root'])
    import numpy as np
    import soundfile as sf
    import torch
    from classifiers.stem_classifier import StemClassifier
    from source_embedding_generator.separator_io import load_seg, load_separator
    from source_embedding_generator import protocol
    from utils.torch_common import set_seed

    torch.set_num_threads(max(1, min(8, int(runtime.get('threads', 4)))))
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    if device == 'cpu':
        raise RuntimeError('Synth layers currently require a supported NVIDIA CUDA GPU; other stem modes remain available.')
    started = time.perf_counter()
    last_progress = 0.0
    last_phase = None
    def progress(phase, fraction=0):
        nonlocal last_progress, last_phase
        if (folder / 'cancel').exists():
            raise InterruptedError('Cancelled')
        now = time.monotonic()
        if phase == last_phase and now - last_progress < 0.15:
            return
        save_json(folder / 'progress.json', {'phase': phase, 'fraction': fraction}, required=False)
        last_progress, last_phase = time.monotonic(), phase
    progress('loading')
    models = Path(runtime['model_root'])
    seg = load_seg(models / 'SEG_mixemb', device=device, use_ema=False)
    classifier = StemClassifier.load(models / 'classifiers/stem_classifier_pcatrain.pkl')
    classifier.check_basis(seg)
    n, step, rate = 441000, 220500, 44100
    with sf.SoundFile(job['input']) as source, sf.SoundFile(job['vocal']) as vocal:
        if source.samplerate != rate or vocal.samplerate != rate or source.channels != 2 or vocal.channels != 2 or len(source) != len(vocal):
            raise ValueError('Expected aligned stereo input and vocal WAVs at 44100 Hz')
        total = len(source)
        if total <= 0:
            raise ValueError('Empty reference selection')
        # Select a representative accompaniment window, independent of requested
        # class labels. Scan on CPU and keep memory independent of song length.
        energies = []
        for pos in range(0, max(1, total - n + 1), step):
            progress('discovering')
            source.seek(pos); vocal.seek(pos)
            bed = source.read(n, dtype='float32', always_2d=True) - vocal.read(n, dtype='float32', always_2d=True)
            energy = float(np.mean(bed * bed))
            energies.append((pos, energy))
        with torch.inference_mode():
            best = {}; diagnostics = []
            anchors = candidate_anchors(energies, total, n)
            # Search the accompaniment first; the former single raw-mixture
            # window could be dominated by vocals or drums. Keep each source's
            # embedding fixed for the final full-track render (no label swaps).
            for pass_index in range(2):
                for anchor in anchors:
                    progress('discovering')
                    source.seek(anchor); vocal.seek(anchor)
                    query_audio = source.read(n, dtype='float32', always_2d=True)
                    if pass_index == 0:
                        query_audio = query_audio - vocal.read(n, dtype='float32', always_2d=True)
                    query_audio = np.pad(query_audio, ((0, n-len(query_audio)), (0, 0)))
                    set_seed(0)
                    discovery = seg.inference(torch.from_numpy(query_audio.T.copy()[None]).to(device).mean(1, keepdim=True),
                                              level=protocol.LEVEL_TRACK, max_steps=16, steps=32, churn=.1, audio=False)
                    embeddings = np.asarray(discovery['emb'], dtype='float32')
                    candidates = synth_candidates(embeddings, classifier)
                    diagnostics.append({'seconds': anchor/rate, 'clean': pass_index == 0,
                                        'classes': list(classifier.predict(embeddings, 'track')),
                                        'candidates': candidates})
                    used = set()
                    for score, label, index, tag in candidates:
                        if index in used:
                            continue
                        used.add(index)
                        if label not in best or score > best[label][0]:
                            best[label] = (score, embeddings[index].copy(), tag, anchor)
                    if len(best) == 2:
                        break
                if best:
                    break
            save_json(folder/'discovery.json', diagnostics, required=False)
            chosen = [(label, i, best[label][2]) for i, label in enumerate(('Synth Part', 'Synth Pad')) if label in best]
            chosen = [(label, i, tag) for i, (label, _, tag) in enumerate(chosen)]
            if not chosen:
                save_json(folder/'result.json', {'protocol': 1, 'ok': True, 'status': 'no_synth_layers',
                          'frames': total, 'sample_rate': rate, 'stems': []})
                return
            anchor = best[chosen[0][0]][3]
            queries = torch.as_tensor(np.stack([best[label][1] for label, _, _ in chosen]), dtype=torch.float32, device=device)
            del seg, discovery
            torch.cuda.empty_cache()
            sep = load_separator(models / 'BS-Locoformer_query', device=device, use_ema=False)
            level = torch.tensor([protocol.LEVEL_TRACK], dtype=torch.long, device=device)
            window = np.sin(np.pi*(np.arange(n)+.5)/n).astype('float32')**2
            sums = np.zeros((len(chosen), n, 2), dtype='float32')
            weights = np.zeros(n, dtype='float32')
            outputs, writers = [], []
            try:
                for label, _, predicted in chosen:
                    filename = label.replace(' ', '-') + '.wav'
                    writers.append(sf.SoundFile(folder/filename, 'w', samplerate=rate, channels=2, subtype='FLOAT'))
                    outputs.append({'name': label, 'file': filename, 'predicted_class': predicted})
                for pos in range(0, total, step):
                    progress('separating', pos/total)
                    count = min(n, total-pos)
                    source.seek(pos); vocal.seek(pos)
                    clean = source.read(count, dtype='float32', always_2d=True) - vocal.read(count, dtype='float32', always_2d=True)
                    clean = np.pad(clean, ((0, n-count), (0, 0)))
                    mix = torch.from_numpy(clean.T.copy()[None]).to(device)
                    w = window[:count].copy()
                    if pos == 0: w[:step] = 1
                    if count < n: w[max(0, count-step):] = 1
                    for i, (_, index, _) in enumerate(chosen):
                        progress('separating', pos/total)
                        result = sep.sample(queries[index:index+1].unsqueeze(0), mix=mix, query_is_embedding=True, level=level)[0, 0]
                        audio = result.cpu().numpy().T[:count]
                        if not np.isfinite(audio).all():
                            raise ValueError('Non-finite synth model output')
                        sums[i, :count] += audio*w[:, None]
                    weights[:count] += w
                    emit = min(step, total-pos)
                    if not np.all(weights[:emit] > 0):
                        raise ValueError('Incomplete synth overlap coverage')
                    for i, writer in enumerate(writers):
                        writer.write(sums[i, :emit]/weights[:emit, None])
                    sums[:, :n-step] = sums[:, step:]; sums[:, n-step:] = 0
                    weights[:n-step] = weights[step:]; weights[n-step:] = 0
            finally:
                for writer in writers: writer.close()
    progress('complete', 1)
    save_json(folder/'result.json', {'protocol': 1, 'ok': True, 'frames': total, 'sample_rate': rate,
                                  'anchor_seconds': anchor/rate, 'elapsed': time.perf_counter()-started, 'stems': outputs})


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--job', required=True, type=Path)
    parser.add_argument('--runtime', required=True, type=Path)
    args = parser.parse_args()
    # Keep diagnostics off the host pipe, which could otherwise fill during loading.
    with (args.job.parent/'worker.log').open('w', encoding='utf-8') as log:
        sys.stdout = sys.stderr = log
        try:
            run(args.job, args.runtime)
        except Exception as error:
            import traceback
            traceback.print_exc()
            save_json(args.job.parent/'result.json', {'protocol': 1, 'ok': False, 'error': str(error)})
            return 1
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
