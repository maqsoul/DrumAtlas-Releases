#!/bin/bash
set -euo pipefail
: "${DRUMATLAS_BUILD_DIR:?}"
: "${DRUMATLAS_MODEL_DIR:?}"
[[ "$(uname -s)" == Darwin ]]
src="$(cd "$(dirname "$0")/.." && pwd)"
version=1.0.9
stage="$(mktemp -d "${TMPDIR:-/tmp}/drumatlas-current.XXXXXX")"
root="$stage/root"
mkdir -p "$root/Applications" "$root/Library/Audio/Plug-Ins/Components" "$root/Library/Audio/Plug-Ins/VST3"
bundles=("Applications/DrumAtlas.app" "Library/Audio/Plug-Ins/VST3/DrumAtlas.vst3" "Library/Audio/Plug-Ins/Components/DrumAtlas.component")
formats=("Standalone/DrumAtlas.app" "VST3/DrumAtlas.vst3" "AU/DrumAtlas.component")
for i in 0 1 2; do
 ditto "$DRUMATLAS_BUILD_DIR/DrumAtlas_artefacts/Release/${formats[$i]}" "$root/${bundles[$i]}"
 test -f "$root/${bundles[$i]}/Contents/Resources/AppIcon.icns"
done
shared="$root/Library/Application Support/DrumAtlas"
mkdir -p "$shared/Licenses"
ditto "$DRUMATLAS_MODEL_DIR" "$shared/Models"
ditto "$src/Installer/MacAssets/Notices" "$shared/Licenses"
cp "$src/THIRD_PARTY.md" "$shared/Licenses/THIRD_PARTY.md"
python3 "$src/Installer/export-source.py" "$shared/Source/DrumAtlas"
# Seal all copied native dependencies, then each finished bundle. Ad-hoc is
# deliberately distinct from Developer ID signing and notarization.
identity="${DRUMATLAS_APP_IDENTITY:--}"
while IFS= read -r -d '' lib; do codesign --force --sign "$identity" "$lib"; done < <(find "$root" -name '*.dylib' -print0)
for bundle in "${bundles[@]}"; do
 codesign --force --deep --sign "$identity" "$root/$bundle"
 codesign --verify --deep --strict "$root/$bundle"
done
pkgbuild --analyze --root "$root" "$stage/components.plist"
python3 - "$stage/components.plist" <<'PY'
import plistlib,sys
p=sys.argv[1]
with open(p,'rb') as f: rows=plistlib.load(f)
for row in rows:
 row['BundleIsRelocatable']=False
 row['BundleOverwriteAction']='upgrade'
with open(p,'wb') as f: plistlib.dump(rows,f)
PY
pkgbuild --root "$root" --component-plist "$stage/components.plist" --identifier audio.drumatlas.installer --version "$version" --install-location / "$stage/DrumAtlas.pkg"
cat > "$stage/welcome.html" <<'HTML'
<html><body style="background:#fff;color:#241c16;font-family:Helvetica;padding:24px"><h1 style="color:#a94615">DRUMATLAS 1.0.0</h1><p>Standalone, VST3 and AU for Logic Pro. EMBER interface, keyboard shortcuts, sample library, AI stems and Stem to MIDI.</p><p>Core AI model files are included. Optional synth-layer runtime is installed separately; personal runtime paths and credentials are never copied.</p><p>Close DrumAtlas and your DAW before installation. Your library, favourites and activation are preserved.</p><p>This package has no Apple Developer ID signature or notarization.</p></body></html>
HTML
cat > "$stage/Distribution.xml" <<XML
<installer-gui-script minSpecVersion="2">
 <title>DrumAtlas 1.0.0</title><welcome file="welcome.html"/>
 <options customize="never" require-scripts="false" hostArchitectures="$(uname -m)"/>
 <domains enable_localSystem="true" enable_currentUserHome="false"/>
 <choices-outline><line choice="main"/></choices-outline>
 <choice id="main" title="DrumAtlas 1.0.0"><pkg-ref id="audio.drumatlas.installer"/></choice>
 <pkg-ref id="audio.drumatlas.installer" version="$version">DrumAtlas.pkg</pkg-ref>
</installer-gui-script>
XML
output="$DRUMATLAS_BUILD_DIR/DrumAtlas-1.0.0-macOS-$(uname -m)-Setup.pkg"
productbuild --distribution "$stage/Distribution.xml" --resources "$stage" --package-path "$stage" "$output"
pkgutil --expand "$output" "$stage/verified"
test -f "$stage/verified/Distribution"
shasum -a 256 "$output" > "$output.sha256"
echo "Package ready: $output"
